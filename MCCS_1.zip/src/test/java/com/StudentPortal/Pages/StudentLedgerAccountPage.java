package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byXPath;

import java.util.concurrent.TimeUnit;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.DatesUtil;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentLedgerAccountPage extends BasePage{

	static int AmountV = AppendValue.apendNumber();
	static String Date = DatesUtil.getCurrentDatebyFormat("M/dd/yyyy");
	static String Note = AppendValue.apendString();

	static Link LedgerCard = new Link("Leadger card", byXPath("//span[text()='Ledger Card']"));
	static Link StipendSchedule = new Link("Leadger card", byXPath("//span[text()='Stipend Schedule']"));
	//static Link Filtericon = new Link("Filter icon", byXPath("//div[@id='refundFundSourceGrid_cnsToolbar_kendoToolBar_settingsButton_wrapper']//a[1]"));
	static Link Filtericon = new Link("Filter icon", byXPath("//button[@id='transactionGrid_cnsToolbar_kendoToolBar_settingsButton']"));
	static Link ClearFilters= new Link("Clear Filters", byXPath("//li[@id='transactionGrid_cnsToolbar_kendoToolBar_clearFiltersButton']"));
	static AngDropDown BillCodeDrp = new AngDropDown("Transaction Date", byXPath("(//th[6]//span)[1]"));
	static AngDropDown TransactionDate = new AngDropDown("Transaction Date", byXPath("(//th[2]//span)[1]"));
	static AngDropDown Code = new AngDropDown("Code", byXPath("(//th[6]//span)[1]"));
	static Button FilterOptions = new Button("Filter options", byXPath("//span[text()='Filter']"));
	static AngDropDown Operator = new AngDropDown("Operator dropdown", byXPath("(//form/div/span[1]/span/span/span)[2]"));
	static Link SelectingOperator = new Link("Selecting operator", byXPath("//div/div/div//li[. = 'Contains']"));
	static TextField Value = new TextField("Enter filter value", byXPath("//input[@title='Value']"));
	//static TextField Value = new TextField("Enter filter value", byXPath("//form/div/input[1]"));
	static Button Filterbutton = new Button("Filter icon", byXPath("//button/span[text()='Filter']"));
	static Link Tablevalue= new Link("Table value", byXPath("(//tr[1]/td[1])[1]"));
	static Link Highligthing1= new Link("Highlighting record", byXPath("(//tr[1]/td[2])[1]"));
	static Link Highligthing= new Link("Highlighting record", byXPath("//tr[1]/td[2][text()='06/27/2022']"));
	static Link More= new Link("More", byXPath("//span[text()='More']"));
	static Link Void= new Link("Void", byXPath("//span[text()='Void']"));
	static TextField VoidNote = new TextField("Void note", byXPath("(//div/textarea[@aria-label='Note'])[4]"));
	static Button Voidbutton = new Button("Void button", byXPath("//button[@id='okVoidPayment']"));
	static Button Delete = new Button("Delete icon", byXPath("//li[@id='deleteTransactionButton']"));
	static TextField DeleteNote = new TextField("Delete note", byXPath("(//div/textarea[@aria-label='Note'])[1]"));
	static Button Deletebutton = new Button("Delete button", byXPath("//button[@id='okDelete']"));
	static Link SelectingTransaction = new Link("Selecting Student", byXPath("(//td/a)[1]"));
	static Link TermList= new Link("Term list", byXPath("//div[@id='search_display_termId']"));
	static TextField SearchCode = new TextField("Search code", byXPath("//input[@placeholder='Search Code']"));
	static Button SelectButton = new Button("Select button", byXPath("//button[text()='Select']"));
	static Button CancelButton = new Button("Cancel button", byXPath("(//button[text()='Cancel'])[1]"));
	static Checkbox Term = new Checkbox("Selecting Term", byXPath("//tr[1]/td[1]/input[1]"));
	static TextField TransactionAmount = new TextField("Transaction Amount", byXPath("//input[@id='transactionAmount']"));
	static TextField TransactionNote = new TextField("Transaction note", byXPath("(//div/textarea[@aria-label='Note'])[1]"));
	static Button SaveAndClose = new Button("Save & Close", byXPath("(//button[@aria-label='Save & Close'])[2]"));
	static Link TermValue= new Link("Term value", byXPath("//tr[1]/td[12]"));
	static Link PrintLedger = new Link("PrintLedger", byXPath("//*[@id='printLedgerButton']"));
	//static TextField IncludeCourseDetail = new TextField("Include Course Detail", byXPath("//span[@aria-label='Include Course Detail: Dropdown']"));
	static TextField IncludeCourseDetail = new TextField("Include Course Detail", byXPath("//cmc-drop-down-list-classic[@cmc-id='includeCourseDetail']/div/div/span"));
	static Link SelectingIncCorDet= new Link("Selecting Include Course Detail", byXPath("(//li[text()='Yes'])[1]"));
	static Button PrintButton = new Button("Print button", byXPath("(//button[@id='okVoid'])[2]"));
	static Link PrintRegistrationBill = new Link("Print Registration Bill", byXPath("//li[@id='printRegistrationBillButton']"));
	static Button PrintDetail = new Button("Print Detail", byXPath("//button[@id='printRegBillDetail']"));
	static Button PrintSummary = new Button("Print Summary", byXPath("//button[@id='printRegBillSummary']"));
	static Button Cancel = new Button("Cancel", byXPath("(//button[text()='Cancel'])[16]"));
	static Link Printicon = new Link("Print icon", byXPath("//div[6]/table/tbody/tr/td/div/div[1]//span"));
	static Button PrintOK = new Button("Print Ok", byXPath("(//p[text()='Print'])"));
	static Link PDFdownload = new Link("PDF download", byXPath("//a[text()='Click here to view the PDF of your report.']"));
	static Button Done = new Button("Done", byXPath("//p[text()='Done']"));
	static Button ApplyCreditsButton = new Button("Apply credits button", byXPath("//button[text()='Apply Credits']"));
	//static Link TransatcionList = new Link("Transaction List", byXPath("//div/cmc-drop-down-list-classic/div/div/span/span/span[2]/span"));
	//static Link TransatcionList1 = new Link("Transaction List", byXPath("//span[@aria-label='Transaction: Dropdown']"));
	static Link TransatcionList1 = new Link("Transaction List", byXPath("(//span[contains(@aria-label,'Transaction')])[1]"));
	static Link SelectingTransactionlist= new Link("Selecting transaction list", byXPath("//span[text()='Only Credits']"));
	static AngDropDown TranDate = new AngDropDown("TranDate", byXPath("//a[@title='Tran Date edit column settings']"));
	static TextField Value1 = new TextField("Enter filter value1", byXPath("//input[@title='Value'][1]"));
	static Link HighlightingTransaction= new Link("Highlighting transaction", byXPath("(//tr/td[5])[1]"));
	static Link HighlightingCode= new Link("Highlighting Code", byXPath("(//tr/td[6])[1]"));
	static Button ApplyCredit= new Button("Apply credit button", byXPath("//*[@id='applyCredit']"));
	static Checkbox ApplyAmount= new Checkbox("Apply amount", byXPath("//div[@id='cnsAutoApplyGrid_cmcGrid']/div[2]/table/tbody/tr[1]/td[1]/input[1]"));
	static Button ApplyButton= new Button("Apply Button", byXPath("//button[@id='autoApplySaveButton']"));
	//static Button ApplyButton= new Button("Apply Button", byXPath("//button[@id='manualApplySaveButton']"));
	static Button AddCharge= new Button("Add charger", byXPath("//*[@id='newChargeButton']"));
	//static AngDropDown BillCode = new AngDropDown("Bill code", byXPath("//span[@aria-label='Bill Code: Dropdown']"));
	static AngDropDown BillCode = new AngDropDown("Bill code", byXPath("//span[contains(@aria-label,'Bill Code')]"));
	static TextField SearchBillCode = new TextField("Search Bill code", byXPath("//div[@id='billingTransactionCode-list']/span/input"));
	static Link SelectingBillCode= new Link("Selecting Bill Code", byXPath("//span[text()='100COURS']"));
	static TextField Amount = new TextField("Amount", byXPath("(//input[@aria-label='Amount'])[1]"));
	static Button Refunds = new Button("Refunds", byXPath("//button[text()='Refunds']"));
	static AngDropDown FundSource = new AngDropDown("Fund Source", byXPath("//a[@title='Fund Source edit column settings']"));
	static AngDropDown AmountReceived = new AngDropDown("Fund Source", byXPath("(//th[4]//span)"));
	static Link SortDescending= new Link("Sort descending", byXPath("//span[. = 'Sort Descending']"));
	static AngDropDown AmountRefunded = new AngDropDown("Amount Refunded", byXPath("//th[5]/a/span"));
	static Button Next = new Button("Next button", byXPath("//button[text()='Next']"));
	//static Link RefundOption = new Link("Refund option", byXPath("//span[@aria-label='Refund Option: Dropdown']"));
	static Link RefundOption = new Link("Refund option", byXPath("//span[contains(@aria-label,'Refund Option')]"));
	static TextField TermId= new TextField("Term Id", byXPath("//input[@name='termId_input']"));
	static TextField DueDate= new TextField("Due Date", byXPath("//input[@id='dueDate']"));
	static Button PostSchedule = new Button("Post schedule", byXPath("(//button[@aria-label='Post/Schedule'])[2]"));
	static Link NewStipend = new Link("New Stipend", byXPath("//*[@id='newScheduledStipendButton']"));
	static Link FundSourceDrp = new Link("Refund option", byXPath("(//button[@aria-label='expand combobox'])[2]"));
	static TextField SearchFundSource= new TextField("Due Date", byXPath("//input[@aria-controls='fundSourceId_listbox']"));
	//static Link SelectingFundSourceST= new Link("Selecting Term", byXPath("//span[text()='Cash Payment']"));
	static Link ReturnMethod = new Link("Return Method", byXPath("(//button[@aria-label=\"expand combobox\"]/span)[5]"));
	static TextField NetAmount= new TextField("Net Amount", byXPath("(//input[@aria-label='Net Amount'])[1]"));
	static TextField Datescheduled= new TextField("Date scheduled", byXPath("//input[@name='scheduledDate']"));
	static Button ScheduleOk = new Button("Schedule Ok", byXPath("//button[@id='scheduledStipendSaveButton']"));
	static AngDropDown ScheduledDate = new AngDropDown("Scheduled Date", byXPath("//a[@title=\"Scheduled Date edit column settings\"]"));
	static Link HighlightingSchedule= new Link("Highlighting Schedule", byXPath("//td[3]"));
	static TextField SearchReturnMethod= new TextField("Search Return Method", byXPath("//input[@aria-owns='returnMethod_listbox']"));
	//static Link Status = new Link("Status", byXPath("//span[@aria-label='Status: Dropdown']"));
	static Link Status = new Link("Status", byXPath("//span[contains(@aria-label,'Status')]"));
	static Button Save = new Button("Save", byXPath("(//button[@aria-label='Save'])[2]"));
	static Button Override = new Button("Override", byXPath("//button[@id='AwardAmountWindowOkButton']"));
	static Button OverrideCancel = new Button("Override cancel", byXPath("//button[@id='AwardAmountWindowCancelButton']"));
	static Link SelectingReundOption= new Link("Selecting Refund Option", byXPath("//li[text()='Schedule Refund']"));
	static Link SelectingTerm= new Link("Selecting Term", byXPath("//span[text()='2022FAR']"));
	//--------Validation message-----
	static Link UpdatingTransactionMsg= new Link("Updating Ledger Transaction Msg", byXPath("//span[text()='The Transaction records were successfully saved.']"));
	static Link AlreadyVoidedMsg= new Link("Already Voided Msg", byXPath("//span[text()='The transaction cannot be voided because it is already voided.']"));
	static Link UpdatingVoidMsg= new Link("Updating Void Msg", byXPath("//span[text()='The Student Transaction records were successfully voided.']"));
	static Link DeletingTranMsg= new Link("DeletingvTransaction Msg", byXPath("//span[text()='The Student Transaction records were successfully deleted.']"));
	static Link PostingChargeMsg= new Link("Posting Charge Msg", byXPath("//span[text()='The Charge records were successfully saved.']"));
	static Link ApplyCreditMsg= new Link("Apply Credit Msg", byXPath("//span[text()='The Transaction records were successfully saved.']"));
	static Link SchldRefundMsg= new Link("Schedule Refund Msg", byXPath("//span[text()='The Refund records were successfully saved.']"));
	static Link SchlStipendMsg= new Link("Schedule Stipend Msg", byXPath("//span[text()='The Stipend records were successfully saved.']"));
	//
	static Button Filter1 = new Button("Click Filter", byXPath("(//span[.='Filter'])[1]"));
	static TextField SettingsValue = new TextField("Enter value", byXPath("(//input[@title=\"Value\"])[1]"));
	static Button SettingsFilterButton = new Button("Click Settings Filter", byXPath("//button[.=\"Filter\"]"));
	static Link HighlightingFundSource= new Link("Highlighting Fund Source", byXPath("(//tr[1]/td[1])[1]"));
	static Link HighlightingFundSource1= new Link("Highlighting Fund Source", byXPath("//td[6]/span[text()='0.00 ']"));

	//xpath for LedgerReturnedCheck
	static Link Payment = new Link("Add payment", byXPath("//*[@id='newPaymentButton']"));
	static AngDropDown AcademicYr = new AngDropDown("Academic year dropdown", byXPath("(//span[@aria-label='select'])[4]"));
	static Link SelectingAYr = new Link("Selecting Academic year", byXPath("//ul[@id='academicYearSequence_listbox']/li[1]/span/div/span[1]"));
	static AngDropDown PaymentType = new AngDropDown("Payment Type", byXPath("(//span[@aria-label='select'])[3]"));
	static Link SelectingPayType = new Link("Selecting Payment type", byXPath("//span[text()='Cash Payment']"));
	static AngDropDown CashPaymentCode = new AngDropDown("Cash Payment COde", byXPath("(//span[@aria-label='select'])[6]"));
	static Link SelectingPayCode = new Link("Selecting Payment code", byXPath("(//span[text()='Check'])[2]"));
	static TextField CheckNumber = new TextField("Check number", byXPath("//input[@name='checkNumber']"));
	static Link ReturnedCheck = new Link("Retruned Check", byXPath("//a[@id='returnedCheckTransactionButton']"));
	static Button ReturnedCheckOk = new Button("Retruned Check Ok", byXPath("//button[@id='okReturnedCheck']"));
	static TextField ReturnNote = new TextField("Retruned Check Note", byXPath("//textarea[@name='studentTransactionReturnedCheckNote']"));

	public StudentLedgerAccountPage AdjustLedgerTransaction(StringHash data) throws Exception {
		Checkbox Term = new Checkbox("Selecting Term", byXPath("(//tbody/tr[1]/td[1]/input)[1]"));

		//Login Page Web Elements
		//waitForPageToLoad();
		wait(8);
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(2);
		LedgerCard.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(2);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(10);
		//		BillCodeDrp.click();
		//		wait(2);
		//		Filter1.click();
		//		wait(2);
		//		SettingsValue.clearAndType(data.get("BillCode"));
		//		//SettingsValue.clearAndType("Tuition");
		//		wait(2);
		//		Filterbutton.click();
		//		wait(2);
		SelectingTransaction.clickUsingJavaScriptExecutor();
		wait(8);
		TermList.clickUsingJavaScriptExecutor();
		wait(5);
		if(Term.isSelected())
		{
			System.out.println("Term is already selected");
			String SelectedTerm = Term.getAttribute("aria-label");
			System.out.println(SelectedTerm);
			TestReportsLog.log(LogStatus.INFO, "Selected Term is "+SelectedTerm);
			CancelButton.clickUsingJavaScriptExecutor();
		}else {
			Term.click();
			String SelectedTerm = Term.getAttribute("aria-label");
			System.out.println(SelectedTerm);
			TestReportsLog.log(LogStatus.INFO, "Selected Term is "+SelectedTerm);
			wait(2);
			SelectButton.clickUsingJavaScriptExecutor();
		}
		wait(2);
		scrollPage(0, 300);
		TransactionNote.clearAndType(Note);
		wait(2);
		scrollPage(0, -600);
		wait(4);
		SaveAndClose.click();
		wait(5);
		CustomAsserts.containsString(UpdatingTransactionMsg.getText(), data.get("UpdatingTransactionMsg").toString());
		//		String TermName = TermValue.getText();
		//		if(TermName.equalsIgnoreCase(data.get("TermCode")))
		//		{
		//			System.out.println("Changes are reflecting");
		//		}else {
		//			System.out.println("Changes are not reflecting");
		//		}
		wait(2);
		return this;

	}
	public StudentLedgerAccountPage AdjustLedgerTransactionVoid(StringHash data) throws Exception {

		Link AlertMsg= new Link("Capturing alert message", byXPath("//span[@role='status']"));
		Link PaymentMsg= new Link("Payment Msg", byXPath("//span[text()='The Transaction records were successfully saved.']"));
		Link SelectingPayCode = new Link("Selecting Payment code", byXPath("//span[text()='"+data.get("PayCode")+"']"));
		Link BankAccount = new Link("BankAccount", byXPath("//span[@aria-label='Bank Account']"));
		Link BankAccountValue = new Link("BankAccountValue", byXPath("(//ul[@id='bankAccountId_listbox']/li/span/div/span)[1]"));
		//driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
		//Login Page Web Elements
		//waitForPageToLoad();
		//ImplicitlyWait();

		wait(12);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(2);
		LedgerCard.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		Payment.click();
		wait(10);
		PaymentType.click();
		wait(1);
		SelectingPayType.click();
		wait(7);
		//AcademicYr.clickUsingJavaScriptExecutor();
		wait(2);
		//SelectingAYr.clickUsingJavaScriptExecutor();
		wait(2);
		TermList.click();
		wait(5);
		Term.click();
		wait(2);
		SelectButton.click();
		wait(2);
		CashPaymentCode.clickUsingJavaScriptExecutor();
		wait(2);
		SelectingPayCode.click();
		wait(2);
		CheckNumber.sendkeys("234");
		wait(1);
		Amount.sendkeys("10");
		wait(2);
		BankAccount.click();
		wait(2);
		BankAccountValue.click();
		wait(3);
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(4);
		System.out.println("Payment is posted successfully");
		scrollPage(0, 600);
		wait(15);
		Cancel.clickUsingJavaScriptExecutor();
		wait(2);
		//CustomAsserts.containsString(data.get("PaymentMsg"), PaymentMsg.getText());
		wait(2);
		scrollPage(0, -800);
		wait(5);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(5);
		scrollPage(0, 200);
		//	TransactionDate.click();
		//	wait(2);
		//	FilterOptions.click();
		//	wait(2);
		//	//Operator.clickUsingJavaScriptExecutor();
		//	//wait(1);
		//	//SelectingOperator.clickUsingJavaScriptExecutor();
		//	//wait(2);
		//	Value.clearAndType(data.get("TransactionDate"));
		//	wait(2);
		//	Filterbutton.click();
		//	wait(2);
		Highligthing1.click();
		wait(5);
		More.click();
		wait(3);
		Void.click();
		wait(3);
		VoidNote.sendKeys(Note);
		wait(3);
		Voidbutton.clickUsingJavaScriptExecutor();
		//System.out.println("Void changes are updated");
		wait(3);
		String Alertmessage = AlertMsg.getText();
		if(Alertmessage.equalsIgnoreCase(data.get("AlreadyVoidedMsg"))) {
			CustomAsserts.containsString(AlreadyVoidedMsg.getText(), data.get("AlreadyVoidedMsg").toString());
			TestReportsLog.log(LogStatus.INFO, Alertmessage);
		}else {
			CustomAsserts.containsString(Alertmessage, data.get("UpdatingVoidMsg").toString());
			TestReportsLog.log(LogStatus.INFO, Alertmessage);
		}
		//CustomAsserts.containsString(AlreadyVoidedMsg.getText(), data.get("AlreadyVoidedMsg").toString());
		System.out.println("Transaction is voided successfully");
		System.out.println(Alertmessage);
		wait(1);
		return this;

	}

	public StudentLedgerAccountPage LedgerCardPrinting(StringHash data) throws Exception {

		Link Printicon = new Link("Print icon", byXPath("(//table[@title='Print']//span[contains(@id,'ReportViewer')])[1]"));
		Link SelectingIncCorDet= new Link("Selecting Include Course deatails", byXPath("(//ul[@id='includeCourseDetail_listbox']/li[1])"));
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;	

		//Login Page Web Elements
		//waitForPageToLoad();
		wait(8);
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(1);
		LedgerCard.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(4);
		More.clickUsingJavaScriptExecutor();
		wait(1);
		PrintLedger.clickUsingJavaScriptExecutor();
		wait(2);
		IncludeCourseDetail.clickUsingJavaScriptExecutor();
		wait(1);
		SelectingIncCorDet.clickUsingJavaScriptExecutor();
		wait(2);
		PrintButton.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		driver.switchTo().frame("reportViewer");
		//	Printicon.clickUsingJavaScriptExecutor();
		//	wait(5);
		//	PrintOK.clickUsingJavaScriptExecutor();
		//	wait(2);
		//	PDFdownload.click();
		//	wait(1);
		//	Done.click();
		//	wait(2);
		driver.switchTo().parentFrame();
		Cancel.clickUsingJavaScriptExecutor();
		wait(2);
		System.out.println("Ledger card detail print is successfull");
		return this;
	}

	public StudentLedgerAccountPage LedgerCardPrintDetail(StringHash data) throws Exception {

		Button Cancel = new Button("Cancel", byXPath("//button[@id='cancelPrintRegDetailBillsReport']")); 
		//Login Page Web Elements
		//waitForPageToLoad();
		wait(8);
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(1);
		LedgerCard.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		More.clickUsingJavaScriptExecutor();
		wait(2);
		PrintRegistrationBill.clickUsingJavaScriptExecutor();
		wait(4);
		if(PrintDetail.isDisplayed()) {
			PrintDetail.clickUsingJavaScriptExecutor();
			wait(20);
			//	driver.switchTo().frame("reportViewer");
			Cancel.waitTillElementClickable();
			Cancel.clickUsingJavaScriptExecutor();
			//	Printicon.clickUsingJavaScriptExecutor();
			//	wait(2);
			//	PrintOK.clickUsingJavaScriptExecutor();
			//	wait(2);
			//	PDFdownload.click();
			//	wait(1);
			//	Done.click();
			//	wait(2);
			//	driver.switchTo().parentFrame();
			//	wait(2);
			//	Cancel.clickUsingJavaScriptExecutor();
			System.out.println("Ledger card detail printing is successfull");
		}else {
			TestReportsLog.log(LogStatus.FAIL, "Print Detail button is not visible");
		}
		return this;
	}

	public StudentLedgerAccountPage LedgerCardPrintSummary(StringHash data) throws Exception {

		Button PrintOK = new Button("Print Ok", byXPath("(//p[text()='Print'])[2]"));
		Button Cancel = new Button("Cancel", byXPath("//button[@id=\"cancelPrintRegDetailBillsReport\"]"));

		//Login Page Web Elements
		//waitForPageToLoad();
		wait(8); 
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(1);
		LedgerCard.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		More.clickUsingJavaScriptExecutor();
		wait(2); 
		PrintRegistrationBill.clickUsingJavaScriptExecutor();
		wait(1);
		if(PrintSummary.isDisplayed()) {
			PrintSummary.clickUsingJavaScriptExecutor();}
		wait(20);
		return this;
		/*driver.switchTo().frame("reportViewer");
			/*WebElement PrintIcon = driver.findElement(byXPath("//span[@id='ReportViewer1_ctl09_ctl06_ctl00_ctl00_ctl00']"));
		Actions actions = new Actions(driver);
		actions.moveToElement(PrintIcon);
		actions.click();
			Printicon.clickUsingJavaScriptExecutor();
			wait(4);
			PrintOK.clickUsingJavaScriptExecutor();
			wait(2);
			//		PDFdownload.click();
			//		wait(1);
			Done.click();
			wait(2);
			driver.switchTo().parentFrame();
			Cancel.clickUsingJavaScriptExecutor();
			wait(2);
			System.out.println("Ledger card summary printing is successfull");
		}else {
			TestReportsLog.log(LogStatus.FAIL, "Print Summary button is not visible");
		}*/

	}

	public StudentLedgerAccountPage ApplyCreditLedger(StringHash data) throws Exception {

		Link SelectingTransactionlist= new Link(data.get("TransactionList"), byXPath("//li[text()='"+data.get("TransactionList")+"']"));
		Link GettingTransaction= new Link("Getting transaction", byXPath("//li[text()='"+data.get("TransactionList")+"']"));
		Link PaymentMsg= new Link("Payment Msg", byXPath("//span[text()='The Transaction records were successfully saved.']"));
		Link SelectingPayCode = new Link("Selecting Payment code", byXPath("//span[text()='"+data.get("PayCode")+"']"));
		Link Filtericon = new Link("Filter icon", byXPath("(//button[@aria-label=\"arrow-button\"])[1]"));
		Link ClearFilters= new Link("Clear Filters", byXPath("//span[text()='Reset to Default']"));
		//waitForPageToLoad();
		//ImplicitlyWait();
		wait(8);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(5);
		LedgerCard.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		//	Filtericon.clickUsingJavaScriptExecutor();
		//	wait(1);
		//	ClearFilters.clickUsingJavaScriptExecutor();
		//	wait(2);
		//	Payment.click();
		//	wait(10);
		//	PaymentType.click();
		//	wait(1);
		//	SelectingPayType.click();
		//	wait(7);
		//	AcademicYr.clickUsingJavaScriptExecutor();
		//	wait(2);
		//	SelectingAYr.clickUsingJavaScriptExecutor();
		//	wait(2);
		//	TermList.click();
		//	wait(5);
		//	Term.click();
		//	wait(2);
		//	SelectButton.click();
		//	wait(2);
		//	CashPaymentCode.clickUsingJavaScriptExecutor();
		//	wait(2);
		//	SelectingPayCode.click();
		//	wait(2);
		//	CheckNumber.sendkeys("234");
		//	wait(1);
		//	Amount.sendkeys("10");
		//	wait(2);
		//	SaveAndClose.clickUsingJavaScriptExecutor();
		//	wait(4);
		//	System.out.println("Payment is posted successfully");
		//	scrollPage(0, 600);
		//	wait(2);
		//	Cancel.clickUsingJavaScriptExecutor();
		//	wait(2);
		//	//CustomAsserts.containsString(data.get("PaymentMsg"), PaymentMsg.getText());
		//	wait(2);
		//	scrollPage(0, -800);
		//	wait(5);
		ApplyCreditsButton.clickUsingJavaScriptExecutor();
		wait(5);
		TransatcionList1.clickUsingJavaScriptExecutor();
		wait(2);
		SelectingTransactionlist.clickUsingJavaScriptExecutor();
		wait(5);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(2);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(10);
		TranDate.clickUsingJavaScriptExecutor();
		wait(2);
		Filter1.click();
		wait(2);
		Value1.clearAndType(data.get("TranDate"));
		wait(2);
		Filterbutton.click();
		wait(2);
		HighlightingTransaction.clickUsingJavaScriptExecutor();
		String SelectedTransaction = HighlightingTransaction.getText();
		System.out.println(SelectedTransaction);
		TestReportsLog.log(LogStatus.INFO, "Selected Transaction is "+SelectedTransaction);
		wait(2);
		ApplyCredit.click();
		//	waitForPageToLoad();
		wait(20);
		ApplyAmount.click();
		String SelectedRecord = GettingTransaction.getText();
		System.out.println(SelectedRecord);
		TestReportsLog.log(LogStatus.INFO, "Selected Record is "+SelectedRecord);
		wait(2);
		ApplyButton.clickUsingJavaScriptExecutor();
		wait(8);
		CustomAsserts.containsString(ApplyCreditMsg.getText(), data.get("ApplyCreditMsg").toString());
		System.out.println("Credit applied successfully");

		return this;
	}
	public StudentLedgerAccountPage LedgerCardPostCharge(StringHash data) throws Exception {
		//Checkbox Term = new Checkbox("Selecting Term", byXPath("//input[@aria-label='"+data.get("TermCode")+"']"));
		//Link SelectingBillCode= new Link(data.get("BillCode"), byXPath("//span[text()='"+data.get("BillCode")+"']"));
		Checkbox Term = new Checkbox("Selecting Term", byXPath("(//tbody/tr[1]/td[1]/input)[1]"));
		Link SelectingBillCode= new Link("Selectecting billcode", byXPath("//ul[@id='billingTransactionCode_listbox']/li[1]/span/div/span[2]"));

		// waitForPageToLoad();
		// driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		//Login Page Web Elements
		//waitForPageToLoad();
		//setImplicitWaitTimeout(implicitWaitTimeout);
		//wait(10);
		wait(8);
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(1);
		LedgerCard.click();
		//setImplicitWaitTimeout(implicitWaitTimeout);
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		AddCharge.click();
		wait(6);
		TermList.clickUsingJavaScriptExecutor();
		wait(3);
		Term.click();
		wait(2);
		String SelectedTerm = Term.getAttribute("aria-label");
		TestReportsLog.log(LogStatus.INFO, "selected term is "+SelectedTerm);
		System.out.println(SelectedTerm);
		SelectButton.click();
		wait(2);
		BillCode.click();
		wait(2);
		//SearchBillCode.waitTillElementClickable();
		//SearchBillCode.sendKeys(data.get("BillCode"));
		//wait(2);
		SelectingBillCode.click();
		wait(2);
		String SelectedBillingCode = SelectingBillCode.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "selected bill code is "+SelectedBillingCode);
		System.out.println(SelectedBillingCode);
		Amount.sendKeys("10");
		wait(5);
		scrollPage(0, -300);
		wait(1);
		SaveAndClose.click();
		wait(5);
		CustomAsserts.containsString(PostingChargeMsg.getText(), data.get("PostingChargeMsg").toString());
		wait(2);
		System.out.println("Charge is posted successfully");
		/*Filtericon.clickUsingJavaScriptExecutor();
        wait(1);
        ClearFilters.clickUsingJavaScriptExecutor();
        wait(3);
        Code.click();
        wait(2);
        Filter1.click();
        wait(2);
        Value1.clearAndType(data.get("BillCode"));
        wait(2);
        Filterbutton.click();
        wait(2);
        String Code = HighlightingCode.getText();
        CustomAsserts.assertString(HighlightingCode.getText(), data.get("BillCode"));
        if(Code.equalsIgnoreCase(data.get("BillCode")))
        {
            System.out.println("Charge is posted successfully");
        }else {
            System.out.println("Charge is not posted successfully");
        }*/
		return this;

	}

	public StudentLedgerAccountPage AdjustLedgerTransactionDelete(StringHash data) throws Exception {

		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;

		//Login Page Web Elements
		//waitForPageToLoad();
		wait(8);
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(1);
		LedgerCard.clickUsingJavaScriptExecutor();
		//setImplicitWaitTimeout(implicitWaitTimeout);
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(6);
		//		Code.click();
		//		wait(2);
		//		Filter1.click();
		//		wait(2);
		//		Value1.clearAndType(data.get("BillCode"));
		//		wait(2);
		//		Filterbutton.click();
		//		wait(2);
		HighlightingCode.click();
		wait(2);
		More.click();
		wait(2);
		Delete.click();
		wait(2);
		DeleteNote.clearAndType(Note);
		wait(2);
		Deletebutton.click();
		wait(7);
		CustomAsserts.containsString(DeletingTranMsg.getText(), data.get("DeletingTranMsg").toString());
		System.out.println("Charge is deleted successfully");
		return this;

	}

	public StudentLedgerAccountPage ScheduleRefundLedgerCard(StringHash data) throws Exception {

		Link ReturnMethod = new Link("Return Method", byXPath("(//span[@aria-controls='returnMethod_listbox']/span)[2]"));
		Link SelectingReundOption= new Link(data.get("RefundOption"), byXPath("//ul/li/span[text()='Schedule Refund']"));
		Link SelectingTerm= new Link("Selecting term", byXPath("//ul[@id='termId_listbox']/li[1]/span/div/span[2]"));
		Link SelectingReturnMethod= new Link("Selecting Return Method", byXPath("//ul[@id='returnMethod_listbox']/li[1]/span"));
		Link Term= new Link("Term dropdown", byXPath("(//button[@aria-label='expand combobox'])[2]"));

		Link Filtericon = new Link("Filter icon", byXPath("(//button[@aria-label='arrow-button'])[1]"));
		Link ClearFilters= new Link("Clear Filters", byXPath("//span[text()='Reset to Default']"));
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;


		//Login Page Web Elements
		//waitForPageToLoad();
		wait(8);
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(1);
		LedgerCard.clickUsingJavaScriptExecutor();
		//setImplicitWaitTimeout(implicitWaitTimeout);
		waitForPageToLoad();
		Refunds.clickUsingJavaScriptExecutor();
		wait(10);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(3);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0, 300);
		//scrollPage(0, 200);
		FundSource.click();
		wait(2);
		Filter1.click();
		wait(2);
		Value1.clearAndType(data.get("FundSource"));
		wait(2);
		Filterbutton.click();
		wait(2);
		//AmountReceived.click();
		//wait(2);
		//SortDescending.click();
		//wait(2);
		//				String sRowValue = "0.00";
		//				WebElement mytable = driver.findElement(By.xpath("//table/tbody[@role='rowgroup']"));
		//				List< WebElement > rows_table = mytable.findElements(By.xpath("//table/tbody[@role='rowgroup']/tr"));
		//				int rows_count = rows_table.size();
		//				System.out.println(rows_count);
		//				List< WebElement > columnss_table = mytable.findElements(By.xpath("//table/tbody[@role='rowgroup']/tr[1]/td"));
		//				int columns_count = columnss_table.size();
		//				System.out.println(columns_count);
		//				for (int i = 1; i <= rows_count; i++) {
		//					String sValue = null;
		//					sValue = driver.findElement(By.xpath("//table/tbody[@role='rowgroup']/tr["+ i +"]/td[4]")).getText();
		//					System.out.println(sValue);
		//					NumberFormat format = NumberFormat.getInstance(Locale.getDefault());
		//					Number number = format.parse(sValue);
		//					System.out.println(number);
		//					double value = number.doubleValue();
		//					System.out.println(value);
		//					if(value>0){
		//				    for(int column = 1; column <= columns_count; column++) {
		//				    	String sColumnValue= driver.findElement(By.xpath("//table/tbody[@role='rowgroup']/tr["+ column +"]/td[5]")).getText();
		//						System.out.println(sColumnValue);
		//						double Cvalue = Double.parseDouble(sColumnValue);
		//						if(Cvalue<value) {
		//						driver.findElement(By.xpath("//table/tbody[@role='rowgroup']/tr[" + i + "]/td["+ column +"]")).click();	
		//						break;
		//				    }
		//				}break;
		//					}
		//					}
		//System.out.println(columns_count);
		HighlightingFundSource.click();
		wait(5);
		Next.click();
		wait(2);
		scrollPage(0, 150);
		wait(2);
		RefundOption.click();
		wait(3);
		SelectingReundOption.click();
		wait(3);
		Term.click();
		wait(2);
		SelectingTerm.click();
		wait(1);
		String SelectedTerm = SelectingTerm.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "selected term is "+SelectedTerm);
		System.out.println(SelectedTerm);
		DueDate.sendKeys(Date);
		String Duedateentered = DueDate.getText();
		System.out.println(Duedateentered);
		wait(2);
		ReturnMethod.click();
		wait(1);
		SelectingReturnMethod.click();
		String SelectedReturnMethod = SelectingReturnMethod.getText();
		System.out.println(SelectedReturnMethod);
		TestReportsLog.log(LogStatus.INFO, "Selected Return Method is "+SelectedReturnMethod);
		wait(2);
		Amount.sendKeys("2");
		wait(2);
		PostSchedule.click();
		//wait(4);
		//Override.click();
		wait(2);
		//CustomAsserts.containsString(SchldRefundMsg.getText(), data.get("SchldRefundMsg").toString());
		//OverrideCancel.click();
		//wait(2);
		System.out.println("Schedule refund is successfully");
		return this;

	}


	public StudentLedgerAccountPage ScheduleStipend(StringHash data) throws Exception {
		Link SelectingTerm= new Link("Selected term", byXPath("//ul[@id='termId_listbox']/li[1]/span[1]/div[1]/span[2]"));
		Link SelectingReturnMethod= new Link("Selecting return method", byXPath("(//ul[@id='returnMethod_listbox']/li[2])"));
		//Link SelectingReturnMethod= new Link("Selecting Return Method", byXPath("//li[text()='"+data.get("ReturnMethod")+"']"));
		Link SelectingStatus= new Link(data.get("Status"), byXPath("//ul[@id='status_listbox']/li[1]/span"));
		Link SelectingFundSourceST= new Link("Selecting Term", byXPath("//ul[@id='fundSourceId_listbox']/li[1]/span[1]/div/span[2]"));
		Link Term= new Link("Term dropdown", byXPath("(//button[@aria-label=\"expand combobox\"])[3]"));
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;

		//Login Page Web Elements
		//waitForPageToLoad();
		wait(8);
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(1);
		StipendSchedule.clickUsingJavaScriptExecutor();
		//setImplicitWaitTimeout(implicitWaitTimeout);
		waitForPageToLoad();
		NewStipend.click();
		wait(4);
		FundSourceDrp.click();
		wait(1);
		//SearchFundSource.clearAndType(data.get("FundSource"));
		//SearchFundSource.click();
		//wait(2);
		SelectingFundSourceST.click();
		String SelectedFundSource = SelectingFundSourceST.getAttribute("title");
		System.out.println(SelectedFundSource);
		TestReportsLog.log(LogStatus.INFO, "Selected FundSource is "+SelectedFundSource);
		wait(2);
		Term.click();
		wait(1);
		SelectingTerm.click();
		String SelectedTerm = SelectingTerm.getAttribute("title");
		System.out.println(SelectedTerm);
		TestReportsLog.log(LogStatus.INFO, "Selected Term is "+SelectedTerm);
		wait(2);
		ReturnMethod.click();
		wait(1);
		//SearchReturnMethod.clearAndType(data.get("ReturnMethod"));
		//wait(2);
		SelectingReturnMethod.click();
		String SelectedRetMethod = SelectingReturnMethod.getText();
		System.out.println(SelectedRetMethod);
		TestReportsLog.log(LogStatus.INFO, "Selected FundSource is "+SelectedRetMethod);
		wait(2);
		Datescheduled.clearAndType(Date);
		wait(2);
		NetAmount.sendKeys("10");
		wait(3);
		ScheduleOk.click();
		wait(2);
		Status.clickUsingJavaScriptExecutor();
		wait(1);
		SelectingStatus.click();
		wait(2);
		scrollPage(0, -200);
		wait(1);
		Save.click();
		wait(2);
		CustomAsserts.containsString(SchlStipendMsg.getText(), data.get("SchlStipendMsg").toString());
		System.out.println("Schedule stipend is successfully");
		scrollPage(0, 300);
		wait(10);
//		ScheduledDate.click();
//		wait(1);
//		Filter1.click();
//		wait(2);
//		Value.sendKeys(Date);
//		wait(2);
//		Filterbutton.click();
//		wait(2);
//		String DateScheduled = HighlightingSchedule.getText();
//		System.out.println(DateScheduled);
//		if(DateScheduled.equalsIgnoreCase(Date))
//		{
//			System.out.println("Schedule stipend is save successfully");
//		}else {
//			System.out.println("Schedule stipend is not saved");
//		}
		return this;
	}

	public StudentLedgerAccountPage AdjustLedgerTransactionReturnedCheck(StringHash data) throws Exception {
		 AngDropDown PaymentType = new AngDropDown("Payment Type", byXPath("//span[contains(@aria-label,'Payment Type')]/span/span"));
		 Link Payment = new Link("Add payment", byXPath("(//span[text()='Payment'])[1]"));
		Checkbox Term = new Checkbox("Selecting Term", byXPath("(//tbody/tr[1]/td[1]/input)[1]"));
		Link ReturnedCHeckMsg= new Link("Returned Check Msg", byXPath("//span[text()='The check was successfully marked as returned.']"));
		Link PaymentMsg= new Link("Payment Msg", byXPath("//span[text()='The Transaction records were successfully saved.']"));
		Link SelectingPayCode = new Link("Selecting Payment code", byXPath("//span[text()='"+data.get("PayCode")+"']"));
		//Link SelectingSubsidiary = new Link("Selecting Subsidiary", byXPath("//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/div/span[1]"));
		//driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
		//Login Page Web Elements
		//waitForPageToLoad();
		//ImplicitlyWait();
//		AngDropDown AcademicYr = new AngDropDown("Academic year dropdown", byXPath("(//span[@aria-label='Academic Year']/span/span)[2]"));
//		 Link SelectingAYr = new Link("Selecting Academic year", byXPath("(//ul[@id='academicYearSequence_listbox']/li/span/div/span)[1]"));
//		 Link HighlightingTransaction = new Link("Highlighting transaction", byXPath("(//tr/td)[15]"));
//		 Link More= new Link("More", byXPath("//font[text()='More']"));
//		 Link ReturnedCheck = new Link("Retruned Check", byXPath("//font[text()='Returned Check']"));
		 
		 AngDropDown AcademicYr = new AngDropDown("Academic year dropdown", byXPath("(//span[@aria-label='Academic Year']/span/span)[2]"));
		 Link SelectingAYr = new Link("Selecting Academic year", byXPath("(//ul[@id='academicYearSequence_listbox']/li/span/div/span)[1]"));
		 Link HighlightingTransaction = new Link("Highlighting transaction", byXPath("(//tr/td)[5]"));
		 //Link More= new Link("More", byXPath("//font[text()='More']"));
		 Link More= new Link("More", byXPath("(//button/span)[15]"));
		 Link ReturnedCheck = new Link("Retruned Check", byXPath("//span[text()='Returned Check']"));
		 Link SelectingPayType = new Link("Selecting Payment type", byXPath("//span[text()='Cash Payment']"));
		 AngDropDown CashPaymentCode = new AngDropDown("Cash Payment COde", byXPath("(//span[contains(@aria-label,'Cash Payment Code')]/span/span)[2]"));
		 Link BankAccount = new Link("BankAccount", byXPath("//span[@aria-label='Bank Account']"));
		 Link BankAccountValue = new Link("BankAccountValue", byXPath("(//ul[@id='bankAccountId_listbox']/li/span/div/span)[1]"));
		
		 
		 
		 
		wait(8);  
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		StudentStudentPage.StudentAccounts.waitTillElementClickable();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(1);
		LedgerCard.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		Payment.click();
		wait(10);
		PaymentType.click();
		wait(1);
		SelectingPayType.click();
		wait(7);
		//AcademicYr.clickUsingJavaScriptExecutor();
		wait(2);
		//SelectingAYr.clickUsingJavaScriptExecutor();
		wait(2);
		TermList.click();
		wait(5);
		Term.click();
		wait(2);
		SelectButton.click();
		wait(2);
		CashPaymentCode.clickUsingJavaScriptExecutor();
		wait(2);
		SelectingPayCode.click();
		wait(2);
		CheckNumber.sendkeys("234");
		wait(1);
		Amount.sendkeys("10");
		wait(2);
		BankAccount.click();
		wait(2);
		BankAccountValue.click();
		wait(2);
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(4);
		System.out.println("Payment is posted successfully");
		scrollPage(0, 600);
		wait(2);
		Cancel.clickUsingJavaScriptExecutor();
		wait(2);
		//CustomAsserts.containsString(data.get("PaymentMsg"), PaymentMsg.getText());
		wait(2);
		scrollPage(0, -800);
		wait(5);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(2);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(20);
		//		Transaction.click();
		//		wait(2);
		//		StudentLedgerAccountPage.Filter1.click();
		//		wait(2);
		//		StudentLedgerAccountPage.Value1.clearAndType(data.get("PaymentName"));
		//		wait(2);
		//		StudentLedgerAccountPage.Filterbutton.click();
		//		wait(2);
		HighlightingTransaction.clickUsingJavaScriptExecutor();
		wait(5);
		More.clickUsingJavaScriptExecutor();
		wait(5);
		ReturnedCheck.clickUsingJavaScriptExecutor();
		wait(7);
		ReturnNote.clearAndType(Note);
		wait(2);
		ReturnedCheckOk.click();
		wait(8);
		CustomAsserts.containsString(data.get("RetunerCheckMsg"), ReturnedCHeckMsg.getText());
		System.out.println("Transaction is returned successfully");
		wait(2);
		return this;
	}

}
