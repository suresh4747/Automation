package com.StudentPortal.Pages;
import static com.framework.elements.Locator.byCSSSelector;
import static com.framework.elements.Locator.byXPath;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.DatesUtil;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentMainPage extends BasePage {

	static String TermNameValueForRegister = StudentTermsPage.TermNameValue;
	static String SMSServiceProviderValue = StudentConfigurationPage.SMSNameValue;
	static String EmployerNameActualValue = StudentConfigurationPage.EmployerNameValue;
	Link TasksSpan = new Link("TasksSpan", byXPath("//span[text()='Tasks']"));
	Link StudentAccountsSpan = new Link("StudentAccountsSpan", byXPath("//cns-panel-bar/ul/li[6]/a/span"));
	Link CareerServices = new Link("Click on Career Services", byXPath("//cns-panel-bar/ul/li[4]/a/span"));
	Link FinancialAidSpan = new Link("FinancialAidSpan", byXPath("//cns-panel-bar/ul/li[5]/a/span"));
	Link StudentServices = new Link("StudentServices", byXPath("//cns-panel-bar/ul/li[7]/a/span"));
	static Link AcademicRecords = new Link("Click on Academic Records span", byXPath("//li[3]/span"));
	static Link StudentCourses = new Link("Click on Student Courses span", byXPath("//li[3]/div/div[3]/div"));
	static Link Add = new Link("Click on Add link", byCSSSelector("#addCourseButton"));
	static Button Override = new Button("Override button", byCSSSelector("#studentOnHoldWindowOkButton"));
	static TextField Course = new TextField("Course Field", byCSSSelector("#search_display_courseId"));
	static TextField SearchBox = new TextField("SearchBox", byCSSSelector("#search"));
	static Checkbox Input = new Checkbox("Input", byXPath("//td/input"));
	static Button Select = new Button("Select button", byXPath("//button[. = 'Select']"));
	static TextField Term = new TextField("Course Field", byCSSSelector("#search_display_termId"));
	static Button SaveAndRegister = new Button("Save and Register", byXPath("//cmc-toolbar-button-save-new[2]//button"));
	static Button AddCourseWithoutCategory = new Button("Add course without category", byCSSSelector("#courseTakenNotAppliedDialogOkButton"));
	static Button Next = new Button("Next", byCSSSelector("#courseInformationProceedButton"));
	//static Link InstructorTableCell = new Link("InstructorTableCell", byCSSSelector("#classSectionGrid_cmcGrid_active_cell"));		
	static Link Register = new Link("Click on register link", byXPath("//cmc-common-toolbar[2]//a[. = 'Register']"));
	static Button RegisterButton = new Button("Register", byCSSSelector("#schedueCourseDialogOkButton"));
	//static Link Drop = new Link("Drop Link", byCSSSelector("#courseDropButton"));
	static Link Drop = new Link("Drop Link", byXPath("//a[8][. = 'Drop']"));	
	static Link MenuButton = new Link("Click MenuButton", byXPath("//div[@id='navbar']/ul/li[2]/a/span"));
	static Link Students = new Link("Students tile", byXPath("//a[text()=\"Students\"]"));
	static Link FilterDropDwon = new Link("Click Filter Drop Down", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
	static Link ClearFiltersButton = new Link("Click Filter Button", byXPath("//a[text()='Clear Filters']"));
	static AngDropDown StuNumDropDown = new AngDropDown("Click Student Number Dropdown", byXPath("//th[2]/a/span"));
	static Button StuNumFilter = new Button("Click Stud Num Filter", byXPath("//span[.=\"Filter\"]"));
	static TextField value = new TextField("Enter Value", byXPath("//input[@title=\"Value\"]"));
	static Button FilterButton = new Button("Click Filter Button", byXPath("//button[text()=\"Filter\"]"));
	static Link StudentAccounts = new Link("Click on StudentAccounts", byXPath("//span[@class='k-link k-header k-state-selected']"));    
	static Link SchoolFields = new Link("Click on SchoolFields", byXPath("//ul[@id='studentTilesPanelBar']/li[3]/div/div[12]/div"));
	static Link Sexbirth = new Link("Click on Sexbirth", byXPath("//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div/div/div/div/cmc-drop-down-list-classic/div/div/span/span/span"));
	static Link SelSexbirth = new Link("Click on SelSexbirth", byXPath("//ul[@id='SEXATBIRTH_listbox']/li[2]"));
	static Link Pronouns = new Link("Click on Pronouns", byXPath("//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div/div[2]/div/div/cmc-drop-down-list-classic/div/div/span/span/span"));
	static Link SelPronouns = new Link("Click on SelPronouns", byXPath("//li[@id='e0fb8a94-81e1-4b2a-add8-18d7f908e96e']"));
	static Link FirstGenarationStudent = new Link("Click on FirstGenarationStudent", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[2]/div/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelFirstGenarationStudent = new Link("Click on SelFirstGenarationStudent", byXPath("//li[@id='6f7170c4-f614-4e8c-b821-938a0d636aa8']"));
	static Link OrigonResident = new Link("Click on OrigonResident", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[2]/div/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelOrigonResident = new Link("Click on SelOrigonResident", byXPath("//li[@id='3c20f9c8-e684-43d8-9140-3fa306a52343']"));
	static Link GenderIdentity = new Link("Click on GenderIdentity", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[3]/div/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelGenderIdentity = new Link("Click on SelGenderIdentity", byXPath("//li[@id='a3e728e3-597e-4a13-8a4d-596a25651627']"));
	static Link Tribe = new Link("Click on Tribe", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[3]/div[2]/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelTribe = new Link("Click on SelTribe", byXPath("//li[@id='ff5adab5-6cb1-40a6-90af-a61848c3df1b']"));
	static Link ImmunaizationConfirmation = new Link("Click on ImmunaizationConfirmation", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[4]/div/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelImmunaizationConfirmation = new Link("Click on SelImmunaizationConfirmation", byXPath("//li[@id='4cebb8ab-8d65-4002-bbb8-9efbd803a683']"));
	static Link ELL = new Link("Click on ELL", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[3]/div[2]/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelELL = new Link("Click on SelELL", byXPath("//li[@id='a6cd6337-07de-4d9b-afe0-80f4bbe0d9e6']"));
	static Link DisebillityRequest = new Link("Click on DisebillityRequest", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[5]/div/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelDisebillityRequest = new Link("Click on SelDisebillityRequest", byXPath("//li[@id='d701844c-6fbd-4247-b165-0b4227754d6a']"));
	static Link VeternFamilyDependent = new Link("Click on VeternFamilyDependent", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[5]/div[2]/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelVeternFamilyDependent = new Link("Click on SelVeternFamilyDependent", byXPath("//li[@id='c055fb2f-9c7d-4f08-965d-9887658ce590']"));
	static Link VeteneryTypePreferance = new Link("Click on VeteneryTypePreferance", byXPath("(//div[@id='maincontent']/div/cns-student/div/section/div/div/div[2]/div/div/div/div/cns-student-school-field/section/div/div[3]/div/div[7]/div[2]/div/div/cmc-drop-down-list-classic/div/div/span/span/span)[1]"));
	static Link SelVeteneryTypePreferance = new Link("Click on SelVeteneryTypePreferance", byXPath("//li[@id='3d5b1bba-9082-4fa2-8da6-0575481b7253']"));
	static Button Save = new Button("Save", byXPath("(//button[@aria-label='Save'])[2]"));
	static Button use = new Button("Use", byXPath("//button[@id='applicantRecordDialogOkButton']"));
	static Button ClsFilterDropDwon = new Button("Click Filter Drop Down", byXPath("(//a[@class='k-button k-split-button-arrow'])[1]"));
	static Link ClsClearFiltersButton = new Link("Click Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
	static Link ClsClearFiltersButton1 = new Link("Click Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
	static Link TermDropDown = new Link("Click Term Number Dropdown", byXPath("(//th[1]//span)[1]"));
	static Button TerNumFilter = new Button("Click Term Num Filter", byXPath("//span[.='Filter']"));
	static TextField value1 = new TextField("Enter Value", byXPath("//input[@title='Value']"));
	static Button FilterButton1 = new Button("Click Filter Button", byXPath("//button[text()='Filter']"));
	static Link SelectPrograme = new Link("SelectPrograme", byXPath("//td[text()='Any']"));
	static Link More = new Link("More", byXPath("//div[@id='moreEnrollmentButton_wrapper']/a[2]"));
	static Link Transfer = new Link("Transfer", byXPath("//a[@id='transferButton']"));
	static Link TransferType = new Link("TransferType", byXPath("(//div[@id='divfirstrow_transfer']/cmc-drop-down-list-classic/div/div/span/span/span)[2]"));
	static Link SelTransferType = new Link("SelTransferType", byXPath("//li[text()='To Enrollment']"));
	static Button Proceed = new Button("Click Proceed", byXPath("(//button[text()='Proceed'])[2]"));
	static Checkbox NewPgmVer = new Checkbox("NewPgmVer", byXPath("//div[@id='transferWindow']/ng-transclude/div/div[3]/div/div/ng-transclude/section/div[3]/cmc-radio-button-group/div/div[2]/cmc-radio-button[2]/div/div/label"));
	static Link ProgrameVersion = new Link("ProgrameVersion", byXPath("(//div[@id='transferWindow']/ng-transclude/div/div[3]/div/div/ng-transclude/section/div[3]/cmc-drop-down-list-classic/div/div/span/span/span)[2]"));
	static TextField EnterProgrameVersion = new TextField("Enter EnterProgrameVersion", byXPath("//input[@aria-owns=\"transferToProgramVersionId_listbox\"]"));
	static Button Next3 = new Button("Next3", byXPath("//button[@id='transferInformationProceedButton']"));
	static Button Next4 = new Button("Next4", byXPath("//button[@id='studentCourseProceedButton']"));
	static Button Next5 = new Button("Next5", byXPath("//button[@id='feeProceedButton']"));
	static Link Transfer2 = new Link("Transfer2", byXPath("(//a[@id='transferSaveButton'])[2]"));
	static Link SelPrgver = new Link("SelPrgver", byXPath("//span[text()='AP Associate 2 Semester']"));
	static Link Transfer3 = new Link("Transfer3", byXPath("//button[@id='enrollAcademicYearDialogOkButton']"));   
	static String TstTypName = AppendValue.apendString();
	static String TstTypCode = AppendValue.apendString();	
	//static Link MenuButton = new Link("Click MenuButton", byXPath("//div[@id='navbar']/ul/li[2]/a/span"));
	static Link Processes = new Link("Processes tile", byXPath("//a[text()='Processes']"));
	static TextField SearchProcesses = new TextField("Search Process", byXPath("//input[@placeholder='Search Processes']"));
	static Link Registration = new Link("Registration Type", byXPath("//span[text()='Registration']"));
	static Button Track = new Button("Click on Track", byXPath("//div[@id='navigationSplitter']/div[3]/div[2]/cns-batch-registration/section/div/div/div[2]/cmc-tabs/div/div/ul/li[2]/button"));
	static TextField StudentGroup = new TextField("Enter Student Group", byXPath("//input[@name='studentGroupDropDown_input']"));
	static Link SelectSG = new Link("Select Student Group", byXPath("//ul/li[text()='2020 Winter SAP Probation (Aid)']"));
	static Link SelectTrack = new Link("Select Track", byXPath("//tr/td[text()='Rudy_Track']"));
	static TextField Next1 = new TextField("Click on Next", byXPath("//div[@id='navigationSplitter']/div[3]/div[2]/cns-batch-registration/section/div/div/div[2]/cmc-tabs/div/div/div/div/cns-batch-registration-track/div/section/div/div[2]/div[5]/div/button"));
	static Checkbox Checkall = new Checkbox("Click on Checkbox", byXPath("//input[@aria-label='Select All StudentId']"));
	static Link Queureg = new Link("Click on Queu Reg", byXPath("//a[@id='queueRegistrationButton']"));
	static Link Queue = new Link("Click on Queue ", byXPath("//button[text()='Queue']"));
	static Button SaveAndClose = new Button("Save and Close", byXPath("//button[@aria-label= \"Save & Close\"]"));	
	static Button Unregister = new Button("Click on Unregister", byXPath("//div[@id='navigationSplitter']/div[3]/div[2]/cns-batch-registration/section/div/div/div[2]/cmc-tabs/div/div/ul/li[3]/button"));
	static Link Term1 = new Link("Click on Term1", byXPath("//div[@aria-label=\"Term\"]"));
	static TextField SearchTerm = new TextField("Enter Term", byXPath("//input[@id='search']"));
	static Checkbox SelectTerm = new Checkbox("Select Term", byXPath("//input[@aria-label='2022 Winter']"));
	static Button Select1 = new Button("Select Button", byXPath("//button[text()='Select']"));
	static TextField Instructor = new TextField("Click Instructor", byXPath("//input[@name=\"InstructorId_input\"]"));
	static Link SelInstructor = new Link("Click on selctIns", byXPath("//span[@title=\"Administrator, System\"]"));
	static TextField Next2 = new TextField("Click on Next", byXPath("//div[@id='navigationSplitter']/div[3]/div[2]/cns-batch-registration/section/div/div/div[2]/cmc-tabs/div/div/div/div/cns-batch-registration-unregister/section/div/div[2]/div[7]/div/button"));
	static Checkbox allstd = new Checkbox("Select all student", byXPath("//input[@aria-label='Select all']"));
	static TextField Reason = new TextField("Enter Reason", byXPath("//input[@name='ReasonId_input']"));
	static Link SelReas = new Link("Click on Reason", byXPath("//span[@title='CANCELLED SECTION']"));
	static Link Queureg2 = new Link("Click on Queu Reg", byXPath("//a[@id='queueUnregistrationButton']"));	
	static TextField Shift = new TextField("Enter on shift", byXPath("//input[@name='shiftId_input']"));
	static Link SelShift = new Link("Click on Selshift", byXPath("//span[@title='Any']"));
	static TextField VersionStartDateDropBox1 = new TextField("VersionStartDateDropBox", byXPath("//input[@name='startDateId_input']"));
	static TextField GradeScale = new TextField("Enter on GradeScale", byXPath("//input[@name='gradeScaleId_input']"));
	static Link SelGradeScale = new Link("Click on SelGradeScale", byXPath("//span[@title='Abarza-Grade-Scale']"));
	static Button Overide = new Button("Click on Overide ", byXPath("//button[. = 'Override']"));
	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
	Date date = new Date();
	String currentDate = formatter.format(date);
	static Link TermU = new Link("Click on Term", byXPath("//div[@id='search_display_termId']"));
	static TextField EnterTermU = new TextField("Enter Term", byXPath("//input[@id='search']"));
	static Checkbox SelectTermU = new Checkbox("Select Term", byXPath("//input[@aria-label='2022 Spring R']"));
	static Button SelectU = new Button("Select Button", byXPath("//button[text()='Select']"));
	static String VerificationAgentValue = AppendValue.apendString();
	static TextField Branch = new TextField("Click on Branch", byXPath("//cmc-search[1]/dl/dd[1]/cmc-search-display/div"));
	static Checkbox SelectBranch = new Checkbox("SelectBranch", byXPath("//tr[1]/td/input"));
	static TextField Benifit = new TextField("Click on Benifit", byXPath("//cmc-search[2]/dl/dd[1]/cmc-search-display/div"));
	static Checkbox SelectBenifit = new Checkbox("SelectBenifit", byXPath("//tr[1]/td/input"));
	static Button SaveandClose = new Button("Save", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
	static Button SaveMessage = new Button("SaveMessage", byXPath("//div[50]//button[. = 'Save']"));
	static Button SaveMessage1 = new Button("SaveMessage1", byXPath("//a[. = 'Save']"));
	static Link IndicatorDropdown = new Link("Click Course Code dropdown", byXPath("//th[1]//span"));
	static Button CFilterDropDown = new Button("Click Filter", byXPath("//span[text()=\"Filter\"]"));
	static TextField IValue = new TextField("Click Filter", byXPath("//input[@title=\"Value\"]"));
	static Button Filter = new Button("Filter Button", byXPath("(//span[text()='Filter'])[2]"));
	static Button Filter1 = new Button("Filter Option", byXPath("(//span[text()='Filter'])[1]"));
	 static TextField Value = new TextField("Value", byXPath("//input[@title='Value']"));
	//Random Value

	static Link ContactManager = new Link("Click Contact Manager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
	static Link International = new Link("Clicl Tasks", byXPath("//span[. = 'International'][1]"));
	static TextField EnterInstructor = new TextField("EnterInstructor", byXPath("//input[@name=\"InstructorId_input\"]"));
	static String EnrollDate = DatesUtil.getCurrentDatebyFormat("M/dd/yyyy");
	static String EffDate = DatesUtil.getCurrentDatebyFormat("M/dd/yyyy");

	static String TrackName = StudentTrackConfiguration.TrackName;
	static String GroupName= StudentTrackConfiguration.Groupname;

	public StudentMainPage RegisterCourse(StringHash data) throws Exception{

		Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));	
		waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		StudentCourses.waitTillElementClickable();
		StudentCourses.click();
		waitForPageToLoad();
		Add.waitTillElementClickable();
		Add.click();
		if (Override.isElementPresent()) {
			Override.click();       
		}
		waitForPageToLoad();
		scrollPage(0, -200);
		Course.waitTillElementFound();
		Course.waitTillElementClickable();
		Course.click();
		wait(3);
		SearchBox.clearAndType(data.get("Course").toString());
		wait(3);
		Input.click();
		Select.click();
		wait(3);
		Term.click();
		wait(3);
		SearchBox.clearAndType(TermNameValueForRegister.toString());
		wait(2);
		Input.click();
		Select.click();
		SaveAndRegister.waitTillElementClickable();
		SaveAndRegister.click();
		AddCourseWithoutCategory.waitTillElementClickable();
		AddCourseWithoutCategory.click();
		waitForPageToLoad();
		scrollPage(0, 500);
		Next.waitTillElementClickable();
		Next.click();
		wait(4);
		InstructorTableCell.waitTillElementClickable();
		InstructorTableCell.click();
		scrollPage(0, 200);
		Register.click();
		wait(2);
		RegisterButton.click();
		scrollPage(0, -500);
		return this;

	}

	public StudentMainPage DropCourse(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		Link CourseTableCell = new Link("CourseTableCell", byXPath("//td[. = '"+data.get("Course")+"']"));
		Link CourseStatusTableCell = new Link("CourseStatusTableCell", byXPath("//td[8]"));
		//Link LetterGradeSpan = new Link("LetterGradeSpan", byXPath("//div[5]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
		Link LetterGradeSpan = new Link("LetterGradeSpan", byXPath("//div[53]/div/ng-transclude/div/div[3]/div/div/ng-transclude/div/div[2]/cmc-drop-down-list-classic[1]/div/div/span//span[2]"));
		Dropbox LetterGrade = new Dropbox("LetterGrade", byXPath("//li[. = '"+data.get("LetterGrade")+"']"));
		Link ReasonSpan = new Link("ReasonSpan", byXPath("//cmc-drop-down-list-classic[2]/div/div/span//span[2]"));
		Dropbox DropReason = new Dropbox("DropReason", byXPath("//li[text()='"+data.get("DropReason")+"']"));
		Button DropButton = new Button("Drop", byCSSSelector("#dropCourse"));

		waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		StudentCourses.waitTillElementClickable();
		StudentCourses.click();
		waitForPageToLoad();
		CustomAsserts.containsString(CourseTableCell.getText(), data.get("Course").toString());
		CustomAsserts.containsString(CourseStatusTableCell.getText(), data.get("CourseStatus").toString());
		Input.click();
		wait(3);
		Drop.waitTillElementClickable();
		Drop.click();
		wait(3);
		LetterGradeSpan.waitTillElementClickable();
		LetterGradeSpan.click();
		wait(2);
		LetterGrade.click();
		ReasonSpan.waitTillElementFound();
		ReasonSpan.click();
		wait(2);
		DropReason.click();
		DropButton.waitTillElementClickable();
		DropButton.click();
		waitForPageToLoad();
		CustomAsserts.containsString(CourseStatusTableCell.getText(), data.get("CourseStatusAfterDropping").toString());	
		return this;

	}


	public StudentMainPage ReinstateCourse(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		Link CourseTableCell = new Link("CourseTableCell", byXPath("//td[. = '"+data.get("Course")+"']"));
		Link CourseStatusTableCell = new Link("CourseStatusTableCell", byXPath("//td[8]"));
		//Link LetterGradeSpan = new Link("LetterGradeSpan", byXPath("//div[5]/cmc-drop-down-list[1]/div/div/span/span/span/span"));	
		Button Reinstate = new Button("Reinstate", byXPath("//a[text()='Reinstate']"));
		Button ReinstatePopUpButton = new Button("ReinstatePopUpButton", byXPath("//button[@id='confirmReinstateCourseWindowOkButton']"));
		Button Override1 = new Button("Override button", byXPath("//button[@id='confirmOverrideRegistrationHoldWindowOkButton']"));


		waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		StudentCourses.waitTillElementClickable();
		StudentCourses.click();
		waitForPageToLoad();
		CustomAsserts.containsString(CourseTableCell.getText(), data.get("Course").toString());
		CustomAsserts.containsString(CourseStatusTableCell.getText(), data.get("CourseStatus").toString());
		Input.click();
		wait(3);
		Reinstate.waitTillElementClickable();
		Reinstate.click();
		wait(3);
		if (ReinstatePopUpButton.isElementPresent()) {
			ReinstatePopUpButton.click();       
		}
		wait(2);
		if (Override1.isElementPresent()) {
			Override1.click();       
		}

		waitForPageToLoad();
		CustomAsserts.containsString(CourseStatusTableCell.getText(), data.get("CourseStatusAfterReinstating").toString());	
		return this;

	}

	public StudentMainPage UnregisterCourse(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		Link CourseTableCell = new Link("CourseTableCell", byXPath("//td[. = '"+data.get("Course")+"']"));
		Link CourseStatusTableCell = new Link("CourseStatusTableCell", byXPath("//td[8]"));
		//Link LetterGradeSpan = new Link("LetterGradeSpan", byXPath("//div[5]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
		Link Unregister = new Link("Unregister", byCSSSelector("#courseUnRegisterButton"));
		Link ReasonSpan = new Link("ReasonSpan", byXPath("//ng-transclude/div[2]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		Dropbox UnregisterDropDown = new Dropbox("Unregister", byXPath("//li[. = '"+data.get("UnregisterReason")+"']"));
		Button OverrideAndUnregister = new Button("OverrideAndUnregister", byXPath("//button[. = 'Override & Unregister']"));
		Link MessageSpan = new Link("Unregister message success", byXPath("/span[. = 'The Student Course records were successfully unregistered.']"));


		waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		StudentCourses.waitTillElementClickable();
		StudentCourses.click();
		waitForPageToLoad();
		CustomAsserts.containsString(CourseTableCell.getText(), data.get("Course").toString());
		CustomAsserts.containsString(CourseStatusTableCell.getText(), data.get("CourseStatus").toString());
		Input.click();
		wait(3);
		Unregister.click();
		wait(8);
		ReasonSpan.waitTillElementClickable();
		ReasonSpan.click();
		wait(2);
		UnregisterDropDown.click();
		OverrideAndUnregister.click();
		waitForPageToLoad();
		CustomAsserts.containsString(CourseStatusTableCell.getText(), data.get("CourseStatusAfterUnregistering").toString());
		//MessageSpan.waitTillElementFound();
		//MessageSpan.isDisplayed();	
		return this;

	}

	public StudentMainPage AddLetterGrade(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		Link CourseTableCell = new Link("CourseTableCell", byXPath("//td[. = '"+data.get("Course")+"']"));
		Link CourseStatusTableCell = new Link("CourseStatusTableCell", byXPath("//td[8]"));
		Link LetterGradeSpan = new Link("LetterGradeSpan", byXPath("//div[2]/cmc-drop-down-list/div/div/span//span[2]"));
		Link CourseSpan = new Link("CourseSpan", byXPath("//span[. = '"+data.get("Course")+"']"));
		Button FinalGrades = new Button("FinalGrades", byXPath("//button[. = 'Final Grades']"));
		Dropbox LetterGradeDropBox = new Dropbox("LetterGradeDropBox", byXPath("//li[. = '"+data.get("LetterGrade")+"']"));
		Button Save = new Button("Save", byXPath("//ng-transclude/cmc-toolbar/section/cmc-toolbar-button-save//button"));
		Button PostGrade = new Button("PostGrade", byXPath("//button[@id='confirmPostGradeWindowOkButton']"));


		waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		StudentCourses.waitTillElementClickable();
		StudentCourses.click();
		waitForPageToLoad();
		CustomAsserts.containsString(CourseTableCell.getText(), data.get("Course").toString());
		//CustomAsserts.containsString(CourseStatusTableCell.getText(), data.get("CourseStatus").toString());
		Input.click();
		CourseSpan.click();
		waitForPageToLoad();
		scrollPage(0, -200);
		FinalGrades.waitTillElementClickable();
		FinalGrades.click();
		wait(6);
		scrollPage(0, 200);
		LetterGradeSpan.waitTillElementClickable();
		LetterGradeSpan.click();
		wait(2);
		LetterGradeDropBox.click();
		scrollPage(0, -200);
		Save.click();
		wait(3);
		if (PostGrade.isElementPresent()) {
			PostGrade.click();       
		} 
		waitForPageToLoad();
		scrollPage(0, -400);
		CustomAsserts.containsString(CourseStatusTableCell.getText(), data.get("CourseStatusAfterAddingLetterGrade").toString());	
		return this;

	}

	public StudentMainPage CreateStudentAndEnrollment(StringHash data) throws Exception{

		int PhoneNumber = AppendValue.apendNumber();	
		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		TextField FirstName = new TextField("FirstName", byCSSSelector("#firstName"));
		TextField LastName = new TextField("LastName", byCSSSelector("#lastName"));
		TextField TitleSpan = new TextField("TitleSpan", byXPath("//cmc-collapse/div/div[2]/div[3]/cmc-drop-down-list/div/div/span/span/span/span"));
		Dropbox Title = new Dropbox("Title", byXPath("//li[. = '"+data.get("Title")+"']"));
		TextField GenderSPan = new TextField("GenderSPan", byXPath("//div[3]/div[3]/cmc-drop-down-list/div/div/span/span/span/span"));
		Dropbox Gender = new Dropbox("Gender", byXPath("//span[. = '"+data.get("Gender")+"']"));
		TextField MaritalStatusSpan = new TextField("MaritalStatusSpan", byXPath("//div[5]/div[2]/cmc-drop-down-list/div/div/span//span[2]"));
		Dropbox MaritalStatus = new Dropbox("MaritalStatus", byXPath("//span[. = '"+data.get("MaritalStatus")+"']"));
		TextField DateOfBirth = new TextField("DateOfBirth", byCSSSelector("#dateOfBirth"));
		TextField Nationality = new TextField("Nationality", byCSSSelector("[name='nationality_input']"));
		TextField Citizenship = new TextField("Citizenship", byXPath("(//input[@aria-label='citizen'])[1]"));
		TextField HomeCampusSpan = new TextField("HomeCampusSpan", byXPath("//div[4]/cmc-multi-select/div/div/div[1]/div"));
		Dropbox HomeCampus = new Dropbox("HomeCampus", byXPath("//li[. = '"+data.get("HomeCampus")+"']"));
		Dropbox ContactInformation = new Dropbox("ContactInformation", byXPath("//cns-student-contact-information/section/div/cmc-collapse/div/div[1]/div//div"));
		TextField PhoneNum = new TextField("PhoneNum", byCSSSelector("#phoneNumber"));
		TextField EmailAddress = new TextField("EmailAddress", byCSSSelector("#emailAddress"));
		TextField StreetAddress = new TextField("StreetAddress", byCSSSelector("#streetAddress"));
		TextField City = new TextField("City", byCSSSelector("#city"));
		TextField StateSpan = new TextField("StateSpan", byXPath("//div/div/div[7]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
		Dropbox State = new Dropbox("State", byXPath("//div/div/div//span[. = '"+data.get("State")+"']"));
		TextField ZipCode = new TextField("ZipCode", byCSSSelector("[name='zipCode_input']"));
		TextField SectionSpan = new TextField("SectionSpan", byXPath("//section/div/div/div[2]/div"));
		Dropbox RecruitInformation = new Dropbox("RecruitInformation", byXPath("//cns-student-recruiting/section/div/cmc-collapse/div/div[1]/div//div"));
		TextField ProspectSourceSpan = new TextField("ProspectSourceSpan", byXPath("//cns-student-recruiting/section/div/cmc-collapse/div/div[2]/div/div[2]/cmc-multi-select/div/div/div[1]/div"));
		Checkbox ProspectSource = new Checkbox("ProspectSource", byXPath("//li[3]//input"));
		Button Select = new Button("Select", byCSSSelector("#leadVendorSubVendorOkButton"));
		TextField ProspectTypeSpan = new TextField("ProspectTypeSpan", byXPath("//cns-student-recruiting/section/div/cmc-collapse/div/div[2]/div/div[2]/cmc-drop-down-list/div/div/span/span/span/span"));
		Dropbox ProspectType = new Dropbox("ProspectType", byXPath("//span[1][. = '"+data.get("ProspectType")+"']"));
		Button AdminRep = new Button("AdminRep", byCSSSelector("#search_display_recruitAssignedAdmissionsRep"));
		TextField SearchNameAdminRep = new TextField("SearchNameAdminRep", byXPath("//input[@placeholder = 'Search Name']"));
		Checkbox Input = new Checkbox("Input", byXPath("//td/input"));
		Button Select1 = new Button("Select1", byXPath("//div/button[. = 'Select']"));
		TextField ProgramSpan = new TextField("ProgramSpan", byXPath("//cns-student-recruiting/section/div/cmc-collapse/div/div[2]/div/div[4]/cmc-multi-select/div/div/div[1]/div"));
		Dropbox Program = new Dropbox("Program", byXPath("//li[. = '"+data.get("Program")+"']"));
		TextField ExpectedStartDate = new TextField("ExpectedStartDate", byCSSSelector("#recruitExpectedStartDate"));
		Button Save = new Button("Save", byXPath("//cmc-toolbar-button-save//button"));
		Link AdmissionsSpan = new Link("AdmissionsSpan", byXPath("//cns-panel-bar/ul/li[2]/span"));
		Link StudentApplications = new Link("StudentApplications", byXPath("//span[. = 'Student Applications']"));
		Link New = new Link("New", byXPath("//a[5][. = 'New']"));
		Link ApplicationTypeSpan = new Link("ApplicationTypeSpan", byXPath("//div[1]/cmc-drop-down-list[2]/div/div/span/span/span/span"));
		Dropbox ApplicationType = new Dropbox("ApplicationType", byXPath("//span[. = '"+data.get("ApplicationType")+"']"));
		Link ProgramCodeSpan = new Link("ProgramCodeSpan", byXPath("//div[2]/cmc-drop-down-list/div/div/span//span[2]"));
		Dropbox ProgramCode = new Dropbox("ProgramCode", byXPath("//span[. = '"+data.get("ProgramCode")+"']"));
		Link ProgramVersionCodeSpan = new Link("ProgramVersionCodeSpan", byXPath("//cns-student-applicant-pending-enrollment-information-detail/section/div/cmc-collapse/div/div[2]/div/div[3]/cmc-drop-down-list/div/div/span/span/span/span"));
		Dropbox ProgramVersionCode = new Dropbox("ProgramVersionCode", byXPath("//span[. = '"+data.get("ProgramVersionCode")+"']"));
		Link VersionStartDate = new Link("VersionStartDate", byXPath("//cns-student-applicant-pending-enrollment-information-detail/section/div/cmc-collapse/div/div[2]/div/div[5]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
		Dropbox VersionStartDateDropBox = new Dropbox("VersionStartDateDropBox", byXPath("//span[2][. = '"+data.get("VersionStartDate")+"']"));
		Link StudentStatusSpan = new Link("StudentStatusSpan", byXPath("//cns-student-applicant-date-and-student-status-detail/section/div/cmc-collapse/div/div[2]/div/div[3]/cmc-drop-down-list/div/div/span//span[2]"));
		Dropbox StudentStatus = new Dropbox("StudentStatus", byXPath("//span[. = '"+data.get("StudentStatus")+"']"));
		Button Save1 = new Button("Save1", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save//button"));
		Link EnrollmentSpan = new Link("EnrollmentSpan", byXPath("//li[3]/div/div[1]/div"));
		Button Use = new Button("Use", byCSSSelector("#applicantRecordDialogOkButton"));
		Button Next = new Button("Next", byXPath("//div[2]/button[. = 'Next']"));
		Link StudentStatusSpan1 = new Link("StudentStatusSpan1", byXPath("//cns-new-student-enrollment-period-program-selection-detail/section/div/cmc-collapse/div/div[2]/div[1]/cmc-drop-down-list-classic[2]/div/div/span/span/span/span"));
		Dropbox StudentStatus1 = new Dropbox("StudentStatus1", byXPath("//span[. = '"+data.get("StudentStatus1")+"']"));
		Link ProgramLanguage = new Link("ProgramLanguage", byXPath("//cmc-drop-down-list-classic[7]/div/div/span/span/span/span"));
		Dropbox ProgramLanguageDropbox = new Dropbox("ProgramLanguageDropbox", byXPath("//span[. = '"+data.get("ProgramLanguage")+"']"));
		Link GradeLevelSpan = new Link("GradeLevelSpan", byXPath("//cmc-drop-down-list-classic[8]/div/div/span//span[2]"));
		Dropbox GradeLevel = new Dropbox("GradeLevel", byXPath("//span[. = '"+data.get("GradeLevel")+"']"));
		Link BillingMethodSpan = new Link("BillingMethodSpan", byXPath("//cmc-drop-down-list[2]/div/div/span//span[2]"));
		Dropbox BillingMethod = new Dropbox("BillingMethod", byXPath("//span[. = '"+data.get("BillingMethod")+"']"));
		TextField EnrollmentDate = new TextField("EnrollmentDate", byXPath("//cmc-date-picker[2]//input[@placeholder = 'MM/DD/YYYY']"));
		Button Next1 = new Button("Next1", byXPath("//div[5]/button[. = 'Next']"));
		Button Next2 = new Button("Next2", byXPath("//div[2]/button[. = 'Next']"));
		Button Next3 = new Button("Next3", byXPath("//button[. = 'Next']"));
		Link Enroll = new Link("Enroll", byXPath("//cmc-common-toolbar[2]//a[. = 'Enroll']"));
		TextField StudentFinalStatus = new TextField("StudentFinalStatus", byXPath("//td[text()='"+data.get("StudentStatus1")+"']"));



		waitForPageToLoad();
		FirstName.click();
		FirstName.clearAndType(AppendValue.apendString().toString());
		//FirstName.clearAndType(data.get("FirstName").toString());
		LastName.click();
		wait(3);
		//LastName.clearAndType(data.get("LastName").toString());
		LastName.clearAndType(AppendValue.apendString().toString());
		TitleSpan.click();
		wait(2);
		Title.click();
		GenderSPan.click();
		wait(2);
		Gender.click();
		MaritalStatusSpan.click();
		wait(2);
		MaritalStatus.click();
		DateOfBirth.click();
		DateOfBirth.clearAndType(data.get("DateOfBirth").toString());
		Nationality.click();
		Nationality.clearAndType(data.get("Nationality").toString());
		Citizenship.click();
		Citizenship.clearAndType(data.get("Citizenship").toString());
		HomeCampusSpan.click();
		wait(2);
		HomeCampus.click();
		scrollPage(0, 350);
		ContactInformation.click();
		wait(2);
		scrollPage(0, 100);
		PhoneNum.click();
		//PhoneNum.sendKeys(PhoneNumber);
		//PhoneNum.e
		//PhoneNum.sendKeys(PhoneNumber)
		//PhoneNum.type(PhoneNumber.toInt());
		PhoneNum.type(data.get("PhoneNum").toString());
		//PhoneNum.typeNum(AppendValue.apendNumber();
		//PhoneNum.sendKeys(AppendValue.apendNumber());
		EmailAddress.click();
		wait(6);
		EmailAddress.clearAndType(data.get("EmailAddress").toString());
		scrollPage(0, 250);
		StreetAddress.click();
		wait(2);
		StreetAddress.clearAndType(data.get("StreetAddress").toString());
		City.click();
		City.clearAndType(data.get("City").toString());
		StateSpan.click();
		wait(2);
		State.click();
		wait(3);
		ZipCode.click();
		ZipCode.clearAndType(data.get("ZipCode").toString());
		SectionSpan.click();
		RecruitInformation.click();
		scrollPage(0, 400);
		wait(2);
		ProspectSourceSpan.click();
		wait(2);
		ProspectSource.click();
		wait(2);
		Select.click();
		wait(2);
		ProspectTypeSpan.click();
		wait(1);
		ProspectType.click();
		wait(1);
		AdminRep.click();
		wait(3);
		SearchNameAdminRep.click();
		SearchNameAdminRep.clearAndType(data.get("SearchNameAdminRep").toString());
		wait(2);
		Input.click();
		wait(1);
		Select1.click();
		wait(1);
		ProgramSpan.click();
		wait(1);
		Program.click();
		ExpectedStartDate.click();
		ExpectedStartDate.clearAndType(data.get("ExpectedStartDate").toString());
		wait(2);
		Save.click();
		waitForPageToLoad();
		AdmissionsSpan.click();
		StudentApplications.click();
		wait(5);
		New.click();
		waitForPageToLoad();
		scrollPage(0, 400);
		ApplicationTypeSpan.click();
		wait(1);
		ApplicationType.click();
		ProgramCodeSpan.click();
		wait(1);
		ProgramCode.click();
		ProgramVersionCodeSpan.click();
		wait(1);
		ProgramVersionCode.click();
		wait(3);
		scrollPage(0, 200);
		VersionStartDate.click();
		wait(1);
		VersionStartDateDropBox.click();
		wait(3);
		scrollPage(0, 400);
		StudentStatusSpan.click();
		wait(2);
		StudentStatus.click();
		wait(2);
		scrollPage(0, -500);
		Save1.click();
		waitForPageToLoad();
		AcademicRecords.click();
		EnrollmentSpan.click();
		waitForPageToLoad();
		New.click();
		waitForPageToLoad();
		Use.click();
		wait(3);
		Next.click();
		wait(5);
		StudentStatusSpan1.click();
		wait(1);
		StudentStatus1.click();
		ProgramLanguage.click();
		wait(1);
		ProgramLanguageDropbox.click();
		GradeLevelSpan.click();
		wait(1);
		GradeLevel.click();
		scrollPage(0, 200);
		BillingMethodSpan.click();
		wait(1);
		BillingMethod.click();
		EnrollmentDate.click();
		EnrollmentDate.clearAndType(data.get("EnrollmentDate").toString());
		Next1.click();
		wait(4);
		Next2.click();
		wait(2);
		Next3.click();
		wait(2);
		Enroll.click();
		waitForPageToLoad();
		CustomAsserts.containsString(StudentFinalStatus.getText(), data.get("StudentStatus1").toString());	
		return this;

	}


	public StudentMainPage AddTasks(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		//Link ContactManager = new Link("ContactManager", byXPath("(//li[1]/span)[5]"));
		//Link ContactManager = new Link("ContactManager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
		//Link TasksSpan = new Link("TasksSpan", byXPath("//span[text()='Tasks']"));
		Button New = new Button("New", byXPath("//button[5][. = 'New']"));
		Button TaskTemplateSpan = new Button("TaskTemplateSpan", byXPath("(//button[@aria-label='expand combobox']/span[1])[2]"));
		//Dropbox TaskTemplateDropDown = new Dropbox("TaskTemplateDropDown", byXPath("//span[. = '"+data.get("TaskTemplate")+"']"));
		Dropbox TaskTemplateDropDown = new Dropbox(data.get("TaskTemplate"), byXPath("//span[. = '"+data.get("TaskTemplate")+"']"));
		TextField Subject = new TextField("Subject", byCSSSelector("[name='subject']"));
		Button StatusSpan = new Button("StatusSpan", byXPath("//div[8]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		//Dropbox Status = new Dropbox("Status", byXPath("//div/span[. = '"+data.get("Status")+"']"));
		Dropbox Status = new Dropbox(data.get("Status"), byXPath("//div/span[. = '"+data.get("Status")+"']"));
		Button SaveAndClose = new Button("SaveAndClose", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
		Link TaskSubjectTableCell = new Link("TaskSubjectTableCell", byXPath("//td[1][. = '"+data.get("TaskTemplate")+"']"));

		//waitForPageToLoad();
		//ContactManager.waitTillElementIsStale();
		//ContactManager.waitTillElementClickableNew();
		wait(10);
		ContactManager.waitTillElementClickable();
		ContactManager.click();
		wait(2);
		TasksSpan.click();
		wait(10);
		New.click();
		waitForPageToLoad();
		TaskTemplateSpan.click();
		wait(2);
		TaskTemplateDropDown.click();
		wait(5);
		Subject.click();
		scrollPage(0, 300);
		StatusSpan.click();
		wait(2);
		Status.click();
		scrollPage(0, -400);
		SaveAndClose.click();
		waitForPageToLoad();
		scrollPage(0, -300);
		CustomAsserts.containsString(TaskSubjectTableCell.getText(), data.get("TaskTemplate").toString());
		return this;
	}


	public StudentMainPage ConfirmPendingTasks(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		//Link ContactManager = new Link("ContactManager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
		//Link TasksSpan = new Link("TasksSpan", byXPath("//li[1]/div/div[1]/div"));
		Button New = new Button("New", byXPath("//a[5][. = 'New']"));
		Button TaskTemplateSpan = new Button("TaskTemplateSpan", byXPath("//cns-student-task-form/div/div[2]/cmc-drop-down-list/div/div/span//span[2]"));
		Dropbox TaskTemplateDropDown = new Dropbox(data.get("TaskTemplate"), byXPath("//span[. = '"+data.get("TaskTemplate")+"']"));
		TextField Subject = new TextField("Subject", byCSSSelector("[name='subject']"));
		Button StatusSpan = new Button("StatusSpan", byXPath("//div[8]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		Dropbox Status = new Dropbox(data.get("Status"), byXPath("//div/span[. = '"+data.get("Status")+"']"));
		Button SaveAndClose = new Button("SaveAndClose", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
		Link TaskSubjectTableCell = new Link("TaskSubjectTableCell", byXPath("//td[1][. = '"+data.get("TaskTemplate")+"']"));
		Link TaskStatusTableCell = new Link("TaskStatusTableCell", byXPath("(//td/span[text()='"+data.get("Status")+"'])[1]"));

		//waitForPageToLoad();
		wait(8);
		ContactManager.waitTillElementClickable();
		ContactManager.click();
		wait(2);
		TasksSpan.click();
		wait(6);
		CustomAsserts.containsString(TaskSubjectTableCell.getText(), data.get("TaskTemplate").toString());
		CustomAsserts.containsString(TaskStatusTableCell.getText(), data.get("Status").toString());
		return this;

	}

	public StudentMainPage EditTasks(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		//Link ContactManager = new Link("ContactManager", byXPath("//ul[@id='studentTilesPanelBar']//li[1]/span"));
		//Link TasksSpan = new Link("TasksSpan", byXPath("//li[1]/div/div[1]/div"));
		Button New = new Button("New", byXPath("//a[5][. = 'New']"));
		Button TaskTemplateSpan = new Button("TaskTemplateSpan", byXPath("//cns-student-task-form/div/div[2]/cmc-drop-down-list/div/div/span//span[2]"));
		Dropbox TaskTemplateDropDown = new Dropbox(data.get("TaskTemplate"), byXPath("//span[. = '"+data.get("TaskTemplate")+"']"));
		TextField Subject = new TextField("Subject", byCSSSelector("[name='subject']"));
		Button StatusSpan = new Button("StatusSpan", byXPath("//div[8]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		//Dropbox Status = new Dropbox(data.get("Status"), byXPath("//div/span[. = '"+data.get("Status")+"']"));
		Link Status = new Link("StatusDropdownValue", byXPath("//div/ul[@id='taskStatusId_listbox']/li[2]"));
		Button SaveAndClose = new Button("SaveAndClose", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
		Link TaskSubjectTableCell = new Link("TaskSubjectTableCell", byXPath("//td[1][. = '"+data.get("TaskTemplate")+"']"));
		Link TaskLink = new Link(data.get("TaskTemplate"), byXPath("//a[. = '"+data.get("TaskTemplate")+"']"));
		TextField Note = new TextField("Note", byCSSSelector("[name='noteTextArea']"));
		//Link TaskStatusTableCell1 = new Link("TaskStatusTableCell", byXPath("//td[. = '"+data.get("Status")+"']"));

		String NoteValue = AppendValue.apendString();

		//waitForPageToLoad();
		wait(8);
		ContactManager.waitTillElementClickable();
		ContactManager.click();
		wait(2);
		TasksSpan.click();
		wait(10);
		//TaskLink.waitTillElementClickable();
		TaskLink.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		scrollPage(0, 500);
		StatusSpan.click();
		wait(2);
		Status.click();
		wait(2);
		String StatusValue = Status.getTextValue();
		//Status.get
		TestReportsLog.log(LogStatus.INFO, "Task Status Value is selected as "+StatusValue);
		Note.click();
		Note.clearAndType(NoteValue.toString());
		scrollPage(0, -500);
		SaveAndClose.click();
		waitForPageToLoad();
		scrollPage(0, -500);	
		TestReportsLog.log(LogStatus.PASS, "The Task Records are successfully saved.");
		//Link TaskNotesTableCell = new Link("TaskNotesTableCell", byXPath("//td[text()='"+NoteValue+"']"));
		//CustomAsserts.containsString(TaskStatusTableCell1.getText(), data.get("Status").toString());
		//CustomAsserts.containsString(TaskNotesTableCell.getText(), NoteValue.toString());
		return this;

	}

	public StudentMainPage CloseTask(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		Link ContactManager = new Link("ContactManager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
		Link TasksSpan = new Link("TasksSpan", byXPath("//span[text()='Tasks']"));
		Button New = new Button("New", byXPath("//a[5][. = 'New']"));
		Button TaskTemplateSpan = new Button("TaskTemplateSpan", byXPath("//cns-student-task-form/div/div[2]/cmc-drop-down-list/div/div/span//span[2]"));
		Dropbox TaskTemplateDropDown = new Dropbox(data.get("TaskTemplate"), byXPath("//span[. = '"+data.get("TaskTemplate")+"']"));
		TextField Subject = new TextField("Subject", byCSSSelector("[name='subject']"));
		Button StatusSpan = new Button("StatusSpan", byXPath("//div[8]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		Dropbox Status = new Dropbox(data.get("Status"), byXPath("//div/span[. = '"+data.get("Status")+"']"));
		Button SaveAndClose = new Button("SaveAndClose", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
		Link TaskSubjectTableCell = new Link("TaskSubjectTableCell", byXPath("//td[1][. = '"+data.get("TaskTemplate")+"']"));
		Link TaskLink = new Link("TaskLink", byXPath("//a[. = '"+data.get("TaskTemplate")+"']"));
		Button ActivityResultSpan = new Button("ActivityResultSpan", byXPath("//div[9]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		//Dropbox ActivityResultDropDown = new Dropbox(data.get("ActivityResult"), byXPath("//span[. = '"+data.get("ActivityResult")+"']"));
		Link ActivityResultDropDown = new Link("Activity result", byXPath("//div/ul[@id='taskResultId_listbox']/li[1]"));
		TextField Note = new TextField("Note", byCSSSelector("[name='noteTextArea']"));
		String NoteValue = AppendValue.apendString();

		//waitForPageToLoad();
		wait(8);
		ContactManager.waitTillElementClickable();
		ContactManager.click();
		wait(2);
		TasksSpan.click();
		wait(10);
		//TaskLink.waitTillElementClickable();
		TaskLink.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		scrollPage(0, 500);
		StatusSpan.click();
		wait(2);
		Status.click();
		wait(2);
		ActivityResultSpan.click();
		wait(2);
		ActivityResultDropDown.click();
		wait(2);
		String ActivityResultValue = ActivityResultDropDown.getTextValue();
		//JavascriptExecutor jse = (JavascriptExecutor)driver;
		//String ActivityResultValue = (String) jse.executeScript("return arguments[0].innerHTML;", ActivityResultDropDown);
		//String ActivityResultValue = jse.executeScript(" return document.getElementByXPath('//div/ul[@id='taskResultId_listbox']/li[1]').innerHTML").toString();
		TestReportsLog.log(LogStatus.INFO, "Activity result Value is selected as "+ActivityResultValue);
		Note.click();
		Note.clearAndType(NoteValue.toString());
		scrollPage(0, -400);
		SaveAndClose.click();
		waitForPageToLoad();
		scrollPage(0, -400);	
		Link TaskNotesTableCell = new Link("TaskNotesTableCell", byXPath("//td[text()='"+NoteValue+"']"));
		//CustomAsserts.containsString(TaskStatusTableCell1.getText(), data.get("Status").toString());
		CustomAsserts.containsString(TaskNotesTableCell.getText(), NoteValue.toString());
		return this;

	}



	public StudentMainPage UpdatingAdminRep(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));	
		Link RecruitInformationSpan = new Link("RecruitInformationSpan", byXPath("//cns-student-recruiting/section/div/cmc-collapse/div/div[1]/div//div"));
		TextField AdminRepSpan = new TextField("AdminRepSpan", byXPath("//cns-student-recruiting/section/div/cmc-collapse/div/div[2]/div/div[3]/cmc-search/dl/dd[1]/cmc-search-display/div/div"));
		TextField SearchBox = new TextField("SearchBox", byCSSSelector("#search"));
		//Link AdminRepCheckBox = new Link("AdminRepCheckBox", byXPath("//div/cmc-grid/div/div/div[2]//input"));
		Link AdminRepCheckBox1 = new Link("AdminRepCheckBox", byXPath("(//input[@class='check-box styled-checkbox serach-control'])[1]"));
		Link AdminRepCheckBox2 = new Link("AdminRepCheckBox", byXPath("(//input[@class='check-box styled-checkbox serach-control'])[2]"));
		Button Select = new Button("Select", byXPath("(//button[text()='Select'])[1]"));
		Button Save = new Button("Save", byXPath("//button[@aria-label='Save']"));
		Button SaveAgain = new Button("SaveAgain", byXPath("//button[@id='reassignLeadSaveButton']"));
		Link StatusTableCell = new Link("StatusTableCell", byXPath("//span[. = 'The Student records were successfully saved.']"));
		Link Name = new Link("Name", byXPath("(//th[@data-title='Name'])[1]"));

		waitForPageToLoad();
		scrollPage(0, 600);
		RecruitInformationSpan.waitTillElementClickable();
		RecruitInformationSpan.click();
		wait(4);
		scrollPage(0, 300);	
		AdminRepSpan.clickUsingJavaScriptExecutor();
		wait(13);
		SearchBox.clickUsingJavaScriptExecutor();
		//SearchBox.clearAndType(data.get("AdminRep").toString());
		wait(5);
		//	Name.click();
		//	wait(4);
		if(AdminRepCheckBox1.isSelected()){
			//wait(2);
			//SearchBox.click();
			//SearchBox.clearAndType(data.get("AdminRep1").toString());
			wait(2);
			AdminRepCheckBox1.click();
			wait(2);
			AdminRepCheckBox2.click();
			scrollPage(0,50);
			wait(5);
			Select.clickUsingJavaScriptExecutor();
			//Cancel.click();
			TestReportsLog.log(LogStatus.INFO, "Admin Rep is selected");
		}
		else {
			wait(3);
			AdminRepCheckBox1.click();
			wait(2);
			Select.clickUsingJavaScriptExecutor();
			TestReportsLog.log(LogStatus.INFO, "Admin Rep is selected");
		}
		wait(6);
		scrollPage(0, -600);
		Save.click();
		wait(8);
		//SaveAgain.click();
		SaveAgain.clickUsingJavaScriptExecutor();
		wait(10);
		CustomAsserts.containsString(StatusTableCell.getText(), data.get("StatusAfterClosing").toString());
		return this;

	}



	public StudentMainPage VerifySMSConfiguration(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));
		Link ContactInformationSpan = new Link("ContactInformationSpan", byXPath("//cns-student-contact-information/section/div/cmc-collapse/div/div[1]/div//div"));
		//Link SubscribeToSMSCheckBox = new Link("SubscribeToSMS", byXPath("(//div[3]/cmc-checkbox//label)[1]"));
		Link SubscribeToSMSCheckBox = new Link("SubscribeToSMS", byXPath("//label[@for='subscribeToSms']"));
		TextField SMSServiceProvider = new TextField("SMSServiceProvider", byCSSSelector("[name='smsProvider_input']"));
		Link SMSServiceProviderList = new Link("SMSServiceProviderList", byXPath("//li[. = '"+SMSServiceProviderValue+"']"));
		Button Save = new Button("Save", byXPath("//cmc-toolbar-button-save//button"));
		Button Save1 = new Button("Save", byXPath("//button[@id='oldAddressSaveButton']"));
		Link SuccessMessageSpan = new Link("SuccessMessageSpan", byXPath("//span[. = 'The Student records were successfully saved.']"));
		TextField MobileNum = new TextField("MobileNum", byXPath("//input[@id='mobileNumber']"));
		Button SaveAgain = new Button("SaveAgain", byXPath("//button[@id='oldAddressSaveButton']"));
		TextField AddressType = new TextField("AddressType", byXPath("//input[@name='oldAddrAddressType_input']"));
		Link AddressTypeValue = new Link("AddressTypeValue", byXPath("//span[text()='"+data.get("AddressType")+"']"));


		waitForPageToLoad();
		scrollPage(0, 600);
		ContactInformationSpan.click();
		wait(3);
		scrollPage(0, 300);
		wait(3);
		if(SubscribeToSMSCheckBox.isSelected()) {
			wait(2);
			SMSServiceProvider.click();
			wait(2);
			SMSServiceProvider.clearAndType(SMSServiceProviderValue.toString());
			wait(2);
			SMSServiceProviderList.click();
			wait(3);
		}
		else
		{
			SubscribeToSMSCheckBox.clickUsingJavaScriptExecutor();
			wait(2);
			SMSServiceProvider.click();
			wait(2);
			SMSServiceProvider.clearAndType(SMSServiceProviderValue.toString());
			wait(2);
			SMSServiceProviderList.click();
			wait(3);	
		}
		wait(2);
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		jsExecutor.executeScript("document.getElementById('mobileNumber').value='4567890123'");
		wait(3);
		Save.clickUsingJavaScriptExecutor();
		wait(10);
		if(AddressType.isDisplayed()){
			AddressType.click();
			wait(2);
			AddressType.clearAndType(data.get("AddressType").toString());
			wait(2);
			AddressTypeValue.click();
			wait(2);
			Save1.clickUsingJavaScriptExecutor();
			wait(8);
			//CustomAsserts.containsString(SuccessMessageSpan.getText(), data.get("SuccessMessageSpan").toString());
		}
		//CustomAsserts.containsString(SuccessMessageSpan.getText(), data.get("SuccessMessageSpan").toString());
		return this;

	}


	public StudentMainPage AddSchoolFields(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));

		Link FinancialAidSpan = new Link("FinancialAidSpan", byXPath("//cns-panel-bar/ul/li[5]/a/span"));
		Link SchoolFieldsSpan = new Link("SchoolFieldsSpan", byXPath("(//span[text()='School Fields'])[4]"));
		Link VeterinarianTypePrefereranceSpan = new Link("VeterinarianTypePrefereranceSpan", byXPath("//div[5]/div[1]/div/div/cmc-drop-down-list-classic/div/div/span//span[2]"));
		//Link VeterinarianTypePrefereranceDropDown = new Link(data.get("VeterinarianTypePrefererance"), byXPath("//li[. = '"+data.get("VeterinarianTypePrefererance")+" ']"));
		Link VeterinarianTypePrefereranceDropDown = new Link("VeterinarianTypePrefererance", byXPath("//div/ul[@id='VTP_listbox']/li[2]"));
		Link LeftHandedSpan = new Link("LeftHandedSpan", byXPath("//cmc-multi-select/div/div/div[1]/div"));
		//Link LeftHandedDropDown = new Link(data.get("LeftHanded"), byXPath("//div[2]//li[. = '"+data.get("LeftHanded")+"']"));
		Link LeftHandedDropDown = new Link("LeftHandedDropDown", byXPath("//div/ul[@id='LeftHand_listbox']/li[1]"));
		TextField FavoriteBrewPub = new TextField("FavoriteBrewPub", byCSSSelector("#BREWPUB"));
		TextField NYTAP = new TextField("NYTAP", byCSSSelector("#NYTP"));
		Button Save = new Button("Save", byXPath("//div[3]/cmc-toolbar/section/cmc-toolbar-button-save//button"));
		Link SuccessMessageSpan = new Link("SuccessMessageSpan", byXPath("//span[. = 'The Student records were successfully saved.']"));

		String Favorite = AppendValue.apendString();
		String NYTAPValue = AppendValue.apendString();

		//waitForPageToLoad();
		wait(8);
		FinancialAidSpan.waitTillElementClickable();
		FinancialAidSpan.click();
		wait(2);
		scrollPage(0, 200);
		SchoolFieldsSpan.click();
		waitForPageToLoad();
		//	VeterinarianTypePrefereranceSpan.click();
		//	wait(2);
		//	VeterinarianTypePrefereranceDropDown.click();
		//	String VeterinarianTypePrefereranceValue = VeterinarianTypePrefereranceDropDown.getText();
		//	TestReportsLog.log(LogStatus.INFO, "VeterinarianTypePrefererance is selected as "+VeterinarianTypePrefereranceValue);
		//	wait(2);
		//	LeftHandedSpan.click();
		//	wait(2);
		//	LeftHandedDropDown.click();
		//	String LeftHandedValue = LeftHandedDropDown.getText();
		//	TestReportsLog.log(LogStatus.INFO, "LeftHandedValue is selected as "+LeftHandedValue);
		//	wait(2);	
		//	FavoriteBrewPub.click();
		//	FavoriteBrewPub.clearAndType(Favorite.toString());
		//	wait(2);
		//	NYTAP.click();
		//	NYTAP.clearAndType(NYTAPValue.toString());
		wait(2);
		scrollPage(0, -500);
		Save.clickUsingJavaScriptExecutor();
		wait(6);
		CustomAsserts.containsString(SuccessMessageSpan.getText(), data.get("SuccessMessageSpan").toString());	
		//CustomAsserts.containsString(StatusTableCell.getText(), data.get("StatusAfterClosing").toString());
		return this;

	}



	public StudentMainPage ScheduleStudentPaymentPlan(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));

		
		Link PaymentScheduleSpan = new Link("PaymentScheduleSpan", byXPath("//span[. = 'Payment Schedule']"));
		Link New = new Link("New", byXPath("//button[. = 'New']"));
		Button AwardYearSpan = new Button("AwardYearSpan", byXPath("//span[@aria-label='Award Year']"));
		//TextField AwardYear = new TextField("AwardYear", byXPath("//div[45]//input"));
		TextField AwardYear = new TextField("AwardYear", byXPath("//input[@aria-controls='awardYearId_listbox']"));
		Link AwardYearDropDown = new Link(data.get("AwardYear"), byXPath("//li/span[text()='"+data.get("AwardYear")+"']"));
		Link FundSourceSpan = new Link("FundSourceSpan", byXPath("//div[4]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		//TextField FundSource = new TextField("FundSource", byXPath("//div[48]//input"));
		TextField FundSource = new TextField("FundSource", byXPath("//input[@aria-controls='sourceId_listbox']"));
		//Link FundSourceDropDown = new Link(data.get("FundSource"), byXPath("//span[. = '"+data.get("FundSource")+"    ']"));
		Link FundSourceDropDown = new Link(data.get("FundSource"), byXPath("(//ul[@id='sourceId_listbox']/li[1]/span/div/span)[1]"));
		TextField GrossAmountSpan = new TextField("GrossAmount", byXPath("//cmc-numeric-input-text/div/div/span/span"));
		TextField GrossAmount = new TextField("GrossAmount", byXPath("(//input[@aria-label='Gross Amount'])[1]"));
		Link StatusSpan = new Link("StatusSpan", byXPath("(//span[@aria-label=\"select\"]/span[1])[6]"));
		Link StatusDropDown = new Link(data.get("Status"), byXPath("//li/span[. = '"+data.get("Status")+"']"));
		Button Proceed = new Button("Proceed", byXPath("//button[. = 'Proceed']"));
		Link Calculate = new Link("Calculate", byXPath("//button[@id='calculateButton']"));
		Link Save = new Link("Save", byXPath("//button[@id='cashOthersSaveButton']"));
		Link PaymentScheduleCollapse = new Link("PaymentScheduleCollapse", byXPath("//div/section/div/cmc-collapse/div/div[1]/div//div"));
		Link FundSourceTableCell = new Link("FundSourceTableCell", byXPath("//a[. = '"+data.get("FundSource")+"']"));
		Link StatusTableCell = new Link("StatusTableCell", byXPath("//td[. = '"+data.get("Status")+"']"));
		Link BilledToTableCell = new Link("BilledToTableCell", byXPath("//td[. = '"+data.get("StudentName")+"']"));



		//waitForPageToLoad();
		wait(8);
		StudentAccountsSpan.waitTillElementClickable();
		StudentAccountsSpan.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0, 200);
		PaymentScheduleSpan.click();
		waitForPageToLoad();
		New.click();
		waitForPageToLoad();
		AwardYearSpan.click();
		wait(6);
		AwardYear.click();
		wait(3);
		AwardYear.clearAndType(data.get("AwardYear").toString());
		wait(2);
		AwardYearDropDown.click();
		wait(5);
		FundSourceSpan.click();
		wait(2);
		FundSource.click();
		wait(2);
		FundSource.clearAndType(data.get("FundSource").toString());
		wait(2);
		FundSourceDropDown.click();
		//wait(10);
		//GrossAmountSpan.click();
		wait(4);
		//GrossAmount.Type(data.get("GrossAmount").toString());
		GrossAmount.type(data.get("GrossAmount").toString());
		wait(2);
		StatusSpan.click();
		wait(2);
		StatusDropDown.click();
		scrollPage(0, 100);
		Proceed.click();
		waitForPageToLoad();
		wait(10);
		scrollPage(0, 300);
		wait(2);
		Calculate.click();
		wait(6);
		scrollPage(0, -400);
		Save.click();
		waitForPageToLoad();
		wait(10);
		PaymentScheduleCollapse.click();
		wait(2);
		CustomAsserts.containsString(FundSourceTableCell.getText(), data.get("FundSource").toString());
		CustomAsserts.containsString(StatusTableCell.getText(), data.get("Status").toString());
		//CustomAsserts.containsString(BilledToTableCell.getText(), data.get("StudentName").toString());	
		//CustomAsserts.containsString(StatusTableCell.getText(), data.get("StatusAfterClosing").toString());
		return this;

	}

	public StudentMainPage PerformRefundCalculation(StringHash data) throws Exception{
		//Link StudentAccountsSpan = new Link("StudentAccountsSpan", byXPath("//li[6]/span"));
		Link RefundCalculationsSpan = new Link("RefundCalculationsSpan", byXPath("//span[. = 'Refund Calculations']"));
		Link New = new Link("New", byXPath("//button[. = 'New']"));
		TextField CalculationName = new TextField("CalculationName", byCSSSelector("[name='refundCalcDescription']"));
		Button Calculate = new Button("Calculate", byXPath("//button[. = 'Calculate']"));	
		//String CalculationNameValue = "NewRefundCalculation"+AppendValue.apendString();
		String CalculationNameValue = "NewRefundCalculation"+AppendValue.apendString();
		Link CalculationTableCell = new Link("CalculationTableCell", byXPath("//a[. = '"+CalculationNameValue+"']"));
		Link Next = new Link("Next", byXPath("//button[text()='Next']"));
		Button Next1 = new Button("Next", byXPath("(//button[@id='advisorSelectionProceedButton'])[2]"));
		Button Next2 = new Button("Next", byXPath("(//button[@id='advisorSelectionProceedButton'])[3]"));
		Button Next3 = new Button("Next", byXPath("(//button[@id='advisorSelectionProceedButton'])[4]"));
		Button SaveAndClose = new Button("SaveAndClose", byXPath("(//a[@id='saveCloseButton'])[2]"));
		TextField LastDayAttended = new TextField("LastDayAttended", byXPath("//input[@name='lastDayAttended']"));
		//Button Update = new Button("Update", byXPath("//button[@id='confirmR2T4DialogOkButton']"));
		Dropbox PaymentType = new Dropbox("Payment Type", byXPath("//span[@aria-owns='periodType_listbox']"));
		Link SelectType = new Link("Select Type", byXPath("(//ul[@id='periodType_listbox']//li)[2]"));
		//bharath
		//		Link termlink = new Link("Term", byXPath("(//span[@aria-label='Term']/span)[2]/span/span"));
		//		TextField term = new TextField("term", byXPath("//input[@aria-owns='r2T4Term_listbox']"));
		//		Link selectterm = new Link("select Term", byXPath("(//span[contains(text(),'"+data.get(term)+"')])[2]"));

		//waitForPageToLoad();
		
		Button Update = new Button("Update", byXPath("//button[@aria-label='Update']"));
		
		wait(8);
		StudentAccountsSpan.waitTillElementClickable();
		StudentAccountsSpan.click();
		wait(2);
		RefundCalculationsSpan.click();
		waitForPageToLoad();
		wait(10);
		New.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(5);
		CalculationName.click();
		CalculationName.clear();
		CalculationName.type(CalculationNameValue);
		wait(2);
		LastDayAttended.click();
		wait(2);
		LastDayAttended.clearAndType(currentDate);
		//wait(4);
		//Update.click();
		//wait(3);
		//termlink.clickUsingJavaScriptExecutor();
		//wait(3);
		//term.click();
		//term.clearAndType(data.get("term"));
		//wait(3);
		//selectterm.clickUsingJavaScriptExecutor(); */
		//		wait(2);
		//		scrollPage(0, 300);
		//		wait(2);
		//		PaymentType.click();
		//		wait(2);
		//		SelectType.click();
		//		wait(2);
		
		//scrollPage(0, 200);
		wait(3);
		Calculate.clickUsingJavaScriptExecutor();
		wait(6);
		//waitForPageToLoad();
		//	scrollPage(0, 500);
		//	Next1.clickUsingJavaScriptExecutor();
		//	waitForPageToLoad();
		//	wait(10);
		//	scrollPage(0, -200);
		//	Next2.clickUsingJavaScriptExecutor();
		//	waitForPageToLoad();
		//	scrollPage(0, -200);
		//	Next3.clickUsingJavaScriptExecutor();
		//	wait(10);
		//	scrollPage(0, 500);
		//	SaveAndClose.clickUsingJavaScriptExecutor();	
		//	if(Next1.isElementDisplayed()) {
		//	   Next1.click();
		//	   //Next.clickUsingJavaScriptExecutor();
		//	   waitForPageToLoad();
		//	   wait(10);
		//	   scrollPage(0, -200);
		//	}
		//	
		//	if(Next2.isElementDisplayed()) {
		//	   Next2.click();
		//	   waitForPageToLoad();
		//	   scrollPage(0, -200);
		//	}
		//	
		//	if(Next3.isElementDisplayed()) {
		//	   Next3.click();
		//	   wait(10);
		//	   scrollPage(0, 500);
		//	}
		//		
		//	if(SaveAndClose.isElementDisplayed()) {
		//	   //if(SaveAndClose.isElementEnabled()) {
		//		SaveAndClose.click();
		//	}
		//	waitForPageToLoad();
		//	scrollPage(0, 900);	
		CustomAsserts.containsString(CalculationTableCell.getText(), CalculationNameValue.toString());
		return this;
	}

	public StudentMainPage AddingEnrollmentToStudent(StringHash data) throws Exception{

		//X-path Parameterization
		int PhoneNumber = AppendValue.apendNumber();	
		Link AdmissionsSpan = new Link("Admission", byXPath("//cns-panel-bar/ul/li[2]/span"));
		Link StudentApplications = new Link("Student Applications", byXPath("//span[. = 'Student Applications']"));
		Link New = new Link("New", byXPath("//*[@id='newButton']"));
		Link ApplicationTypeSpan = new Link("Application Type", byXPath("//div[1]/cmc-drop-down-list[2]/div/div/span/span/span/span"));
		Link ApplicationType = new Link("Application Type", byXPath("//div/div/div[3]/ul/li[1]/div/span[1]"));
		Link ProgramSpan = new Link("Program Code", byXPath("(//button[@aria-label='expand combobox'])[3]"));
		//Link ProgramCode = new Link("ProgramCode", byXPath("//span[. = '"+data.get("ProgramCode")+"']"));
		Link Program = new Link("Program Code", byXPath("(//ul[@id='ProgramId_listbox']/li//div/span[2])[1]"));
		Link Shift = new Link("Shift", byXPath("(//button[@aria-label='expand combobox'])[4]"));
		Link SelShift = new Link("Shift", byXPath("(//ul[@id='shiftId_listbox']/li[1]//div/span[2])[1]"));
		Link ProgramVersionCodeSpan = new Link("Program Version Code", byXPath("//span[@aria-controls='ProgramVersionId_listbox']/span[2]/span"));
		//Dropbox ProgramVersionCode = new Dropbox("ProgramVersionCode", byXPath("//span[. = '"+data.get("ProgramVersionCode")+"']"));
		Link ProgramVersionCode = new Link("Program Version Code", byXPath("//ul[@id='ProgramVersionId_listbox']/li[1]//div/span[2]"));
		//Link VersionStartDate = new Link("VersionStartDate", byXPath("//cns-student-applicant-pending-enrollment-information-detail/section/div/cmc-collapse/div/div[2]/div/div[5]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
		Link VersionStartDate = new Link("Version StartDate", byXPath("//span[@aria-controls='StartDateId_listbox']/span[2]/span"));
		Link SelVersionStartDate = new Link("Version StartDate", byXPath("(//ul[@id='StartDateId_listbox']/li[1]//div/span[1])[1]"));
		Link Billingcodespan = new Link("Billingcode", byXPath("(//button[@aria-label='expand combobox'])[7]"));
		Link SelBillingcodespan = new Link("Billingcode", byXPath("(//ul[@id='billingMethodId_listbox']/li[2]//div/span[2])[1]"));
		Link StudentStatusSpan = new Link("Student Status", byXPath("//cns-student-applicant-date-and-student-status-detail/section/div/cmc-collapse/div/div[2]/div/div[3]/cmc-drop-down-list/div/div/span//span[2]"));
		//Link StudentStatus = new Link("StudentStatus", byXPath("//span[. = '"+data.get("StudentStatus")+"']"));
		Button Save1 = new Button("Save1", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save//button"));
		Link EnrollmentSpan = new Link("Enrollment", byXPath("//span[text()='Enrollments']"));
		Button Use = new Button("Use", byCSSSelector("#applicantRecordDialogOkButton"));
		Button Next = new Button("Next", byXPath("//button[@id='studentSelectionProceedButton']"));
		Link StudentStatusSpan1 = new Link("Student Status", byXPath("(//button[@aria-label='expand combobox'])[2]"));
		Link SelectStudentStatus1 = new Link("Student Status", byXPath("//ul[@id='SchoolStatusId_listbox']/li[1]//div/span[2]"));
		Link GradeScalelSpan = new Link("GradeScalel", byXPath("//div[7]/cmc-drop-down-list[2]/div/div/span/span/span/span"));
		Link GradeScale = new Link("GradeScale", byXPath("//ul[@id='gradeScaleId_listbox']/li[1]/div/span[1]"));
		Link GradelevelSpan = new Link("Grade Scale", byXPath("(//button[@aria-label='expand combobox'])[5]"));
		Link Gradelevel = new Link("Grade Scale", byXPath("(//ul[@id='gradeLevelId_listbox']/li[1]//div/span[2])[1]"));
		TextField EnrollmentDate = new TextField("EnrollmentDate", byXPath("//cmc-date-picker[2]//input[@placeholder = 'MM/DD/YYYY']"));
		Button Next1 = new Button("Next1", byXPath("//button[@id='programSelectionProceedButton']"));
		Button Next2 = new Button("Next2", byXPath("//button[@id='enrollmentNumbersProceedButton']"));
		Button Next3 = new Button("Next3", byXPath("//button[. = 'Next']"));
		Button Enroll = new Button("Enroll", byXPath("(//*[@id='enrollmentPeriodSaveButton'])[2]"));
		//TextField StudentFinalStatus = new TextField("StudentFinalStatus", byXPath("//td[text()='"+data.get("StudentStatus1")+"']"));	
		Link AddEnrollmentSaveMessage = new Link("AddEnrollmentSaveMessage", byXPath("//span[. = 'The Student was successfully enrolled.']"));
		//Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		Link AdmissionsRepresentativespan = new Link("Admissions Representative", byXPath("//cns-student-applicant-date-and-student-status-detail/section/div/cmc-collapse/div/div[2]/div/div[5]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
		Link AdmissionsRepresentative = new Link("Admissions Representative", byXPath("//div[81]//li[1]"));
		Link AcademicRecords = new Link("Academic Records", byXPath("//cns-panel-bar/ul/li[3]/a/span"));
		Button DontUse = new Button("Dont use", byXPath("(//*[@id='applicantRecordDialogNotOkButton'])"));

		//Method Implementation
//		waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		EnrollmentSpan.click();
		wait(8);
		New.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
//		DontUse.clickUsingJavaScriptExecutor();
//		wait(5);
		Next.click();
		wait(5);
		StudentStatusSpan1.click();
		wait(2);
		SelectStudentStatus1.click();
		wait(2);
		String SelectStudentStaus1 = SelectStudentStatus1.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Student Status Name is selected as "+SelectStudentStaus1);
		wait(3);
		ProgramSpan.click();
		wait(2);
		Program.click();
		wait(2);
		ProgramVersionCodeSpan.click();
		wait(2);
		ProgramVersionCode.click();
		wait(3);
		scrollPage(0, 300);
		wait(2);
		VersionStartDate.click();
		wait(3);
		SelVersionStartDate.click();
		wait(10);
		Shift.click();
		wait(2);
		SelShift.click();
		String SelShiftt = SelShift.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Shift Name is selected as "+SelShiftt);
		wait(2);
		GradelevelSpan.click();
		wait(3);
		Gradelevel.click();
		String Gradelvel = Gradelevel.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Gradelevel Name is selected as "+Gradelvel);
		wait(3);
		scrollPage(0, 400);
		wait(2);
		Billingcodespan.click();
		wait(3);
		SelBillingcodespan.click();
		String SelonBillingcodespan = SelBillingcodespan.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Billing code span is selected as "+SelonBillingcodespan);
		wait(3);
		scrollPage(0, 650);
		wait(2);
		Next1.click();
		wait(2);
		Next2.click();
		wait(2);
		scrollPage(0, 50);
		Enroll.click();
		wait(5);
		CustomAsserts.containsString(AddEnrollmentSaveMessage.getText(), data.get("SuccessMessage").toString());
		System.out.println("Enrollment is added successfully");
//		wait(5);
		return this;
	}

	public StudentMainPage Batcunr(StringHash data) throws Exception{

		Link SelInstructor = new Link("Click on selctIns", byXPath("//span[@title='"+data.get("Instructor Name")+"']"));
		waitForPageToLoad();
		wait(10);
		/*MenuButton.click();
	waitForPageToLoad();
	wait(2);
	Processes.click();
	waitForPageToLoad();
	wait(2);*/
		SearchProcesses.clearAndType(data.get("Search Name").toString());
		waitForPageToLoad();
		wait(2);
		Registration.click();
		waitForPageToLoad();
		wait(5);
		Unregister.click();
		waitForPageToLoad();
		wait(3);
		Term1.click();
		wait(3);
		//Name.clearAndType(data.get("Name").toString());
		SearchTerm.clearAndType(data.get("Term Name").toString());
		//waitForPageToLoad();
		wait(2);
		//SelectSG.click();
		//wait(2);
		SelectTerm.click();
		wait(3);
		Select1.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(2);
		//scrollPage(0, 200);
		//wait(2);
		Instructor.clearAndType(data.get("Instructor Name").toString());
		wait(5);
		SelInstructor.clickUsingJavaScriptExecutor();
		wait(1);
		Next2.clickUsingJavaScriptExecutor();
		wait(2);
		allstd.clickUsingJavaScriptExecutor();
		allstd.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0, 300);
		wait(2);
		Reason.clearAndType(data.get("Reason Name").toString());
		wait(3);
		SelReas.clickUsingJavaScriptExecutor();
		wait(1);
		Queureg2.clickUsingJavaScriptExecutor();
		wait(2);
		Queue.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(2);
		return this;
	}

	public StudentMainPage RegTrack(StringHash data) throws Exception{
		waitForPageToLoad();
		wait(10);
		/*MenuButton.click();
	waitForPageToLoad();
	wait(2);
	Processes.click();
	waitForPageToLoad();
	wait(2);*/
		SearchProcesses.clearAndType(data.get("Search Name").toString());
		waitForPageToLoad();
		wait(2);
		Registration.click();
		waitForPageToLoad();
		wait(5);
		Track.click();
		waitForPageToLoad();
		wait(3);
		StudentGroup.clearAndType(data.get("Student Group Name").toString());
		wait(2);
		SelectSG.clickUsingJavaScriptExecutor();
		wait(5);
		SelectTrack.clickUsingJavaScriptExecutor();
		wait(3);
		Next1.clickUsingJavaScriptExecutor();
		wait(3);
		Checkall.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0, 200);
		Queureg.clickUsingJavaScriptExecutor();
		wait(2);
		Queue.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(2);
		return this;
	}


	public StudentMainPage PlaceStudentsIntoExternship(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));


		
		Link PlacementsInternships = new Link("Click on Placements&Internships", byXPath("//span[text()='Placements & Internships']"));
		Button New = new Button("Click New", byXPath("//*[@id='studentPlacementNewButton']"));
		Link Employer = new Link("Select Employer", byXPath("//*[@id='search_display_employerSearch']"));
		TextField SearchEmployer = new TextField("Search Employer Name", byXPath("//*[@id='search']"));
		Checkbox EmployerButton = new Checkbox("Select Employer Button", byXPath("(//input[@type='checkbox'])[2]"));
		Button Select = new Button("Select Button", byXPath("//button[text()='Select']"));
		Link JobType = new Link("Enter Job Type", byXPath("(//button[@aria-label='expand combobox'])[2]"));
		Link SelJobType = new Link("Select Job Type", byXPath("//span[. ='Internship/Externship']"));
		//static TextField PlacementStatus = new TextField("Enter Job Status", byXPath("//input[@name='placementStatus_input']"));
		//static Link SelPlacementStatus = new Link("Select Job Status", byXPath("//*[@id='0884bfb5-865a-4e2f-ab5a-efd249df6840']/div/span[1]"));
		TextField jobTitle_input = new TextField("Enter jobTitle_input'", byXPath("//input[@name='jobTitle_input']"));
		//Link SeljobTitle_input = new Link("Select jobTitle_input'", byXPath("//span[. ='Administrative']"));
		Link SeljobTitle_input = new Link("Select jobTitle_input'", byXPath("//div/ul[@id='jobTitle_listbox']/li[1]"));
		TextField InFieldofStudy = new TextField("Enter Field od Study'", byXPath("//input[@name='inFieldOfStudy_input']"));
		//Link SelInFieldofStudy = new Link("Select Field od Study'", byXPath("//span[. ='Related']"));
		Link SelInFieldofStudy = new Link("Select Field of Study'", byXPath("//div/ul[@id='inFieldOfStudy_listbox']/li[1]"));
		TextField HowPlaced = new TextField("Enter HowPlaced Value'", byXPath("//input[@name='howPlaced_input']"));
		//Link SelHowPlaced = new Link("Sel HowPlaced Value'", byXPath("//span[. ='College']"));
		Link SelHowPlaced = new Link("Sel HowPlaced Value'", byXPath("//div/ul[@id='howPlaced_listbox']/li[1]"));
		TextField SalaryAmount = new TextField("Enter Salary Amount'", byXPath("(//input[@aria-label='Salary Amount'])[1]"));
		//static Link SelSalaryAmount = new Link("Select Salary Amount'", byXPath("//*[@id='salary']/.."));
		TextField SalaryStatus = new TextField("Enter Salary Status'", byXPath("//input[@name='salaryOption_input']"));
		//Link SelSalaryStatus = new Link("Select Salary Status'", byXPath("//span[. ='Actual']"));
		Link SelSalaryStatus = new Link("Select Salary Status'", byXPath("(//ul[@id='salaryOption_listbox']/li[1]/span/div/span)[1]"));
		TextField SalaryType = new TextField("Enter Salary Type'", byXPath("//input[@name='salaryType_input']"));
		//Link SelSalaryType = new Link("Select Salary Type'", byXPath("//span[. ='Flat Rate']"));
		Link SelSalaryType = new Link("Select Salary Type'", byXPath("(//ul[@id='salaryType_listbox']/li[1]/span/div/span)[1]"));
		TextField DatePlaced = new TextField("Enter Date Placed'", byXPath("//*[@id='datePlaced']"));
		TextField StartDate = new TextField("Enter Start Date'", byXPath("//*[@id='startDate']"));
		Button SaveAndClose = new Button("Save and Close", byXPath("(//button[@aria-label='Save & Close'])[2]"));
		Link EmployerAddedSuccessMessage = new Link("EmployerAddedSuccessMessage", byXPath("//a[. = '"+EmployerNameActualValue+"']"));

		Button JobTitleSpan = new Button("JobTitleSpan", byXPath("//div/div/div[2]/div/div[2]/cmc-drop-down-list/div/div/span//span[2]"));
		Button InFieldOfStudySpan = new Button("InFieldOfStudySpan", byXPath("//div[5]/cmc-drop-down-list[3]/div/div/span//span[2]"));
		Button HowPlacedSpan = new Button("HowPlacedSpan", byXPath("//cmc-drop-down-list[4]/div/div/span/span/span/span"));
		Button SalaryStatusSpan = new Button("SalaryStatusSpan", byXPath("(//button[@aria-label='expand combobox'])[15]"));
		Button SalaryTypeSpan = new Button("SalaryTypeSpan", byXPath("(//button[@aria-label='expand combobox'])[16]"));

		TextField VerificationAgent = new TextField("VerificationAgent", byXPath("//input[@id='plVerificationAgent']"));
		TextField VerificationAgentTitle = new TextField("VerificationAgentTitle", byXPath("//input[@id='plVerificationAgentTitle']"));
		TextField VerificationDate = new TextField("VerificationDate", byXPath("//input[@id='plVerificationDate']"));
		TextField VerificationPhoneNum = new TextField("VerificationPhoneNum", byXPath("//input[@id='plVerificationPhone']"));
		Button VerificationRep = new Button("Verification Representative", byXPath("//span[@aria-controls='plVerificationRep_listbox']"));
		Link VerificationRepValue = new Link("Verification Rep Value", byXPath("//div/ul[@id='plVerificationRep_listbox']/li[1]"));
		int VerificationPhoneNumValue = AppendValue.apendNumber();
		Button Reload = new Button("Reload", byXPath("//*[@id='cnsGridPlacement_cnsToolbar_kendoToolBar_reloadButton']"));

		//waitForPageToLoad();
		wait(8);
		CareerServices.waitTillElementClickable();
		CareerServices.click();
		wait(3);
		PlacementsInternships.click();
		wait(10);
		New.click();
		wait(25);
		scrollPage(0, 300);	
		Employer.click();
		wait(4);
		SearchEmployer.clearAndType(EmployerNameActualValue.toString());
		wait(3);
		EmployerButton.click();
		wait(3);
		Select.click();
		wait(12);
		JobType.click();
		wait(2);
		SelJobType.click();	
		//JobStatus.clearAndType(data.get("JobStatus Name").toString());
		//wait(2);
		//SelPlacementStatus.click();
		//wait(2);
		scrollPage(0,400);
		wait(2);
		//JobTitleSpan.click();
		wait(1);	
		//jobTitle_input.clearAndType(data.get("jobTitle_input Name").toString());
		//wait(1);
		//SeljobTitle_input.click();
		//String JobTitle = SeljobTitle_input.getTextValue();
		//TestReportsLog.log(LogStatus.INFO, "JobTitle is selected as "+JobTitle);
		scrollPage(0, 150);
		wait(3);
		SalaryAmount.sendKeys(data.get("SalaryAmount"));
		wait(3);
		//InFieldOfStudySpan.clickUsingJavaScriptExecutor();
		wait(1);	
		//InFieldofStudy.clearAndType(data.get("InFieldofStudy Name").toString());
		//wait(2);
		//SelInFieldofStudy.clickUsingJavaScriptExecutor();
		//String InFieldOfStudy = SelInFieldofStudy.getTextValue();
		//TestReportsLog.log(LogStatus.INFO, "In Field Of Study is selected as "+InFieldOfStudy);
		wait(2);
		//HowPlacedSpan.clickUsingJavaScriptExecutor();	
		//HowPlaced.clearAndType(data.get("HowPlaced Name").toString());
		wait(2);
		//SelHowPlaced.clickUsingJavaScriptExecutor();
		//String HowPlacedValue = SelHowPlaced.getTextValue();
		//TestReportsLog.log(LogStatus.INFO, "How Placed is selected as "+HowPlacedValue);
		scrollPage(0,100);
		wait(3);
		//SalaryStatus.clearAndType(data.get("SalaryStatus Name").toString());
		SalaryStatusSpan.clickUsingJavaScriptExecutor();	
		wait(2);
		SelSalaryStatus.clickUsingJavaScriptExecutor();
		wait(2);
		String SalaryStatusValue = SelSalaryStatus.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Salary Status is selected as "+SalaryStatusValue);
		//SalaryType.clearAndType(data.get("SalaryType Name").toString());
		SalaryTypeSpan.clickUsingJavaScriptExecutor();
		wait(2);
		SelSalaryType.clickUsingJavaScriptExecutor();
		String SalaryTypeValue = SelSalaryType.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Salary Type is selected as "+SalaryTypeValue);
		wait(2);
		//DatePlaced.clearAndType(data.get("Date Placed"));
		DatePlaced.clearAndType(currentDate);
		wait(2);
		//StartDate.clearAndType(data.get("Start Date"));
		StartDate.clearAndType(currentDate);
		wait(5);
		//VerificationAgent.click();
		wait(2);
//		VerificationAgent.clearAndType(VerificationAgentValue.toString());
//		wait(2);
//		VerificationAgentTitle.click();
//		wait(2);
//		VerificationAgentTitle.clearAndType("Mr");
//		wait(2);
//		VerificationDate.clearAndType(currentDate);
//		wait(2);
//		VerificationPhoneNum.sendKeys(String.valueOf(VerificationPhoneNumValue));
//		wait(2);
//		VerificationRep.click();
//		wait(2);
//		VerificationRepValue.click();
//		String VerificationRepActualValue = VerificationRepValue.getTextValue();
//		TestReportsLog.log(LogStatus.INFO, "Verification Representative is selected  as "+VerificationRepActualValue);
		wait(3);
		scrollPage(0, -700);
		wait(7);
		SaveAndClose.waitTillElementClickable();
		SaveAndClose.clickUsingJavaScriptExecutor();
		//TestReportsLog.log(LogStatus.INFO, "The Employer records were successfully saved.");
		waitForPageToLoad();
		scrollPage(0, -400);
		wait(3);
		Reload.click();
		wait(4);
		Reload.click();
		wait(4);
		CustomAsserts.containsString(EmployerAddedSuccessMessage.getText(), EmployerNameActualValue.toString());
		return this;

	}

	public StudentMainPage AddEstimatedFAPackaging(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));		
		
		Link EstimatesSpan = new Link("EstimatesSpan", byXPath("//span[text()='Estimates']"));
		TextField BeginningAwardYear = new TextField("BeginningAwardYear", byXPath("//div[1]/cmc-drop-down-list-classic[2]/div/div/span//span[2]"));
		//TextField EnterBeginningAwardYear = new TextField("EnterBeginningAwardYear", byXPath("//div[40]//input"));
		TextField EnterBeginningAwardYear = new TextField("EnterBeginningAwardYear", byXPath("//input[@aria-controls='estimateFirstAwardYear_listbox']"));
		Link BeginningAwardYearDropDown = new Link(data.get("BeginningAwardYear"), byXPath("//li/span[. = '"+data.get("BeginningAwardYear")+"']"));
		TextField TotalProgramCOA = new TextField("TotalProgramCOA", byXPath("(//input[@aria-label=\"Total Program COA\"])[1]"));
		TextField TotalProgramCOAValue = new TextField("TotalProgramCOAValue", byCSSSelector("[name='estimateTotalCoa']"));
		TextField StartDate = new TextField("StartDate", byCSSSelector("[name='estimateStartDate']"));
		Button Save = new Button("Save", byXPath("//button[. = 'Save']"));
		Link EstimateRecordsSuccessMessage = new Link("EstimateRecordsSuccessMessage", byXPath("//span[. = '"+data.get("EstimateRecordsSuccessMessage")+"']"));
		Button CalculateEFC = new Button("CalculateEFC", byCSSSelector("#calculateEfcBtn"));
		Button CalculatePell = new Button("CalculatePell", byCSSSelector("#calculatePellBtn"));	
		Button ProgramVersionSpan = new Button("ProgramVersionSpan", byXPath("//cns-student-estimate-program-information/div/div/div[1]/cmc-drop-down-list-classic[1]/div/div/span//span[2]"));
		TextField ProgramVersionInputBox = new TextField("ProgramVersionInputBox", byXPath("//input[@aria-controls=\"estimateProgramVer_listbox\"]"));
		//Link ProgramVersionDropDown = new Link(data.get("ProgramVersion"), byXPath("//span[. = '"+data.get("ProgramVersion")+"']"));	
		Link ProgramVersionDropDown = new Link("ProgramVersion", byXPath("//div/ul[@id='estimateProgramVer_listbox']/li[1]/span"));
		Button Recalculate = new Button("Recalculate", byXPath("//button[@id='estimateCoaChangeConfirmationDialogOkButton']"));

		int COAValue = AppendValue.apendShortNumber();
		LocalDate myDateObj = LocalDate.now();
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		String currentDate = myDateObj.format(myFormatObj); // Corrected to use myDateObj
		System.out.println(currentDate);
		//waitForPageToLoad();
		wait(12);
		FinancialAidSpan.waitTillElementClickable();
		FinancialAidSpan.click();
		wait(2);	
		EstimatesSpan.click();
		waitForPageToLoad();
		wait(15);	
		ProgramVersionSpan.clickUsingJavaScriptExecutor();
		wait(2);
		//ProgramVersionInputBox.click();
		//ProgramVersionInputBox.clearAndType(data.get("ProgramVersion").toString());
		wait(2);
		ProgramVersionDropDown.clickUsingJavaScriptExecutor();
		wait(4);		
		String ProgramVersionValue = ProgramVersionDropDown.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Program version is selected  as  "+ProgramVersionValue);
		StartDate.clickUsingJavaScriptExecutor();
		wait(2);
		StartDate.clearAndType(currentDate);
		wait(5);
		BeginningAwardYear.clickUsingJavaScriptExecutor();
		wait(6);
		EnterBeginningAwardYear.click();
		wait(6);
		EnterBeginningAwardYear.clearAndType(data.get("BeginningAwardYear").toString());
		wait(6);
		BeginningAwardYearDropDown.click();
		wait(6);
		TotalProgramCOA.click();
		wait(5);
		TotalProgramCOAValue.sendKeys(String.valueOf(COAValue));
		TestReportsLog.log(LogStatus.INFO, "COA Value is updated as  "+COAValue);
		wait(5);
		wait(6);	
		if(Recalculate.isDisplayed()) {
			Recalculate.click();
			wait(10);
		}
		Save.click();
		wait(10);	
		CustomAsserts.containsString(EstimateRecordsSuccessMessage.getText(), data.get("EstimateRecordsSuccessMessage").toString());
		scrollPage(0, 550);
		wait(2);
		CalculateEFC.click();
		wait(10);
		CalculatePell.click();
		wait(10);
		scrollPage(0, -550);
		Save.click();
		wait(10);
		CustomAsserts.containsString(EstimateRecordsSuccessMessage.getText(), data.get("EstimateRecordsSuccessMessage").toString());	
		return this;
	}

	public StudentMainPage VerifyAcademicYearsInformation(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));	
		//Link FinancialAidSpan = new Link("FinancialAidSpan", byXPath("//cns-panel-bar/ul/li[5]/a/span"));
		Link EstimatesSpan = new Link("EstimatesSpan", byXPath("//span[text()='Estimates']"));
		Button EstimatedAwards = new Button("EstimatedAwards", byXPath("//button[. = 'Estimated Awards']"));
		TextField AwardYearTableCell = new TextField("AwardYear", byXPath("//td[. = '"+data.get("BeginningAwardYear")+"']"));
		//TextField COATableCell = new TextField("COA", byXPath("//td[. = '"+data.get("COAValue")+"']"));


		//waitForPageToLoad();
		wait(8);
		FinancialAidSpan.waitTillElementClickable();
		FinancialAidSpan.click();
		wait(2);
		EstimatesSpan.click();
		waitForPageToLoad();
		wait(8);
		EstimatedAwards.click();
		waitForPageToLoad();	
		CustomAsserts.containsString(AwardYearTableCell.getText(), data.get("BeginningAwardYear").toString());
		//CustomAsserts.containsString(COATableCell.getText(), data.get("COAValue").toString());
		return this;

	}

	public StudentMainPage AddPromissoryNote(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));

		Link StudentAccountsSpan = new Link("StudentAccountsSpan", byXPath("//cns-panel-bar/ul[1]/li[6]/a/span"));
		Link PaymentScheduleSpan = new Link("PaymentScheduleSpan", byXPath("//span[. = 'Payment Schedule']"));
		Link FundSourceType = new Link("FundType", byXPath("(//a[. = '"+data.get("FundSourceFullName")+"'])[1]"));
		Link PromissoryNote = new Link("PromissoryNote", byXPath("//button[. = 'Promissory Note']"));
		//TextField StudentName = new TextField("StudentName", byXPath("//div/div[. = '"+data.get("StudentName")+"']"));
		TextField StudentName = new TextField("StudentName", byXPath("//div[text()='"+data.get("StudentName")+"']"));
		TextField PromissoryNotePoint = new TextField("PromissoryNotePoint", byXPath("//span[. = 'A. PROMISE TO PAY.']"));
		Button Cancel = new Button("Cancel", byXPath("//button[@id='cancelPromissoryNoteLetterPrint']"));

		//waitForPageToLoad();
		wait(8);
		StudentAccountsSpan.waitTillElementClickable();
		StudentAccountsSpan.click();
		wait(2);
		scrollPage(0, 200);
		PaymentScheduleSpan.click();
		waitForPageToLoad();
		FundSourceType.click();
		waitForPageToLoad();
		wait(15);
		PromissoryNote.click();
		waitForPageToLoad();
		wait(5);
		//CustomAsserts.containsString(StudentName.getText(), data.get("StudentName").toString());	
		//CustomAsserts.containsString(PromissoryNotePoint.getText(), "A. PROMISE TO PAY.".toString());
		scrollPage(0, 300);
		//Cancel.clickUsingJavaScriptExecutor();
		return this;

	}

	public StudentMainPage EditAwardInformation(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));

		//Link FinancialAidSpan = new Link("FinancialAidSpan", byXPath("//li[5]/span"));
		Link AwardingSpan = new Link("AwardingSpan", byXPath("//span[. = 'Awarding']"));
		Button Awards = new Button("Awards", byXPath("//button[. = 'Awards']"));
		//TextField AwardYearTableCell = new TextField("AwardYear", byXPath("//td[. = '"+data.get("BeginningAwardYear")+"']"));
		//TextField COATableCell = new TextField("COA", byXPath("//td[. = '"+data.get("COAValue")+"']"));
		Link New = new Link("New", byXPath("//button[@id='newButton']"));
		Link AcademicYears = new Link("AcademicYears", byXPath("//button[. = 'Academic Years']"));
		Button ManualEntry = new Button("ManualEntry", byCSSSelector("#autoAwardingYearDialogNotOkButton"));
		TextField StartDate = new TextField("StartDate", byCSSSelector("[name='startDate']"));
		TextField EndDate = new TextField("EndDate", byCSSSelector("[name='endDate']"));
		//Button AwardYear1Span = new Button("AwardYear1Span", byXPath("//div[2]/cmc-drop-down-list-classic[1]/div/div/span/span/span[. = ' ']"));
		Button AwardYear1Span = new Button("AwardYear1Span", byXPath("//span[@aria-controls='firstAwardYear_listbox']"));
		//TextField AwardYear1 = new TextField("AwardYear1", byXPath("//div[63]//input"));
		TextField AwardYear1 = new TextField("AwardYear1", byXPath("//input[@aria-controls='firstAwardYear_listbox']"));
		//Link AwardYear1DropDown = new Link(data.get("AwardYear1"), byXPath("//div/div/div//li[. = '"+data.get("AwardYear1")+"']"));
		Link AwardYear1DropDown = new Link("AwardYear1", byXPath("//div/ul[@id='firstAwardYear_listbox']/li[1]"));
		Button GradeLevelSpan = new Button("GradeLevelSpan", byXPath("//cmc-drop-down-list-classic[3]/div/div/span//span[2]"));
		//Link GradeLevelDropDown = new Link(data.get("GradeLevel"), byXPath("//span[. = '"+data.get("GradeLevel")+"']"));
		Link GradeLevelDropDown = new Link("GradeLevel", byXPath("//div/ul[@id='gradeLevelId_listbox']/li[1]"));
		Button HousingSpan = new Button("HousingSpan", byXPath("(//span[@aria-label=\"select\"])[5]"));
		//Link HousingDropDown = new Link(data.get("Housing"), byXPath("//span[. = '"+data.get("Housing")+"']"));
		Link HousingDropDown = new Link("HousingDropDown", byXPath("//div/ul[@id='housingStatusCode_listbox']/li[1]"));
		Button AwardYear1PackagingStatus = new Button("AwardYear1PackagingStatus", byXPath("//div[9]/cmc-drop-down-list-classic[1]/div/div/span//span[2]"));
		//Link AwardYear1PackagingStatusDropDown = new Link(data.get("AwardYear1PackagingStatus"), byXPath("//div/div/div//span[. = '"+data.get("AwardYear1PackagingStatus")+"']"));
		Link AwardYear1PackagingStatusDropDown = new Link("AwardYear1PackagingStatus", byXPath("//div/ul[@id='awardYear1PackageStatus_listbox']/li[1]"));
		Button BudgetDefinitionSpan = new Button("BudgetDefinitionSpan", byXPath("//div/div[1]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		//Link BudgetDefinitionDropDown = new Link(data.get("BudgetDefinition"), byXPath("//span[. = '"+data.get("BudgetDefinition")+"']"));
		Link BudgetDefinitionDropDown = new Link("BudgetDefinition", byXPath("//div/ul[@id='budgetId_listbox']/li[1]"));
		Button Calculate = new Button("Calculate", byXPath("//button[. = 'Calculate']"));
		Button Save = new Button("Save", byXPath("(//button[@aria-label='Save'])[2]"));
		Button Proceed = new Button("Proceed", byCSSSelector("#weeksEnrolledInAcademicYearDialogOkButton"));
		Link AcademicYearSuccessMessage = new Link("AcademicYearSuccessMessage", byXPath("//span[. = 'The Student Academic Year records were successfully saved.']"));
		Button PackagingMethodSpan = new Button("PackagingMethodSpan", byXPath("//cmc-drop-down-list-classic[2]/div/div/span//span[2]"));
		//Link PackagingMethodDropDown = new Link(data.get("PackagingMethod"), byXPath("//span[. = '"+data.get("PackagingMethod")+"']"));
		Link PackagingMethodDropDown = new Link("PackagingMethod", byXPath("//div/ul[@id='packageMethod_listbox']/li[1]"));
		//Button New = new Button("New", byXPath("//a[5][. = 'New']"));
		Button TypeOfAidSpan = new Button("TypeOfAidSpan", byXPath("//section/div[3]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		//Link TypeOfAidDropDown = new Link(data.get("TypeOfAid"), byXPath("//li[. = '"+data.get("TypeOfAid")+"']"));
		Link TypeOfAidDropDown = new Link("TypeOfAid", byXPath("//div/ul[@id='typeOfAidId_listbox']/li[1]"));
		Button SourceSpan = new Button("SourceSpan", byXPath("//div[4]/cmc-drop-down-list-classic/div/div/span/span/span/span"));
		//Link SourceDropDown = new Link(data.get("Source"), byXPath("//span[. = '"+data.get("Source")+"']"));
		Link SourceDropDown = new Link("Source", byXPath("//div/ul[@id='sourceId_listbox']/li[1]"));
		Button GrossAmountSpan = new Button("GrossAmountSpan", byXPath("//div[5]/cmc-numeric-input-text/div/div/span/span"));
		TextField GrossAmount = new TextField("GrossAmount", byCSSSelector("[name='grossAmount']"));
		Button StatusSpan = new Button("StatusSpan", byXPath("//div[5]/cmc-drop-down-list-classic/div/div/span/span/span/span"));
		//Link StatusDropDown = new Link("StatusDropDown", byXPath("//li[. = 'Approved']"));
		Link StatusDropDown = new Link("StatusDropDown", byXPath("//div/ul[@id='statusNewAid_listbox']/li[1]"));
		Button Proceed1 = new Button("Proceed1", byXPath("//button[. = 'Proceed']"));
		Button SaveAndClose = new Button("SaveAndClose", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
		//Link FundSourceValue = new Link("FundSourceValue", byXPath("//a[. = '"+data.get("Source")+"']"));
		Link FundSourceValue = new Link("FundSourceValue", byXPath("//a[@class='cmc-link-column']"));
		TextField AmountPackagedSpan = new TextField("AmountPackagedSpan", byXPath("//div[1]/cmc-numeric-input-text/div/div/span/span"));
		TextField AmountPackaged = new TextField("AmountPackaged", byCSSSelector("[name='amount']"));
		Button Recalculate = new Button("Recalculate", byXPath("//button[@id='studentGrantDialogOkButton']"));
		Link StudentRecordsGrantSuccessMessage = new Link("StudentRecordsGrantSuccessMessage", byXPath("//span[. = 'The Student Grant records were successfully saved.']"));	
		Button SaveBudgetCalculation = new Button("SaveBudgetCalculation", byXPath("(//button[@class='cmc-toolbar-button ng-binding'])[8]"));	
		Button AcademicYearSpan = new Button("AcademicYearSpan", byXPath("//div[1]/cmc-drop-down-list-classic[1]/div/div/span//span[2]"));
		Link AcademicYearValue = new Link("AcademicYearValue", byXPath("//span[. = '"+currentDate+"']"));	
		Button Continue = new Button("SaveBudgetCalculation", byXPath("//button[@id='needAndNonNeedBasedOkButton']"));
		//Button AcademicYearDropdown = new Button("AcademicYearDropdown", byXPath("//span[@aria-label='Academic Year: Dropdown']"));
		Button AcademicYearDropdown = new Button("AcademicYearDropdown", byXPath("(//span[contains(@aria-label,'Academic Year')])[2]"));
		Link AcademicYear = new Link("AcademicYear", byXPath("//ul[@id='academicYearDefination_listbox']/li[1]"));
		Button Update = new Button("Update", byXPath("//button[@id='financialAcademicYearDialogOkButton']"));
		TextField WeeksNonEnroll = new TextField("WeeksNonEnroll", byXPath("(//input[@aria-label='Weeks Non Enroll'])[1]"));


		int GrossAmountValue = AppendValue.apendShortNumber();
		int GrossAmountValueUpdated = GrossAmountValue+10;
		String[] dateArray = currentDate.split("/");
		int year = Integer.parseInt(dateArray[2]);
		int EndDateValue = year+1;
		String EndDateActual = currentDate.replace(dateArray[2], String.valueOf(EndDateValue));

		//waitForPageToLoad();
		wait(8);
		FinancialAidSpan.waitTillElementClickable();
		FinancialAidSpan.clickUsingJavaScriptExecutor();
		wait(2);
		AwardingSpan.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		AcademicYears.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(12);
		//scrollPage(0, -100);
		New.clickUsingJavaScriptExecutor();
		wait(2);
		if(ManualEntry.isDisplayed())
		{
			ManualEntry.clickUsingJavaScriptExecutor();
		}
		waitForPageToLoad();
		//scrollPage(0, 400);
		StartDate.clickUsingJavaScriptExecutor();
		wait(2);
		StartDate.clearAndType(currentDate);
		wait(2);
		EndDate.clickUsingJavaScriptExecutor();
		EndDate.clear();
		EndDate.sendKeys(String.valueOf(EndDateActual));
		TestReportsLog.log(LogStatus.INFO, "End Date has been entered as  "+EndDateActual);
		wait(2);
		AwardYear1Span.clickUsingJavaScriptExecutor();
		wait(2);
		AwardYear1.clickUsingJavaScriptExecutor();
		wait(1);
		//AwardYear1.clearAndType(data.get("AwardYear1").toString());
		wait(1);
		AwardYear1DropDown.clickUsingJavaScriptExecutor();
		String AwardYear1Value = AwardYear1DropDown.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Award Year1 value is entered as  "+AwardYear1Value);
		wait(2);
		GradeLevelSpan.clickUsingJavaScriptExecutor();
		wait(2);
		GradeLevelDropDown.clickUsingJavaScriptExecutor();
		String GradelevelValue = GradeLevelDropDown.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Grade level value is entered as  "+GradelevelValue);
		wait(2);
		HousingSpan.clickUsingJavaScriptExecutor();
		wait(2);
		HousingDropDown.clickUsingJavaScriptExecutor();
		String HousingValue = HousingDropDown.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Housing value is entered as  "+HousingValue);
		wait(2);
		//scrollPage(0, 200);
		AcademicYearDropdown.click();
		wait(2);
		AcademicYear.click();
		wait(2);		
		if(Update.isDisplayed())
		{
			Update.clickUsingJavaScriptExecutor();
		}
		//WeeksNonEnroll.click();
		wait(2);
		//WeeksNonEnroll.clearAndType("1");
		//wait(2);
		scrollPage(0, 200);
		wait(2);
		AwardYear1PackagingStatus.clickUsingJavaScriptExecutor();
		wait(2);
		AwardYear1PackagingStatusDropDown.clickUsingJavaScriptExecutor();
		String AwardYear1PackagingStatusValue = AwardYear1PackagingStatusDropDown.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Award Year1 packaging status is entered as  "+AwardYear1PackagingStatusValue);
		wait(2);
		scrollPage(0, 500);
		BudgetDefinitionSpan.clickUsingJavaScriptExecutor();
		wait(2);
		BudgetDefinitionDropDown.clickUsingJavaScriptExecutor();
		String BudgetDefinitionValue = BudgetDefinitionDropDown.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Budget Definition is entered as  "+BudgetDefinitionValue);
		TestReportsLog.log(LogStatus.INFO, "The Student Grant records were successfully saved.");
		wait(5);
		//Calculate.clickUsingJavaScriptExecutor();
		wait(7);
		//SaveBudgetCalculation.clickUsingJavaScriptExecutor();
		wait(2);
		//if(Proceed.isDisplayed())
		//{
		//	Proceed.clickUsingJavaScriptExecutor();
		//}
		waitForPageToLoad();
		scrollPage(0, 500);
		//		//CustomAsserts.containsString(AcademicYearSuccessMessage.getText(), "The Student Academic Year records were successfully saved.".toString());
		//		Awards.click();
		//		waitForPageToLoad();
		//		AcademicYearSpan.clickUsingJavaScriptExecutor();
		//		wait(2);
		//		AcademicYearValue.clickUsingJavaScriptExecutor();
		//		wait(6);
		//		PackagingMethodSpan.clickUsingJavaScriptExecutor();
		//		wait(2);
		//		PackagingMethodDropDown.clickUsingJavaScriptExecutor();
		//		String PackagingMethodValue = PackagingMethodDropDown.getTextValue();
		//		TestReportsLog.log(LogStatus.INFO, "Packaging method is entered as  "+PackagingMethodValue);
		//		wait(6);
		//		New.clickUsingJavaScriptExecutor();
		//		wait(5);
		//		TypeOfAidSpan.clickUsingJavaScriptExecutor();
		//		wait(2);
		//		TypeOfAidDropDown.clickUsingJavaScriptExecutor();
		//		String TypeOfAid = TypeOfAidDropDown.getTextValue();
		//		TestReportsLog.log(LogStatus.INFO, "Type of Aid is entered as  "+TypeOfAid);
		//		wait(2);
		//		SourceSpan.clickUsingJavaScriptExecutor();
		//		wait(2);
		//		SourceDropDown.clickUsingJavaScriptExecutor();
		//		String SourceValue = SourceDropDown.getTextValue();
		//		TestReportsLog.log(LogStatus.INFO, "Source is entered as  "+SourceValue);
		//		wait(5);
		//		GrossAmountSpan.click();
		//		wait(2);
		//		GrossAmount.sendKeys(String.valueOf(GrossAmountValue));
		//		TestReportsLog.log(LogStatus.INFO, "Gross amount is entered as  "+GrossAmountValue);
		//		wait(2);
		//		StatusSpan.clickUsingJavaScriptExecutor();
		//		wait(2);
		//		StatusDropDown.clickUsingJavaScriptExecutor();
		//		String StatusValue = StatusDropDown.getTextValue();
		//		TestReportsLog.log(LogStatus.INFO, "Status is entered as  "+StatusValue);
		//		wait(2);
		//		Proceed1.clickUsingJavaScriptExecutor();
		//		wait(3);
		//		Continue.clickUsingJavaScriptExecutor();
		//		waitForPageToLoad();
		//		wait(5);
		//		SaveAndClose.clickUsingJavaScriptExecutor();
		//		waitForPageToLoad();
		//		FundSourceValue.clickUsingJavaScriptExecutor();
		//		waitForPageToLoad();
		//		wait(5);
		//		scrollPage(0, -150);
		//		AmountPackagedSpan.click();
		//		wait(2);
		//		AmountPackaged.sendKeys(String.valueOf(GrossAmountValueUpdated));
		//		TestReportsLog.log(LogStatus.INFO, "Gross amount is updated as  "+GrossAmountValueUpdated);
		//		wait(2);
		//		SaveAndClose.clickUsingJavaScriptExecutor();
		//		waitForPageToLoad();
		//		Recalculate.clickUsingJavaScriptExecutor();
		//		wait(10);	
		//		CustomAsserts.containsString(StudentRecordsGrantSuccessMessage.getText(), "The Student Grant records were successfully saved.".toString());
		return this;
	}


	public StudentMainPage VerifyAwardUpdate(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));	
		//Link FinancialAidSpan = new Link("FinancialAidSpan", byXPath("//cns-panel-bar/ul[1]/li[5]/a/span"));	
		Link Audit = new Link("Audit", byXPath("(//span[text()='Audit'])[5]"));
		Link ModifiedByCellValue = new Link("ModifiedByCellValue", byXPath("//tr[1]/td[. = '"+data.get("ModifiedBy")+"']"));
		//Link NoteCellValue = new Link("NoteCellValue", byXPath("//tr[1]/td[. = '"+data.get("Note")+"']"));
		Link FieldCellValue = new Link("FieldCellValue", byXPath("//tr[1]/td[. = '"+data.get("Field")+"']"));
 

		//waitForPageToLoad();
		wait(8);
		FinancialAidSpan.waitTillElementClickable();
		FinancialAidSpan.click();
		wait(2);
		scrollPage(0, -100);
		Audit.click();
		waitForPageToLoad();
		CustomAsserts.containsString(ModifiedByCellValue.getText(), data.get("ModifiedBy").toString());
		//CustomAsserts.containsString(NoteCellValue.getText(), data.get("Note").toString());
		//CustomAsserts.containsString(FieldCellValue.getText(), data.get("Field").toString());
		return this;
	}

	public StudentMainPage Confsch(StringHash data) throws Exception{
		Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));

		//Login Page Web Elements
		waitForPageToLoad();
		wait(15);
		FilterDropDwon.click();
		wait(2);
		ClearFiltersButton.click();
		waitForPageToLoad();
		wait(15);
		StuNumDropDown.click();
		//waitForPageToLoad();
		wait(2);
		StuNumFilter.click();
		//waitForPageToLoad();
		wait(2);
		value.clearAndType(data.get("Student Number"));
		//waitForPageToLoad();
		wait(2);
		FilterButton.click();
		//waitForPageToLoad();
		wait(10);
		ClickStudentName.click();
		//waitForPageToLoad();
		wait(5);
		AcademicRecords.click();
		wait(3);
		SchoolFields.click();
		wait(5);
		scrollPage(0, -200);
		wait(2);
		Sexbirth.click();
		wait(2);
		SelSexbirth.click();
		wait(2);
		/*Pronouns.click();
	wait(2);
	SelPronouns.click();
	wait(2);
	FirstGenarationStudent.click();
	wait(2);
	SelFirstGenarationStudent.click();
	wait(2);
	OrigonResident.click();
	wait(2);
	SelOrigonResident.click();
	wait(2);
	GenderIdentity.click();
	wait(2);
	SelGenderIdentity.click();
	wait(2);
	Tribe.click();
	wait(2);
	SelTribe.click();
	wait(2);
	ImmunaizationConfirmation.click();
	wait(2);
	SelImmunaizationConfirmation.click();
	wait(2);
	ELL.click();
	wait(2);
	SelELL.click();
	wait(2);
	DisebillityRequest.click();
	wait(2);
	SelDisebillityRequest.click();
	wait(2);
	VeternFamilyDependent.click();
	wait(2);
	SelVeternFamilyDependent.click();
	wait(2);
	scrollPage(0, 200);
	VeteneryTypePreferance.click();
	wait(2);
	SelVeteneryTypePreferance.click();
	wait(2);
	scrollPage(0, -300);
	wait(2);*/
		Save.click();	
		waitForPageToLoad();
		wait(2);
		return this;
	}


	public StudentMainPage BatchOfStudentRegestrationTrack(StringHash data) throws Exception{

		//X-path Parameterization
			TextField ProcessSearchField= new TextField("Search filed", By.xpath("//input[@id='lists-treeview-filter']"));
			Link RegistrationLink = new Link("Registration", By.xpath("//span[.='Registration']"));
			TextField ProcessSearch = new TextField("Process", By.xpath("//input[@placeholder='Search Processes']"));
			Link Registration= new Link(" Registration Search", By.xpath("//span[(text()='Registration')]"));
			Button Track = new Button("Track", By.xpath("//button[contains(text(),'Track')]"));
			//static Link Dropdown= new Link("Expand Track Info", By.xpath("//div//a[@cmc-expand='$ctrl.step1Expand']/div"));
			//static Link SelectTrack= new Link("Select Track", By.xpath("//input[@placeholder='Search Processes']"));
			Link TrackInfoClick= new Link("Select Track", By.xpath("//td[(text()='Test Track')]"));
			TextField EnterSgroup= new TextField("Student Group", By.xpath("//input[@name='studentGroupDropDown_input']"));
			Button Next = new Button("Next", By.xpath("//button[contains(text(),'Next')]"));
			Checkbox AllstuCheck= new Checkbox("Student Group", By.xpath("//input[@aria-label='Select All StudentId']"));
			Button Queue = new Button("Queue Registration", By.xpath("//*[@id='queueRegistrationButton']"));
			Button SubmitQueue = new Button("Queue Registration", By.xpath("//button[@id='saveSubmitJob']"));
			Button Override = new Button("Override", By.xpath("//div//button[(text()='Override')]"));
			AngDropDown TrackDropdown = new AngDropDown("Track Dropdown", By.xpath("//th[@data-field='Name']//a"));
			Link SelectingTrack= new Link("Select Track", By.xpath("//td[text()='"+StudentTrackConfiguration.TrackName+"']"));
			Link PopUpValidation = new Link("Validation Message", By.xpath("//span[contains(text(),'The Track Registration records were successfully queued.')]"));
			
		//Method Implementation
			waitForPageToLoad();
			ProcessSearch.sendkeys("Registration");
			wait(1);
			Registration.click();
			wait(8);
			Track.clickUsingJavaScriptExecutor();
			wait(6);
			TrackDropdown.clickUsingJavaScriptExecutor();
			wait(2);
			Filter1.click();
			wait(2);
			Value.clearAndType(StudentTrackConfiguration.TrackName);
			wait(2);
			Filter.click();
			wait(2);
			
//			List<WebElement> rows = driver.findElements(By.xpath("//table//tr")); 
//			Link PopUpValidation = new Link("Validation Message", By.xpath("//span[contains(text(),'The Track Registration records were successfully queued.')]"));
//			wait(7);
//			rows.size();
//			System.out.println(rows.size());
//			for (int i=1; i<=rows.size(); i++) {
//				WebElement elementTrackName = driver.findElement(By.xpath("//table//tr["+i+"]//td[1]"));
//				System.out.println("//table//tr["+i+"]//td[1]");
//				String actualValue = elementTrackName.getText();
//				System.out.println(actualValue);
//				//System.out.println(Abcd);
//				if(actualValue.equals(TrackName.toString())) {
//					elementTrackName.getText();
//					elementTrackName.click();
//					wait(2);
//					System.out.println(elementTrackName);
//					wait(4);
//					break; 
//				}
//			}
			SelectingTrack.click();
			wait(4);
			EnterSgroup.click();
			wait(4);
			EnterSgroup.clearAndType(StudentTrackConfiguration.Groupname.toString());
			wait(2);
			scrollPage(0,20);
			Next.click();
			wait(14);
			AllstuCheck.clickUsingJavaScriptExecutor();
			wait(3);
			Queue.clickUsingJavaScriptExecutor();
			wait(5);
			/*if (Override.isDisplayed()) {
					Override.clickUsingJavaScriptExecutor();
					wait(5);
				}*/
			SubmitQueue.clickUsingJavaScriptExecutor();
			wait(7);
			CustomAsserts.containsString(PopUpValidation.getText(), data.get("SuccessMessage").toString());
			return this;

		}

	public StudentMainPage BatchOfStudentUnRegistrationTrack(StringHash data) throws Exception{

		//X-path Parameterization
			Link Instructor = new Link("Instructor", byXPath("//div[2]/cmc-drop-down-list/div/div/span/span/span/span"));
			Checkbox SelectTerm = new Checkbox("Term Name", byXPath("//tr[2]/td/input"));
			Link SelInstructor = new Link("Instructor Name", byXPath("(//ul[@id='InstructorId_listbox']/li//div/span)[1]"));
			Link BatchStudentUnRegSaveMessage = new Link("Batch Student UnRegister SaveMessage", byXPath("//span[. = 'The Unregister records were successfully queued.']"));
			Link UnReas = new Link("Reason", byXPath("(//button[@aria-label='expand combobox'])[6]"));
			Link SelReass = new Link("Reason", byXPath("//ul[@id='ReasonId_listbox']/li[1]//div/span[1]"));
			Checkbox SelectTerm1 = new Checkbox("Select Term1", byXPath("//input[@aria-label='"+data.get("Term Name")+"']"));
			TextField SearchProcesses = new TextField("Search Process", byXPath("//input[@placeholder='Search Processes']"));
			Link Registration = new Link("Registration Type", byXPath("//span[text()='Registration']"));
			Button Unregister = new Button("Unregister", byXPath("//button[text()='Unregister']"));
			Link Term1 = new Link("Term1", byXPath("//div[@aria-label='Term']"));
			TextField SearchTerm = new TextField("Enter Term", byXPath("//input[@id='search']"));
			TextField Next2 = new TextField("Next", byXPath("//button[contains(text(),'Next')]"));
			Checkbox allstd = new Checkbox("Select all student", byXPath("//input[@aria-label='Select all']"));
			TextField Reason = new TextField("Enter Reason", byXPath("//input[@name='ReasonId_input']"));
			Link SelReas = new Link("Reason", byXPath("//span[@title='CANCELLED SECTION']"));
			Link Queureg2 = new Link("Queue Register", byXPath("//*[@id='queueUnregistrationButton']"));	
			Link TermU = new Link("Term", byXPath("//div[@id='search_display_termId']"));
			TextField EnterTermU = new TextField("Enter Term", byXPath("//input[@id='search']"));
			Button SelectU = new Button("Select Button", byXPath("//button[text()='Select']"));
			TextField EnterInstructor = new TextField("Enter Instructor", byXPath("//input[@name='InstructorId_input']"));
			Link Queue = new Link("Queue ", byXPath("//button[text()='Queue']"));
			Link ErrorMessage = new Link("ErrorMessage ", byXPath("//span[text()='There are no students to Unregister.']"));
			
		//Method Implementation
			waitForPageToLoad();
			SearchProcesses.clearAndType("Registration");
			wait(2);
			Registration.click();
			wait(2);
			Unregister.clickUsingJavaScriptExecutor();
			wait(3);
			TermU.click();
			wait(2);
			EnterTermU.clearAndType(data.get("Term Code").toString());
			wait(5);
			SelectTerm1.click();
			wait(2);	
			SelectU.click();
			wait(7);
			/*Term1.click();
				wait(3);
				SelectTerm.click();
				wait(3);
				String SelctTerm = SelectTerm.getAttribute("title");
			    TestReportsLog.log(LogStatus.INFO, "SelectTermName is selected as "+SelctTerm);
				Select1.click();
				wait(7);*/
			EnterInstructor.click();
			wait(2);
			EnterInstructor.clearAndType(data.get("Instructor").toString());
			wait(2);
			String SelInstructr = SelInstructor.getAttribute("title");
			TestReportsLog.log(LogStatus.INFO, "Instructor Name is selected as "+SelInstructr);
			wait(2);
			SelInstructor.click();
			wait(2);
			Next2.click();
			wait(2);
			//allstd.click();
			//allstd.click();
			wait(2);
			scrollPage(0, 300);
			wait(2);
			UnReas.click();
			wait(3);
			SelReass.click();
			wait(1);
			Queureg2.click();
			wait(2);
//			if(ErrorMessage.isDisplayed()) {
//				wait(1);
//				TestReportsLog.log(LogStatus.FAIL, ErrorMessage.getText());
//			}else {
			Queue.click();
			wait(5);
			CustomAsserts.containsString(BatchStudentUnRegSaveMessage.getText(), data.get("SuccessMessage").toString());
//			}
			return this;
		}

	public StudentMainPage ConfirmInformationSchoolFields(StringHash data) throws Exception{

		//X-path Parameterization
		Link AcademicRecords = new Link("Academic Records", byXPath("//cns-panel-bar/ul[1]/li[3]/a/span"));
		Link ConfirmInfoSchoolFieldSaveMessage = new Link("Confirm Info School Field Save Message", byXPath("//span[. = 'The Student records were successfully saved.']"));
		Link SchoolFields1 = new Link("School Fileds", byXPath("//div[text()='School Fields']"));
		TextField Value = new TextField("Value", byXPath("//textarea[@aria-label=\"FATXK\"]"));
		Link SchoolFields = new Link("Click on SchoolFields", byXPath("(//span[text()='School Fields'])[2]"));
		Button Save = new Button("Save", byXPath("(//button[@aria-label='Save'])[2]"));
		TextField Gender = new TextField("Gender", byXPath("(//textarea)[1]"));
		TextField SchoolField = new TextField("SchoolField", byCSSSelector("#ULNXG"));
		
		AngDropDown GenderIdentity = new AngDropDown("GenderIdentity", byXPath("//span[@aria-label='Gender Identity']"));
		Link GenderIdentityValue = new Link("GenderIdentityValue", byXPath("//ul[@id='Gen_listbox']/li[1]/span"));
		

		//Method Implementation
//		waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.clickUsingJavaScriptExecutor();
		wait(3);
		SchoolFields.clickUsingJavaScriptExecutor();
		wait(5);
		//scrollPage(0, -500);
		//wait(2);
		//SchoolField.clearAndType("Student");
		//wait(2);
		wait(2);
		GenderIdentity.click();
		wait(2);
		//EDUID.ClearExistingText();
		//wait(2);
		//EDUID.backSpace();
		//wait(2);
		//SchoolFields.click();
		GenderIdentityValue.click();
		wait(2);
		String GenderIdentityValues = GenderIdentityValue.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Gender identity is selected as "+GenderIdentityValues);
		wait(2);
		scrollPage(0, -300);
		wait(2);
		Save.click();	
		wait(8);
		CustomAsserts.containsString(ConfirmInfoSchoolFieldSaveMessage.getText(), data.get("SuccessMessage").toString());
		System.out.println("School field is added successfully for Academic Records");
		return this;
	}



	public StudentMainPage ProgrameTransferToStudent(StringHash data) throws Exception{

		//X-path Parameterization
		Link EnrollmentSpan = new Link("Enrollment", byXPath("//span[text()='Enrollments']"));
		Link SelTransferType = new Link("TransferType", byXPath("//li[text()='To Enrollment']"));
		Link TransStudentSaveMessage = new Link("Trans Student SaveMessage", byXPath("//span[. = 'The Transfer Enrollment records were successfully saved.']"));
		//Link SelPrgver = new Link("Programe Versions", byXPath("//span[text()='"+data.get("To Programe Version")+"']"));
		Link SelPrgver = new Link("Programe Versions", byXPath("//ul[@id=\"transferToProgramVersionId_listbox\"]/li/span/div/span"));
		//Link ProgramVersion = new Link("Program versions", byXPath("(//span[@id='programVersionDropDown'])[1]"));
		Link ProgramVersion = new Link("Program versions", byXPath("//div[@aria-label='program Version']"));
		Link SelectingProgramVersion = new Link("All Program versions", byXPath("//a[text()='Agriculture - AA (AB23020013) - Active)']"));
		Link SelectingAllProgramVersion = new Link("All Program versions", byXPath("//a[text()='All Program Versions']"));
		Link AcademicRecords = new Link("Academic Records span", byXPath("//cns-panel-bar/ul/li[3]/a/span"));
		Link StudentCourses = new Link("Student Courses span", byXPath("//li[3]/div/div[3]/div"));
		Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("(//div[@id='cnsGrid_cnsToolbar_kendoToolBar_settingsButton_wrapper']/button)[2]"));
		//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
		Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//*[@id='cnsGrid_cnsToolbar_kendoToolBar_clearPreferencesButton']"));
		Link TermDropDown = new Link("Term Number Dropdown", byXPath("(//th[1]//span)[1]"));
		Button TerNumFilter = new Button("Term Number Filter", byXPath("//span[.='Filter']"));
		TextField value1 = new TextField("Value", byXPath("//input[@title='Value']"));
		Button FilterButton1 = new Button("Filter Button", byXPath("//button[text()='Filter']"));
		Link SelectPrograme = new Link("Programe", byXPath("(//tbody/tr[1]/td[2])[1]"));
		Link More = new Link("More", byXPath("//div[@id='moreEnrollmentButton_wrapper']/a[2]"));
		Link Transfer = new Link("Transfer", byXPath("(//ul[@id='moreEnrollmentButton_optionlist']/li[6]/a)[2]"));
		Link TransferType = new Link("TransferType", byXPath("(//div[@id='divfirstrow_transfer']/cmc-drop-down-list-classic/div/div/span/span/span)[2]"));
		//Link SelTransferType = new Link("SelTransferType", byXPath("//li[text()='To Enrollment']"));
		Button Proceed = new Button("Proceed", byXPath("(//button[text()='Proceed'])[2]"));
		Checkbox NewPgmVer = new Checkbox("New Programe Version", byXPath("//div[@id='transferWindow']/ng-transclude/div/div[3]/div/div/ng-transclude/section/div[3]/cmc-radio-button-group/div/div[2]/cmc-radio-button[2]/div/div/label"));
		//Link ProgrameVersion = new Link("Programe Version", byXPath("(//div[@id='transferWindow']/ng-transclude/div/div[3]/div/div/ng-transclude/section/div[3]/cmc-drop-down-list-classic/div/div/span/span/span)[2]"));
		Link ProgrameVersion = new Link("Programe Version", byXPath("(//span[text()='New Program Version'])[2]"));
		TextField EnterProgrameVersion = new TextField("Programe Version", byXPath("//input[@aria-owns=\"transferToProgramVersionId_listbox\"]"));
		Button Next3 = new Button("Next3", byXPath("//button[@id='transferInformationProceedButton']"));
		Button Next4 = new Button("Next4", byXPath("//button[@id='studentCourseProceedButton']"));
		Button Next5 = new Button("Next5", byXPath("//button[@id='feeProceedButton']"));
		Link Transfer2 = new Link("Transfer2", byXPath("(//a[@id='transferSaveButton'])[2]"));
		//Link SelPrgver = new Link("SelPrgver", byXPath("//span[text()='AP Associate 2 Semester']"));
		Link Transfer3 = new Link("Transfer3", byXPath("//button[@id='enrollAcademicYearDialogOkButton']"));  
		TextField value = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
		Button FilterButton = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));

		//Method Implementation
		//waitForPageToLoad();
		//wait(10);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		EnrollmentSpan.click();
		wait(5);
		ProgramVersion.click();
		wait(2);
		SelectingAllProgramVersion.click();
		wait(7);
		ClsFilterDropDwon.click();
		wait(2);
		ClsClearFiltersButton.click();
		wait(3);
		/*ProgramVersion.click();
			wait(1);
			SelectingProgramVersion.click();
			wait(10);*/
		TermDropDown.click();
		wait(2);
		TerNumFilter.click();
		wait(2);
		value.clearAndType(data.get("Program Version"));
		wait(2);
		FilterButton.click();
		wait(5);
		SelectPrograme.click();
		wait(5);
		More.click();
		wait(3);
		Transfer.click();
		wait(3);
		WebElement transfert=driver.findElement(By.id("enrollStatusHistoryDialogOkButton"));
		TransferType.click();
		wait(3);
		SelTransferType.click();
		wait(3);
		ProgrameVersion.click();
		wait(5);
		//EnterProgrameVersion.clearAndType(data.get("To Programe Version").toString());
		//wait(3);
		//SelPrgver.click();
		wait(3);
		Proceed.click();
		wait(3);
		if (transfert.isDisplayed()) {
			transfert.click();
			wait(8);
		} 
		Next3.click();
		wait(3);
		Next4.click();
		wait(3);
		Next5.click();
		wait(3);
		Transfer2.click();
		wait(3);
		Transfer3.clickUsingJavaScriptExecutor();
		wait(7);
		CustomAsserts.containsString(TransStudentSaveMessage.getText(), data.get("SuccessMessage").toString());
		wait(2);
		return this;

	}


	public StudentMainPage AddBillableServices(StringHash data) throws Exception{

		
		Link BillableServicesSpan = new Link("BillableServicesSpan", byXPath("//span[. = 'Billable Services']"));
		Button New = new Button("New", byXPath("//button[. = 'New']"));
		Button TermSpan = new Button("TermSpan", byXPath("(//button[@aria-label='expand combobox']/span[1])[2]"));
		Link Term = new Link("Term", byXPath("//div/ul[@id='TermId_listbox']/li[1]"));
		Button ProgramVersionSpan = new Button("ProgramVersionSpan", byXPath("(//button[@aria-label='expand combobox']/span[1])[3]"));
		Link ProgramVersion = new Link("ProgramVersion", byXPath("//div/ul[@id='EnrollmentId_listbox']/li[1]"));
		Button ServiceCategorySpan = new Button("ServiceCategorySpan", byXPath("//div/cmc-drop-down-list-classic[1]/div/div/span//span[2]"));
		Link ServiceCategory = new Link("ServiceCategory", byXPath("//div/ul[@id='CategoryId_listbox']/li[1]"));
		Button ServiceSpan = new Button("ServiceSpan", byXPath("//cmc-drop-down-list-classic[2]/div/div/span//span[2]"));
		Link Service = new Link("Service", byXPath("//div/ul[@id='ServiceId_listbox']/li[1]"));
		Button SaveAndClose = new Button("SaveAndClose", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
		Link ServiceCategoryTableCell = new Link("ServiceCategoryTableCell", byXPath("(//tr/td[2])[1]"));
		Link SaveMessage = new Link("Trans Student SaveMessage", byXPath("//span[. = 'The Billable Service records were successfully saved.']"));

		//waitForPageToLoad();
		wait(8);
		StudentServices.waitTillElementClickable();
		StudentServices.click();
		wait(2);
		BillableServicesSpan.click();
		wait(12);
		New.click();
		wait(15);
		TermSpan.click();
		wait(3);
		Term.click();
		String TermValue = Term.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Term is selected as "+TermValue);
		wait(3);
		ProgramVersionSpan.click();
		wait(3);
		ProgramVersion.click();
		String ProgramVersionValue = ProgramVersion.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Programversion is selected as "+ProgramVersionValue);
		wait(3);
		ServiceCategorySpan.click();
		wait(3);
		ServiceCategory.click();
		String ServiceCategoryValue = ServiceCategory.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Service category is selected as "+ServiceCategoryValue);
		wait(3);
		ServiceSpan.click();
		wait(3);
		Service.click();
		String ServiceValue = Service.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Service is selected as "+ServiceValue);
		wait(6);
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(5);
		//CustomAsserts.containsString(ServiceCategoryValue.toString(),ServiceCategoryTableCell.getText());
		CustomAsserts.containsString(SaveMessage.toString(),data.get("SuccessMessage").toString());

		return this;
	}




	public StudentMainPage AddAthletics(StringHash data) throws Exception{

		//Link StudentServices = new Link("StudentServices", byXPath("//li[7]/span"));
		Link AthleticsSpan = new Link("AthleticsSpan", byXPath("//span[. = 'Athletics']"));
		Button New = new Button("New", byXPath("//button[. = 'New']"));
		Button SportSpan = new Button("SportSpan", byXPath("(//span[@aria-label='select']/span[1])[3]"));
		Link Sport = new Link("Sport", byXPath("//div/ul[@id='sportId_listbox']/li[1]"));
		Button RecruitmentTypeSpan = new Button("RecruitmentTypeSpan", byXPath("(//span[@aria-label='select']/span[1])[4]"));
		Link RecruitmentType = new Link("RecruitmentType", byXPath("//div/ul[@id='recruitmentTypeId_listbox']/li[1]"));
		Button AthleticStatusSpan = new Button("AthleticStatusSpan", byXPath("(//span[@aria-label='select']/span[1])[5]"));
		Link AthleticStatus = new Link("AthleticStatus", byXPath("//div/ul[@id='athleticStatusId_listbox']/li[1]"));
		Button LastActiveTermSpan = new Button("LastActiveTermSpan", byXPath("(//button[@aria-label='expand combobox'])[2]"));
		Link LastActiveTerm = new Link("LastActiveTerm", byXPath("//div/ul[@id='lastActiveTermId_listbox']/li[1]"));
		TextField RemainingEligibility = new TextField("RemainingEligibility", byXPath("//input[@name='remainingEligibility']"));
		TextField AthleticID = new TextField("AthleticID", byXPath("//input[@name='athleticIdentifier']"));
		Button SaveAndClose = new Button("SaveAndClose", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
		Button UpdateAthleticID = new Button("UpdateAthleticID", byXPath("//button[@id='confirmStudentAthleticIdentifierWindowOkButton']"));
		Link AthleticStatusTableCell = new Link("AthleticStatusTableCell", byXPath("(//tr/td[3])[1]"));

		int AthleticIdValue = AppendValue.apendShortNumber();

		Link AthleticsSaveMessage = new Link("Trans Student SaveMessage", byXPath("//span[. = 'The Athletic records were successfully saved.']"));

		waitForPageToLoad();
		StudentServices.click();
		wait(2);
		AthleticsSpan.click();
		wait(12);
		New.click();
		wait(18);
		SportSpan.click();
		wait(2);
		Sport.click();
		String SportValue = Sport.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Sport is selected as "+SportValue);
		wait(2);
		RecruitmentTypeSpan.click();
		wait(2);
		RecruitmentType.click();
		String RecruitmentTypeValue = RecruitmentType.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Recruitment Type is selected as "+RecruitmentTypeValue);
		wait(3);
		AthleticStatusSpan.click();
		wait(2);
		AthleticStatus.click();
		String AthleticStatusValue = AthleticStatus.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Athletic Status is selected as "+AthleticStatusValue);
		wait(3);
		LastActiveTermSpan.click();
		wait(2);
		LastActiveTerm.click();
		String LastActiveTermValue = LastActiveTerm.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Last active term is selected as "+LastActiveTermValue);
		wait(3);
		RemainingEligibility.click();
		wait(2);
		RemainingEligibility.sendKeys(String.valueOf(1));
		TestReportsLog.log(LogStatus.INFO, "Remaining eligibility is entered as "+1);
		wait(4);
		//AthleticID.click();
		//wait(2);
		//AthleticID.clear();
		//wait(2);
		//AthleticID.sendKeys(String.valueOf(AthleticIdValue));
		//wait(2);
		//TestReportsLog.log(LogStatus.INFO, "Athletic ID is entered as "+AthleticIdValue);
		SaveAndClose.click();
		wait(6);
		//	if(UpdateAthleticID.isDisplayed()) {
		//		UpdateAthleticID.click();
		//		wait(14);
		//	}
		CustomAsserts.containsString(AthleticsSaveMessage.toString(),data.get("SuccessMessage").toString());
		//CustomAsserts.containsString(AthleticStatusValue.toString(),AthleticStatusTableCell.getText());
		return this;
	}


	public StudentMainPage AddAccomodations(StringHash data) throws Exception{


		//Link StudentServices = new Link("StudentServices", byXPath("//cns-panel-bar/ul/li[7]/span"));
		Link AccomodationsSpan = new Link("AccomodationsSpan", byXPath("//span[text()='Accommodation']"));
		Button DisabledSpan = new Button("DisabledSpan", byXPath("//div[1]/cmc-drop-down-list-classic[1]/div/div/span//span[2]"));
		Link Disabled = new Link("Disabled", byXPath("//div/ul[@id='isDisabled_listbox']/li[1]"));
		Button StatusSpan = new Button("StatusSpan", byXPath("//div[1]/cmc-drop-down-list-classic[2]/div/div/span//span[2]"));
		Link Status = new Link("Status", byXPath("//div/ul[@id='disabilityStatusId_listbox']/li[1]"));
		Button SearchDisabilityTypes = new Button("SearchDisabilityTypes", byCSSSelector("#search_display_disabilityTypes"));
		Checkbox DisabilityType = new Checkbox("DisabilityType", byXPath("//tr[1]/td/input"));
		Checkbox DisabilityTypeValue = new Checkbox("DisabilityTypeValue", byXPath("//tr[2]/td/input"));
		Button Select = new Button("Select", byXPath("//button[. = 'Select']"));
		Button AssistanceDuringRegistrationSpan = new Button("AssistanceDuringRegistrationSpan", byXPath("//div[3]/cmc-drop-down-list-classic[1]/div/div/span//span[2]"));
		Link AssistanceDuringRegistration = new Link("AssistanceDuringRegistration", byXPath("//div/ul[@id='isRegistrationAssistanceNeeded_listbox']/li[1]"));
		Button PriorityRegistrationSpan = new Button("PriorityRegistrationSpan", byXPath("//div[3]/cmc-drop-down-list-classic[2]/div/div/span//span[2]"));
		Link PriorityRegistration = new Link("PriorityRegistration", byXPath("//div/ul[@id='isPriorityRegistration_listbox']/li[1]"));
		TextField Note = new TextField("Note", byXPath("//textarea[@name='note']"));
		Button Save = new Button("Save", byXPath("//div[3]/cmc-toolbar/section/cmc-toolbar-button-save//button"));
		Button Add = new Button("Add", byXPath("//button[@id='newButton']"));
		Button ServiceSpan = new Button("ServiceSpan", byXPath("//span[@aria-label='Service']/span[2]"));
		Link Service = new Link("Service", byXPath("//div/ul[@id='serviceTypeId_listbox']/li[1]"));
		TextField StartDate = new TextField("StartDate", byXPath("//input[@id='serviceBeginDate']"));
		TextField EndDate = new TextField("EndDate", byXPath("//input[@id='serviceEndDate']"));
		Button SaveService = new Button("SaveService", byCSSSelector("#studentServiceTypeSaveButton"));
		//driver.manage().timeouts().implicitlyWait(45, TimeUnit.SECONDS);
		Link AccomodationServiceSuccessMessage = new Link("AccomodationServiceSuccessMessage", byXPath("//span[.='The Accommodation Service records were successfully saved.']"));

		String NoteValue = AppendValue.apendString();

		//waitForPageToLoad();
		wait(8);
		StudentServices.waitTillElementClickable();
		StudentServices.click();
		wait(2);
		AccomodationsSpan.click();
		wait(20);
		DisabledSpan.click();
		wait(2);
		Disabled.click();
		String DisabledValue = Disabled.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Disabled is selected as "+DisabledValue);
		wait(3);
		StatusSpan.click();
		wait(2);
		Status.click();
		String StatusValue = Status.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Status is selected as "+StatusValue);
		wait(3);	
		SearchDisabilityTypes.click();
		wait(4);	
		if(DisabilityType.isSelected()){
			DisabilityType.click();
			wait(2);
			DisabilityTypeValue.click();
			wait(2);
			Select.click();
			//Cancel.click();
			TestReportsLog.log(LogStatus.INFO, "Disability type is selected");
		}
		else {
			wait(3);
			DisabilityType.click();
			wait(2);
			Select.click();
			TestReportsLog.log(LogStatus.INFO, "Disability type is selected");
		}
		wait(3);
		AssistanceDuringRegistrationSpan.click();
		wait(2);
		AssistanceDuringRegistration.click();
		String AssistanceDuringRegistrationValue = AssistanceDuringRegistration.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Assistance during registration is selected as "+AssistanceDuringRegistrationValue);
		wait(3);
		PriorityRegistrationSpan.click();
		wait(2);
		PriorityRegistration.click();
		wait(2);
		Note.click();
		wait(2);
		Note.clearAndType(NoteValue.toString());
		wait(2);
		scrollPage(0, -200);
		Save.click();
		wait(12);
		scrollPage(0, 200);
		wait(3);
		Add.click();
		wait(5);
		ServiceSpan.click();
		wait(4);
		Service.clickUsingJavaScriptExecutor();
		String ServiceValue = Service.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Service is selected as "+ServiceValue);
		wait(2);
		StartDate.click();
		wait(1);
		StartDate.clearAndType(data.get("StartDate").toString());
		wait(2);
		EndDate.click();
		wait(1);
		EndDate.clearAndType(data.get("EndDate").toString());
		wait(2);
		SaveService.click();
		wait(10);
		CustomAsserts.containsString(AccomodationServiceSuccessMessage.getText(),data.get("SuccessMessage").toString());
		return this;
	}



	public StudentMainPage VeteranConfirmnewinfoaddedtofield(StringHash data) throws Exception{

		//X-path Parameterization
//			Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("StudentName")+"']"));
			Link StudentServices = new Link("Student Services", byXPath("//cns-panel-bar/ul/li[7]/a/span"));
			Link ConfirmInfoSchoolFieldSaveMessage = new Link("Confirm Info School Field SaveMessage", byXPath("//span[. = 'The Veteran records were successfully saved.']"));
			Link Veteran = new Link("Veteran", byXPath("(//span[. ='Veteran'])[2]"));
			Link New = new Link("New", byXPath("//*[@id='newButton']"));
			Link AddVeteran = new Link("Add Veteran", byXPath("//*[contains(text(),'Add as Veteran')]"));
			Link Select = new Link("Select", byXPath("//button[. = 'Select']"));
			Link CertifiedTerm = new Link("Certified Term", byXPath("//span[contains(@aria-owns,'lastCertifiedTermId')]/span/span[2]/span"));
			Link SelCertifiedTerm = new Link("Selecting Certified Term", byXPath("//ul[@id='lastCertifiedTermId_listbox']/li[1]/div/span[1]"));
			Link CertificateType = new Link("Certificate Type", byXPath("//span[contains(@aria-controls,'veteranAffairsCertificationTypeId')]/span[2]/span"));
			Link SelCertificateType = new Link("Certificate Type", byXPath("//ul[@id='veteranAffairsCertificationTypeId_listbox']/li[1]/span"));
			TextField Branch = new TextField("Branch", byXPath("//div[@id='search_display_veteranTypes']"));
			Checkbox SelectBranch = new Checkbox("Select Branch", byXPath("//tr[1]/td/input"));
			TextField Benefit = new TextField("Benefit", byXPath("//div[@id='search_display_benefitsReceived']"));
			Checkbox SelectBenefit = new Checkbox("Select Benefit", byXPath("//tr[1]/td/input"));
			Button SaveandClose = new Button("Save", byXPath("(//button[@aria-label='Save & Close'])[2]"));
			
		//Method Implementation
			//waitForPageToLoad();
			StudentServices.waitTillElementClickable();
			StudentServices.clickUsingJavaScriptExecutor();
			wait(2);
//			scrollPage(0,15);
//			wait(3);
			Veteran.clickUsingJavaScriptExecutor();
			wait(7);
			scrollPage(0, -150);
			wait(2);
			New.click();
			wait(3);
			if (AddVeteran.isDisplayed()) {
				AddVeteran.click(); 
				wait(2);
			}
			//AddVeteran.click();
			//wait(10);
			scrollPage(0,200);
			wait(2);
			Branch.clickUsingJavaScriptExecutor();
			wait(2);
			SelectBranch.clickUsingJavaScriptExecutor();
			wait(2);
			Select.clickUsingJavaScriptExecutor();
			wait(5);
			Benefit.clickUsingJavaScriptExecutor();
			wait(2);
			SelectBenefit.clickUsingJavaScriptExecutor();
			wait(2);
			Select.clickUsingJavaScriptExecutor();
			wait(5);
//			CertifiedTerm.clickUsingJavaScriptExecutor();
//			wait(2);
//			SelCertifiedTerm.clickUsingJavaScriptExecutor();
//			wait(5);
			CertificateType.clickUsingJavaScriptExecutor();
			wait(2);
			SelCertificateType.clickUsingJavaScriptExecutor();
			wait(5);
			SaveandClose.click();	
			wait(5);
			CustomAsserts.containsString(ConfirmInfoSchoolFieldSaveMessage.getText(), data.get("SuccessMessage").toString());
			System.out.println("Veteran information is added successfully");
			return this;
		}

	public StudentMainPage IndicatorsConfnewinfocanbeaddtofield(StringHash data) throws Exception{

		//X-path Parameterization
//			Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("StudentName")+"']"));
			Link StudentServices = new Link("Student Services", byXPath("//cns-panel-bar/ul/li[7]/a/span"));
			Link ConfirmInfoSchoolFieldSaveMessage = new Link("Confirm Info School Field SaveMessage", byXPath("//span[. = 'The Indicator Defined Service records were successfully saved.']"));
			Link Indicator = new Link("Indicators", byXPath("//span[. ='Indicators']"));
			Link New = new Link("New", byXPath("//*[@id='newButton']"));
			Link Select = new Link("Select", byXPath("//button[. = 'Select']"));
//			Link CertifiedTerm = new Link("Certified Term", byXPath("//div/cmc-drop-down-list-classic[1]/div/div/span/span/span/span"));
			Link SelCertifiedTerm = new Link("Select Certified Term", byXPath("//li[1]/div/span[1]"));
			AngDropDown IndicatorDropdown = new AngDropDown("Indicator Dropdown", byXPath("(//button[@aria-label='expand combobox'])[2]"));
			Link SelIndicator1 = new Link("Selecting Indicator Dropdown", byXPath("(//ul[@id='indicatorId_listbox']/li[1]/span/div/span)[1]"));
			TextField EffectiveDate = new TextField("Effective Date", byXPath("//cmc-date-picker[1]//input[@placeholder = 'MM/DD/YYYY']"));
			TextField EndDate = new TextField("End Date", byXPath("//cmc-date-picker[2]//input[@placeholder = 'MM/DD/YYYY']"));
			Button SaveandClose = new Button("Save and Close", byXPath("(//button[@aria-label='Save & Close'])[2]"));
			
		//Method Implementation
			//waitForPageToLoad();
			StudentServices.waitTillElementClickable();
			StudentServices.clickUsingJavaScriptExecutor();
			wait(3);
			scrollPage(0,15);
			wait(3);
			Indicator.clickUsingJavaScriptExecutor();
			wait(7);
			scrollPage(0, -300);
			wait(2);
			New.click();
			wait(3);
			scrollPage(0,200);
			wait(2);
			IndicatorDropdown.clickUsingJavaScriptExecutor();
			wait(2);
			SelIndicator1.clickUsingJavaScriptExecutor();
			wait(5);
			EffectiveDate.clearAndType(EffDate);
			wait(5);
			//EndDate.clearAndType(data.get("EndDate"));
			//wait(3);
			SaveandClose.clickUsingJavaScriptExecutor();	
			wait(5);
			CustomAsserts.containsString(ConfirmInfoSchoolFieldSaveMessage.getText(), data.get("SuccessMessage").toString());
			System.out.println("Indicator is added successfully");
			return this;
		}
	public StudentMainPage DeleteIndicatorsConfirmnewinformationcanbeaddedtofield(StringHash data) throws Exception{

		//X-path Parameterization
		Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("StudentName")+"']"));
		Link StudentServices = new Link("Student Services", byXPath("//cns-panel-bar/ul/li[7]/a/span"));
		Link ConfirmIndicatorSaveMessage = new Link("Confirm Info School Field SaveMessage", byXPath("//span[. = 'The Indicator records were successfully deleted.']"));
		Link Indicator = new Link("Indicator", byXPath("//span[. = 'Indicators']"));
		Link SelectIndicator = new Link("Indicator", byXPath("//div[2]//td[2]"));
		Button IDeleteButton = new Button("Delete", byXPath("//a[@id='deleteButton']"));
		Button IConfirmDeleteButton = new Button("Confirm Delete", byXPath("(//button[contains(text(),'Delete')])[2]"));
		Link IndicatorDropdown = new Link("Course Code dropdown", byXPath("//th[1]//span"));
		Button CFilterDropDown = new Button("Filter", byXPath("//span[text()=\"Filter\"]"));
		TextField IValue = new TextField("Filter", byXPath("//input[@title=\"Value\"]"));
		Button Filter = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));

		//Method Implementation
		//waitForPageToLoad();
		//wait(10);
		StudentServices.waitTillElementClickable();
		StudentServices.click();
		wait(3);
		scrollPage(0,15);
		wait(3);
		Indicator.clickUsingJavaScriptExecutor();
		wait(7);
		IndicatorDropdown.click();
		wait(2);
		CFilterDropDown.click();
		wait(2);
		IValue.clearAndType(data.get("IndicatorName"));
		wait(2);
		Filter.click();
		wait(3);
		SelectIndicator.click();
		wait(3);
		IDeleteButton.clickUsingJavaScriptExecutor();
		wait(4);
		IConfirmDeleteButton.clickUsingJavaScriptExecutor();
		wait(5);
		//CustomAsserts.containsString(ConfirmIndicatorSaveMessage.getText(), data.get("SuccessMessage").toString());
		//wait(2);
		return this;
	}

	public StudentMainPage InternationalConfirmnewinformationcanbeaddedtofield(StringHash data) throws Exception{

        //X-path Parameterization
//		Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("StudentName")+"']"));
//		Link StudentServices = new Link("Student Services", byXPath("//li[7]/span"));
//		Link ConfirmInfoSchoolFieldSaveMessage1 = new Link("Confirm Info School Field SaveMessage1", byXPath("//span[. = 'The Dependent Information records were successfully saved.']"));
//		Link ConfirmInfoSchoolFieldSaveMessage = new Link("Confirm Info School Field SaveMessage", byXPath("//span[. = 'The International records were successfully saved.']"));
//		Link Veteran = new Link("Veteran", byXPath("//div/span[. = 'Veteran']"));
//		Link Indicator = new Link("Indicator", byXPath("//span[. = 'Indicators']"));
//		Link New = new Link("New", byXPath("//a[5][. = 'New']"));
//		Link AddVeteran = new Link("Add Veteran", byXPath("//div[39]//button[1]"));
//		Link Select = new Link("Select", byXPath("//button[. = 'Select']"));
//		Link CertifiedTerm = new Link("Certified Term", byXPath("//div/cmc-drop-down-list-classic[1]/div/div/span/span/span/span"));
//		Link SelCertifiedTerm = new Link("Certified Term", byXPath("//li[1]/div/span[1]"));
//		Link Transstatus = new Link("Transaction status", byXPath("//cns-student-international-general/div/cmc-collapse/div/div[2]/div[1]/cmc-drop-down-list/div/div/span/span/span/span"));
//		Link SelTransstatus = new Link("Transaction status", byXPath("//div/div/div[2]/ul/li[2]"));
//		Link Visatyepe = new Link("Visa type", byXPath("//cns-student-international-general/div/cmc-collapse/div/div[2]/div[2]/cmc-drop-down-list/div/div/span/span/span/span"));
//		Link SelVisatyepe = new Link("Visa type", byXPath("//div/div/div[3]/ul/li[1]//span[2]"));
//		Link FormPurpose = new Link("Form Purpose", byXPath("//div[2]/div[2]/div/cmc-drop-down-list/div/div/span/span/span/span"));
//		Link SelFormPurpose = new Link("Form Purpose", byXPath("//ul[@id='generalFormPurpose_listbox']/li[1]/div/span[1]"));
//		Link CountryBirth = new Link("Country Birth", byXPath("//cns-student-international-f1-m1-data/div/cmc-collapse/div/div[2]/div[1]/cmc-drop-down-list/div/div/span/span/span/span"));
//		Link SelectData = new Link("Data", byXPath("//cns-student-international-f1-m1/div/cmc-collapse/div/div[1]/div//div"));
//		Link SelectFund = new Link("Fund", byXPath("//cns-student-international-f1-m1-funds/div/cmc-collapse/div/div[1]/div//div"));
//		Link SelectProgramme = new Link("Programme", byXPath("//cns-student-international-program/div/cmc-collapse/div/div[1]/div//div"));
//		Link SelectDependentinfo = new Link("Dependent Info", byXPath("//div/a/div"));
//		Link SelectAddress = new Link("Address", byXPath("//cns-student-international-address/div/cmc-collapse/div/div[1]/div//div"));
//		Link SelCountryBirth = new Link("Country Birth", byXPath("//div/div/div[3]/ul/li[1]/div/span[2]"));
//		TextField ProficiancyReason = new TextField("Proficiancy Reason", byXPath("//cns-student-international-f1-m1-data/div/cmc-collapse/div/div[2]/div[6]//textarea"));
//		TextField ProficiancyReason1 = new TextField("Proficiancy Reason1", byXPath("//cns-student-international-f1-m1-data/div/cmc-collapse/div/div[2]/div[6]//textarea"));
//		TextField Personal = new TextField("Enter Personal", byXPath("//cns-student-international-f1-m1-funds/div/cmc-collapse/div/div[2]/div[1]/cmc-numeric-input-text[1]/div/div/span/span"));
//		TextField Personal1 = new TextField("Enter Personal1", byXPath("//div[1]/cmc-numeric-input-text[1]/div/div/span/span"));
//		Link Enrollmentstatus = new Link("Enrollment status", byXPath("//cns-student-international-program/div/cmc-collapse/div/div[2]/div/div[1]/cmc-drop-down-list/div/div/span/span/span/span"));
//		Link SelEnrollmentstatus = new Link("Enrollment status", byXPath("(//div/div/div[3]/ul/li[1]//span[1])[1]"));
//		Link EducationLevel = new Link("Education Level", byXPath("//div[2]/div/div[2]/div/cmc-drop-down-list/div/div/span/span/span/span"));
//		Link SelEducationLevel = new Link("Education Level", byXPath("(//div/div/div[3]/ul/li[1]//span[1])"));
//		Link PrimeryMajor = new Link("Primery Major", byXPath("//div[2]/div/div[3]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
//		Link SelPrimeryMajor = new Link("Education Level", byXPath("//div/ul[@id='programVerMajor_listbox']/li[1]"));
//		TextField InstituteCharge = new TextField("Institute Charge", byXPath("//div[4]/cmc-numeric-input-text[1]/div/div/span/span"));
//		TextField InstituteCharge1 = new TextField("Institute Charge", byXPath("//div[4]/cmc-numeric-input-text[1]/div/div/span/span"));
//		TextField LivingExpense = new TextField("Living Expense", byXPath("//div[2]/div/div[4]/cmc-numeric-input-text[2]/div/div/span/span"));
//		TextField LivingExpense1 = new TextField("Living Expense", byXPath("//div[4]/cmc-numeric-input-text[2]/div/div/span/span"));
//		Link Add = new Link("add", byXPath("//a[5][. = 'Add']"));
//		Link Relationship = new Link("Relationship", byXPath("//span[@aria-controls=\"dependentInfoRelationship_listbox\"]/span"));
//		Link SelRelationship = new Link("Relationship", byXPath("//ul[@id=\"dependentInfoRelationship_listbox\"]/li[1]/div/span[1]"));
//		TextField Firstname = new TextField("Firstname", byXPath("//ng-transclude/div/div/div[2]/cmc-input-text[1]//input"));
//		TextField Lastname = new TextField("Lastname", byXPath("//ng-transclude/div/div/div[2]/cmc-input-text[2]//input"));
//		TextField MiddleName = new TextField("MiddleName", byXPath("//ng-transclude/div/div/div[3]/cmc-input-text//input"));
//		TextField Firstname1 = new TextField("Firstname", byXPath("//ng-transclude/div/div/div[2]/cmc-input-text[1]//input"));
//		TextField Lastname1 = new TextField("Lastname", byXPath("//ng-transclude/div/div/div[2]/cmc-input-text[2]//input"));
//		TextField MiddleName1 = new TextField("MiddleName", byXPath("//ng-transclude/div/div/div[3]/cmc-input-text//input"));
//		TextField EffectiveDate = new TextField("Effective Date", byXPath("//cmc-date-picker[1]//input[@placeholder = 'MM/DD/YYYY']"));
//		TextField EffectiveDate1 = new TextField("Effective Date", byXPath("//ng-transclude//input[@placeholder = 'MM/DD/YYYY']"));
//		Link Gender = new Link("Gender", byXPath("//span[@aria-controls=\"dependentInfoGender_listbox\"]/span"));
//		Link SelGender = new Link("Gender", byXPath("//ul[@id=\"dependentInfoGender_listbox\"]/li[1]/div/span[1]"));
//		Link CountryofBirth = new Link("Country of Birth", byXPath("//span[@aria-controls=\"dependentInfoBirthCountry_listbox\"]/span"));
//		Link SelCountryofBirth = new Link("Country of Birth", byXPath("//ul[@id=\"dependentInfoBirthCountry_listbox\"]/li[1]/div/span[1]"));
//		Link Citizenship = new Link("Citizenship", byXPath("//span[@aria-controls=\"dependentInfoCitizenshipCountry_listbox\"]/span"));
//		Link SelCitizenship = new Link("Citizenship", byXPath("//ul[@id=\"dependentInfoCitizenshipCountry_listbox\"]/li[1]/div/span[1]"));
//		TextField Expenses = new TextField("Expenses", byXPath("//input[1][@aria-label=\"Expenses\"]"));
//		TextField Expenses1 = new TextField("Expenses", byXPath("//div[6]/cmc-numeric-input-text/div/div/span/span"));
//		Dropbox VisaType = new Dropbox("Visa Type", byXPath("//span[@aria-controls=\"dependentInfoVisaType_listbox\"]/span"));
//		Link SelVisaType = new Link("Visa Type", byXPath("//ul[@id=\"dependentInfoVisaType_listbox\"]/li[1]/div/span[1]"));
//		Link CopyfromStudentProfile = new Link("Copy from Student Profile", byXPath("//div/div/div[1]/div[3]/a"));
//		TextField StretAddress = new TextField("Street Address", byXPath("//div[2]/div/div[2]/cmc-textarea[1]//textarea"));
//		TextField StretAddress1 = new TextField("Street Address", byXPath("//div[2]/div/div[2]/cmc-textarea[1]//textarea"));
//		Link Country = new Link("Country", byXPath("//span[@aria-controls=\"foreignCountry_listbox\"]/span"));
//		Link SelCountry = new Link("Country", byXPath("//ul[@id=\"foreignCountry_listbox\"]/li[1]/div/span[1]"));
//		TextField PhnNumber = new TextField("Phone Number", byXPath("(//input[@aria-label=\"Phone Number\"])[1]"));
//		Link SaveMassege1 = new Link("Save Massege1", byXPath("//a[@id=\"studentInternationalSaveButton\"]"));
//		Button SaveMassege = new Button("Save Massege", byXPath("//button[@id=\"saveDependentInfo\"]"));
//		Button Yes = new Button("Yes", byXPath("//button[@id=\"studentInternationalInformationDialogOkButton\"]"));
//		TextField Birthday = new TextField("Birthdate", byXPath("//input[@name=\"dependentInfoBirthDate\"]"));
//		Link ContactManager = new Link("Contact Manager", byXPath("//cns-panel-bar/ul[1]/li[1]/span"));
//		Link International = new Link("International tile", byXPath("//span[. = 'International'][1]"));
//
//		//Method Implementation
//		//waitForPageToLoad();
//		wait(10);
//		ContactManager.waitTillElementClickable();
//		ContactManager.click();
//		wait(3);
//		International.clickUsingJavaScriptExecutor();
//		waitForPageToLoad();
//		//wait(5);
//		//			Yes.click();
//		//			wait(5);
//		Transstatus.clickUsingJavaScriptExecutor();
//		wait(2);
//		SelTransstatus.click();
//		wait(3);
//		Visatyepe.clickUsingJavaScriptExecutor();
//		wait(2);
//		SelVisatyepe.clickUsingJavaScriptExecutor();
//		wait(5);
//		FormPurpose.clickUsingJavaScriptExecutor();
//		wait(2);
//		SelFormPurpose.clickUsingJavaScriptExecutor();
//		wait(5);
//		scrollPage(0, 650);
//		wait(5);
//		SelectData.clickUsingJavaScriptExecutor();
//		wait(2);
//		scrollPage(0, 90);
//		wait(3);
//		CountryBirth.clickUsingJavaScriptExecutor();
//		wait(2);
//		SelCountryBirth.clickUsingJavaScriptExecutor();
//		wait(3);
//		ProficiancyReason1.clickUsingJavaScriptExecutor();
//		wait(3);
//		ProficiancyReason.clearAndType("Learn");
//		wait(3);
//		scrollPage(0, 700);
//		wait(4);
//		SelectFund.clickUsingJavaScriptExecutor();
//		wait(7);
//		Personal1.clickUsingJavaScriptExecutor();
//		wait(3);
//		Personal.sendKeys(String.valueOf(100));
//		wait(3);
//		scrollPage(0, 500);
//		wait(3);
//		SelectProgramme.clickUsingJavaScriptExecutor();
//		wait(3);
////		Enrollmentstatus.clickUsingJavaScriptExecutor();
////		wait(3);
////		SelEnrollmentstatus.clickUsingJavaScriptExecutor();
////		wait(5);
//		EducationLevel.clickUsingJavaScriptExecutor();
//		wait(3);
//		SelEducationLevel.clickUsingJavaScriptExecutor();
//		wait(5);
//		PrimeryMajor.clickUsingJavaScriptExecutor();
//		wait(3);
//		SelPrimeryMajor.clickUsingJavaScriptExecutor();
//		wait(5);
//		/*InstituteCharge1.click();
//		    wait(2);
//		    InstituteCharge.sendKeys(String.valueOf(1000));
//		    wait(3);
//		    LivingExpense1.click();
//		    wait(2);
//		    LivingExpense.sendKeys(String.valueOf(100));
//		    wait(3);*/
//		scrollPage(0, 300);
//		wait(3);
//		SelectDependentinfo.clickUsingJavaScriptExecutor();
//		wait(3);
//		Add.clickUsingJavaScriptExecutor();
//		wait(3);
//		Relationship.clickUsingJavaScriptExecutor();
//		wait(3);
//		SelRelationship.clickUsingJavaScriptExecutor();
//		wait(3);
//		Firstname1.clickUsingJavaScriptExecutor();
//		wait(2);
//		Firstname.clearAndType("AA");
//		wait(3);
//		Lastname1.clickUsingJavaScriptExecutor();
//		wait(2);
//		Lastname.clearAndType("BB");
//		wait(3);
//		MiddleName1.clickUsingJavaScriptExecutor();
//		wait(2);
//		MiddleName.clearAndType("CC");
//		wait(3);
//		Birthday.clearAndType(EffDate);
//		wait(2);
//		Gender.clickUsingJavaScriptExecutor();
//		wait(3);
//		SelGender.clickUsingJavaScriptExecutor();
//		wait(3);
//		CountryofBirth.clickUsingJavaScriptExecutor();
//		wait(3);
//		SelCountryofBirth.clickUsingJavaScriptExecutor();
//		wait(3);
//		Citizenship.clickUsingJavaScriptExecutor();
//		wait(3);
//		SelCitizenship.clickUsingJavaScriptExecutor();
//		wait(3);
//		Expenses.sendKeys("150");
//		wait(3);
//		VisaType.click();
//		wait(2);
//		SelVisaType.click();
//		wait(2);
//		scrollPage(0, 50);
//		wait(3);
//		SaveMassege.click();	
//		wait(5);
//		CustomAsserts.containsString(ConfirmInfoSchoolFieldSaveMessage1.getText(), data.get("SuccessMessage1").toString());
//		wait(2);
//		scrollPage(0, 550);
//		wait(3);
//		SelectAddress.clickUsingJavaScriptExecutor();
//		wait(2);
//		CopyfromStudentProfile.clickUsingJavaScriptExecutor();
//		wait(6);
//		StretAddress1.clickUsingJavaScriptExecutor();
//		wait(2);
//		StretAddress.clearAndType("US");
//		wait(2);
//		Country.clickUsingJavaScriptExecutor();
//		wait(3);
//		SelCountry.clickUsingJavaScriptExecutor();
//		wait(5);
//		PhnNumber.clearAndType("12345");
//		wait(2);
//		scrollPage(0, -1000);
//		wait(2);
//		scrollPage(0, -1200);
//		wait(2);
//		SaveMassege1.clickUsingJavaScriptExecutor();
//		wait(6);
//		CustomAsserts.containsString(ConfirmInfoSchoolFieldSaveMessage.getText(), data.get("SuccessMessage").toString());
//		wait(2);
//		return this;  
		Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("StudentName")+"']"));
		Link StudentServices = new Link("Student Services", byXPath("//li[7]/span"));
		Link ConfirmInfoSchoolFieldSaveMessage1 = new Link("Confirm Info School Field SaveMessage1", byXPath("//span[. = 'The Dependent Information records were successfully saved.']"));
		Link ConfirmInfoSchoolFieldSaveMessage = new Link("Confirm Info School Field SaveMessage", byXPath("//span[. = 'The International records were successfully saved.']"));
		Link Veteran = new Link("Veteran", byXPath("//div/span[. = 'Veteran']"));
		Link Indicator = new Link("Indicator", byXPath("//span[. = 'Indicators']"));
		Link New = new Link("New", byXPath("//a[5][. = 'New']"));
		Link AddVeteran = new Link("Add Veteran", byXPath("//div[39]//button[1]"));
		Link Select = new Link("Select", byXPath("//button[. = 'Select']"));
		Link CertifiedTerm = new Link("Certified Term", byXPath("//div/cmc-drop-down-list-classic[1]/div/div/span/span/span/span"));
		Link SelCertifiedTerm = new Link("Certified Term", byXPath("//li[1]/div/span[1]"));
		Link Transstatus = new Link("Transaction status", byXPath("//cmc-drop-down-list[@cmc-id='generalTransmittalStatus']/div/div/span/button"));
		Link SelTransstatus = new Link("Transaction status", byXPath("//ul[@id='generalTransmittalStatus_listbox']/li[2]"));
		Link Visatyepe = new Link("Visa type", byXPath("//cmc-drop-down-list[@cmc-id='generalVisaCode']/div/div/span/button"));
		Link SelVisatyepe = new Link("Visa type", byXPath("//ul[@id='generalVisaCode_listbox']/li[1]/span/div/span[1]"));
		Link FormPurpose = new Link("Form Purpose", byXPath("//cmc-drop-down-list[@cmc-id='generalFormPurpose']/div/div/span/button"));
		Link SelFormPurpose = new Link("Form Purpose", byXPath("//ul[@id='generalFormPurpose_listbox']/li[1]/span/div/span[1]"));
		
		Link CountryBirth = new Link("Country Birth", byXPath("//cmc-drop-down-list[@cmc-id='f1CountryOfBirth']/div/div/span/button"));
		Link SelectData = new Link("Data", byXPath("//cns-student-international-f1-m1/div/cmc-collapse/div/div[1]/div//div"));
		Link SelectFund = new Link("Fund", byXPath("//cns-student-international-f1-m1-funds/div/cmc-collapse/div/div[1]/div//div"));
		Link SelectProgramme = new Link("Programme", byXPath("//cns-student-international-program/div/cmc-collapse/div/div[1]/div//div"));
		Link SelectDependentinfo = new Link("Dependent Info", byXPath("//cns-student-international-dependent-information//div/a/div"));
		Link SelectAddress = new Link("Address", byXPath("//cns-student-international-address/div/cmc-collapse/div/div[1]/div//div"));
		Link SelCountryBirth = new Link("Country Birth", byXPath("//ul[@id='f1CountryOfBirth_listbox']/li[1]/span/div/span[1]"));
		TextField ProficiancyReason = new TextField("Proficiancy Reason", byXPath("//cns-student-international-f1-m1-data/div/cmc-collapse/div/div[2]/div[6]//textarea"));
		TextField ProficiancyReason1 = new TextField("Proficiancy Reason1", byXPath("//cns-student-international-f1-m1-data/div/cmc-collapse/div/div[2]/div[6]//textarea"));
		TextField Personal = new TextField("Enter Personal", byXPath("//input[@aria-label='Personal'][1]"));
		TextField Personal1 = new TextField("Enter Personal1", byXPath("//div[1]/cmc-numeric-input-text[1]/div/div/span/span"));
		Link Enrollmentstatus = new Link("Enrollment status", byXPath("//cns-student-international-program/div/cmc-collapse/div/div[2]/div/div[1]/cmc-drop-down-list/div/div/span/span/span/span"));
		Link SelEnrollmentstatus = new Link("Enrollment status", byXPath("(//div/div/div[3]/ul/li[1]//span[1])[1]"));
		Link EducationLevel = new Link("Education Level", byXPath("//cmc-drop-down-list[@cmc-id='programVerEducationLevel']/div/div/span/button"));
		Link SelEducationLevel = new Link("Education Level", byXPath("//ul[@id='programVerEducationLevel_listbox']/li[1]/span/div/span[1]"));
		Link PrimeryMajor = new Link("Primery Major", byXPath("//cmc-drop-down-list[@cmc-id='programVerMajor']/div/div/span/button"));
		Link SelPrimeryMajor = new Link("Education Level", byXPath("//ul[@id='programVerMajor_listbox']/li[1]/span/div/span[1]"));
		TextField InstituteCharge = new TextField("Institute Charge", byXPath("//input[@aria-label='Institutional Charges'][1]"));
		TextField InstituteCharge1 = new TextField("Institute Charge", byXPath("//div[4]/cmc-numeric-input-text[1]/div/div/span/span"));
		TextField LivingExpense = new TextField("Living Expense", byXPath("//input[@aria-label='Living Expenses'][1]"));
		TextField LivingExpense1 = new TextField("Living Expense", byXPath("//div[4]/cmc-numeric-input-text[2]/div/div/span/span"));
		Link Add = new Link("add", byXPath("//button[5][. = 'Add']"));
		Link Relationship = new Link("Relationship", byXPath("//cmc-drop-down-list[@cmc-id='dependentInfoRelationship']/div/div/span/button"));
		Link SelRelationship = new Link("Relationship", byXPath("//ul[@id='dependentInfoRelationship_listbox']/li[1]/span/div/span[1]"));
		TextField Firstname = new TextField("Firstname", byXPath("//input[@id='dependentInfoFirstName']"));
		TextField Lastname = new TextField("Lastname", byXPath("//input[@id='dependentInfoLastName']"));
		TextField MiddleName = new TextField("MiddleName", byXPath("//ng-transclude/div/div/div[3]/cmc-input-text//input"));
		TextField Firstname1 = new TextField("Firstname", byXPath("//ng-transclude/div/div/div[2]/cmc-input-text[1]//input"));
		TextField Lastname1 = new TextField("Lastname", byXPath("//ng-transclude/div/div/div[2]/cmc-input-text[2]//input"));
		TextField MiddleName1 = new TextField("MiddleName", byXPath("//ng-transclude/div/div/div[3]/cmc-input-text//input"));
		TextField EffectiveDate = new TextField("Effective Date", byXPath("//cmc-date-picker[1]//input[@placeholder = 'MM/DD/YYYY']"));
		TextField EffectiveDate1 = new TextField("Effective Date", byXPath("//ng-transclude//input[@placeholder = 'MM/DD/YYYY']"));
		Link Gender = new Link("Gender", byXPath("//cmc-drop-down-list[@cmc-id='dependentInfoGender']/div/div/span/button"));
		Link SelGender = new Link("Gender", byXPath("//ul[@id='dependentInfoGender_listbox']/li[1]/span/div/span[1]"));
		Link CountryofBirth = new Link("Country of Birth", byXPath("//cmc-drop-down-list[@cmc-id='dependentInfoBirthCountry']/div/div/span/button"));
		Link SelCountryofBirth = new Link("Country of Birth", byXPath("//ul[@id='dependentInfoBirthCountry_listbox']/li[1]/span/div/span[1]"));
		Link Citizenship = new Link("Citizenship", byXPath("//cmc-drop-down-list[@cmc-id='dependentInfoCitizenshipCountry']/div/div/span/button"));
		Link SelCitizenship = new Link("Citizenship", byXPath("//ul[@id='dependentInfoCitizenshipCountry_listbox']/li[1]/span/div/span[1]"));
		TextField Expenses = new TextField("Expenses", byXPath("//input[1][@aria-label='Expenses']"));
		TextField Expenses1 = new TextField("Expenses", byXPath("//div[6]/cmc-numeric-input-text/div/div/span/span"));
		Dropbox VisaType = new Dropbox("Visa Type", byXPath("//cmc-drop-down-list[@cmc-id='dependentInfoVisaType']/div/div/span/button"));
		Link SelVisaType = new Link("Visa Type", byXPath("//ul[@id='dependentInfoVisaType_listbox']/li[1]/span/div/span[1]"));
		Link CopyfromStudentProfile = new Link("Copy from Student Profile", byXPath("//div/div/div[1]/div[3]/a"));
		TextField StretAddress = new TextField("Street Address", byXPath("//textarea[@name='foreignStreetAddress']"));
		TextField StretAddress1 = new TextField("Street Address", byXPath("//div[2]/div/div[2]/cmc-textarea[1]//textarea"));
		Link Country = new Link("Country", byXPath("//span[@aria-controls='foreignCountry_listbox']/span"));
		Link SelCountry = new Link("Country", byXPath("//ul[@id='foreignCountry_listbox']/li[1]/div/span[1]"));
		TextField PhnNumber = new TextField("Phone Number", byXPath("(//input[@aria-label='Phone Number'])[1]"));
		Link SaveAndCose = new Link("Save Massege1", byXPath("//button[@id='studentInternationalSaveButton']"));
		Button Save = new Button("Save Massege", byXPath("//button[@id='saveDependentInfo']"));
		Button Yes = new Button("Yes", byXPath("//button[@id='studentInternationalInformationDialogOkButton']"));
		TextField Birthday = new TextField("Birthdate", byXPath("//input[@name='dependentInfoBirthDate']"));
		Link ContactManager = new Link("Contact Manager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
		Link International = new Link("International", byXPath("//span[. = 'International'][1]"));
		AngDropDown CountryOfCitizenship = new AngDropDown("Country Of Citizenship", byXPath("//cmc-drop-down-list[@cmc-id='studentInfoCitizenshipCountry']/div/div/span/button"));
		Link SelCountryOfCitizenship = new Link("Select Country Of Citizenship", byXPath("//ul[@id='studentInfoCitizenshipCountry_listbox']/li[1]/span/div/span[1]"));
		Button Change = new Button("Click on Change", byXPath("//button[@id='studentInternationalInformationDialogOkButton']"));
		TextField USStreetAddress = new TextField("US Street Address", byXPath("//textarea[@id='usStreetAddress']"));
		TextField UsCity = new TextField("Enter US City", byXPath("//input[@id='usCity']"));
		TextField UsState = new TextField("Enter US State", byXPath("(//input[@aria-label='State'])[1]"));
		Link SelectState = new Link("Click on the State", byXPath("(//span[@title='NY'])[1]"));
		Dropbox PostalCode = new Dropbox("Click on the DropDown", byXPath("//span[@aria-controls='usPostalCode_listbox']"));
		Link SelectPostalCode = new Link("Click on PostalCode", byXPath("//ul[@id='usPostalCode_listbox']/li[1]"));
		TextField Englishproficiency = new TextField("Enter the Proficiency", byXPath("//textarea[@id='EnglishProficiencyNotRequiredReason']"));
		Link AlertMsg= new Link("Capturing alert message", byXPath("//span[@role='alert']"));
		Link Dontsave = new Link ("Dontsave",byXPath("//button[@id='cnsDirtyCheckUnsavedChangesDialogNotOkButton']"));

		//Method Implementation
		ContactManager.waitTillElementClickable();
		ContactManager.clickUsingJavaScriptExecutor();
		International.waitTillElementClickable();
		International.clickUsingJavaScriptExecutor();
		wait(2);
//		Dontsave.waitTillElementClickable();
//		Dontsave.click();
//		wait(10);
		//waitForPageToLoad();
		//		try {
		//
		//			String Alertmessage = AlertMsg.getText();
		//
		//			if (AlertMsg.isDisplayed()) {
		//
		//			TestReportsLog.log(LogStatus.INFO, Alertmessage);
		//
		//			}
		//
		//			} catch (Exception e) {
		//
		//			}
		//		wait(20);
//		if (Change.isDisplayed()) {
//			Change.click();
//		}
		//Yes.click();
		wait(4);
//		Transstatus.waitTillElementClickable();
//		Transstatus.click();
//		SelTransstatus.waitTillElementClickable();
//		SelTransstatus.click();
		wait(1);
		Visatyepe.waitTillElementClickable();
		Visatyepe.clickUsingJavaScriptExecutor();
		SelVisatyepe.waitTillElementClickable();
		SelVisatyepe.clickUsingJavaScriptExecutor();
		wait(1);
//		FormPurpose.waitTillElementClickable();
//		FormPurpose.clickUsingJavaScriptExecutor();
//		SelFormPurpose.waitTillElementClickable();
//		SelFormPurpose.clickUsingJavaScriptExecutor();
		wait(1);
		CountryOfCitizenship.waitTillElementClickable();
		CountryOfCitizenship.click();
		SelCountryOfCitizenship.waitTillElementClickable();
		SelCountryOfCitizenship.click();
		wait(1);
		scrollPage(0, 650);
		SelectData.waitTillElementClickable();
		SelectData.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0, 90);
		CountryBirth.waitTillElementClickable();
		CountryBirth.clickUsingJavaScriptExecutor();
		SelCountryBirth.waitTillElementClickable();
		SelCountryBirth.clickUsingJavaScriptExecutor();
		wait(1);
		Englishproficiency.waitTillElementFound();
		Englishproficiency.clearAndType("Learn");
		wait(1);
		scrollPage(0, 700);
		SelectFund.waitTillElementClickable();
		SelectFund.clickUsingJavaScriptExecutor();
		wait(1);
		//		Personal1.click();
		//		wait(3);
		Personal.waitTillElementClickable();
		Personal.sendKeys(String.valueOf(100));
		wait(1);
		scrollPage(0, 500);
		SelectProgramme.waitTillElementClickable();
		SelectProgramme.clickUsingJavaScriptExecutor();
		//		Enrollmentstatus.clickUsingJavaScriptExecutor();
		//		wait(3);
		//		SelEnrollmentstatus.clickUsingJavaScriptExecutor();
		//		wait(5);
		EducationLevel.waitTillElementClickable();
		EducationLevel.clickUsingJavaScriptExecutor();
		SelEducationLevel.waitTillElementClickable();
		SelEducationLevel.clickUsingJavaScriptExecutor();
		wait(1);
		PrimeryMajor.waitTillElementClickable();
		PrimeryMajor.clickUsingJavaScriptExecutor();
		SelPrimeryMajor.waitTillElementClickable();
		SelPrimeryMajor.clickUsingJavaScriptExecutor();
		wait(1);
		InstituteCharge.waitTillElementClickable();
		InstituteCharge.clickUsingJavaScriptExecutor();
		InstituteCharge.sendKeys("200");
		wait(1);
		LivingExpense.waitTillElementClickable();
		LivingExpense.clickUsingJavaScriptExecutor();
		wait(1);
		LivingExpense.waitTillElementFound();
		LivingExpense.sendKeys("100");
		wait(1);
		scrollPage(0, 300);
		SelectDependentinfo.waitTillElementClickable();
		SelectDependentinfo.clickUsingJavaScriptExecutor();
		Add.waitTillElementClickable();
		Add.clickUsingJavaScriptExecutor();
		wait(2);
		Relationship.waitTillElementClickable();
		Relationship.clickUsingJavaScriptExecutor();
		SelRelationship.waitTillElementClickable();
		SelRelationship.clickUsingJavaScriptExecutor();
		Firstname1.waitTillElementClickable();
		Firstname1.clickUsingJavaScriptExecutor();
		wait(1);
		Firstname.waitTillElementClickable();
		Firstname.clearAndType("AA");
		Lastname1.waitTillElementClickable();
		Lastname1.clickUsingJavaScriptExecutor();
		wait(1);
		Lastname.waitTillElementClickable();
		Lastname.clearAndType("BB");
		wait(1);
		//		MiddleName1.clickUsingJavaScriptExecutor();
		//		wait(2);
		//		MiddleName.clearAndType("CC");
		//		wait(3);
		Birthday.waitTillElementFound();
		Birthday.clearAndType(EffDate);
		wait(1);
		Gender.waitTillElementClickable();
		Gender.clickUsingJavaScriptExecutor();
		SelGender.waitTillElementClickable();
		SelGender.clickUsingJavaScriptExecutor();
		wait(1);
		CountryofBirth.waitTillElementClickable();
		CountryofBirth.clickUsingJavaScriptExecutor();
		SelCountryofBirth.waitTillElementClickable();
		SelCountryofBirth.clickUsingJavaScriptExecutor();
		wait(1);
		Citizenship.waitTillElementClickable();
		Citizenship.clickUsingJavaScriptExecutor();
		SelCitizenship.waitTillElementClickable();
		SelCitizenship.clickUsingJavaScriptExecutor();
		wait(1);
		Expenses.waitTillElementFound();
		Expenses.sendKeys("150");
		wait(1);
		VisaType.waitTillElementClickable();
		VisaType.click();
		SelVisaType.waitTillElementClickable();
		SelVisaType.click();
		wait(1);
		scrollPage(0, 50);
		Save.waitTillElementClickable();
		Save.click();	
		wait(5);
		CustomAsserts.containsString(ConfirmInfoSchoolFieldSaveMessage1.getText(), data.get("SuccessMessage1").toString());
		scrollPage(0, 550);
		SelectAddress.waitTillElementClickable();
		SelectAddress.clickUsingJavaScriptExecutor();
				wait(7);
			CopyfromStudentProfile.clickUsingJavaScriptExecutor();
		wait(2);
		StretAddress.waitTillElementClickable();
		StretAddress.clickUsingJavaScriptExecutor();
		StretAddress.waitTillElementFound();
		StretAddress.clearAndType("US");
		wait(1);
		/*
		Country.waitTillElementClickable();
		Country.clickUsingJavaScriptExecutor();
		SelCountry.waitTillElementClickable();
		SelCountry.clickUsingJavaScriptExecutor();
		wait(1);
		PhnNumber.waitTillElementClickable();
		PhnNumber.clearAndType("12345");
		wait(1);
		USStreetAddress.waitTillElementClickable();
		USStreetAddress.clickUsingJavaScriptExecutor();
		USStreetAddress.waitTillElementFound();
		USStreetAddress.clearAndType("132, My Street, Kingston, New York");
		wait(2);
		UsCity.waitTillElementFound();
		UsCity.clearAndType("Denver");
		wait(1);
		UsState.waitTillElementFound();
		UsState.clearAndType("NY");
		SelectState.waitTillElementClickable();
		SelectState.clickUsingJavaScriptExecutor();
		wait(1);
		PostalCode.waitTillElementClickable();
		PostalCode.clickUsingJavaScriptExecutor();
		SelectPostalCode.waitTillElementClickable();
		SelectPostalCode.clickUsingJavaScriptExecutor();  */
		wait(1);
		scrollPage(0, -1000);
		wait(1);
		scrollPage(0, -1200);
		SaveAndCose.waitTillElementClickable();
		SaveAndCose.clickUsingJavaScriptExecutor();
		wait(5);
		//CustomAsserts.containsString(ConfirmInfoSchoolFieldSaveMessage.getText(), data.get("SuccessMessage").toString());
		return this;
	}

	public StudentMainPage BatchOfStudentRegistration(StringHash data) throws Exception{

		//X-path Parameterization
		Link ClickTerm = new Link("Term", byXPath("//div[@id='search_display_termId']"));
		TextField TermCode = new TextField("Enter Term Code", byXPath("//input[@placeholder='Search Name or Code']"));
		Checkbox TermCheckBox = new Checkbox("Select Term", byXPath("//tr//td//input"));
		Button TermSelectButton = new Button("Select Button", byXPath("//button[.='Select']"));
		Link ClassSectionClick = new Link("ClassSection", byXPath("//td[.='BI 211       - Human Anatomy-Lec']"));
		Button NextButton = new Button("Next Button", byXPath("//button[.='Next']"));
		Link AllStuCheckBox = new Link("Select CheckBox", byXPath("//th//input"));
		Link QueueRegistration = new Link("Queue Registration", byXPath("//a[@id='queueRegistrationButton']"));
		Button QueueButton = new Button("Queue Button", byXPath("//button[@id='saveSubmitJob']"));
		Link PopUpValidation = new Link("Validation Message", By.xpath("//span[text()='The Track Registration records were successfully queued.')]"));
		TextField SearchProcesses = new TextField("Search Process", byXPath("//input[@placeholder='Search Processes']"));
		Link Registration = new Link("Registration Type", byXPath("//span[text()='Registration']"));

		//Method Implementation
		//waitForPageToLoad();
		SearchProcesses.waitTillElementClickable();
		SearchProcesses.click();
		wait(3);
		SearchProcesses.sendkeys("Registration");
		wait(2);
		Registration.click();
		wait(7);
		ClickTerm.clickUsingJavaScriptExecutor();
		wait(3);
		TermCode.clearAndType(data.get("TermCode").toString());
		wait(2);
		TermCheckBox.clickUsingJavaScriptExecutor();
		wait(1);
		scrollPage(0,50);
		TermSelectButton.clickUsingJavaScriptExecutor();
		wait(3);
		ClassSectionClick.clickUsingJavaScriptExecutor();
		wait(3);
		scrollPage(0,40);
		NextButton.click();
		wait(7);
		AllStuCheckBox.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0,70);
		QueueRegistration.clickUsingJavaScriptExecutor();
		wait(4);
		QueueButton.clickUsingJavaScriptExecutor();
		//wait(2);
		//CustomAsserts.containsString(PopUpValidation.getText(), data.get("SuccessMessage").toString());
		wait(4);
		return this;

	}


	public StudentMainPage TransferedProgrameReentry(StringHash data) throws Exception{

		//X-path Parameterization
		Link EnrollmentSpan = new Link("Enrollment", byXPath("//li[3]/div/div[1]/div"));
		Link reentryStudentSaveMessage = new Link("Programe Reentry Student SaveMessage", byXPath("//span[. = 'The Enrollment records were successfully saved.']"));
		Link selecting_programe = new Link("selecting_programe", byXPath("(//tbody/tr[1]/td[2])[1]"));
		Link reentry = new Link("reentry ", byXPath("//a[text()='Reentry']"));
		Button proceed = new Button("proceed ", byXPath("(//button[text()='Proceed'])[1]"));
		//Link reentry_startdate_dropdown = new Link("reentry_startdate_dropdown", byXPath("//span[@aria-label='Reentry Start Date: Dropdown']/span/span/span"));
		Link reentry_startdate_dropdown = new Link("reentry_startdate_dropdown", byXPath("//span[contains(@aria-label,'Reentry Start Date')]/span/span/span"));
		Link term_selected = new Link("term start date ", byXPath("(//ul[@id='StartDateId_listbox']/li/div/span)[1]"));
		//Link school_status_dropdown = new Link("school_status_dropdown", byXPath("//span[@aria-label='School Status: Dropdown']/span/span/span"));
		Link school_status_dropdown = new Link("school_status_dropdown", byXPath("//span[contains(@aria-label,'School Status')]/span/span/span"));
		Link active = new Link("active", byXPath("//span[@title='Active']"));		
		Button next1 = new Button("next 1 ", byXPath("//button[@id='programSelectionProceedButton']"));
		Button ok_button = new Button("ok", byXPath("//button[@id='confirmSAPWindowOkButton']"));
		Button next2 = new Button("next 2 ", byXPath("//button[@id='studentCourseProceedButton']"));
		Button next3 = new Button("next 3 ", byXPath("//button[@id='feeProceedButton']"));
		Link entryclick = new Link("re enrty", byXPath("(//a[@id='reentrySaveButton'])[2]"));
		Link AcademicRecords = new Link("Academic Records", byXPath("//cns-panel-bar/ul/li[3]/a/span"));
		Link StudentCourses = new Link("Student Courses", byXPath("//li[3]/div/div[3]/div"));
		Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("(//a[@class='k-button k-split-button-arrow'])[1]"));
		//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
		Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//a[. = 'Reset to Default']"));
		Link TermDropDown = new Link("Term Number Dropdown", byXPath("(//th[1]//span)[1]"));
		Button TerNumFilter = new Button("Term Number Filter", byXPath("//span[.='Filter']"));
		TextField value1 = new TextField("Value", byXPath("//input[@title='Value']"));
		Button FilterButton1 = new Button("Filter Button", byXPath("//button[text()='Filter']"));
		Link SelectPrograme = new Link("Programe", byXPath("//td[text()='Any']"));
		Link More = new Link("More", byXPath("//div[@id='moreEnrollmentButton_wrapper']/a[2]"));
		Link Transfer = new Link("Transfer", byXPath("//a[@id='transferButton']"));
		TextField value = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
		Button FilterButton = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));

		//Method Implementation
		//waitForPageToLoad();
		//wait(10);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		EnrollmentSpan.click();
		wait(10);
		ClsFilterDropDwon.click();
		wait(2);
		ClsClearFiltersButton.click();
		wait(5);
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		TermDropDown.click();
		wait(2);
		TerNumFilter.click();
		wait(2);
		value.clearAndType(data.get("Program Version"));
		wait(2);
		FilterButton.click();
		wait(5);
		selecting_programe.click();  
		wait(5);
		More.click();
		wait(5);
		reentry.clickUsingJavaScriptExecutor();
		wait(3);
		proceed.click();
		//wait(7);
		//driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		waitForPageToLoad();
		reentry_startdate_dropdown.click();
		wait(3);
		term_selected.click();
		wait(3);
		school_status_dropdown.click();
		wait(3);
		active.click();
		wait(5);
		next1.click();
		wait(5);
		if(ok_button.isDisplayed())
			ok_button.click();
		wait(5);
		next2.click();
		wait(5);
		next3.click();
		wait(5);
		entryclick.clickUsingJavaScriptExecutor();
		wait(5);
		CustomAsserts.containsString(reentryStudentSaveMessage.getText(), data.get("SuccessMessage").toString());	
		return this;
	}


}



