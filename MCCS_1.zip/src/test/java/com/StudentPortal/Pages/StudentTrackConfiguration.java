package com.StudentPortal.Pages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.framework.base.BasePage;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.StringHash;

public class StudentTrackConfiguration extends BasePage{
	static ArrayList<Integer> arr=new ArrayList<Integer>();
	//static Link MenuButton = new Link("Click Menu Button", By.xpath("//span[@title='Menu Button']"));
	//static Link Groups = new Link("Groups",By.xpath("//a[@title='Groups']"));
	static Link NewGroup = new Link(" New Groups",By.xpath("//*[@id='listAddButton']"));
	static TextField NewGroupName= new TextField ("New Group name",By.xpath("//input[@id='name']"));
	static Link SaveNewGrp = new Link("Click Save",By.xpath("//button[@aria-label='Save']"));
	static Link AddStudents = new Link("Click on Add",By.xpath("//*[@id='listAddButton']"));	
	static Link StuDownArrow= new Link("Add Student",By.xpath("(//th[@data-field='StudentNumber']/a/span)[1]"));
	static TextField EnterStudentId= new TextField ("Enter Student Number",By.xpath("//input[@title='Value']"));
	static Button StuFilter = new Button("Click on Filter",By.xpath("//button[.='Filter']"));
	static Link StuCheckBox= new Link("Select Student",By.xpath("//tr//td//input"));
	static Button StuSelect = new Button("Click on Select",By.xpath("//button[.='Select']"));
	//The Student records were successfully saved.
	Link Groupvalidation = new Link("Validation Message", By.xpath("//span[text()='The Student records were successfully saved.']"));
	static Link SaveNClose= new Link("Save and Close",By.xpath("//button[@aria-label='Save & Close']"));
	static String Groupname = AppendValue.apendString();
	static String Abc;



	//Registration Track Creation

	//static Link Configuration = new Link("Click Configuration", By.xpath("//a[@title='Configuration']"));
	static TextField Searchfield= new TextField("Searchfiled", By.xpath("//input[@id='lists-treeview-filter']"));
	static Link RegTrack = new Link("Click on Registration Track", By.xpath("//div/span[.='Registration Tracks']"));
	static Link NewTrack = new Link("Click on New", By.xpath("//*[@id='newButton']"));
	static TextField NewTrackName= new TextField("Name", By.xpath("//input[@id='name']"));
	static TextField NewTrackCode= new TextField("Code", By.xpath("//input[@id='code']"));
	static Link TermFieldCLick = new Link("Click on Term", By.xpath("//div[@id='search_display_classSectionSearch']"));
	static TextField TermSearchField= new TextField("Search", By.xpath("//input[@id='search']"));
	static Link TermCheckBox = new Link("Select CheckBox", By.xpath("(//tr//td//input)[1]"));
	static Button TermSelect = new Button("Click on Select",By.xpath("//button[.='Select']"));
	static Link Campusdropdown = new Link("Select campus", By.xpath("(//button[@aria-label='expand combobox'])[1]"));
	static Link CampusSelect= new Link("Select campus", By.xpath("//ul[@id='campusGroupId_listbox']//li[1]//div/span[1]"));
	static Button AddtoList = new Button("Click on AddToList",By.xpath("//button[.='Add to List']"));
	static Link AlltermCheckBox = new Link("Select CheckBox", By.xpath("//div[@id='classSectionListCnsGrid']//input[@id='checkAll']"));//click twice
	static Link ClassSection = new Link("Click on class section", By.xpath("//a[contains(text(),'Class Sections')]"));
	static Link ClassSectionScroll = new Link("Class Section Scroll", By.xpath("//div[@id='detailPane']"));

	//call save and close
	//The Registration Track records were successfully saved.
	Link validation = new Link("Validation Message", By.xpath("//span[text()='The Registration Track records were successfully saved.']"));
	static String TrackName = AppendValue.apendString();
	static String TrackCode = AppendValue.apendString();
	static String Abcd;

	//Track Registration

	//static Link Processes = new Link("Click Processes", By.xpath("//a[@title='Processes']"));
	static TextField ProcessSearchField= new TextField("Searchfiled", By.xpath("//input[@id='lists-treeview-filter']"));
	static Link RegistrationLink = new Link("Click Registration", By.xpath("//span[.='Registration']"));
	static TextField ProcessSearch = new TextField("Process", By.xpath("//input[@placeholder='Search Processes']"));
	static Link Registration= new Link(" Registration Search", By.xpath("//span[(text()='Registration')]"));
	static Button Track = new Button("Click Track", By.xpath("//button[contains(text(),'Track')]"));
	//static Link Dropdown= new Link("Expand Track Info", By.xpath("//div//a[@cmc-expand='$ctrl.step1Expand']/div"));
	//static Link SelectTrack= new Link("Select Track", By.xpath("//input[@placeholder='Search Processes']"));
	static Link TrackInfoClick= new Link("Select Track", By.xpath("//td[(text()='Test Track')]"));
	static TextField EnterSgroup= new TextField(" Student Group", By.xpath(" //input[@name='studentGroupDropDown_input']"));
	static TextField Search= new TextField("Search", By.xpath("//input[@id='search']"));

	//static Link SGroupDropDown= new Link("Student Group DropDown",By.xpath("//span[@aria-controls='studentGroupDropDown_listbox']"));
	static Button Next = new Button("Click Next", By.xpath("//button[contains(text(),'Next')]"));
	static Checkbox AllstuCheck= new Checkbox(" Student Group", By.xpath(" //input[@aria-label='Select All StudentId']"));
	static Button Queue = new Button("Click Queue Registration", By.xpath("//a[@id='queueRegistrationButton']"));
	static Button SubmitQueue = new Button("Click Queue Registration", By.xpath("//button[@id='saveSubmitJob']"));
	static Button Override = new Button("Click on Override", By.xpath("//div//button[(text()='Override')]"));
	static Checkbox SelectStudent= new Checkbox("SelectStudent", By.xpath("(//tr//td//input)[1]"));



	public StudentTrackConfiguration StudentGroup(StringHash data) throws Exception {
//		arr.add(0,443184);
//		arr.add(1, 489220);
//		waitForPageToLoad();
		NewGroup.clickUsingJavaScriptExecutor();
		wait(12);
		scrollPage(0,-270);
		wait(4);
		NewGroupName.clickUsingJavaScriptExecutor();
		wait(1);
		NewGroupName.clearAndType(Groupname);
		wait(2);
		Abc= Groupname;
		System.out.println( "New group name:"+Abc);
		SaveNewGrp.clickUsingJavaScriptExecutor();
		wait(5);
			AddStudents.clickUsingJavaScriptExecutor();
			wait(5);
			Search.clearAndType(data.get("StudentNumber"));
			wait(6);
			SelectStudent.click();
			wait(2);
			//Search.clearAndType(data.get("SecondStudent"));
			wait(2);
			//SelectStudent.click();
			wait(2);
			StuSelect.clickUsingJavaScriptExecutor();
			wait(3);
		SaveNClose.clickUsingJavaScriptExecutor();
		wait(3);
		//CustomAsserts.containsString(Groupvalidation.getText(), data.get("Validation msg").toString());

		return this;
	}
	public StudentTrackConfiguration RegistrationTrackCreation(StringHash data) throws Exception{
//		String CreatedGrp;

		Searchfield.sendkeys("Registration Tracks");
		wait(3);
		RegTrack.clickUsingJavaScriptExecutor();
		wait(6);
		NewTrack.clickUsingJavaScriptExecutor();
		wait(7);
		NewTrackName.clearAndType(TrackName);
//		Abcd=TrackName;
		System.out.println("Created Track Name:"+TrackName);
		wait(3);
		NewTrackCode.clearAndType(TrackCode);
		String TrackRegiCode=NewTrackCode.getText();
		wait(3);
		Campusdropdown.clickUsingJavaScriptExecutor();
		wait(1);
		CampusSelect.clickUsingJavaScriptExecutor();
		wait(1);
		scrollPage(0,30);
		ClassSection.clickUsingJavaScriptExecutor();
//		wait(2);
//		ClassSectionScroll.dragScrollbar(70);
//		wait(2);
		TermFieldCLick.clickUsingJavaScriptExecutor();
		wait(2);
		TermSearchField.clearAndType(data.get("TermCode").toString());
		wait(2);
		TermCheckBox.clickUsingJavaScriptExecutor();
		wait(1);
		TermSelect.clickUsingJavaScriptExecutor();
		wait(3);
		AddtoList.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0,25);
		AlltermCheckBox.clickUsingJavaScriptExecutor();
		AlltermCheckBox.clickUsingJavaScriptExecutor();
		wait(3);
		SaveNClose.clickUsingJavaScriptExecutor();
		wait(3);
		//CustomAsserts.containsString(validation.getText(), data.get("Validation msg2").toString());
		return this;
	}
}
	/*public StudentTrackConfiguration TrackRegistration(StringHash data) throws Exception{


		waitForPageToLoad();
		wait(1);
		ProcessSearch.sendkeys("Registration");
		wait(1);
		Registration.click();
		wait(8);
		Track.click();
		wait(6);
		List<WebElement> rows = driver.findElements(By.xpath("//table//tr")); 
		Link PopUpValidation = new Link("Validation Message", By.xpath("//span[contains(text(),'The Track Registration records were successfully queued.')]"));
		wait(1);
		rows.size();
		System.out.println(rows.size());
		for (int i=1; i<=rows.size(); i++) {
			WebElement elementTrackName = driver.findElement(By.xpath("//table//tr["+i+"]//td[1]"));
			System.out.println("//table//tr["+i+"]//td[1]");
			String actualValue = elementTrackName.getText();
			System.out.println(actualValue);
			System.out.println(Abcd);
			if(actualValue.equals(Abcd.toString())) {
				elementTrackName.getText();
				elementTrackName.click();
				wait(2);
				System.out.println(elementTrackName);
				wait(4);
				break; 
			}
		}

		EnterSgroup.click();
		wait(4);
		EnterSgroup.clearAndType(Abc.toString());
		wait(2);
		scrollPage(0,20);
		Next.click();
		wait(14);
		AllstuCheck.clickUsingJavaScriptExecutor();
		wait(3);
		Queue.clickUsingJavaScriptExecutor();
		wait(5);
		
		SubmitQueue.clickUsingJavaScriptExecutor();
		wait(7);
		CustomAsserts.containsString(PopUpValidation.getText(), data.get("SuccessMessage").toString());
		return this;

	}
}*/

