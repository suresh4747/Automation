package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byCSSSelector;
import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;

import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import static com.framework.elements.Locator.byName;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.DatesUtil;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentAcademicRecordsPage extends BasePage{
	
	
	static Link StudentCourses = new Link("Student Courses span", byXPath("//span[text()='Student Courses']"));
	static Button FilterDropDwon = new Button("Filter Drop Down", byXPath("(//a[@class=\"k-button k-split-button-arrow\"])[1]"));
	static Button ClearFiltersButton = new Button("Filter Button", byId("listClearFiltersButton"));
	static AngDropDown StuNumDropDown = new AngDropDown("Student Number Dropdown", byXPath("//th[2]/a/span"));
	static Button StuNumFilter = new Button("Stud Num Filter", byXPath("//span[.=\"Filter\"]"));
	static TextField value = new TextField("Enter Value", byXPath("//input[@title=\"Value\"]"));
	static Button FilterButton = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));
	//X-Path Parameter	static Link ClickStudent = new Link("Click Student Name",byXPath("//span[.=\"Harris, Colette\"]"));
	static Link AcademicRecords = new Link("Academic Records", byXPath("//cns-panel-bar/ul[1]/li[3]/a/span"));
	static Link NewEnrButton = new Link("New", byId("newButton"));
	static Link ClickNext1 = new Link("New", byId("studentSelectionProceedButton"));
	static Link SchoolStatusSpan = new Link("School Status Span", byXPath("//div/div[1]/cmc-drop-down-list-classic[2]/div/div/span/span/span[. = ' ']"));
	static TextField EnterSchoolStatus = new TextField("School Status", byXPath("//input[@aria-owns=\"SchoolStatusId_listbox\"]"));
	//	X-Path Parameter	static Button SelectSchoolStatus = new Button(" School Status", byXPath("//span[.=\"Being Processed\"]"));
	//static Button ClickProgram = new Button("Program", byXPath("//span[@aria-label=\"Program: Dropdown\"]"));
	static Button ClickProgram = new Button("Program", byXPath("//span[contains(@aria-label,'Program')]"));
	static TextField ProgramName = new TextField("Program Name", byXPath("//input[@aria-owns=\"ProgramId_listbox\"]"));
	//X-Path Parameter	static Button SelectProgram = new Button(" Program", byXPath("//span[.=\"Advanced & Continuous Studies\"]"));
	static Link ClickProgramVersion = new Link("Program Version", byXPath("//span[@aria-owns=\"ProgramVersionId_listbox\"]"));
	static TextField EnterProgramVersion = new TextField("School Status", byXPath("//input[@aria-owns=\"ProgramVersionId_listbox\"]"));
    static Link ClickFilter = new Link("Filter", byXPath("//a[text()=\"Clear Filters\"]"));
    static Link CourseCodeDropdown = new Link("Course Code dropdown", byXPath("//a[@title=\"Course Code edit column settings\"]"));
    static Button CClFilterDropDown = new Button("Filter", byXPath("(//span[text()=\"Filter\"])[1]"));
    static TextField Value = new TextField("Filter", byXPath("//input[@title=\"Value\"]"));
    static Button Filter = new Button("Filter Button", byXPath("(//span[text()=\"Filter\"])[2]"));
	static TextField Notes = new TextField("Notes", byXPath("//textarea[@name='note']"));
	static TextField Course = new TextField("Course Field", byCSSSelector("#search_display_courseId"));
	static TextField SearchBox = new TextField("SearchBox", byCSSSelector("#search"));
	static Checkbox Input = new Checkbox("Input", byXPath("//td/input"));
	static Button Select = new Button("Select button", byXPath("//button[. = 'Select']"));
	//	static TextField Term = new TextField("Course Field", byCSSSelector("#search_display_termId"));
	static Button SaveAndRegister = new Button("Save and Register", byXPath("//cmc-toolbar-button-save-new[2]//button"));
	static Button AddCourseWithoutCategory = new Button("Add course without category", byCSSSelector("#courseTakenNotAppliedDialogOkButton"));
	static Link Next = new Link("Next", byId("courseInformationProceedButton"));
	//static Link InstructorTableCell = new Link("InstructorTableCell", byCSSSelector("#classSectionGrid_cmcGrid_active_cell"));
	static TextField Term = new TextField("Term", byXPath("//input[@name='termId_input']"));	
	static Link Register = new Link("Register link", byId("courseUnRegisterButton")); 
	static Button RegisterButton = new Button("Register", byXPath("(//button[.=\"Register\"])[3]"));
	//static Link Drop = new Link("Drop Link", byCSSSelector("#courseDropButton"));
	static Link Drop = new Link("Drop Link", byXPath("//button[8][. = 'Drop']"));
	//static Link DropLetterGrade = new Link("Drop Letter Grade", byXPath("//span[@aria-label=\"Letter Grade: Dropdown\"]"));
	static Link DropLetterGrade = new Link("Drop Letter Grade", byXPath("//span[contains(@aria-label,'Letter Grade')]"));
	static TextField EnterDropLetterGrade = new TextField("Drop Letter Grade", byXPath("//input[@aria-owns=\"letterGrade_listbox\"]"));
	static Link ClickDropGradeReasons = new Link("Grade Reasons", byXPath("//span[@aria-owns=\"dropReason_listbox\"]"));
	static TextField EnterReason = new TextField("Grade Reasons", byXPath("//input[@aria-owns=\"dropReason_listbox\"]"));
	static Button ClickEnteredReason = new Button("Entered Reason", byXPath("(//li[.=\"Degree change\"])[1]"));
	static Button DropButton = new Button("Drop Button", byXPath("(//button[.=\"Drop\"])[2]"));
	//	static Link ClickCourse = new Link(" Course", byXPath("//span[.=\"APR110E\"]")); 
	static Link Attendence = new Link("Attendence", byXPath("//li[@aria-controls=\"Attendance\"]"));
	static TextField EnterAttendenceInMin = new TextField("Attendence in Minutes", byXPath("(//input[@aria-label=\"Minutes\"])[1]"));
	static Button ClickSave = new Button("Save", byId("attendanceDetailSaveButton"));
	static Link FinalGrades = new Link("Final Grades", byXPath("//li[@aria-controls=\"Final Grades\"]"));
	static Dropbox LetterGradeDropdown = new Dropbox("Letter Grade Dropdown", byXPath("(//button[@aria-label=\"expand combobox\"])[2]"));
	static Link SelectGrade = new Link("Select Letter Grade", byXPath("//ul[@id=\"letterGrade_listbox\"]/li[1]"));
	static TextField NumericGrade = new TextField("Numeric Grade", byXPath("(//input[@aria-label=\"Numeric Grade\"])[2]"));
	static TextField LetterGrade = new TextField("Letter Grade", byName("letterGrade_input"));
	static Button SaveClose = new Button("Save and Close", byXPath("(//button[@aria-label=\"Save & Close\"])[2]"));
	static Link StudentStatusHistory = new Link("Status Change", byXPath("//span[text()='Student Status History']"));
	static Link ChangeStatus = new Link("Change Status", byId("studentStatusChangeButton"));
	static Button NewStatus = new Button("New Status", byXPath("(//span[@aria-label=\"select\"])[4]"));
	static TextField EnterNewStatus = new TextField("New Status", byXPath("//input[@aria-controls=\"newStatus_listbox\"]"));
	static TextField EffectiveDate = new TextField("Chnage Status Effective Date", byXPath("//input[@name=\"changeStatusDate1\"]"));
	static Button ChangeButton = new Button("Change Button", byXPath("//button[.=\"Change\"]"));
	//Transfer Credits Web Elements
	static Link TransderCredits = new Link("Transfer Credits", byXPath("//span[. = \"Transfer Credits\"]"));
	static Link NewTC = new Link("New Button", byXPath("//button[. = 'New']"));
	static TextField TransferTypes = new TextField("Transfer Types", byName("transferCreditType_input"));
	static TextField TransferStatus = new TextField("Transder Status", byName("transferCreditStatus_input"));
	//	static Button SelectTransferStatus = new Button(" Transfer Types", byXPath("//span[. = 'College Transfer has been approved']"));
	static Link TCTermSpan = new Link("Term Span", byId("search_display_termIdAdvance"));
	static TextField TCEnterTermCode = new TextField("Term Code", byId("search"));
	//	static Checkbox CheckTermCode = new Checkbox(" Term Code", byXPath("//input[@aria-label='"+data.get("TermCode")+"']"));
	static Button TCSelect = new Button("Select", byXPath("//button[. = 'Select']"));
	static TextField TCGrade = new TextField("Grade", byXPath("//span/span/span[. = ' ']"));
	//	static Button SelectTCGrade = new Button(" Grade", byXPath("//li[. ='"+data.get("TermCode")+"']"));
	static Link TCExInstAdd = new Link("Add to add external institute", byXPath("//div[2]/div/div/cns-grid//a[. = 'Add']"));
	static TextField ExInstitute = new TextField("External Institution", byName("institutionId_input"));
	static Button SelectExInstitute = new Button("ExInstitute", byXPath("//span[. = 'ABC BEAUTY ACADEMY']"));
	static TextField ExCourse = new TextField("Course", byName("institutionCourseId_input"));
	static Button SelectExCourse = new Button("Course", byXPath("//span[. = 'ENG01']"));
	static TextField DateCompleted= new TextField("Date Completed", byId("dateCompletedId"));
	static TextField GradeReceived= new TextField("Grade Received", byId("extCollegeGradeReceivedId"));
	static Button ExOk = new Button("External OK", byId("saveInstitutionId"));
	static Link TCIntInstAdd = new Link("Add Internal Institute", byXPath("(//button[.=\"Add\"])[2]"));
	static TextField CampusCourse = new TextField("Internal Campus Course", byName("campusCourseId_input"));
	static Button ClickOk = new Button("OK", byId("saveCampusCourseId"));
	static Button TCSaveClose = new Button(" Save and Close", byXPath("//div[2]//button[@aria-label='Save & Close']"));	
	//Program Change Web Elements
	static Link Enrollments = new Link("Enrollments", byXPath("//span[. = 'Enrollments']"));
	static AngDropDown Maindropdown = new AngDropDown("Awards Drop Down", byXPath("//div[2]/cns-grid/div[1]/cns-grid-toolbar/cmc-common-toolbar/div/div[1]/button[2]"));
	static Button MainClearFilter = new Button("Clear Filter", byXPath("//div//a[. = 'Clear Filters']"));
	static AngDropDown Enroldropdown = new AngDropDown("Fund Source drop down", byXPath("(//a[@title='Program Version edit column settings'])[1]"));
	static Button EnrolFilter = new Button("Filter", byXPath("(//span[text()='Filter'])[1]"));
	static AngDropDown ClickEqualsTo = new AngDropDown("Equals To", byXPath("//div/span[1]/span/span[. = 'Is equal to']"));
	static TextField EnrolValue = new TextField("Value", byXPath("//input[@title='Value']"));
	static Button EnrolFilterButton = new Button("Filter Button", byXPath("//button/span[.='Filter']"));
	static AngDropDown More = new AngDropDown("More", byXPath("//div[@id='moreEnrollmentButton_wrapper']"));
	static Link ProgramChange = new Link("Program Change", byXPath("//span[text()='Program Change']"));
	//static Button ProgramSpan = new Button("Program Span", byXPath("//span[@aria-label=\"Program: Dropdown\"]"));
	static Button ProgramSpan = new Button("Program Span", byXPath("//span[@aria-controls='ProgramId_listbox']/span[2]"));
	static TextField EnterProgramName = new TextField("Program", byXPath("//input[@aria-controls='ProgramId_listbox']"));
	//static Button SelectProgram = new Button(" Program", byXPath("//span[.=\"Nora's Bachelor of Arts\"]"));
	static Button PVSpan = new Button("PV Span", byXPath("//span[@aria-controls='ProgramVersionId_listbox']/span[2]"));
	static TextField EnterPVName = new TextField("Program Version", byXPath("//input[@aria-controls='ProgramVersionId_listbox']"));
	//static Button SelectPV = new Button("Select Program Version", byXPath("//span[.=\"Bachelor of Arts: Business\"]"));
	//static Button ShiftSpan = new Button("Shift Span", byXPath("//span[@aria-label=\"Shift: Dropdown\"]"));
	static Button ShiftSpan = new Button("Shift Span", byXPath("//span[contains(@aria-label,'Shift')]"));
	static TextField EnterShift = new TextField("Shift", byXPath("//input[@aria-owns=\"shiftId_listbox\"]"));
	//static Button SelectShift = new Button("Select shift", byXPath("//span[.=\"Day\"]"));
	//static Button GradeLevelSpan = new Button("Grade Level Span", byXPath("//span[@aria-label=\"Grade Level: Dropdown\"]"));
	static Button GradeLevelSpan = new Button("Grade Level Span", byXPath("//span[contains(@aria-label,'Grade Level')]"));
	static TextField EnterGradeLevel = new TextField("Grade Level", byXPath("//input[@aria-owns=\"gradeLevelId_listbox\"]"));
	//static Button SelectGradeLevel = new Button(" Grade Level", byXPath("//div/span[. = '1st year, never attended college']"));
	//static Button CatalogSpan = new Button("Catalog Span", byXPath("//span[@aria-label=\"Catalog: Dropdown\"]"));
	static Button CatalogSpan = new Button("Catalog Span", byXPath("//span[contains(@aria-label,'Catalog')]"));
	static TextField EnterCatalog = new TextField("Catalog", byXPath("//input[@aria-owns=\"catalogYearId_listbox\"]"));
	//static Button Selectcatalog = new Button(" Catalog", byXPath("//span[.=\"2021 Catalog\"]"));
	static TextField EnterBillingMethod = new TextField("Billing Method", byName("billingMethodId_input"));
	static TextField GraduateDate = new TextField("Graduate Date", byId("graduationDate"));
	static Button PVNext = new Button("PVNext", byXPath("//button[@id='programSelectionProceedButton']"));
	static Button CourseNext = new Button("CourseNext", byXPath("//button[@id='studentCourseProceedButton']"));
	static Button FeeNext = new Button("FeeNext", byXPath("//button[@id='feeProceedButton']"));
	static Link Change = new Link("Change Button", byXPath("(//button[@id='programChangeSaveButton'])[2]"));
	static Button Yes = new Button("Yes", byXPath("//button[id='terminationBudgetConfigDialogOkButton']"));
	//static Button StartDateSpan = new Button("Start Date Span", byXPath("//span[@aria-label=\"Start Date: Dropdown\"]"));
	static Button StartDateSpan = new Button("Start Date Span", byXPath("//span[contains(@aria-label,'Start Date')]"));
	static TextField EnterStartDate = new TextField("Start Date", byXPath("//input[@aria-owns=\"StartDateId_listbox\"]"));
	//static Button SelectStartDate = new Button(" Start Date", byXPath("//span[.=\"NMBFA22\"]"));	
	//Minimum Registration Lock
	static Link Unregister = new Link("Unregister", byXPath("//button[@id='courseUnRegisterButton']"));
	static Link RegistrationLock = new Link("Registration Lock", byXPath("//*[.=\"Registration Lock\"]"));
	
	//Add Course to Student Schedule
	//static Link AddCourseNew = new Link("New Button", byId("addCourseButton"));
	static Link AddCourseNew = new Link("New Button", byXPath("//button[@id='addCourseButton']"));
	static Link AddCourseSpan = new Link("Course Span", byXPath("//div[@id=\"search_display_courseId\"]"));
	static TextField AddSearchCourse = new TextField("Course Code", byId("search"));
	//static Checkbox CheckCourseCode= new Checkbox("Course", byXPath("//input[@aria-label=\"APR117A\"]"));
	static Button SelectButton = new Button("Select", byXPath("//button[.=\"Select\"]"));
	static Button AddSaveClose = new Button("Save and Close", byXPath("(//button[@aria-label=\"Save & Close\"])[2]"));
	static Button AddwithoutCategory = new Button("Add without category", byXPath("//button[@aria-label=\"Add Course without Category\"]"));
	static String TDate = DatesUtil.getCurrentDatebyFormat("M/dd/yyyy");
	
	public StudentAcademicRecordsPage AddCourseToStudentSchedule(StringHash data) throws Exception{

		Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Course records were successfully saved.']"));
		Checkbox CheckCourseCode= new Checkbox(data.get("CourseCode"), byXPath("//input[@aria-label='"+data.get("CourseCode")+"']"));
			
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.click();
		wait(30);
		AddCourseNew.clickUsingJavaScriptExecutor();
		wait(20);
		AddCourseSpan.click();
		wait(2);
		AddSearchCourse.clearAndType(data.get("CourseCode"));
		wait(5);
		CheckCourseCode.check();
		wait(3);
		SelectButton.click();
		wait(5);
		AddSaveClose.clickUsingJavaScriptExecutor();
		wait(2);
		AddwithoutCategory.clickUsingJavaScriptExecutor();
		wait(5);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(3);
		return this;
	}
	
	public StudentAcademicRecordsPage RegisterCourse(StringHash data) throws Exception{

		Link InstructorTableCell = new Link("Section Selection", byXPath("(//tr/td[2])[2]"));
		Link ClickCourseCode = new Link(data.get("CourseCode"), byXPath("//input[@aria-label = '"+data.get("CourseCode")+"']"));
		Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
		Link SelectTerm = new Link(data.get("TermCode"), byXPath("//span[text()='"+data.get("TermCode")+"']"));
		
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Course records were successfully registered.']"));
		
		
		Link RegisterButton1 = new Link("RegisterButton", byXPath("(//*[@aria-label='Register'])[2]"));
		
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.click();
		wait(20);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(2);
		Filter.click();
		wait(6);
		ClickCourseCode.click();
		wait(5);
		Register.clickUsingJavaScriptExecutor();
		wait(20);
		scrollPage(0, 300);
		wait(10);
		Term.clearAndType(data.get("TermCode"));
		wait(2);
		SelectTerm.click();
		wait(2);
		//Notes.clearAndType("Registering a Student");
		//wait(2);
		Next.waitTillElementClickable();
		Next.click();
		wait(4);
		InstructorTableCell.click();
		wait(2);
		scrollPage(0, 600);
		wait(2);
		RegisterButton.clickUsingJavaScriptExecutor();
		wait(9);
		//RegisterButton1.click();
		
		
		try {
    		if(RegisterButton1.isDisplayed()) {
    			RegisterButton1.click();
        	}
    	} 
    	catch (Exception e) {
    		TestReportsLog.log(LogStatus.PASS, "Registration is done successfully");
    	}
		
		
		//RegisterButton.c
//		WebElement isregdisplayed = driver.findElement(By.xpath("//button[@id=\"schedueCourseDialogOkButton\"]"));
//		String text = isregdisplayed.getText();
//		if(text.equals("Register"))
//		{
//			isregdisplayed.click();
//		}
			
		//CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(15);
		return this;
	}

	public StudentAcademicRecordsPage DropCourse(StringHash data) throws Exception{

		Link ClickCourseCode = new Link(data.get("CourseCode"), byXPath("//input[@aria-label = '"+data.get("CourseCode")+"']"));
		Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
		//Dropbox ClickDropGrade = new Dropbox(data.get("DropGrade"), byXPath("//li[.='"+data.get("DropGrade")+"']"));
		//	Button ClickEnteredReason = new Button("Click Entered Reason", byXPath("(//li[.='"+data.get("DropGrade")+"'[1]"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Course records were successfully dropped.']"));
		//Dropbox DropGradeSpan = new Dropbox("Drop Grade Span", byXPath("//span[@aria-label=\"Letter Grade: Dropdown\"]/span/span[2]/span"));
		Dropbox DropGradeSpan = new Dropbox("Drop Grade Span", byXPath("(//span[@aria-label=\"select\"])[4]"));
		Link SelectDropGrade = new Link("Drop Grade", byXPath("//ul[@id=\"letterGrade_listbox\"]/li[1]"));
		Dropbox DropReasonsSpan = new Dropbox("Drop Reasons Dropdown", byXPath("(//span[@aria-label=\"select\"])[5]"));
		Link SelectDropReason = new Link("Drop Reason", byXPath("//ul[@id=\"dropReason_listbox\"]/li[1]"));
		
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.click();
		wait(25);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(2);
		Filter.click();
		wait(5);
		ClickCourseCode.click();
		wait(4);
		Drop.clickUsingJavaScriptExecutor();
		wait(18);
		DropGradeSpan.clickUsingJavaScriptExecutor();
		wait(4);
		SelectDropGrade.clickUsingJavaScriptExecutor();
		String DropGradeValue = SelectDropGrade.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Drop Grade Value is selected as " +DropGradeValue);
    	wait(4);
    	DropReasonsSpan.clickUsingJavaScriptExecutor();
    	wait(4);
    	SelectDropReason.clickUsingJavaScriptExecutor();
    	String DropReasonValue = SelectDropReason.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Drop Grade Value is selected as " +DropReasonValue);
		wait(4);
		DropButton.clickUsingJavaScriptExecutor();
		wait(10);
		//CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
	}
	
	public StudentAcademicRecordsPage ReinstateCoursePage(StringHash data) throws Exception{

		Link ClickCourseCode = new Link(data.get("CourseCode"), byXPath("//input[@aria-label = '"+data.get("CourseCode")+"']"));
		Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[text()='The Student Course records were successfully reinstated.']"));
		Link ReinstateButton = new Link("Reinstate", byXPath("(//span[text()=\"Reinstate\"])[1]"));
		Button ReinstateConfirm = new Button("Reinstate Confirm", byXPath("(//button[@aria-label=\"Reinstate\"])[1]"));
		
		
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.click();
		wait(25);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(2);
		Filter.click();
		wait(2);
		ClickCourseCode.click();
		wait(4);
		ReinstateButton.clickUsingJavaScriptExecutor();
		wait(10);
		ReinstateConfirm.click();
		wait(8);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
	}
	

	public StudentAcademicRecordsPage IndividualAttendence(StringHash data) throws Exception{

		Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
		Link ClickCourse = new Link(data.get("CourseCode"), byXPath("//span[.= '"+data.get("CourseCode")+"']"));
		Link ClickDate = new Link(data.get("AttendenceDate"), byXPath("//span[.='"+data.get("AttendenceDate")+"']"));
		Link Date = new Link("Attendence Date", byXPath("//table/tbody/tr[2]/td[1]/a"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Attendance records were successfully saved.']"));
		
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.click();
		wait(25);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(2);
		Filter.click();
		wait(10);
		ClickCourse.click();
		wait(25);
		scrollPage(0, -200);
		wait(4);
		Attendence.click();
		wait(4);
		scrollPage(0, 500);
		wait(2);
		ClickDate.click();
		wait(4);
		EnterAttendenceInMin.sendKeys("30");
		wait(2);
		ClickSave.click();
		wait(7);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
	}
	
	public StudentAcademicRecordsPage individualFinalGradesPage(StringHash data) throws Exception{

		Link ClickStudent = new Link("Student Name",byXPath("//span[.='"+data.get("StudentName")+"']"));
		Link ClickCourse = new Link("Course", byXPath("//span[.= '"+data.get("CourseCode")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Course records were successfully saved.']"));
		
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.click();
		wait(25);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(2);
		Filter.click();
		wait(10);
		ClickCourse.click();
		wait(20);
		scrollPage(0, -200);
		wait(4);
		FinalGrades.click();
		wait(10);
		LetterGradeDropdown.click();
		wait(2);
		SelectGrade.click();
		wait(2);
//		NumericGrade.sendKeys("50");
		//	LetterGrade.waitTillElementFound();
		//	NumericGrade.sendKeys(data.get("LetterFinalGrade"));
		wait(2);
		SaveClose.click();
		wait(5);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
	}

	public StudentAcademicRecordsPage StatusChangePage(StringHash data) throws Exception{

		Link SelectNewStatus = new Link(data.get("NewStatus"), byXPath("//li[.='"+data.get("NewStatus")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Status was successfully changed.']"));
		//Dropbox ReasonsDropdown = new Dropbox("Reasons Dropdown", byXPath("//span[@aria-label=\"Reason: Dropdown\"]/span/span[2]/span"));
		Dropbox ReasonsDropdown = new Dropbox("Reasons Dropdown", byXPath("//span[contains(@aria-label,'Reason')]/span/span[2]/span"));
		Link SelectReasons = new Link("Reason", byXPath("//ul[@id=\"changeReason_listbox\"]/li[1]/div/span[1]"));
		
		//waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentStatusHistory.click();
		wait(25);
		ChangeStatus.click();
		wait(20);
		NewStatus.click();
		wait(2);
		EnterNewStatus.sendKeys(data.get("NewStatus"));
		wait(2);
		SelectNewStatus.click();
		wait(2);
//		ReasonsDropdown.click();
//		wait(2);
//		SelectReasons.click();
//		String Reasons = SelectReasons.getAttribute("title");
//		TestReportsLog.log(LogStatus.INFO, "Reason is selected as " +Reasons);
//		wait(2);
		ChangeButton.click();
		wait(10);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(10);
		return this;
	}

	public StudentAcademicRecordsPage TransferCreditsPage(StringHash data) throws Exception{

		//Checkbox CheckTermCode = new Checkbox(data.get("TermCode"), byXPath("//input[@aria-label='"+data.get("TermCode")+"']"));
		//Button SelectTCGrade = new Button(data.get("Grade"), byXPath("//li[. ='"+data.get("Grade")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Transfer Credits records were successfully saved.']"));
		Dropbox TransferTypesDropdown = new Dropbox("Transfer Types Dropdown",byXPath("(//button[@aria-label=\"expand combobox\"])[2]"));
		Link SelectTransferTypes = new Link("Tranfer Types",byXPath("//ul[@id='transferCreditType_listbox']/li[1]/span/div/span[1]"));
		Dropbox TransferStatusDropdown = new Dropbox("Transfer Status Dropdown", byXPath("(//button[@aria-label=\"expand combobox\"])[3]"));
		Link SelectTransferStatus = new Link("Transfer Types Status", byXPath("//ul[@id=\"transferCreditStatus_listbox\"]/li[2]/span/div/span[1]"));
		Dropbox CampusCourseDropdown = new Dropbox("Campus Course Dropdown", byXPath("(//button[@aria-label='expand combobox']/span[1])[4]"));
		Link SelectCampusCourse = new Link("Campus Course", byXPath("//ul[@id=\"campusCourseId_listbox\"]/li[1]/span/div/span[1]"));
		Link TermSpan = new Link("Term Span", byXPath("//div[@id=\"search_display_termIdAdvance\"]"));
		Checkbox SelectTerm = new Checkbox("Term", byXPath("//tr[1]/td/input"));
		//Dropbox GradeDropdown = new Dropbox("Grade dropdown", byXPath("//span[@aria-label=\"Grade: Dropdown\"]/span/span[2]/span"));
		Dropbox GradeDropdown = new Dropbox("Grade dropdown", byXPath("//span[contains(@aria-label,'Grade')]"));
		Link SelectGrade = new Link("Grade", byXPath("//ul[@id=\"gradeAdvance_listbox\"]/li[1]/span"));
		Dropbox ExInsDropdown = new Dropbox("External Institution Dropdown", byXPath("(//button[@aria-label=\"expand combobox\"]/span)[4]"));
		Link SelectExInst = new Link("External Institution", byXPath("//ul[@id=\"institutionId_listbox\"]/li[1]/span/div/span[1]"));
		Dropbox ExInstCourseDrodown = new Dropbox("External Institution Dropdown", byXPath("(//button[@aria-label=\"expand combobox\"]/span)[5]"));
		Link SelectExInstCourse = new Link("External Institutuion Course", byXPath("//ul[@id=\"institutionCourseId_listbox\"]//li[1]/span/div/span[1]"));
		Link NewExtInst = new Link("New External Institutuion", byXPath("(//button[@id=\"newButton\"])[2]"));
		
		//waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		TransderCredits.click();
		wait(25);
		NewTC.click();
		wait(20);
		scrollPage(0, 300);
		wait(2);
		TransferTypesDropdown.click();
		wait(2);
		SelectTransferTypes.click();
		String TransferTypesValue = SelectTransferTypes.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Transfer Type value is selected as " +TransferTypesValue);
		wait(2);
		TransferStatusDropdown.click();
		wait(2);
		SelectTransferStatus.click();
		String TransferStatusValue = SelectTransferStatus.getText();
		TestReportsLog.log(LogStatus.INFO, "Transfer Status value is selected " +TransferStatusValue);
		wait(2);
		TermSpan.click();
		wait(4);
		SelectTerm.check();
		String TermValue = SelectTerm.getAttribute("aria-label");
		TestReportsLog.log(LogStatus.INFO, "Term Value is selected as " +TermValue);
		wait(2);
		TCSelect.clickUsingJavaScriptExecutor();
		wait(5);
		GradeDropdown.click();
		wait(2);
		SelectGrade.click();
		String GradeValue = SelectGrade.getText();
		TestReportsLog.log(LogStatus.INFO, "Grade value is selected as " +GradeValue);
		wait(2);
		/*TCGrade.sendKeys(data.get("Grade"));
		wait(4);
		SelectTCGrade.click();
		wait(4);
		*/
		NewExtInst.click();
		wait(5);
		ExInsDropdown.click();
		wait(2);
		SelectExInst.click();
		String ExInstValue = SelectExInst.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "External Institution is selected as " +ExInstValue);
    	wait(2);
    	ExInstCourseDrodown.click();
		wait(2);
		SelectExInstCourse.click();
		String ExInstCourseValue = SelectExInstCourse.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "External Institution Course is selected as " +ExInstCourseValue);
    	wait(2);
		DateCompleted.clearAndType(TDate);
		wait(2);
		GradeReceived.clearAndType("B");
		wait(2);
		ExOk.click();
		wait(4);
		scrollPage(0, 500);
		wait(4);
		TCIntInstAdd.click();
		wait(5);
		CampusCourseDropdown.click();
		wait(2);
		SelectCampusCourse.click();
		String CampusCourseValue = SelectCampusCourse.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Campus Course is selected as " +CampusCourseValue);
		wait(2);
		ClickOk.click();
		wait(2);
		scrollPage(0, -1000);
		wait(2);
		TCSaveClose.click();
		wait(10);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(10);
		return this;
	}

	public StudentAcademicRecordsPage ProgramChangePage(StringHash data) throws Exception{

		TextField HighlightProgramVersion = new TextField("Status", byXPath("(//tr/td)[1]"));
		Link SelectProgram = new Link(data.get("NewProgramName"), byXPath("(//span[.='"+data.get("NewProgramName")+"'])[1]"));
		Link SelectPV = new Link(data.get("NewProgramVersionName"), byXPath("//ul/li[1]/span/div/span[.='"+data.get("NewProgramVersionName")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[.='The Enrollment records were successfully saved.']"));
		//Dropbox StartDateDropdown = new Dropbox("Start Date Dropdown", byXPath("//span[@aria-label=\"Start Date: Dropdown\"]/span/span[2]/span"));
		Dropbox StartDateDropdown = new Dropbox("Start Date Dropdown", byXPath("(//span[contains(@aria-label,'Start Date')]/span[2])[2]"));
		Link SelectStartDate = new Link("Start Date", byXPath("//ul[@id='StartDateId_listbox']/li/span/div/span[1]"));
		//Dropbox ShiftDropdown = new Dropbox("Shift Dropdown", byXPath("//span[@aria-label=\"Shift: Dropdown\"]/span/span[2]/span"));
		Dropbox ShiftDropdown = new Dropbox("Shift Dropdown", byXPath("(//span[contains(@aria-label,'Shift')]/span[2])[2]"));
		Link SelectShift = new Link("Shift", byXPath("//ul[@id='shiftId_listbox']/li[1]/span/div/span[1]"));
		//Dropbox GradeLevelDropdown = new Dropbox("Grade Level Dropdown"	, byXPath("//span[@aria-label=\"Grade Level: Dropdown\"]/span/span[2]/span"));
		Dropbox GradeLevelDropdown = new Dropbox("Grade Level Dropdown"	, byXPath("//span[contains(@aria-label,'Grade Level')]/span[2]"));
		Link SelectGradeLevel = new Link("Grade Level", byXPath("//ul[@id='gradeLevelId_listbox']/li[1]/span/div/span[1]"));
		//Dropbox CatalogDropdown = new Dropbox("Catalog Dropdown", byXPath("//span[@aria-label=\"Catalog: Dropdown\"]/span/span[2]/span"));
		Dropbox CatalogDropdown = new Dropbox("Catalog Dropdown", byXPath("(//span[contains(@aria-label,'Catalog')]/span[2])[2]"));
		Link SelectCatalog = new Link("Catalog", byXPath("//ul[@id='catalogYearId_listbox']/li[1]/span/div/span[1]"));
		Button ConfirmTransfer = new Button("Confirm", byXPath("//button[@id='terminationBillingChangeDialogOkButton']"));
		Button MainClearFilter = new Button("Clear filter", byXPath("//li[@id='cnsGrid_cnsToolbar_kendoToolBar_clearFiltersButton']"));
		
		//waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.clickUsingJavaScriptExecutor();
		wait(2);
		Enrollments.clickUsingJavaScriptExecutor();
		wait(25);
		Maindropdown.click();
		wait(2);
		MainClearFilter.click();
		wait(5);
		Enroldropdown.click();
		wait(2);
		EnrolFilter.click();
		wait(2);
		EnrolValue.clearAndType(data.get("ProgramVersionName"));
		wait(2);
		EnrolFilterButton.click();
		wait(10);
		HighlightProgramVersion.click();
		wait(20);
		More.click();
		wait(2);
		ProgramChange.click();
		wait(5);
		waitForPageToLoad();
		ProgramSpan.clickUsingJavaScriptExecutor();
		wait(2);
		EnterProgramName.clearAndType(data.get("NewProgramName"));
		wait(2);
		SelectProgram.clickUsingJavaScriptExecutor();
		wait(4);
		PVSpan.clickUsingJavaScriptExecutor();
		wait(2);
		EnterPVName.clearAndType(data.get("NewProgramVersionName"));
		wait(3);
		SelectPV.click();
		wait(2);
		StartDateDropdown.clickUsingJavaScriptExecutor();
		wait(2);
		SelectStartDate.click();
		String StartDateValue = SelectStartDate.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Start Date is selected as " +StartDateValue);
    	wait(2);
    	ShiftDropdown.click();
		wait(2);
		SelectShift.click();
		String ShiftValue = SelectShift.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Shift is selected as " +ShiftValue);
		wait(2);
		GradeLevelDropdown.click();
		wait(2);
		SelectGradeLevel.click();
		String GradeLevel = SelectGradeLevel.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Grade Level is selected as " +GradeLevel);
		wait(4);
		CatalogDropdown.click();
		wait(2);
		SelectCatalog.click();
		String Catalog = SelectCatalog.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Catalog is selected as " +Catalog);
		scrollPage(0, 500);
		wait(2);
		//GraduateDate.clearAndType(data.get("GraduateDate"));
		wait(2);
		//EnterBillingMethod.clearAndType(data.get("BillingMethod"));
		//wait(2);
		PVNext.clickUsingJavaScriptExecutor();
		wait(5);
		//WebElement yess=driver.findElement(By.id("terminationBudgetConfigDialogOkButton"));
//		if (yess.isDisplayed()) {
//			yess.click();
//			wait(10);
//		}
		//Yes.clickUsingJavaScriptExecutor();
		//wait(5);
		CourseNext.click();
		wait(2);
		FeeNext.click();
		wait(2);
		Change.click();
		wait(10);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(10);
		return this;

//		TextField HighlightProgramVersion = new TextField("Highlight Program Version", byXPath("//tr/td[3]"));
//		Link SelectProgram = new Link(data.get("NewProgramName"), byXPath("(//span[.='"+data.get("NewProgramName")+"'])[1]"));
//		Link SelectPV = new Link(data.get("NewProgramVersionName"), byXPath("//ul/li[1]/div/span[.='"+data.get("NewProgramVersionName")+"']"));
//		Link ValidationMessage = new Link("Validation Message", byXPath("//span[.='The Enrollment records were successfully saved.']"));
//		Dropbox StartDateDropdown = new Dropbox("Start Date Dropdown", byXPath("//span[@aria-label='Start Date']"));
//		Link SelectStartDate = new Link("Start Date", byXPath("//ul[@id=\"StartDateId_listbox\"]/li/div/span[1]"));
//		Dropbox ShiftDropdown = new Dropbox("Shift Dropdown", byXPath("//span[@aria-owns='shiftId_listbox']"));
//		Link SelectShift = new Link("Shift", byXPath("//ul[@id=\"shiftId_listbox\"]/li[1]/div/span[1]"));
//		Dropbox GradeLevelDropdown = new Dropbox("Grade Level Dropdown"	, byXPath("//span[@aria-owns=\"gradeLevelId_listbox\"]"));
//		Link SelectGradeLevel = new Link("Grade Level", byXPath("//ul[@id=\"gradeLevelId_listbox\"]/li[1]/div/span[1]"));
//		Dropbox CatalogDropdown = new Dropbox("Catalog Dropdown", byXPath("//span[@aria-owns=\"catalogYearId_listbox\"]"));
//		Link SelectCatalog = new Link("Catalog", byXPath("//ul[@id=\"catalogYearId_listbox\"]/li[1]/div/span[1]"));
//		Button ConfirmTransfer = new Button("Confirm", byXPath("//button[@id=\"terminationBillingChangeDialogOkButton\"]"));
//		Link Dontsave = new Link ("Dontsave",byXPath("//button[@id='cnsDirtyCheckUnsavedChangesDialogNotOkButton']"));
//		wait(5);
//		AcademicRecords.waitTillElementClickable();
//		AcademicRecords.clickUsingJavaScriptExecutor();
//		Enrollments.waitTillElementClickable();
//		Enrollments.clickUsingJavaScriptExecutor();
//		wait(8);
////		Dontsave.waitTillElementClickable();
////		Dontsave.click();
////		wait(12);
////		Maindropdown.waitTillElementClickable();
////		Maindropdown.clickUsingJavaScriptExecutor();
////		wait(1);
////		MainClearFilter.waitTillElementClickable();
////		MainClearFilter.clickUsingJavaScriptExecutor();
////		wait(3);
////		Enroldropdown.waitTillElementClickable();
////		Enroldropdown.click();
////		wait(1);
////		EnrolFilter.waitTillElementClickable();
////		EnrolFilter.click();
////		wait(1);
////		EnrolValue.waitTillElementClickable();
////		EnrolValue.clearAndType(data.get("ProgramVersionName"));
////		wait(1);
////		EnrolFilterButton.waitTillElementClickable();
////		EnrolFilterButton.click();
//		wait(4);
//		HighlightProgramVersion.waitTillElementClickable();
//		HighlightProgramVersion.click();
//		wait(5);
//		More.waitTillElementClickable();
//		More.clickUsingJavaScriptExecutor();
//		wait(1);
//		ProgramChange.waitTillElementClickable();
//		ProgramChange.clickUsingJavaScriptExecutor();
//		wait(15);
//		ProgramSpan.waitTillElementClickable();
//		ProgramSpan.clickUsingJavaScriptExecutor();
//		wait(1);
//		EnterProgramName.waitTillElementClickable();
//		EnterProgramName.clearAndType(data.get("NewProgramName"));
//		wait(1);
//		SelectProgram.waitTillElementClickable();
//		SelectProgram.click();
//		wait(1);
//		PVSpan.waitTillElementClickable();
//		PVSpan.clickUsingJavaScriptExecutor();
//		wait(1);
//		EnterPVName.waitTillElementClickable();
//		EnterPVName.clearAndType(data.get("NewProgramVersionName"));
//		wait(1);
//		SelectPV.waitTillElementClickable();
//		SelectPV.clickUsingJavaScriptExecutor();
//		wait(1);
//		StartDateDropdown.waitTillElementClickable();
//		StartDateDropdown.clickUsingJavaScriptExecutor();
//		SelectStartDate.waitTillElementClickable();
//		SelectStartDate.click();
//		String StartDateValue = SelectStartDate.getAttribute("title");
//		TestReportsLog.log(LogStatus.INFO, "Start Date is selected as " +StartDateValue);
//		wait(1);
//		ShiftDropdown.waitTillElementClickable();
//    	ShiftDropdown.clickUsingJavaScriptExecutor();
//		SelectShift.waitTillElementClickable();
//		SelectShift.click();
//		String ShiftValue = SelectShift.getAttribute("title");
//		TestReportsLog.log(LogStatus.INFO, "Shift is selected as " +ShiftValue);
//		wait(1);
//		GradeLevelDropdown.waitTillElementClickable();
//		GradeLevelDropdown.click();
//		SelectGradeLevel.waitTillElementClickable();
//		SelectGradeLevel.click();
//		String GradeLevel = SelectGradeLevel.getAttribute("title");
//		TestReportsLog.log(LogStatus.INFO, "Grade Level is selected as " +GradeLevel);
//		wait(1);
//		CatalogDropdown.waitTillElementClickable();
//		CatalogDropdown.click();
//		SelectCatalog.waitTillElementClickable();
//		SelectCatalog.click();
//		String Catalog = SelectCatalog.getAttribute("title");
//		TestReportsLog.log(LogStatus.INFO, "Catalog is selected as " +Catalog);
//		wait(1);
//		scrollPage(0, 500);
//		//GraduateDate.clearAndType(data.get("GraduateDate"));
//		//wait(2);
//		//EnterBillingMethod.clearAndType(data.get("BillingMethod"));
//		//wait(2);
//		PVNext.waitTillElementClickable();
//		PVNext.click();
//		wait(1);
//		//Yes.clickUsingJavaScriptExecutor();
//		//wait(5);
//		CourseNext.waitTillElementClickable();
//		CourseNext.click();
//		wait(1);
//		FeeNext.waitTillElementClickable();
//		FeeNext.click();
//		wait(1);
//		Change.waitTillElementClickable();
//		Change.click();
//		wait(11);
//		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
//		return this;	
//		
		
		
	}
	
	public StudentAcademicRecordsPage verifyMinimumLimitPage(StringHash data) throws Exception{

		Link InstructorTableCell = new Link("Section Selection", byXPath("//td[text()='"+data.get("Instructor")+"']"));
		Link ClickCourseCode = new Link(data.get("CourseCode"), byXPath("//input[@aria-label = '"+data.get("CourseCode")+"']"));
		//Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
		TextField ValidationMessage = new TextField("Get the validation point", byXPath("//span[.=\"Minimum Limit\"]"));
		TextField EnterTerm = new TextField("Term ", byXPath("//input[@name=\"termId_input\"]"));
		Link SelectTerm = new Link("Term", byXPath("//span[.='"+data.get("TermCode")+"']"));
		
		Link RegisterButton1 = new Link("RegisterButton", byXPath("//button[@id='schedueCourseDialogOkButton']"));
		
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.click();
		wait(25);
		CourseCodeDropdown.click();
		wait(3);
		CClFilterDropDown.click();
		wait(3);
		Value.clearAndType(data.get("CourseCode"));
		wait(3);
		Filter.click();
		wait(5);
		ClickCourseCode.click();
		wait(3);
		Register.clickUsingJavaScriptExecutor();
		wait(20);
		scrollPage(0, 300);
		wait(2);
		Notes.clearAndType("Registering a Student");
		wait(2);
		EnterTerm.clearAndType(data.get("TermCode"));
		wait(2);
		SelectTerm.click();
		wait(2);
		Next.clickUsingJavaScriptExecutor();
		wait(4);
		InstructorTableCell.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0, 400);
		wait(2);
		RegisterButton.clickUsingJavaScriptExecutor();
		wait(5);
//		
//		try {
//    		if(RegisterButton1.isDisplayed()) {
//    			RegisterButton1.click();
//        	}
    	//} 
//    	catch (Exception e) {
//    		TestReportsLog.log(LogStatus.PASS, "Registration is done successfully");
//    	}
		
		//RegisterButton1.click();
		wait(25);
		scrollPage(0, -1000);
		wait(3);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(2);
		Filter.click();
		wait(2);
		ClickCourseCode.click();
		wait(3);
		Unregister.clickUsingJavaScriptExecutor();
		//wait(10);
		//RegistrationLock.clickUsingJavaScriptExecutor();
		wait(10);
		//CustomAsserts.containsString(ValidationMessage.getText(), data.get("ValidationPoint").toString());
		wait(5);
		return this;
	}
	
	public StudentAcademicRecordsPage verifyMaximumLimitPage(StringHash data) throws Exception{
		
		Link InstructorTableCell = new Link("Section Selection", byXPath("//td[text()='"+data.get("Instructor")+"']"));
		Link ClickCourseCode = new Link(data.get("CourseCode"), byXPath("//input[@aria-label = '"+data.get("CourseCode")+"']"));
		//Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
		TextField ValidationMessage = new TextField("Get the validation point", byXPath("//span[.=\"Maximum Limit\"]"));
		TextField EnterTerm = new TextField("Term ", byXPath("//input[@name=\"termId_input\"]"));
		Link SelectTerm = new Link("Term", byXPath("//span[.='"+data.get("TermCode")+"']"));
		
		Link RegisterButton1 = new Link("RegisterButton", byXPath("//button[@id='schedueCourseDialogOkButton']"));
		
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.waitTillElementClickable();
		StudentCourses.click();
		wait(25);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(3);
		Filter.click();
		wait(6);
		ClickCourseCode.click();
		wait(3);
		Register.clickUsingJavaScriptExecutor();
		wait(25);
		scrollPage(0, 300);
		wait(2);
		Notes.clearAndType("Registering a Student");
		wait(2);
		EnterTerm.clearAndType(data.get("TermCode"));
		wait(2);
		SelectTerm.click();
		wait(2);
		Next.click();
		wait(4);
		InstructorTableCell.click();
		wait(2);
		scrollPage(0, 500);
		wait(2);
		RegisterButton.click();
		wait(10);
		//RegisterButton1.click();
		
//		try {
//    		if(RegisterButton1.isDisplayed()) {
//    			RegisterButton1.click();
//        	}
//    	} 
//    	catch (Exception e) {
//    		TestReportsLog.log(LogStatus.PASS, "Registration is done successfully");
//    	}
		
		//CustomAsserts.containsString(ValidationMessage.getText(), data.get("ValidationPoint").toString());
		wait(5);
		return this;
	}
	
public StudentAcademicRecordsPage VerifyScheduleLockPage(StringHash data) throws Exception{
		
		Link InstructorTableCell = new Link("Section Selection", byXPath("//td[text()='"+data.get("Instructor")+"']"));
		Link ClickCourseCode = new Link(data.get("CourseCode"), byXPath("//input[@aria-label = '"+data.get("CourseCode")+"']"));
		Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
		TextField ValidationMessage = new TextField("Get the validation point", byXPath("//span[.=\"Schedule Change\"]"));
		TextField EnterTerm = new TextField("Term ", byXPath("//input[@name=\"termId_input\"]"));
		Link SelectTerm = new Link("Term", byXPath("//span[.='"+data.get("TermCode")+"']"));
		
		
		Link RegisterButton1 = new Link("RegisterButton", byXPath("//button[@id='schedueCourseDialogOkButton']"));
		
		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.waitTillElementClickable();
		StudentCourses.click();
		wait(25);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(3);
		Filter.click();
		wait(6);
		ClickCourseCode.click();
		wait(3);
		Register.clickUsingJavaScriptExecutor();
		wait(20);
		scrollPage(0, 300);
		wait(2);
		Notes.clearAndType("Registering a Student");
		wait(2);
		EnterTerm.clearAndType(data.get("TermCode"));
		wait(2);
		SelectTerm.click();
		wait(2);
		Next.waitTillElementClickable();
		Next.click();
		wait(4);
		InstructorTableCell.waitTillElementClickable();
		InstructorTableCell.click();
		wait(2);
		scrollPage(0, 400);
		wait(2);
		RegisterButton.click();
		wait(10);
		//RegisterButton1.click();
		
//		try {
//    		if(RegisterButton1.isDisplayed()) {
//    			RegisterButton1.click();
//        	}
//    	} 
//    	catch (Exception e) {
    		TestReportsLog.log(LogStatus.PASS, "Schedule Registration Lock is successful.");
//    	}
		
		//CustomAsserts.containsString(ValidationMessage.getText(), data.get("ValidationPoint").toString());
		wait(5);
		return this;
	}
	
	public StudentAcademicRecordsPage DeleteCoursePage(StringHash data) throws Exception{
		 
		//X-path Parameterization
			Checkbox SelectCheckbox = new Checkbox("Checkbox", byXPath("//input[@id='checkAll']"));
			Link SuccessMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Course records were successfully deleted.']"));
			Button DeleteButton = new Button("Delete Button", byId("deletedCourseButton"));
			Button ConfirmDeleteButton = new Button("Confirm Delete Button", byXPath("(//button[@aria-label='Delete'])[4]"));
			//Link reasonsdropdown = new Link("Reason drop down", byXPath("(//span[@aria-label=\"Reason: Dropdown\"])[3]"));
			Link reasonsdropdown = new Link("Reason drop down", byXPath("(//span[contains(@aria-label,'Reason')])[3]"));
			Link SelectReason = new Link("Reason", byXPath("(//ul[@id='DeletewithReasoncode_listbox']/li)[1]"));
			Button OkDelete = new Button("Delete Button", byXPath("(//button[text()='Delete'])[2]"));
			Button FinalDelete = new Button("Final Delete Button", byId("deleteValidationDialogOkButton"));
			//Link AcademicRecords = new Link("Academic Records", byXPath("//cns-panel-bar/ul/li[3]/a/span"));
			Link StudentCourses = new Link("Student Courses span", byXPath("//span[text()='Student Courses']"));
			Link CourseCodeDropdown = new Link("Course Code dropdown", byXPath("//a[@title='Course Code edit column settings']"));
			Button CClFilterDropDown = new Button("Filter", byXPath("//span[text()=\"Filter\"]"));
			TextField Value = new TextField("Filter", byXPath("//input[@title=\"Value\"]"));
		    Button Filter = new Button("Filter Button", byXPath("//button[@title='Filter']"));
		    
		//Method Implementation
			//waitForPageToLoad();
		   // wait(10);
		    AcademicRecords.waitTillElementClickable();
			AcademicRecords.click();
			wait(2);
			StudentCourses.click();
			waitForPageToLoad();
			CourseCodeDropdown.click();
			wait(2);
			CClFilterDropDown.click();
			wait(2);
			Value.clearAndType(data.get("Course"));
			wait(2);
			Filter.click();
			wait(12);
			SelectCheckbox.click();
			wait(5);
			DeleteButton.clickUsingJavaScriptExecutor();
			wait(2);
			ConfirmDeleteButton.click();
			wait(2);
			reasonsdropdown.click();
			wait(2);
			SelectReason.click();
			String ReasonValue = SelectReason.getText();
			TestReportsLog.log(LogStatus.INFO, "Reason is selected as " +ReasonValue);
			wait(2);
			OkDelete.click();
			wait(10);
			//FinalDelete.clickUsingJavaScriptExecutor();
			//wait(20);
			//CustomAsserts.containsString(SuccessMessage.getText(), data.get("SuccessMessage").toString());
			//wait(5);
			return this;
		}
	
	
	public StudentAcademicRecordsPage DeleteCourse(StringHash data) throws Exception{

		Checkbox SelectCheckbox = new Checkbox("Checkbox", byXPath("//input[@aria-label='"+data.get("CourseCode")+"']"));
		Link SuccessMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Course records were successfully deleted.']"));
		Button DeleteButton = new Button("Delete Button", byId("deletedCourseButton"));
		Button ConfirmDeleteButton = new Button("Confirm Delete Button", byId("(//button[@aria-label=\"Delete\"])[4]"));
		//Link reasonsdropdown = new Link("Reason drop down", byXPath("(//span[@aria-label=\"Reason: Dropdown\"])[3]"));
		Link reasonsdropdown = new Link("Reason drop down", byXPath("(//span[contains(@aria-label,'Reason')])[3]"));
		Link SelectReason = new Link("Reason", byXPath("(//ul[@id='DeletewithReasoncode_listbox']/li)[1]"));
		Button OkDelete = new Button("Delete Button", byXPath("(//button[.=\"Delete\"])[2]"));
		Button FinalDelete = new Button("Final Delete Button", byXPath("//button[@id='deleteValidationDialogOkButton']"));

		wait(2);
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(2);
		StudentCourses.click();
		wait(25);
		CourseCodeDropdown.click();
		wait(2);
		CClFilterDropDown.click();
		wait(2);
		Value.clearAndType(data.get("CourseCode"));
		wait(4);
		Filter.click();
		wait(5);
		SelectCheckbox.click();
		wait(5);
		DeleteButton.click();
		wait(2);
		ConfirmDeleteButton.click();
		wait(2);
		/*reasonsdropdown.click();
		wait(2);
		SelectReason.click();
		String ReasonValue = SelectReason.getText();
		TestReportsLog.log(LogStatus.INFO, "Reason is selected as " +ReasonValue);
		wait(2);*/
		OkDelete.click();
		wait(5);	
		if(FinalDelete.isDisplayed()) {
			FinalDelete.click();
		}	
		wait(5);
		CustomAsserts.containsString(SuccessMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
	}
}
