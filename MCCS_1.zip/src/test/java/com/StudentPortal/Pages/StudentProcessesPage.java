package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byCSSSelector;
import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;
import static com.framework.elements.Locator.byName;

import org.openqa.selenium.By.ByName;

import java.text.SimpleDateFormat;
//import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



import com.framework.base.BasePage;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

import groovy.json.internal.Exceptions;

public class StudentProcessesPage extends BasePage{

//	Processes Page Web Elements
	static TextField EnterTextInProcesses = new TextField("Text", byId("daily-processes-treeview-filter"));
	static Link Attendance = new Link("Attendance", byXPath("//span[.=\"Attendance\"]"));
	static TextField EnterTermCode = new TextField("Term Code", byId("search"));
	static TextField AttTermCode = new TextField("Term Code", byName("termId_input"));
	static Button ATTSelectTerm = new Button("Term", byXPath("//span[@title=\"NANDA\"]"));
	static Button ClickCourseCode = new Button("Course Code", byXPath("//span[.=\"Course Code:\"]"));
	static Link ClickCourseSpan = new Link("Course Span", byId("search_display_courseSearch"));
	static TextField EnterCourseCode = new TextField("Course Code", byId("search"));
	//Xpath Parameter		static Checkbox CheckCourse = new Checkbox("Select the course", byXPath("//input[@aria-label=\"MTH111 - COLLEGE ALGEBRA\"]"));
	static Button Select = new Button("Select", byXPath("//button[.=\"Select\"]"));
	static TextField AttendanceStartDate = new TextField("Attendance Start Date", byId("attendenceStartDate"));
	static TextField AttendanceEndDate = new TextField("Attendance End Date", byId("attendenceEndtDate"));
	static Button ApplyFilter = new Button("Apply Filter", byXPath("//button[.=\"Apply Filters\"]"));
	static Button Save = new Button("Save", byXPath("(//button[@id=\"saveButton\"])[2]"));
	static Link finalGradeSave = new Link("Save", byXPath("//button[@id=\"saveButton\"]"));
	static Link Gradebook = new Link("Attendance", byXPath("//span[.=\"Gradebook\"]"));
	static TextField Campus = new TextField("Campus", byXPath("//input[@name=\"campusDropDown_input\"]"));
	static Link TermSpan = new Link("Term Span", byId("search_display_termId"));
	static TextField EnterTermName = new TextField("Term Name", byId("search"));
	static TextField LetterGrade = new TextField("Letter Grade", byXPath("(//tbody)[2]/tr[1]/td[2]"));
	static Link LetterGradeDrop = new Link("Letter Grade dropdown", byXPath("(//tbody)[2]/tr[1]/td[2]/span/span/span[1]"));
	static Link SelectLetterGrade = new Link("Select Letter Grade", byXPath("(//ul[contains(@id,'listbox')]/li[1]/span[1])[3]"));
	static Button ClickAttendanceField = new Button("Attendance field", byXPath("(//td[@class=\"editable-cell k-table-td\"])[2]"));
	static TextField EnterAttendance = new TextField("Attendance in Minutes", byXPath("//input[@data-role=\"autocomplete\"]"));
	//SAP Calculation Web Elements
	static Link SAPCalculation = new Link("SAP calculation", byXPath("//span[.=\"SAP Calculation\"]"));
	static Link SAPTermSpan = new Link("Term Span", byId("search_display_termId"));
	static TextField SAPTermName = new TextField("Term Code", byId("search"));
	static Checkbox CheckTerm = new Checkbox("Term", byXPath("//input[@aria-label=\"NANDA\"]"));
	static Button SAPSelect = new Button("Select", byXPath("//button[.=\"Select\"]"));
	static Button SAPQueue = new Button("Queue Batch", byId("queueButton"));
	static Link SAPOpenBatches = new Link("Open Batches", byXPath("//li[@aria-controls=\"Open Batches\"]"));
	static Link SubmittedByDropdown = new Link("Drop down", byXPath("(//a[@aria-label=\"Column Settings\"])[3]"));
	static Button SubmittedByFilterDropDown = new Button("Filter", byXPath("//span[text()=\"Filter\"]"));
	static TextField SubmittedByValue = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
	static Button SubmittedByFilter = new Button("Button", byXPath("//button[text()=\"Filter\"]"));
	static Button SAPConfirmqueue = new Button("Confirm Queue", byId("saveSubmitBatchPackingJob"));
	static Button SAPQueueOpenBatch = new Button("Queue Open Batch", byId("//span[text()='Queue Calculation']"));   
	//Approve Disbursements to Pay Web Elements
	static Link ApproveDisbursementsToPay = new Link("Approve Disbursements to Pay", byXPath("//span[.=\"Approve Disbursements to Pay\"]"));
	static TextField ADCampus = new TextField("Campus", byName("campusDropDown_input"));
	static TextField DisDateFrom = new TextField("Disbursement Date from", byId("disbursementFromDateDatePicker"));
	static TextField DisDateTo = new TextField("Disbursement Date to", byId("disbursementToDateDatePicker"));
	static TextField ADAwardYear = new TextField("Eter Disbursement Award year", byXPath("//input[@aria-label=\"Award Year\"]"));
	static TextField ADFundType = new TextField("Fund Source", byName("fundTypeDropDown_input"));
	static TextField SearchField = new TextField("Search Processes", byXPath("//input[@placeholder='Search Processes']"));
	static Link RefundsStipends = new Link("Refunds/Stipends", byXPath("//span[text()='Refunds/Stipends']"));
	static Link Process = new Link("Process", byXPath("//span[contains(@aria-label,'Process')]"));
	static Link ReturnMethod = new Link("Return Method", byXPath("//span[contains(@aria-label,'Return Method')]"));
	static Link PrintChecks = new Link("Print Checks", byXPath("//span[contains(@aria-label,'Print Checks')]"));
	static Link RecordSelection = new Link("Record selection", byXPath("//span[contains(@aria-label,'Record Selection')]"));
	//static Link BankAccount = new Link("Bank Account", byXPath("//div[@aria-label='Bank Account']"));
	static Link BankAccount = new Link("Bank Account", byXPath("//div[contains(@aria-label,'Bank Account')]"));
	static TextField SearchBankAccount = new TextField("Search Bank Account", byXPath("//input[@placeholder='Search Bank Account Name']"));
	static Button Next = new Button("Next", byXPath("//cmc-collapse/div[1]/div[2]/div[10]/div/button"));
	static Button QueuePost = new Button("Queue Post", byXPath("//button[@id='queueProcessButton']"));
	static Link StipendSelection = new Link("Stipend selection", byXPath("//span[contains(@aria-label,'Stipend Selection')]"));
	static Button Queue = new Button("Queue", byXPath("//button[text()='Queue']"));
	//Print employer letters Web Elements
	static Link Letters = new Link("Letters", byXPath("//span[text()='Letters']"));
	static Link Type = new Link("Type", byXPath("//span[contains(@aria-label,'Type')]"));
	static Button NextButton = new Button("Next", byXPath("//button[text()='Next']"));
	static Link ClearLetters = new Link("Clear Letters", byXPath("//span[contains(@aria-label,'Clear Letter Request after Generating')]"));
	static Checkbox CheckLetters = new Checkbox("Check Letters", byXPath("//input[@id='checkAll']"));
	static Button QueueLetters = new Button("Queue Letters", byXPath("//a[@id='queueLetterButton']"));
	static Button QueueSAPBatch = new Button("Queue Batch", byXPath("//button[@id=\"saveSubmitBatchPackingJob\"]"));

	//update school fields for a group
	static Link ClickSchoolFields = new Link("School Defined Fields", byXPath("//span[.=\"Update School Fields\"]"));
	static TextField GroupName = new TextField("Group Name", byXPath("(//input[@aria-label='Group'])[1]"));
	static TextField SchoolField = new TextField("SchoolField", byXPath("//input[@name=\"schoolDefinedField_input\"]"));
	static Button SdNext = new Button("Next", byXPath("//button[.=\"Next\"]"));
	static Link UpdateSF = new Link("Update School fields", byXPath("//button[@id=\"updateSchoolFieldsButton\"]"));
	//static TextField SFValue = new TextField("School field value", byXPath("//textarea[@name=\"schoolDefinedFieldValue\"]"));
	static TextField SFValue = new TextField("School field value", byXPath("//input[@name='schoolDefinedFieldValue_input']"));
	
	static Button OkButton = new Button("Ok", byXPath("//button[@id=\"OKButton\"]"));
	static Link SFQueue = new Link("Queue batch", byXPath("//button[@id=\"queueUpdateButton\"]"));
	static Link SFQueuepost = new Link("Queue batch", byXPath("//button[@id=\"saveSubmitBatchPackingJob\"]"));
	Link AlertMsg= new Link("Capturing alert message", byXPath("//span[@role='alert']"));
	
	//static String Group1 = StudentGroupPage.Group;
		
	public StudentProcessesPage BatchAttendancePage(StringHash data) throws Exception {

		//Checkbox CheckCourse = new Checkbox(data.get("CourseNameCode"), byXPath("//input[@aria-label='"+data.get("CourseNameCode")+"']"));
		Checkbox CheckCourse = new Checkbox(data.get("CourseNameCode"), byXPath("(//tr/td)[1]"));
		//	 Button SelectTerm = new Button("Select Term", byXPath("//span[.='"+data.get("TermCode")+"']"));
		TextField Campus = new TextField("Enter Campus", byName("campusDropDown_input"));
		Link SelectCampus = new Link(data.get("CampusName"), byXPath("//span[.='"+data.get("CampusName")+"']"));
		Button ATTSelectTerm = new Button(data.get("TermCode"), byXPath("//span[.='"+data.get("TermName")+"']"));
		Button Refresh = new Button("Click Refresh Button", byId("attendanceGrid_cnsToolbar_kendoToolBar_reloadButton"));
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
		Date date = new Date();
		String currentDate = formatter.format(date);
		String[] dateArray = currentDate.split("/");
		int Day = Integer.parseInt(dateArray[1]);
		int EndDateValue = Day-1;
		String EndDateActual = currentDate.replace(dateArray[1], String.valueOf(EndDateValue));
		Link Absent = new Link("Absent", byXPath("//li[contains(text(),'Absent')]"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[.='The Attendance records were successfully saved.']"));
		
		//waitForPageToLoad();
		//wait(5);
		EnterTextInProcesses.waitTillElementClickable();
		EnterTextInProcesses.click();
		wait(3);
		EnterTextInProcesses.clearAndType("Attendance");
		wait(2);
		Attendance.click();
		waitForPageToLoad();
//		Campus.clearAndType(data.get("CampusName"));
//		wait(2);
//		SelectCampus.click();
		wait(2);
		AttTermCode.clearAndType(data.get("TermCode"));
		wait(5);
		ATTSelectTerm.click();
		wait(2);
		ClickCourseSpan.click();
		wait(4);
		EnterCourseCode.clearAndType(data.get("CourseCode"));
		wait(5);
		CheckCourse.check();
		wait(2);
		Select.clickUsingJavaScriptExecutor();
		wait(5);
//		AttendanceEndDate.clearAndType(EndDateActual);
//		wait(2);
//		AttendanceStartDate.clearAndType(currentDate);
//		wait(2);
		ApplyFilter.clickUsingJavaScriptExecutor();
		wait(10);	
		ClickAttendanceField.clickUsingJavaScriptExecutor();
		wait(5);
//		EnterAttendance.clear();
//		wait(2);
//		ClickAttendanceField.click();
//		wait(4);
//		EnterAttendance.sendKeys("30");
//		wait(5);
		EnterAttendance.sendKeys("Absent");
		wait(5);
		Save.click();
		wait(5);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
		//table[1]/tbody[1]/tr[1]/td[6]

	}
	
	public StudentProcessesPage BatchFinalGradesPage(StringHash data) throws Exception {

		Checkbox TermName = new Checkbox(data.get("TermName"), byXPath("//input[@aria-label='"+data.get("TermName")+"']"));
		Checkbox CheckCourse = new Checkbox(data.get("CourseNameCode"), byXPath("//input[@aria-label='"+data.get("CourseNameCode")+"']"));
		Link SelectCampus = new Link("Select Campus", byXPath("//span[.='"+data.get("CampusName")+"']"));

		//waitForPageToLoad();
		EnterTextInProcesses.waitTillElementClickable();
		EnterTextInProcesses.click();
		wait(3);
		EnterTextInProcesses.clearAndType("Gradebook");
		//Gradebook.waitTillElementFound();
		wait(2);
		Gradebook.click();
		wait(10);
//		Campus.clearAndType(data.get("CampusName"));
//		wait(2);
//		SelectCampus.click();
		wait(2);
		TermSpan.click();
		wait(4);
		EnterTermCode.clearAndType(data.get("TermCode"));
		wait(4);
		TermName.check();
		wait(2);
		Select.clickUsingJavaScriptExecutor();
		wait(5);
		ClickCourseSpan.click();
		wait(4);
		EnterCourseCode.clearAndType(data.get("CourseCode"));
		wait(8);
		CheckCourse.check();
		wait(2);
		Select.clickUsingJavaScriptExecutor();
		wait(4);
		ApplyFilter.waitTillElementClickable();
		ApplyFilter.click();
		wait(5);
		LetterGrade.click();
		wait(2);
		LetterGradeDrop.click();
		wait(2);
		SelectLetterGrade.click();
		//NumericGrade.deleteAndType(data.get("NumericdataGrade"));
		wait(5);
		finalGradeSave.click();
		wait(5);
		return this;

	}
	public StudentProcessesPage ProcessRefund(StringHash data) throws Exception {
		Link SelectingProcess= new Link(data.get("Process"), byXPath("//li/span[text()='"+data.get("Process")+"']"));
		Link SelectingReturnMethod= new Link(data.get("ReturnMethod"), byXPath("//li/span[text()='"+data.get("ReturnMethod")+"']"));
		Link SelectingRecordSelection= new Link(data.get("RecordSelection"), byXPath("//li/span[text()='"+data.get("RecordSelection")+"']"));
		Link SelectingPrintChecks= new Link(data.get("PrintChecks"), byXPath("//li/span[text()='"+data.get("PrintChecks")+"']"));
		Checkbox SelectingBankAccount= new Checkbox("SelectingBancAct", byXPath("(//tbody/tr/td)[1]"));

		//waitForPageToLoad();
		SearchField.waitTillElementClickable();
		SearchField.click();
		wait(3);
		SearchField.clearAndType(data.get("Component"));
		wait(2);
		RefundsStipends.click();
		wait(5);
		Process.click();
		wait(1);
		SelectingProcess.click();
		wait(1);
		ReturnMethod.click();
		wait(1);
		SelectingReturnMethod.click();
		wait(1);
		RecordSelection.click();
		wait(1);
		SelectingRecordSelection.click();
		wait(1);
		PrintChecks.click();
		wait(1);
		SelectingPrintChecks.click();
		wait(2);
		BankAccount.click();
		wait(2);
		//SearchBankAccount.clearAndType(data.get("BankAccount"));
		//wait(2);
		SelectingBankAccount.click();
		String SelectedBankAccount = SelectingBankAccount.getAttribute("aria-label");
		System.out.println(SelectedBankAccount);
		TestReportsLog.log(LogStatus.INFO, "Selected Bank Account is "+SelectedBankAccount);
		wait(2);
		Select.click();
		wait(2);
		Next.click();
		wait(3);
		scrollPage(0, 400);
		wait(1);
		QueuePost.click();
		wait(4);
		Queue.click();
		wait(2);
		System.out.println("Processes refunds are scheduled");
		return this;

	}

	public StudentProcessesPage ProcessStipend(StringHash data) throws Exception {
		Link SelectingProcess= new Link(data.get("Process"), byXPath("//li/span[text()='"+data.get("Process")+"']"));
		Link SelectingReturnMethod= new Link(data.get("ReturnMethod"), byXPath("//li/span[text()='"+data.get("ReturnMethod")+"']"));
		Link SelectingRecordSelection= new Link(data.get("RecordSelection"), byXPath("//li/span[text()='"+data.get("RecordSelection")+"']"));
		Link SelectingPrintChecks= new Link(data.get("PrintChecks"), byXPath("//li/span[text()='"+data.get("PrintChecks")+"']"));
		Checkbox SelectingBankAccount= new Checkbox("Selecting Bank Account", byXPath("//table/tbody/tr[1]/td[1]/input"));
		Link SelectingStipendSelection= new Link("Selecting Stipend", byXPath("//ul[@id='stipendSelectionType_listbox']/li[1]/span"));

		//waitForPageToLoad();
		SearchField.waitTillElementClickable();
		SearchField.click();
		wait(3);
		SearchField.clearAndType(data.get("Component"));
		wait(2);
		RefundsStipends.click();
		wait(5);
		Process.click();
		wait(1);
		SelectingProcess.click();
		wait(2);
		StipendSelection.click();
		wait(2);
		SelectingStipendSelection.click();
		String SelectedStipendSelection = SelectingStipendSelection.getText();
		System.out.println(SelectedStipendSelection);
		TestReportsLog.log(LogStatus.INFO, "Selected Stipend options is "+SelectedStipendSelection);
		wait(1);
		ReturnMethod.click();
		wait(1);
		SelectingReturnMethod.click();
		wait(1);
		RecordSelection.click();
		wait(1);
		SelectingRecordSelection.click();
		wait(1);
		PrintChecks.click();
		wait(1);
		SelectingPrintChecks.click();
		wait(2);
		BankAccount.click();
		wait(2);
		//SearchBankAccount.clearAndType(data.get("BankAccount"));
		//wait(2);
		SelectingBankAccount.click();
		String SelectedBankAccount = SelectingBankAccount.getAttribute("aria-label");
		System.out.println(SelectedBankAccount);
		TestReportsLog.log(LogStatus.INFO, "Selected Bank Account is "+SelectedBankAccount);
		wait(2);
		Select.click();
		wait(2);
		Next.click();
		wait(2);
		QueuePost.clickUsingJavaScriptExecutor();
		wait(2);
		Queue.clickUsingJavaScriptExecutor();
		wait(2);
		System.out.println("Processes Stipends are scheduled");
		return this;

	}


	public StudentProcessesPage SAPCalculationPage(StringHash data) throws Exception {

		Checkbox CheckTerm = new Checkbox(data.get("TermCode"), byXPath("//input[@aria-label='"+data.get("TermCode")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("(//td[.=' Succeeded'])[1]"));
		
		
		EnterTextInProcesses.waitTillElementClickable();
		EnterTextInProcesses.click();
		wait(3);
		EnterTextInProcesses.clearAndType("SAP Calculation");
		SAPCalculation.waitTillElementFound();
		SAPCalculation.click();
		wait(5);
		SAPTermSpan.click();
		wait(4);
		SAPTermName.clearAndType(data.get("TermCode"));
		wait(5);
		CheckTerm.check();
		wait(2);
		SAPSelect.clickUsingJavaScriptExecutor();
		wait(3);
		SAPQueue.click();
		wait(4);
		SAPConfirmqueue.click();
		wait(10);
		SAPOpenBatches.click();
		wait(5);
		//scrollPage(0, 500);
		wait(6);
		//SAPQueueOpenBatch.clickUsingJavaScriptExecutor();
		wait(2);
		//QueueSAPBatch.clickUsingJavaScriptExecutor();
//		wait(10);
		CustomAsserts.containsString(ValidationMessage.getText(), "Succeeded".toString());
		wait(3);
		return this;
	}

	public StudentProcessesPage ApproveDisbursementPage(StringHash data) throws Exception {


		Dropbox ADCampusDropdown = new Dropbox("Campus Dropdown", byXPath("(//button[@aria-label=\"expand combobox\"])[1]"));
		Link SelectCampus = new Link("Campus", byXPath("//ul[@id=\"campusDropDown_listbox\"]/li[1]/span/div/span[1]"));
		//Link SelectAwardYear = new Link("Award Year",byXPath("//ul[@id=\"awardYearDropDown_listbox\"]/li[1]"));
		Dropbox FundSourceDropdown = new Dropbox("Fund Source Dropdown", byXPath("//span[@aria-controls=\"fundTypeDropDown_listbox\"]/span"));
		//Link SelectADFundSource = new Link("Fund Source", byXPath("//ul[@id=\"fundTypeDropDown_listbox\"]/li[2]/div/span[1]"));
		Link SelectAwardYear = new Link(data.get("AwardYear"),byXPath("//li[.='"+data.get("AwardYear")+"']"));
		Dropbox SelectADFundSource = new Dropbox(data.get("FundSource"), byXPath("//span[.='"+data.get("FundSource")+"']"));
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
		Date date = new Date();
		String currentDate = formatter.format(date);
		String[] dateArray = currentDate.split("/");
		int year = Integer.parseInt(dateArray[2]);
		int EndDateValue = year-1;
		String From = currentDate.replace(dateArray[2], String.valueOf(EndDateValue));
		Button Next = new Button("Next", byXPath("(//button[@class=\"k-button k-primary ng-binding\"])[1]"));
		
		
		
		//waitForPageToLoad();
		//wait(5);
		
		EnterTextInProcesses.waitTillElementClickable();
		EnterTextInProcesses.click();
		wait(3);
		EnterTextInProcesses.sendKeys("Approve Disbursements to Pay");
		wait(2);
		ApproveDisbursementsToPay.click();
		waitForPageToLoad();
		wait(5);
		ADCampusDropdown.click();
		wait(2);
		SelectCampus.click();
		String CampusValue = SelectCampus.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Campus is selected as " +CampusValue);
		wait(2);
		ADAwardYear.click();
		wait(2);
		SelectAwardYear.click();
		wait(2);
		DisDateFrom.clearAndType(From);
		wait(2);
		DisDateTo.clearAndType(currentDate);
		wait(4);
		//	ADAwardYear.sendKeys(data.get("AwardYear"));
		//	wait(4);
		ADFundType.clearAndType(data.get("FundSource"));
		wait(2);
		SelectADFundSource.click();
		wait(2);	
		Next.click();
		wait(10);
		return this;
	}


	public StudentProcessesPage ProcessLetters(StringHash data) throws Exception {
		Link SelectingType = new Link(data.get("Type"), byXPath("//li[text()='"+data.get("Type")+"']")); 
		Link SelectingCLr = new Link(data.get("ClearLetter"), byXPath("//li[text()='"+data.get("ClearLetter")+"']"));
		Checkbox SelectingLetter = new Checkbox(data.get("TaskTemplate"), byXPath("//input[@aria-label = '"+data.get("TaskTemplate")+"']"));
		Link QueLetterMsg= new Link("Queue Letter Msg", byXPath("//span[text()='The Letters were successfully queued']"));

		//waitForPageToLoad();
		SearchField.waitTillElementClickable();
		SearchField.click();
		wait(3);
		SearchField.clearAndType(data.get("Component"));
		wait(2);
		Letters.click();
		wait(5);
		Type.click();
		wait(2);
		SelectingType.click();
		wait(2);
		ClearLetters.click();
		wait(2);
		SelectingCLr.click();
		wait(2);
		if(NextButton.isEnabled()) {
			NextButton.click();
			wait(3);
			CheckLetters.click();
			wait(2);
			SelectingLetter.click();
			wait(2);
			QueueLetters.click();
			wait(2);
			Queue.click();
			wait(2);
			CustomAsserts.containsString(QueLetterMsg.getText(), data.get("QueLetterMsg").toString());
		}else {
			String Errormessage = AlertMsg.getText();
			System.out.println(Errormessage);
			TestReportsLog.logfail(LogStatus.FAIL, Errormessage);
		}
		
		return this;
	}
	
	public StudentProcessesPage UpdateSchoolFieldsPage(StringHash data) throws Exception {

		 

		Link SelectGroupName = new Link("Group Name", byXPath("//li[.='"+data.get("GroupName")+"']"));

		Link SelectSchoolField = new Link("School Field", byXPath("//span[.='"+data.get("SchoolField")+"']"));

		Link ValidationMessage = new Link("Validation Message", byXPath("//span[text() = 'The Update School Fields were successfully queued']"));
		
		Link GenderValue = new Link("GenderValue", byXPath("//span[text()='"+data.get("SchoolFieldValue")+"']"));

 

	//	EnterTextInProcesses.waitTillElementClickable();
		EnterTextInProcesses.sendKeys("Update School Fields");
		wait(4);
//		ClickSchoolFields.waitTillElementClickable();
		ClickSchoolFields.click();
		wait(5);
	//	GroupName.waitTillElementClickable();
		GroupName.clearAndType(data.get("GroupName"));
		wait(5);
	//	SelectGroupName.waitTillElementClickable();
		SelectGroupName.click();
		wait(5);
	//	SchoolField.waitTillElementClickable();
		SchoolField.clearAndType(data.get("SchoolField"));
        wait(4);
	//	SelectSchoolField.waitTillElementClickable();
		SelectSchoolField.click();
        wait(4);
	//	SdNext.waitTillElementClickable();
		SdNext.click();
        wait(4);
	//	UpdateSF.waitTillElementClickable();
		UpdateSF.click();
		wait(3);
	//	SFValue.waitTillElementClickable();
		SFValue.clearAndType(data.get("SchoolFieldValue"));
		wait(3);
		GenderValue.click();
		wait(5);
		//	OkButton.waitTillElementClickable();
		OkButton.click();
		wait(5);
	//	SFQueue.waitTillElementClickable();
		SFQueue.click();
		wait(5);
	//	SFQueuepost.waitTillElementClickable();
		SFQueuepost.click();
		wait(7);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		return this;

		}
}
