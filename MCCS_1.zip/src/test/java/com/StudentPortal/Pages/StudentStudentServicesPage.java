package com.StudentPortal.Pages;


import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;
import static com.framework.elements.Locator.byName;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.DatesUtil;
import com.framework.util.Encrypt;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;
public class StudentStudentServicesPage  extends BasePage{

	//Housing deposit web elements

	static Link StudentServices = new Link("Student Services", byXPath("//cns-panel-bar/ul/li[7]/a/span"));
	static Link Housingdeposits = new Link("Housing deposits", byXPath("//span[. = \"Housing Deposits\"]"));
	static Link New = new Link("New", byXPath("//button[@id=\"newButton\"]"));
	//static Dropbox DepositTypes = new Dropbox("Deposit Types", 	byXPath("//span[@aria-label=\"Deposit Type: Dropdown\"]/span/span[2]"));
	static Dropbox DepositTypes = new Dropbox("Deposit Types", 	byXPath("(//span[@aria-label=\"select\"])[4]"));
	static Link SelectDepositType = new Link("Deposit Type", byXPath("//ul[@id=\"depositType_listbox\"]/li[1]/span"));
	static TextField Amount = new TextField("Amount", byXPath("//input[1][@aria-label=\"Amount\"]"));
	//static Dropbox PaymentTypeDropdown = new Dropbox("Payment Types Dropdown", byXPath("//span[@aria-label=\"Payment Type: Dropdown\"]/span/span[2]/span"));
	static Dropbox PaymentTypeDropdown = new Dropbox("Payment Types Dropdown", byXPath("(//span[@aria-label='select'])[7]"));
	static Link SelectPaymentType = new Link("Payment Type", byXPath("//ul[@id=\"paymentType_listbox\"]/li[1]"));
	static Button SaveClose = new Button("Save and Close", byXPath("(//button[@aria-label=\"Save & Close\"])[2]"));
	
	
	public StudentStudentServicesPage HousingDepositPage(StringHash data) throws Exception{
		
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Housing Deposit records were successfully saved.']"));
		
		//wait(20);
		StudentServices.waitTillElementClickable();
		StudentServices.click();
		wait(2);
		Housingdeposits.click();
		wait(10);
		New.click();
		wait(10);
		DepositTypes.clickUsingJavaScriptExecutor();
		wait(2);
		SelectDepositType.clickUsingJavaScriptExecutor();
		wait(2);
		Amount.type("100");
		wait(2);
		PaymentTypeDropdown.click();
		wait(2);
		SelectPaymentType.click();
		wait(2);
		scrollPage(0, -200);
		wait(2);
		SaveClose.clickUsingJavaScriptExecutor();
		wait(8);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
		
	}		
}
