package com.StudentPortal.Pages;

import java.util.Base64;

public class Sample2 {

public static void main(String[] args) throws InterruptedException {

	//Scanner sc=new  Scanner(System.in);
	String str1="210395678900001";
	String str3="";
	int c=0;
	for (int i = 0; i < str1.length(); i++) {
		if (str1.charAt(i)=='0') {
			c++;
		}
	}
	System.out.println(c);
	for (int i = 0; i <c; i++) {
		str3+="0";
	}
	System.out.println(str3);
	for (int i = 0; i <str1.length(); i++) {
		if (str1.charAt(i)!='0') {
			str3+=str1.charAt(i);
		}
	}
	System.out.println(str3);

}
}