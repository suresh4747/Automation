package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byXPath;


import java.util.concurrent.TimeUnit;


import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentAccountSchoolFieldsPage extends BasePage{

	static Link ContactManager = new Link("Contact Manager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
	static Link Admissions = new Link("Admissions", byXPath("//cns-panel-bar/ul[1]/li[2]/a/span"));
	static Link AcademicRecords = new Link("Academic records", byXPath("//cns-panel-bar/ul[1]/li[3]/a/span"));
	static Link CareerServices = new Link("CareerServices", byXPath("//cns-panel-bar/ul[1]/li[4]/a/span"));
	static Link FinancialAid = new Link("FinancialAid", byXPath("//cns-panel-bar/ul[1]/li[5]/a/span"));
	static Link StudentAccounts = new Link("StudentAccounts", byXPath("//cns-panel-bar/ul[1]/li[6]/a/span"));
	static Link StudentServices = new Link("StudentServices", byXPath("//cns-panel-bar/ul/li[7]/a/span"));
	static Link SchoolFieldsStdAcc = new Link("School fields", byXPath("(//span[text()='School Fields'])[5]"));
	static Link SchoolFieldsAdmission = new Link("School fields", byXPath("(//span[text()='School Fields'])[1]"));
	static Link SchoolFieldsStdserv = new Link("School fields", byXPath("(//span[text()='School Fields'])[6]"));
	static Link SchoolFieldsCarserv = new Link("School fields", byXPath("(//span[text()='School Fields'])[3]"));
	static Button HousingSchoolFields = new Button("Housing School Fields", byXPath("//button[text()='Housing School Fields']"));
	static TextField InternationalStudent = new TextField("International Student", byXPath("//input[@aria-label='INTSTU']"));
	
	static TextField FetchingFGS = new TextField("Fecthing First generation Student", byXPath("//div[2]/div[1]/div/div/cmc-drop-down-list-classic/div/div/span/span"));
	//static TextField DisabilityRequest = new TextField("Disability request", byXPath("//span[@aria-label='Disability Request: Dropdown']"));
	static TextField DisabilityRequest = new TextField("Disability request", byXPath("//span[contains(@aria-label,'Disability Request')]"));
	//static TextField GenderIdentity = new TextField("Gender Identity", byXPath("//span[@aria-label='Gender Identity: Dropdown']"));
	static TextField GenderIdentity = new TextField("Gender Identity", byXPath("//span[contains(@aria-label,'Gender Identity')]"));
	static TextField LeftHanded = new TextField("Left Handed", byXPath("//input[@aria-label='LeftHand']"));
	static Button Save = new Button("Save button", byXPath("(//button[@aria-label='Save'])[2]"));
	static Link Successmsg = new Link("Success message", byXPath("//div[59]//span[2]"));
	static Link Clear = new Link("Clear existing data", byXPath("//span[@aria-label='delete']"));
	static Link SelectingLeftHand= new Link("Selecting LeftHand", byXPath("(//li[text()='Yes'])[2]"));
	static Link SelectingFGS= new Link("Selecting First Generation student", byXPath("(//li[text()='Yes'])[1]"));
	static Link SelectingDisreq= new Link("Selecting Disability request", byXPath("(//li[text()='Yes'])[3]"));
	static Link SelectingGenIden= new Link("Selecting Gender Identity", byXPath("//li[text()='Woman']"));
	//static Button Save = new Button("Save button", byXPath("(//button[@aria-label='Save'])[2]"));	
	Link SchFieldMsg= new Link("School defined filed Msg", byXPath("//span[text()='The Student records were successfully saved.']"));
	Link AlertMsg= new Link("Capturing alert message", byXPath("//span[@role='status']"));
	
	//xpath for housing application
	static Link HousingApplications = new Link("Housing Applications", byXPath("//span[text()='Housing Applications']"));
	static Button New = new Button("New Button", byXPath("//*[@id='newButton']"));
	static AngDropDown BuildingCategory = new AngDropDown("Desired building category", byXPath("(//button[@aria-label='expand combobox'])[2]"));
	static Link SelectingBuildCategory = new Link("Selecting Category", byXPath("(//ul[@id='actionNumber0_listbox']/li/span/div/span[1])[1]"));
	static AngDropDown RoomCategory = new AngDropDown("Desired building category", byXPath("(//button[@aria-label='expand combobox'])[3]"));
	static Link SelectingRoomCategory = new Link("Selecting Category", byXPath("(//ul[@id='actionNumber1_listbox']/li/span/div/span[1])[1]"));
	static AngDropDown Building = new AngDropDown("Desired building", byXPath("(//button[@aria-label='expand combobox'])[4]"));
	static Link SelectingBuilding = new Link("Selecting Building", byXPath("(//ul[@id='actionNumber2_listbox']/li/span/div/span[1])[1]"));
	static TextField NoRoomates = new TextField("No Roomates", byXPath("(//label/span[text()='No'])[1]"));
	static AngDropDown Term = new AngDropDown("Housing Period", byXPath("//span[@aria-controls='actionNumber4_listbox']/span[1]"));
	static AngDropDown HousingTerm = new AngDropDown("Housing Term", byXPath("//span[@aria-controls='actionNumber0_listbox']/span[1]"));
	static Link SelectHousingTerm = new Link("Select Housing term", byXPath("//ul[@id='actionNumber0_listbox']/li[1]/span/div/span[1]"));
	static Checkbox RoomType = new Checkbox("Room Type", byXPath("//label[@for='actionNumberFalse1_1']/span"));
	static Link SelectingTerm = new Link("Selecting Housing Period", byXPath("(//ul[@id='actionNumber3_listbox']/li//spandiv/span[1])[1]"));
	static Button SaveAndClose = new Button("Save and Close", byXPath("(//button[@aria-label='Save & Close'])[3]"));
	static Link ProgramVersion = new Link("Program versions", byXPath("(//span[@id='programVersionDropDown'])[1]"));
	static Link SelectingAllProgramVersion = new Link("Selecting All Program versions", byXPath("//a[text()='All Program Versions']"));
	

	public StudentAccountSchoolFieldsPage AccountSchoolField(StringHash data) throws Exception{
		//TextField EDUID = new TextField("EDU Id", byXPath("//input[@aria-label='EDUID']"));
		TextField Gender = new TextField("Gender", byXPath("//textarea[@id='Gender']"));
		Link SchoolFields = new Link("School Fileds", byXPath("//div[text()='School Fields']"));
		//Link SelectingINTSTU= new Link("Selecting INTSTU", byXPath("(//ul[@id='INTSTU_listbox']/li[1])"));
		AngDropDown GenderIdentity = new AngDropDown("GenderIdentity", byXPath("//span[@aria-label='Gender Identity']"));
		Link GenderIdentityValue = new Link("GenderIdentityValue", byXPath("//ul[@id='Gen_listbox']/li[1]/span"));
		
		waitForPageToLoad();
		scrollPage(0, 100);
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(2);
		SchoolFieldsStdAcc.clickUsingJavaScriptExecutor();
		wait(5);
		scrollPage(0, -500);
		wait(2);
		GenderIdentity.click();
		wait(2);
		//EDUID.ClearExistingText();
		//wait(2);
		//EDUID.backSpace();
		//wait(2);
		//SchoolFields.click();
		GenderIdentityValue.click();
		wait(2);
		String GenderIdentityValues = GenderIdentityValue.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Gender identity is selected as "+GenderIdentityValues);
//		SelectingINTSTU.enter();
//		String SelectedINTSTU = SelectingINTSTU.getText().toString();
//		System.out.println(SelectedINTSTU);
//		TestReportsLog.log(LogStatus.INFO, "Selected Value is "+SelectedINTSTU);
//		wait(2);
		scrollPage(0, -800);
		wait(2);
		Save.click();
		wait(8);
		String AlertMessage = AlertMsg.getText();
		if(AlertMessage.equalsIgnoreCase(data.get("SchFieldMsg"))){
		CustomAsserts.containsString(SchFieldMsg.getText(), data.get("SchFieldMsg").toString());
		}else {
			System.out.println("Error message displayed is "+AlertMessage);
			TestReportsLog.log(LogStatus.INFO, "Error message displayed is "+AlertMessage);
		}
//		scrollPage(0, 500);
//		String INTSTU = InternationalStudent.getText();
//		System.out.println(INTSTU);
//		System.out.println("School field added successfully for Student Accounts");
		return this;
		
	}
	
    public StudentAccountSchoolFieldsPage AdmissionSchoolField(StringHash data) throws Exception{
    	
    	TextField CSIGlobalId = new TextField("CSI Global Id", byXPath("(//input[@aria-label='CSI Global ID'])[1]"));
    	//TextField EDUID = new TextField("EDU Id", byXPath("//input[@aria-label='EDUID']"));
    	TextField EDUID = new TextField("EDU Id", byXPath("//textarea[@aria-label='EDUID']"));
    	Link SchoolFields = new Link("School Fileds", byXPath("//div[text()='School Fields']"));
    	//Link SelectingFGS= new Link("Selecting First Generation student", byXPath("//ul[@id='FIRSTGEN_listbox']/li[2]"));
    	AngDropDown GenderIdentity = new AngDropDown("GenderIdentity", byXPath("//span[@aria-label='Gender Identity']"));
		Link GenderIdentityValue = new Link("GenderIdentityValue", byXPath("//ul[@id='Gen_listbox']/li[1]/span"));
		
    	driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
		waitForPageToLoad();
		wait(3);
		Admissions.click();
		wait(2);
		SchoolFieldsAdmission.clickUsingJavaScriptExecutor();
		wait(5);
		scrollPage(0, -500);
//		wait(2);
//		EDUID.backSpace();
//		wait(2);
		//CSIGlobalId.click();
		//CSIGlobalId.sendKeys("6");
		wait(2);
		GenderIdentity.click();
		wait(2);
		//EDUID.ClearExistingText();
		//wait(2);
		//EDUID.backSpace();
		//wait(2);
		//SchoolFields.click();
		GenderIdentityValue.click();
		wait(2);
		String GenderIdentityValues = GenderIdentityValue.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Gender identity is selected as "+GenderIdentityValues);
		//SelectingFGS.click();
		//String SelectedFGS = SelectingFGS.getText();
		//System.out.println(SelectedFGS);
		//TestReportsLog.log(LogStatus.INFO, "Selected Value is "+SelectedFGS);
		wait(2);
		scrollPage(0, -300);
		wait(2);
		Save.click();
		wait(8);
		CustomAsserts.containsString(SchFieldMsg.getText(), data.get("SchFieldMsg").toString());
//		FirstGenerationStudent.waitTillElementFound();
//		String FGS = FirstGenerationStudent.getText();
//		System.out.println(FGS);
//		System.out.println("School field added successfully for Admissions");

		return this;
		
	}
    
    public StudentAccountSchoolFieldsPage StudentServiceSchoolField(StringHash data) throws Exception{
    	
    	TextField CSIGlobalId = new TextField("CSI Global Id", byXPath("//input[@aria-label='CSI Global ID']"));
    	//TextField EDUID = new TextField("EDU Id", byXPath("//input[@aria-label='EDUID']"));
    	TextField Gender = new TextField("Gender", byXPath("//textarea[@id='Gender']"));
    	Link SchoolFields = new Link("School Fileds", byXPath("//div[text()='School Fields']"));
    	//Link SelectingDisreq= new Link("Selecting Disability request", byXPath("(//ul[@id='DISREQUEST_listbox']/li[1])"));
    	AngDropDown GenderIdentity = new AngDropDown("GenderIdentity", byXPath("//span[@aria-label='Gender Identity']"));
		Link GenderIdentityValue = new Link("GenderIdentityValue", byXPath("//ul[@id='Gen_listbox']/li[1]/span"));
		
    	driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
		waitForPageToLoad();
		StudentServices.clickUsingJavaScriptExecutor();
		wait(1);
		SchoolFieldsStdserv.clickUsingJavaScriptExecutor();
		wait(5);
		scrollPage(0, -500);
		wait(2);
		//Gender.sendKeys("F");
		//wait(2);
		GenderIdentity.click();
		wait(2);
		//EDUID.ClearExistingText();
		//wait(2);
		//EDUID.backSpace();
		//wait(2);
		//SchoolFields.click();
		GenderIdentityValue.click();
		wait(2);
		String GenderIdentityValues = GenderIdentityValue.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Gender identity is selected as "+GenderIdentityValues);
//		SelectingDisreq.click();
//		String SelectedDisreq = SelectingDisreq.getText();
//		System.out.println(SelectedDisreq);
//		TestReportsLog.log(LogStatus.INFO, "Selected Value is "+SelectedDisreq);
//		wait(2);
		scrollPage(0, -500);
		wait(2);
		Save.click();
		wait(8);
		CustomAsserts.containsString(SchFieldMsg.getText(), data.get("SchFieldMsg").toString());
//		DisabilityRequest.waitTillElementFound();
//		String DR = DisabilityRequest.getText();
//		System.out.println(DR);
//		System.out.println("School field added successfully for Student Services");
		return this;
		
	}
    
    public StudentAccountSchoolFieldsPage StudentServiceHousingSchoolField(StringHash data) throws Exception{

    	//TextField EDUID = new TextField("EDU Id", byXPath("//input[@aria-label='EDUID']"));
    	TextField Gender = new TextField("Gender", byXPath("//textarea[@id='Gender']"));
    	Link SchoolFields = new Link("School Fileds", byXPath("//div[text()='School Fields']"));
    	Link HouSchFieldMsg= new Link("Housing School defined filed Msg", byXPath("//span[text()='The Student Services Housing School Fields were successfully saved.']"));
    	
    	AngDropDown GenderIdentity = new AngDropDown("GenderIdentity", byXPath("//span[@aria-label='Gender Identity']"));
		Link GenderIdentityValue = new Link("GenderIdentityValue", byXPath("//ul[@id='Gen_listbox']/li[1]/span"));
		 Link StudentServices = new Link("StudentServices", byXPath("//a[@aria-label='Student Services']"));

    	driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
		waitForPageToLoad();
		StudentServices.clickUsingJavaScriptExecutor();
		wait(1);
		SchoolFieldsStdserv.clickUsingJavaScriptExecutor();
		wait(3);
		scrollPage(0, -500);
		wait(2);
		HousingSchoolFields.clickUsingJavaScriptExecutor();
		wait(6);
		scrollPage(0, -800); 
		//Gender.sendKeys("F");
		wait(2);
		GenderIdentity.clickUsingJavaScriptExecutor();
		wait(2);
		//EDUID.ClearExistingText();
		//wait(2);
		//EDUID.backSpace();
		//wait(2);
		//SchoolFields.click();
		GenderIdentityValue.clickUsingJavaScriptExecutor();
		wait(2);
		String GenderIdentityValues = GenderIdentityValue.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Gender identity is selected as "+GenderIdentityValues);
//		SelectingLeftHand.enter();
//		String SelectedLeftHand = SelectingLeftHand.getText();
//		System.out.println(SelectedLeftHand);
//		TestReportsLog.log(LogStatus.INFO, "Selected Value is "+SelectedLeftHand);
//		wait(2);
		scrollPage(0, -500);
		wait(2);
		Save.clickUsingJavaScriptExecutor();
		wait(8);
		CustomAsserts.containsString(HouSchFieldMsg.getText(), data.get("HouSchFieldMsg").toString());
//		scrollPage(0, 200);
//		LeftHanded.waitTillElementFound();
//		String LH = LeftHanded.getText();
//		System.out.println(LH);
//		System.out.println("School field added successfully for Student Services Housing Fileds");
		return this;
		
	}
    
    	public StudentAccountSchoolFieldsPage CareerServiceSchoolField(StringHash data) throws Exception{

    	Link SchoolFields = new Link("School Fileds", byXPath("//div[text()='School Fields']"));
    	//TextField EDUID = new TextField("EDU Id", byXPath("//input[@aria-label='EDUID']"));
    	TextField Gender = new TextField("Gender", byXPath("//textarea[@id='Gender']"));
    	AngDropDown GenderIdentity = new AngDropDown("GenderIdentity", byXPath("//span[@aria-label='Gender Identity']"));
		Link GenderIdentityValue = new Link("GenderIdentityValue", byXPath("//ul[@id='Gen_listbox']/li[1]/span"));
		
    	driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;	
		waitForPageToLoad();
		CareerServices.clickUsingJavaScriptExecutor();
		wait(1);
		SchoolFieldsCarserv.clickUsingJavaScriptExecutor();
		wait(6);
		scrollPage(0, -500);
		wait(1);
		//Gender.sendKeys("F");
		wait(2);
		GenderIdentity.click();
		wait(2);
		//EDUID.ClearExistingText();
		//wait(2);
		//EDUID.backSpace();
		//wait(2);
		//SchoolFields.click();
		GenderIdentityValue.click();
		wait(2);
//		String GenderIdentityValues = GenderIdentityValue.getTextValue();
//		TestReportsLog.log(LogStatus.INFO, "Gender identity is selected as "+GenderIdentityValues);
//		SelectingGenIden.click();
//		String SelectedGenIden = SelectingGenIden.getText();
//		System.out.println(SelectedGenIden);
//		TestReportsLog.log(LogStatus.INFO, "Selected Value is "+SelectedGenIden);
//		wait(2);
		scrollPage(0, -500);
		wait(2);
		Save.clickUsingJavaScriptExecutor();
		wait(8);
		CustomAsserts.containsString(SchFieldMsg.getText(), data.get("SchFieldMsg").toString());
//		GenderIdentity.waitTillElementFound();
//		String GI = GenderIdentity.getText();
//		System.out.println(GI);
//		System.out.println("School field added successfully for Career Services");
		return this;
    	}	
    	
    	
    	public StudentAccountSchoolFieldsPage AddingHousingApplication(StringHash data) throws Exception{

    		Link HousingMsg= new Link("Housing application Msg", byXPath("//span[text()='The Housing Application records were successfully saved.']"));
    		Link MilesSelection= new Link("MilesSelection", byXPath("//label/span[text()='0-20']"));
    		Link Programversion= new Link("Programversion", byXPath("//div[@id='programVersionDropDown']"));
    		Link SelectTerm= new Link("SelectTerm", byXPath("//ul[@id='actionNumber4_listbox']/li[1]/div/span[1]"));
    		Link HousingPeriod= new Link("HousingPeriod", byXPath("(//button[@aria-label='expand combobox'])[5]"));
    		Link HousingPeriodValue= new Link("HousingPeriodValue", byXPath("(//ul[@id='actionNumber4_listbox']/li[1]/span/div/span)[1]"));
    		
    		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
    		//waitForPageToLoad();
    		wait(8);
    		StudentServices.waitTillElementClickable();
    		StudentServices.clickUsingJavaScriptExecutor();
    		wait(1);
    		HousingApplications.clickUsingJavaScriptExecutor();
    		wait(3);
    		Programversion.click();
    		wait(1);
    		SelectingAllProgramVersion.click();
    		wait(10);
    		//scrollPage(0, -500);
    		//wait(5);
    		New.click();
    		scrollPage(0, 400);
    		wait(10);
    		BuildingCategory.clickUsingJavaScriptExecutor();
    		wait(2);
    		SelectingBuildCategory.click();
    		wait(2);
    		RoomCategory.click();
    		wait(2);
    		SelectingRoomCategory.clickUsingJavaScriptExecutor();
    		wait(2);
    		Building.click();
    		wait(2);
    		SelectingBuilding.click();
    		wait(4);
    		NoRoomates.clickUsingJavaScriptExecutor();
    		wait(2);
    		HousingPeriod.click();
    		wait(2);
    		HousingPeriodValue.click();
//    	    HousingTerm.click();
//    		wait(2);
//    		SelectHousingTerm.click();
    		//Term.click();
    		wait(2);
    		//SelectTerm.click();
    		//wait(2);
//    		RoomType.click();
//    		MilesSelection.click();
//    		wait(2);
    		SaveAndClose.clickUsingJavaScriptExecutor();
    		wait(5);
    		CustomAsserts.containsString(HousingMsg.getText(), data.get("HousingMsg").toString());
    		wait(2);
    		return this;
    	}
}
;