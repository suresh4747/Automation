package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;


import static com.framework.elements.Locator.byCSSSelector;



import static com.framework.elements.Locator.byCSSSelector;


import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.framework.base.BasePage;
import com.framework.elements.Button;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.DatesUtil;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;
import com.framework.elements.AngDropDown;
import com.framework.elements.Checkbox;


import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

public class StudentConfigurationPage extends BasePage{ 
	//Login Page Web Elements	
	static String SubNameValue = AppendValue.apendString();
	static String SubCodeValue = AppendValue.apendString();
	static String TaskTempNameValue = AppendValue.apendString();
	static String TaskTempCodeValue = AppendValue.apendString();
	static String TaskSchNameValue = AppendValue.apendString();
	static String DocNameValue = AppendValue.apendString();
	static String DocCodeValue = AppendValue.apendString();
	static String DocSchNameValue = AppendValue.apendString();
	static String RstName = AppendValue.apendString();
	static String RstCode = AppendValue.apendString();
	static String SMSNameValue = AppendValue.apendString();
	static String SMSCodeValue = AppendValue.apendString();	
	static String EmployerNameValue = AppendValue.apendString();
	static String EmployerCodeValue = AppendValue.apendString();
	static String EmailAddressValue = AppendValue.apendString();	
	static Link MenuButton = new Link("Click MenuButton", byXPath("//div[@id='navbar']/ul/li[2]/a/span"));
	static Link Configuration = new Link("Configuration tile", byXPath("//a[text()='Configuration']"));
	static TextField SearchConfiguration = new TextField("Search Configuration", byXPath("//input[@placeholder='Search Configuration']"));
	static Link ResidencyTypes = new Link("Residency Types", byXPath("//span[text()='Residency Types']"));
	static Button NewButton = new Button("New Button ", byXPath("//*[@id='newButton']"));
	static TextField Name = new TextField("Name", byXPath("//input[@id='name']"));
	static TextField Code = new TextField("Code", byXPath("//input[@id='code']"));
	static Link TaskTemplates = new Link("Task Templates", byXPath("//span[text()='Task Templates']"));																						
	static TextField EventType = new TextField("EventType", byXPath("//input[@name='taskTypeId_input']"));
	static Link SelectingEventType = new Link("Selecting Event Type", byXPath("//span[. = 'Meeting']"));																								  
	static Button SaveAndClose = new Button("Save and Close", byXPath("//button[@aria-label= 'Save & Close']"));
	static Link TaskSchedules = new Link("Task schedules", byXPath("//span[text()='Task Schedules']"));
	static TextField ScheduleTaskFor = new TextField("Schedule Task For", byXPath("//input[@name='basisForTask_input']"));
	static Link SelectingScheduleFor = new Link("Selecting schedule for", byXPath("//span[. = 'Prospective Student']"));
	//static TextField DocumentsList = new TextField("Document list", byXPath("//div[@aria-label='Documents']"));
	//static Link SelectingDocumentList = new Link("Selecting document list", byXPath("//li[. = 'Medical Certificate']"));
	static TextField TriggerWhen = new TextField("Trigger When", byXPath("//input[@name='triggerWhen_input']"));
	static Link SelectingTriggerWhen= new Link("Selecting trigger when", byXPath("//span[. = 'Lead Type']"));
	static TextField TriggerChangesTo = new TextField("Trigger changes to", byXPath("//div[@id='search_display_triggerChnagesTo']"));
	static Link SelectingChangesTo= new Link("Selecting Changes To", byXPath("//span[. = 'Lead Type']"));
	static TextField SearchName = new TextField("Search Name", byXPath("//input[@placeholder='Search Name']"));
	static Checkbox ChangestoName = new Checkbox("Selecting changes to status", byXPath("//input[@aria-label='CRM']"));
	static Button SelectButton = new Button("Select button", byXPath("//button[text()='Select']"));
	static TextField TaskEventType = new TextField("Task EventType", byXPath("//input[@name='taskType_input']"));
	static Link SelectingType= new Link("Selecting EventType", byXPath("//span[. = 'Other']"));
	static TextField TaskTemplate = new TextField("Task Template", byXPath("//input[@name='taskTemplate_input']"));
	static Link SelectingTaskTemplate= new Link("Selecting TaskTemplate", byXPath("//div/div/div//span[. = 'Duplicate Lead']"));
	static Link AssignTo= new Link("Assign To", byXPath("//span[text()='Assign To']"));
	static TextField AssignedTo = new TextField("Assigned To", byXPath("//input[@name='taskAssignTo_input']"));
	static Link SelectingAssignedTo= new Link("Selecting AssignedTo", byXPath("//span[. = 'Student']"));
	static Link Units = new Link("Units", byXPath("//span/span/span[. = ' ']"));
	static Link SelectingUnits= new Link("Selecting Units", byXPath("//li[. = 'Days']"));
	static TextField Event = new TextField("Event", byXPath("//input[@name='whenTime_input']"));
	static Link SelectingEvent= new Link("Selecting Event", byXPath("//span[. = 'Event Occurred']"));
	static Link Documents = new Link("Documents", byXPath("//span[text()='Documents']"));
	static TextField Module = new TextField("Module", byXPath("//input[@name='moduleId_input']"));
	static Link SelectingModule = new Link("Selecting Module", byXPath("//li[text()='Career Services']"));
	static TextField DocumentType = new TextField("DocumentType", byXPath("//input[@name='directionType_input']"));
	static Link SelectingDocumentType = new Link("Selecting Module", byXPath("//li[text()='FERPA']"));
	static TextField Campuses = new TextField("Campuses", byXPath("//div[@aria-label='Campuses']"));
	static TextField CampusesGroup = new TextField("Campuses DCRC", byXPath("//div[contains(@aria-label,'Campus Group')]"));
	static Checkbox SelectingCampus = new Checkbox("Selecting campus", byXPath("//input[@aria-label='DTS']"));
	static Link DocumentSchedules = new Link("Document schedules", byXPath("//span[text()='Document Schedules']"));
	static Link ScheduleCriteria = new Link("Schedule Criteria", byXPath("//a[contains(text(),'Schedule Criteria')]"));
	static TextField SearchCriteria = new TextField("Search Criteria", byXPath("//input[@id='schedDocSchedCriteriaItem-filter']"));
	static Link SelectingSearchCriteria = new Link("Selecting Search Criteria", byXPath("//span[. = 'Dependency Status']"));
	static Link Arrowmark = new Link("Arrow mark", byXPath("//div[@id='schedDocSchedCriteriaMoveButton']//i[2]"));
	static TextField Value = new TextField("Value", byXPath("//div[@id='search_display_MODEL']"));
	static Checkbox DependentStatus = new Checkbox("Dependent status", byXPath("//input[@aria-label='Dependent']"));
	static Link DocumentCriteria = new Link("Document Criteria", byXPath("//div/a[contains(text(),'Documents')]"));
	static Link AddDocument= new Link("Add document", byXPath("//span[text()='Document']"));
	//static Link AddDocument= new Link("Add document", byXPath("(//a[@id='addDocumentButton']"));
	static Checkbox SelectingDocument = new Checkbox("Selecting document", byXPath("//input[@aria-label='Medical Certificate']"));
	static Button Filtericon = new Button("Filter icon", byXPath("(//a[@title='Settings'])[2]"));
	static Button Filtericon1 = new Button("Filter icon", byXPath("(//div[2]/a[2])[2]"));
	static Link ClearFilters= new Link("Clear Filters", byXPath("//a[text()='Clear All']"));
	static Link ClearFilters1= new Link("Clear Filters", byXPath("(//a[@id=\"n.courseDetail.gridId_cnsToolbar_kendoToolBar_clearFiltersButton\"])[1]"));
	static AngDropDown Listdrpdwn= new AngDropDown("Task template dropdown", byXPath("(//th[2]/a/span)[1]"));
	static Button Filteroption= new Button("Filteroption", byXPath("//span[text()='Filter']"));
	static TextField FilterValue = new TextField("Filter Value",byXPath("//input[@title='Value']"));
	static Button Filterbutton = new Button("Filter button", byXPath("//button[. = 'Filter']"));
	static Link Tablevalue= new Link("Table value", byXPath("//td/a"));
	static Link ClearFiltersFordocsch= new Link("Clear Filters for document schedule", byXPath("(//a[text()='Clear Filters'])[2]"));
	static Link Subsidiaries = new Link("Subsidiaries", byXPath("//span[text()='Subsidiaries']"));
	static Link TransactionCodes = new Link("Transaction codes", byXPath("//div[@id='search_display_transactionCode']"));
	static TextField SearchCode = new TextField("Search Code",byXPath("//input[@placeholder='Search Code']"));
	static Button SelectCode = new Button("Select code", byXPath("//div/button[text()='Select']"));
	static AngDropDown Namedrpdwn= new AngDropDown("Name dropdown", byXPath("(//th[1]/a/span)[1]"));	
	//static Link MenuButton = new Link("Click MenuButton", byXPath("//div[@id='navbar']/ul/li[2]/a/span"));
	static Link Students = new Link("Students tile", byXPath("//a[text()=\"Students\"]"));
	static Link FilterDropDwon = new Link("Click Filter Drop Down", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
    static Link ClearFiltersButton = new Link("Click Filter Button", byXPath("//a[text()='Clear Filters']"));
    static AngDropDown StuNumDropDown = new AngDropDown("Click Student Number Dropdown", byXPath("//th[2]/a/span"));
    static Button StuNumFilter = new Button("Click Stud Num Filter", byXPath("//span[.='Filter']"));
    static TextField value = new TextField("Enter Value", byXPath("//input[@title='Value']"));
    static Button FilterButton = new Button("Click Filter Button", byXPath("//button[text()='Filter']"));
    static Link StudentAccounts = new Link("Click on StudentAccounts", byXPath("//span[@class='k-link k-header k-state-selected']"));
	static Link ContactManager = new Link("Contact Manager", byXPath("//cns-panel-bar/ul/li[1]/span"));
	static Link Documents1 = new Link("Documents", byXPath("//span[text()='Documents']"));	
	static Link NewDocument = new Link("Click on NewDocuments", byXPath("//a[@id='studentDocumentsAddButton']"));
	static TextField Entermodule = new TextField("Click on ClickMadule", byXPath("//input[@name='studentDocModule_input']"));
	static Link SelectModule = new Link("select module", byXPath("(//span[text()='Admissions'])[1]"));
	static TextField EnterDocument = new TextField("Click on Document", byXPath("//input[@name='studentDocName_input']"));
	static Link SelectDocument = new Link("select module", byXPath("//span[@title='AATestOL']"));
	static Link SelectDocument1 = new Link("select module", byXPath("//span[@title='Admissions Document List']"));
	static TextField DocumentStatus = new TextField("Click on DocumentStatus", byXPath("//input[@name='studentDocStatus_input']"));
	static Link SelectDocumentStatus = new Link("select DocumentStatus", byXPath("//span[@title='CMC Sig Req']"));
	static Button SaveAndClose1 = new Button("Save and Close", byXPath("//a[@id='studentDocumentSaveAnCloseButton']"));
	static Link NewDocumentList = new Link("Click on NewDocumentsList", byXPath("(//a[@id='studentDocumentsAddButton'])[2]"));	
	static Button SaveAndClose3 = new Button("Save and Close", byXPath("//a[@id='studentDocumentListSaveAnCloseButton']"));
	static TextField SearchContactManager = new TextField("Search SearchContactManager", byXPath("//input[@placeholder='Search Configuration']"));
	static Link TaskTemplets = new Link("TaskTemplets", byXPath("//span[text()='Task Templates']"));
	static Button NewButton1 = new Button("New Residency Types ", byXPath("//a[@id='newButton']"));
	static TextField Description = new TextField("Search Description", byXPath("//input[@name='name']"));
	static TextField Code1 = new TextField("Search Code", byXPath("//input[@name='code']"));
	static TextField Catogery = new TextField("Search Catogery", byXPath("//input[@name='taskCategoryId_input']"));
	static Link SelCatogery = new Link("Select SelCatogery", byXPath("//span[@title='Career Services']"));
	static TextField EventType1 = new TextField("Search EventType1", byXPath("//input[@name='taskTypeId_input']"));
	static TextField SelEventType1 = new TextField("Select SelEventType1", byXPath("//span[@title='E-Mail To Employer']"));
	static TextField EmailSubject = new TextField("Select EmailSubject", byXPath("//input[@name='emailSubject']"));
	static Button SaveAndClose2 = new Button("Save and Close", byXPath("//button[@aria-label='Save & Close']"));
	static Link Employeer = new Link("Employeer", byXPath("//span[text()='Employers']"));
	static AngDropDown TeDropDown = new AngDropDown("Click Term Number Dropdown", byXPath("(//span[@class='k-icon k-i-more-vertical'])[2]"));  
	static Button TerNumFilter = new Button("Click Term Num Filter", byXPath("//span[.='Filter']"));
    static TextField Cvalue = new TextField("Enter Value", byXPath("(//input[@title='Value'])[3]"));
    static Button CFilterButton = new Button("Click Filter Button", byXPath("//button[@type='submit']"));
    static Link ClkEmpName = new Link("Click ClkEmpName", byXPath("//a[text()='Bookstore']"));
    //static Link Task = new Link("Click Task", byXPath("//div[@id='maincontent']/div/ui-view/cns-employer-detail/div/div/div[2]/aside/cns-tile-set/div/cns-tile[5]/div/div/div[2]"));
    static Link Task = new Link("Click Task", byXPath("//div[. = 'Tasks']"));
    static TextField TaskTemplet = new TextField("Enter TaskTemplet", byXPath("//input[@name='taskTemplateId_input']"));
    static Link SelTask = new Link("Click SelTask", byXPath("//span[@title='TASK1']"));
    static Link Student = new Link("Click on Student", byXPath("//div[@id='search_display_studentId']"));
	static TextField EnterStudent = new TextField("Enter Term", byXPath("//input[@id='search']"));
	static Checkbox SelectStudent = new Checkbox("Select Term", byXPath("//input[@aria-label='AAMODT, JAMIE']"));
	static Button Select = new Button("Select Button", byXPath("//button[text()='Select']"));
//	static Link AcademicRecords = new Link("Contact Manager", byXPath("//cns-panel-bar/ul[1]/li[3]/span"));
	static Link DegreeProgressAuditValue = new Link("DegreeProgressAudit", byXPath("//span[text()='Degree Progress Audit']"));
	static Link Communication = new Link("Click Communication ", byXPath("(//li[@id='RequiredCoursePanelItem0']/span/span)[1]"));
	static AngDropDown DegDropDown = new AngDropDown("Click DegDropDown", byXPath("(//a[@title='Column Settings'])[13]"));
    static TextField Cvalue1 = new TextField("Enter Value", byXPath("//input[@title='Value']"));
	static Link ClikCourseCode = new Link("Click ClikCourseCode ", byXPath("//td[text()='COM111']"));
	static Link Clikwaive = new Link("Click Clikwaive ", byXPath("(//a[text()='Waive'])[1]"));
	static Link Clikwaive1 = new Link("Click Clikwaive1 ", byXPath("//button[text()=' Waive ']"));
	static Link FilterDropDwon1 = new Link("Click Filter Drop Down", byXPath("//div[@id='listSettingsButton_wrapper']/a[2]"));
	static Link ClsFilterDropDwon = new Link("Click Filter Drop Down", byXPath("//li[1]/div[1]/cns-grid/div[1]/cns-grid-toolbar/cmc-common-toolbar/div/div[2]/a[2]"));
	static Link ClsClearFiltersButton = new Link("Click Filter Button", byXPath("//div//a[. = 'Clear Filters']"));	
	//--------Validation Message----
	Link DocScheduleMsg= new Link("Document Schedule Msg", byXPath("//span[text()='The Document Schedule records were successfully saved.']"));
	Link DocTypeMsg= new Link("Document Type Msg", byXPath("//span[text()='The Document Type records were successfully saved.']"));
	Link SubsidiaryMsg= new Link("Subsidiary Msg", byXPath("//span[text()='The Subsidiary records were successfully saved.']"));
	
	//Add Colleges Web elements
	static Link ClickColleges = new Link("Colleges", byXPath("//span[.='Colleges']"));
	static Link newButton = new Link("New", byXPath("//a[@id='newButton']"));
	static TextField CollegeName = new TextField("College Name", byXPath("//input[@id='name']"));
	static TextField CollegeCode = new TextField("College Code", byXPath("//input[@id='code']"));
	static TextField CollegeAddress = new TextField("College Address", byXPath("//input[@id='streetAddress']"));
	static TextField CollegeCity = new TextField("College City", byXPath("//input[@id='city']"));
	static TextField CollegeState = new TextField("College State", byXPath("//input[@name='state_input']"));
	static TextField CollegeCountry = new TextField("College Country", byXPath("//input[@name='countryId_input']"));
	static TextField CollegePhoneNumber = new TextField("College Phone Number", byXPath("//input[@id='phoneNumber']"));
	static TextField CollegeZipCode = new TextField("College Zip Code", byXPath("//input[@name='postalCode_input']"));

	//Add Course to a College
	static Button FilterDropDown = new Button("Filter Drop Down", byXPath("(//a[@class=\"k-button k-split-button-arrow\"])[1]"));
	static Link ClearFilter = new Link("Clear Filter", byXPath("//li[.='Clear Filters']"));
	static AngDropDown CollegeNameDropDown = new AngDropDown("College Name Drop Down", byXPath("//th[2]/a[1]/span"));
	static Link Filter = new Link("Filter", byXPath("//span[.='Filter']"));
	static TextField Collegevalue = new TextField("Value", byXPath("//input[@title='Value']"));
	static Button Filter1 = new Button("Filter Button", byXPath("//button[text()='Filter']"));
	static Link ClickCollege = new Link("College Name", byXPath("//a[.='New1']"));
	static Link NewCollegeCourse = new Link("New", byId("newButton_CollegeCourse"));
	static TextField CourseName = new TextField("CourseName", byId("courseName"));
	static TextField CourseCode = new TextField("CourseName", byId("courseCode"));
	static TextField CourseStartDate = new TextField("Course Start Date", byId("creditAcceptedBeginDate"));
	static TextField CourseEndDate = new TextField("Course End Date", byId("minGradeRequired"));
	static TextField CourseCredits = new TextField("Course Credits",byXPath("//input[1][@aria-label='Credits']"));
	static Button CourseSaveClose = new Button("Course Save and Close", byXPath("//button[.='Save & Close']"));
	//Method Implementation
	
	static String TDate = DatesUtil.getCurrentDatebyFormat("mm/dd/yyyy");
	static String TCode = AppendValue.apendString();  
	static String EmailSubject1 = AppendValue.apendString();
	static String Description1 = AppendValue.apendString();
	static TextField SearchConfiguration1 = new TextField("Search SearchContactManager", byXPath("//input[@placeholder='Search Configuration']"));
	static TextField TaskTemplettab = new TextField("Click TaskTemplet", byXPath("//input[@name='taskTemplateId_input']"));
	
	static String TaskCode = AppendValue.apendString();
	static String TaskName;
	
	//Enter Login Credential to Get into the Student's or Any Home Page
	public StudentConfigurationPage CreateResidencyType(StringHash data) throws Exception {
		waitForPageToLoad();
		wait(30);
		MenuButton.click();
		wait(2);
		Configuration.click();
		wait(2);
		SearchConfiguration.clearAndType(data.get("Search Name").toString());
		wait(2);
		ResidencyTypes.click();
		waitForPageToLoad();
		wait(2);
		NewButton.click();
		waitForPageToLoad();
		wait(2);
		//Name.clearAndType(data.get("Name").toString());
		Name.clearAndType(RstName);
		waitForPageToLoad();
		wait(2);
		//Code.clearAndType(data.get("Code").toString());
		Code.clearAndType(RstCode);
		waitForPageToLoad();
		wait(2);
		SaveAndClose.click();
		waitForPageToLoad();
		wait(3);
		return this;
    }
	
public StudentConfigurationPage CreateTaskTemplate(StringHash data) throws Exception{
		Link SelectingEventType1 = new Link("Selecting Event Type", byXPath("//span[. = '"+data.get("EventType")+"']"));
		//Campuses.sendKeys(StudentStudentPage.LastNameValue);
		
		waitForPageToLoad();
		SearchConfiguration.clearAndType(data.get("Component").toString());
		TaskTemplates.waitTillElementClickable();
		TaskTemplates.click();
		waitForPageToLoad();
		NewButton.click();
		waitForPageToLoad();
		wait(5);
		//Name.clearAndType(data.get("TaskTemplateName").toString());
		Name.clearAndType(TaskTempNameValue);
		wait(2);
		//Code.clearAndType(data.get("TaskTemplateCode").toString());
		Code.clearAndType(TaskTempCodeValue);
		wait(2);
		EventType.clearAndType(data.get("EventType").toString());;
		wait(2);
		SelectingEventType1.click();
		wait(2);
		SaveAndClose.waitTillElementClickable();
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(5);
		waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor();
		wait(2);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(5);
		Listdrpdwn.click();
		wait(2);
		Filteroption.click();
		wait(2);
		FilterValue.clearAndType(TaskTempNameValue);
		wait(2);
		Filterbutton.click();
		wait(2);
		String TaskTemplateName = Tablevalue.getText();
		System.out.println(TaskTemplateName);
		if(TaskTemplateName.equalsIgnoreCase(TaskTempNameValue))
		{
			System.out.println("Task template is matching");
		}else {
			System.out.println("Task template is not matching");
		}
		wait(1);
		
		return this;
	}
	
	public StudentConfigurationPage CreateTaskSchedule(StringHash data) throws Exception{
		Link SelectingScheduleFor1 = new Link("Selecting schedule for", byXPath("//span[. = '"+data.get("ScheduleFor")+"']"));
		Link SelectingTriggerWhen1= new Link("Selecting trigger when", byXPath("//span[. = '"+data.get("TriggerWhen")+"']"));
		Checkbox ChangestoName1 = new Checkbox("Selecting changes to status", byXPath("//input[@aria-label='"+data.get("TriggerChangesTo")+"']"));
		Link SelectingType1 = new Link("Selecting EventType", byXPath("//span[. = '"+data.get("Events")+"']"));
		Link SelectingTaskTemplate1 = new Link("Selecting TaskTemplate", byXPath("//div/div/div//span[. = '"+data.get("TaskTemplate")+"']"));
		Link SelectingAssignedTo1 = new Link("Selecting AssignedTo", byXPath("//span[. = '"+data.get("AssignedTo")+"']"));
		Link SelectingUnits1 = new Link("Selecting Units", byXPath("//li[. = '"+data.get("Units")+"']"));
		Link SelectingEvent1 = new Link("Selecting Event", byXPath("//span[. = '"+data.get("Event")+"']"));
		
		waitForPageToLoad();
		SearchConfiguration.clearAndType(data.get("Component").toString());
		TaskSchedules.waitTillElementClickable();
		TaskSchedules.click();
		wait(5);
		NewButton.waitTillElementClickable();
		NewButton.click();
		wait(10);
		//Name.clearAndType(data.get("TaskScheduleName").toString());
		Name.clearAndType(TaskSchNameValue);
		ScheduleTaskFor.clearAndType(data.get("ScheduleFor"));
		wait(3);
		//SelectingScheduleFor.waitTillElementFound();
		SelectingScheduleFor1.clickUsingJavaScriptExecutor();
		wait(2);
		//DocumentsList.clearAndType(data.get("DocumentsList"));
		//wait(3);
		//SelectingDocumentList.clickUsingJavaScriptExecutor();
		TriggerWhen.clearAndType(data.get("TriggerWhen").toString());
		wait(3);
		SelectingTriggerWhen1.clickUsingJavaScriptExecutor();
		TriggerChangesTo.click();
		SearchName.clearAndType(data.get("TriggerChangesTo"));
		wait(2);
		ChangestoName1.clickUsingJavaScriptExecutor();
		SelectButton.click();
		wait(2);
		//scrollPage(0, 300);
		TaskEventType.clearAndType(data.get("Events").toString());
		wait(1);
		SelectingType1.clickUsingJavaScriptExecutor();
		TaskTemplate.clearAndType(data.get("TaskTemplate").toString());
		wait(1);
		SelectingTaskTemplate1.clickUsingJavaScriptExecutor();
		//AssignTo.clickUsingJavaScriptExecutor();
		AssignedTo.clearAndType(data.get("AssignedTo").toString());
		wait(1);
		SelectingAssignedTo1.clickUsingJavaScriptExecutor();
		//wait(2);
		//AssignTo.clickUsingJavaScriptExecutor();
		//wait(1);
		scrollPage(0,500);
		wait(1);
		Units.clickUsingJavaScriptExecutor();
		//Units.sendKeys(data.get("Units").toString());
		wait(1);
		SelectingUnits1.clickUsingJavaScriptExecutor();
		Event.clearAndType(data.get("Event").toString());
		wait(1);
		SelectingEvent1.clickUsingJavaScriptExecutor();
		Thread.sleep(2000);
		SaveAndClose.click();
		waitForPageToLoad();
		wait(2);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(2);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(5);
		Listdrpdwn.click();
		wait(2);
		Filteroption.click();
		wait(2);
		FilterValue.clearAndType(TaskSchNameValue);
		wait(2);
		Filterbutton.click();
		wait(2);
		String TaskScheduleName = Tablevalue.getText();
		System.out.println(TaskScheduleName);
		if(TaskScheduleName.equalsIgnoreCase(TaskSchNameValue))
		{
			System.out.println("Task schedule is matching");
		}else {
			System.out.println("Task schedule is not matching");
		}
		wait(1);
		return null;
		
	}
	
	public StudentConfigurationPage CreateDocumetType(StringHash data) throws Exception{
	    Link SelectingModule1 = new Link("Selecting Module", byXPath("//li/span[text()='"+data.get("ModuleName")+"']"));
	    Link SelectingDocumentType1 = new Link("Selecting DocumentType", byXPath("//ul[@id='directionType_listbox']/li[1]/span"));
	    Checkbox SelectingCampus1 = new Checkbox("Selecting campus", byXPath("(//tr/td/input)[1]"));
	    TextField DocumentType = new TextField("DocumentType", byXPath("(//button[@aria-label='expand combobox']/span)[2]"));
	    driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
	    
		//wait(10);
		SearchConfiguration.clearAndType(data.get("Component").toString());
		wait(2);
		Documents.waitTillElementClickable();
		Documents.click();
		wait(3);
		NewButton.click();
		//waitForPageToLoad();
		//wait(15);
		Name.waitTillElementClickable();
		Name.clearAndType(DocNameValue);
		//Name.clearAndType(DocNameValue);
		//wait(1);
		Code.clearAndType(DocCodeValue);
		//Code.clearAndType(DocCodeValue);
		//wait(1);
		Module.sendKeys(data.get("ModuleName"));
		wait(3);
		SelectingModule1.click();
		String SelectedModule = SelectingModule1.getText();
		System.out.println(SelectedModule);
		TestReportsLog.log(LogStatus.INFO, "Selected value is "+SelectedModule);
		DocumentType.click();
		SelectingDocumentType1.clickUsingJavaScriptExecutor();
		String SelectedDocType = SelectingDocumentType1.getText();
		System.out.println(SelectedDocType);
		TestReportsLog.log(LogStatus.INFO, "Selected value is "+SelectedDocType);
		//Campuses.clickUsingJavaScriptExecutor();---this is used for DTS
		CampusesGroup.clickUsingJavaScriptExecutor();
		//wait(2);
		//SearchName.clearAndType(data.get("CampusGroup").toString());
		wait(2);
		SelectingCampus1.click();
		String SelectedCampus = SelectingCampus1.getAttribute("aria-label");
		System.out.println(SelectedCampus);
		TestReportsLog.log(LogStatus.INFO, "Selected value is "+SelectedCampus);
		SelectButton.clickUsingJavaScriptExecutor();
		Thread.sleep(2000);
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(5);
		CustomAsserts.containsString(DocTypeMsg.getText(), data.get("DocTypeMsg").toString());
		//waitForPageToLoad();
//		Filtericon.clickUsingJavaScriptExecutor();
//		//wait(2);
//		ClearFilters.clickUsingJavaScriptExecutor();
//		//wait(5);
//		Listdrpdwn.click();
//		//wait(2);
//		Filteroption.click();
//		//wait(2);
//		FilterValue.clearAndType(DocNameValue);
//		//wait(2);
//		Filterbutton.click();
//		//wait(2);
//		String DocumentTypeName = Tablevalue.getText();
//		System.out.println(DocumentTypeName);
//		if(DocumentTypeName.equalsIgnoreCase(DocNameValue))
//		{
//			System.out.println("Document type is matching");
//		}else {
//			System.out.println("Document type is not matching");
//		}
		wait(1);
		return this;
	}
   
	public StudentConfigurationPage CreateDocumetSchedule(StringHash data) throws Exception{
	    Link SelectingSearchCriteria1 = new Link("Selecting Search Criteria", byXPath("//div[@id='schedDocSchedCriteriaItem']/div/ul/li[1]/div/span"));
	    Checkbox DependentStatus1 = new Checkbox("Dependent status", byXPath("//div[@id='searchModel_searchgrid}']//tr[1]/td[1]//input"));
	    Checkbox SelectingDocument1 = new Checkbox("Selecting document", byXPath("//div[@id='$ctrl.cmcId}']/div[2]//tr[1]/td[1]/input"));
	    driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
	   
		//wait(10);
		SearchConfiguration.clearAndType(data.get("Component").toString());
		wait(5);
		DocumentSchedules.waitTillElementClickable();
		DocumentSchedules.click();
		wait(3);
		NewButton.click();
		waitForPageToLoad();
		//wait(2);
		Name.clearAndType(DocSchNameValue);
		//Name.clearAndType(DocSchNameValue);
		//wait(2);
		scrollPage(0, 500);
		//wait(2);
		ScheduleCriteria.click();
		//SearchCriteria.clearAndType(data.get("Status").toString());
		SelectingSearchCriteria1.click();
		String SelectedCriteria = SelectingSearchCriteria1.getText();
		System.out.println(SelectedCriteria);
		TestReportsLog.log(LogStatus.INFO, "Selected value is "+SelectedCriteria);
		Arrowmark.clickUsingJavaScriptExecutor();
		Value.clickUsingJavaScriptExecutor();
		//SearchName.clearAndType(data.get("DependentStatus").toString());
		DependentStatus1.clickUsingJavaScriptExecutor();
		String SelectedDocumentStatus = DependentStatus1.getAttribute("aria-label");
		System.out.println(SelectedDocumentStatus);
		TestReportsLog.log(LogStatus.INFO, "Selected value is "+SelectedDocumentStatus);
		SelectButton.clickUsingJavaScriptExecutor();
		//wait(2);
		ScheduleCriteria.clickUsingJavaScriptExecutor();
		//wait(2);
		DocumentCriteria.clickUsingJavaScriptExecutor();
		//wait(3);
		AddDocument.clickUsingJavaScriptExecutor();
		//SearchName.clearAndType(data.get("DocumentType").toString());
		wait(2);
		SelectingDocument1.clickUsingJavaScriptExecutor();
		String SelectedDocument = SelectingDocument1.getAttribute("aria-label");
		System.out.println(SelectedDocument);
		TestReportsLog.log(LogStatus.INFO, "Selected value is "+SelectedDocument);
		//wait(2);
		SelectButton.clickUsingJavaScriptExecutor();
		wait(2);
		SaveAndClose.clickUsingJavaScriptExecutor();
		//waitForPageToLoad();
		wait(5);
		CustomAsserts.containsString(DocScheduleMsg.getText(), data.get("DocScheduleMsg").toString());
//		Filtericon.clickUsingJavaScriptExecutor();
//		wait(2);
//		ClearFilters.clickUsingJavaScriptExecutor();
//		wait(2);
//		Listdrpdwn.click();
//		wait(2);
//		Filteroption.click();
//		wait(2);
//		FilterValue.clearAndType(DocSchNameValue);
//		wait(2);
//		Filterbutton.click();
//		wait(2);
//		String DocumentschName = Tablevalue.getText();
//		System.out.println(DocumentschName);
//		if(DocumentschName.equalsIgnoreCase(DocSchNameValue))
//		{
//			System.out.println("Document schedule is matching");
//		}else {
//			System.out.println("Document schedule is not matching");
//		}
		System.out.println("Document is scheduled successfully");
		
		return this;
	}

	public StudentConfigurationPage CreateSubsidiary(StringHash data) throws Exception {
		Checkbox SelectingCode = new Checkbox("Selecting Code", byXPath("(//td[@role='gridcell']/input)[1]"));
	    driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
	   
	    //wait(10);
		SearchConfiguration.clearAndType(data.get("Component").toString());
		wait(2);
		Subsidiaries.click();
		//waitForPageToLoad();
		wait(3);
		NewButton.click();
		waitForPageToLoad();
		//wait(22);
		Name.clearAndType(SubNameValue);
		//wait(2);
		Code.clearAndType(SubCodeValue);
		//wait(2);
		scrollPage(0, 300);
		//wait(2);
		TransactionCodes.click();
		//wait(2);
		//SearchCode.clearAndType(data.get("TransactionCode"));
		//wait(2);
		SelectingCode.click();
		String SelectedCode = SelectingCode.getAttribute("aria-label");
		System.out.println(SelectedCode);
		TestReportsLog.log(LogStatus.INFO, "Selected value is "+SelectedCode);
		//wait(1);
		SelectCode.click();
		//wait(2);
		scrollPage(0, -300);
		//wait(2);
		SaveAndClose.click();
		wait(5);
		CustomAsserts.containsString(SubsidiaryMsg.getText(), data.get("SubsidiaryMsg").toString());
//		Filtericon.clickUsingJavaScriptExecutor();
//		wait(2);
//		ClearFilters.clickUsingJavaScriptExecutor();
//		wait(2);
//		Namedrpdwn.click();
//		wait(2);
//		Filteroption.click();
//		wait(2);
//		FilterValue.clearAndType(SubNameValue);
//		wait(2);
//		Filterbutton.click();
//		wait(2);
//		String SubName = Tablevalue.getText();
//		System.out.println(SubName);
//		if(SubName.equalsIgnoreCase(SubNameValue))
//		{
//			CustomAsserts.containsString(SubName, SubNameValue);
//			System.out.println("Subsidiary name is matching");
//		}else {
//			System.out.println("Subsidiary name is not matching");
//		}
		wait(1);
		return this;
   }
  
public StudentConfigurationPage AddSMSServiceProvider(StringHash data) throws Exception{
	   
	   Link SMSProvidersSpan = new Link("SMSProvidersSpan", byXPath("//span[. = 'SMS Service Providers']"));
	   Link New = new Link("New", byCSSSelector("#newButton")); 
	   TextField Name = new TextField("Name", byCSSSelector("#name"));
	   TextField Code = new TextField("Code", byCSSSelector("#code"));
	   TextField DomainName = new TextField("DomainName", byCSSSelector("#domainName"));
	   TextField MaxLength = new TextField("MaxLength", byCSSSelector("#maximumMessageLength"));
	   Button Save = new Button("Save", byXPath("//button[@aria-label='Save & Close']"));
	   Link SMSProvidersSaveMessage = new Link("SMSProvidersSaveMessage", byXPath("//span[. = 'The Sms Service Provider records were successfully saved.']"));
	   
	    int MaxLengthValue = AppendValue.apendShortNumber();
	    String DomainNameValue = AppendValue.apendString();
	    
	    
		
		waitForPageToLoad();
		SearchConfiguration.click();
		SearchConfiguration.clearAndType("SMS Service Providers");
		wait(3);
		SMSProvidersSpan.click();
		waitForPageToLoad();
		New.click();
		waitForPageToLoad();
		scrollPage(0,300);
		Name.click();
		wait(2);
		Name.clearAndType(SMSNameValue.toString());
		wait(2);
		Code.click();
		wait(2);
		Code.clearAndType(SMSCodeValue.toString());
		wait(2);
		DomainName.click();
		wait(2);
		DomainName.clearAndType(DomainNameValue.toString());
		wait(2);
		MaxLength.click();
		wait(2);
		MaxLength.sendKeys(String.valueOf(MaxLengthValue));
		TestReportsLog.log(LogStatus.INFO, "Max length is entered as "+MaxLengthValue);
		wait(2);
		Save.click();
		wait(8);
		CustomAsserts.containsString(SMSProvidersSaveMessage.getText(), data.get("SuccessMessage").toString());
		System.out.println("SMS service provided is created successfully");
		return this;
	}	
   
  
 public StudentConfigurationPage AddNewEmployer(StringHash data) throws Exception{

	   
	   Link EmployersSpan = new Link("EmployersSpan", byXPath("//span[. = 'Employers']"));
	   Link New = new Link("New", byCSSSelector("#newButton")); 
	   TextField EmployerName = new TextField("EmployerName", byCSSSelector("#employerName"));
	   TextField EmployerCode = new TextField("EmployerCode", byXPath("//input[@id='employerCode']"));
	   TextField EMailAddress = new TextField("EMailAddress", byCSSSelector("#employerEmailAddress"));
	   TextField StreetAdress = new TextField("StreetAdress", byCSSSelector("#streetAddress"));
	   TextField City = new TextField("City", byCSSSelector("#city"));
	   TextField PIN = new TextField("PIN", byXPath("(//input[@aria-label='Postal Index Number'])[1]"));
	   TextField PhoneNum = new TextField("PhoneNum", byCSSSelector("#phoneNumber"));
	   TextField EmployeeExtension = new TextField("EmployeeExtension", byCSSSelector("#employeExtension"));
	   Button Save = new Button("Save", byXPath("//button[@aria-label='Save & Close']"));
	   Link EmployerSuccessMessage = new Link("EmployerSuccessMessage", byXPath("//span[. = 'The Employer records were successfully saved.']"));
	   //String EmployerNameValue = AppendValue.apendString();
	   //String EmailAddressValue = AppendValue.apendString();
	  // String EmployerNameValue = AppendValue.apendString();
	  // String EmailAddressValue = AppendValue.apendString();
	   int PhoneNumValue = AppendValue.apendNumber();
	   int ExtensionValue = AppendValue.apendNumber();
	   
		waitForPageToLoad();
		SearchConfiguration.click();
		SearchConfiguration.clearAndType("Employers");
		wait(3);
		EmployersSpan.click();
		waitForPageToLoad();
		New.click();
		waitForPageToLoad();
		EmployerName.click();
		wait(3);
		EmployerName.clearAndType(EmployerNameValue.toString());
		wait(3);
		//EmployerCode.click();
		wait(3);
		//EmployerCode.clearAndType(EmployerCodeValue.toString());
		wait(2);
		scrollPage(0,300);
		EMailAddress.click();
		wait(3);
		EMailAddress.clearAndType(EmailAddressValue+"@SIS.com".toString());
		StreetAdress.click();
		wait(2);
		StreetAdress.clearAndType(data.get("StreetAdress").toString());
		wait(2);
		City.click();
		wait(3);
		City.clearAndType(data.get("City").toString());
		//wait(2);
		//PIN.click();
		wait(4);
		//PIN.
		//PIN.type("12345");
		//PIN.clearAndType(data.get("PIN").toString());
		//wait(2);
		scrollPage(0,100);
		PhoneNum.click();
		wait(3);
		//JavascriptExecutor js = JavaScriptExecutor(driver);
		//js.executeScript(document.getElementById('phoneNumber').value='testuser');
		PhoneNum.sendKeys(String.valueOf(PhoneNumValue));
		TestReportsLog.log(LogStatus.INFO, "Phone num is entered as "+PhoneNumValue);
		//PhoneNum.type(data.get("PhoneNum").toString());
		//PhoneNum.clearAndType(data.get("PhoneNum").toString());
		scrollPage(0,200);
		EmployeeExtension.click();
		wait(3);
		//EmployeeExtension.clearAndType(data.get("EmployeeExtension").toString());
		EmployeeExtension.sendKeys(String.valueOf(ExtensionValue));
		TestReportsLog.log(LogStatus.INFO, "Employee extension is entered as "+ExtensionValue);
		scrollPage(0,-700);
		Save.clickUsingJavaScriptExecutor();
		wait(7);
		CustomAsserts.containsString(EmployerSuccessMessage.getText(), data.get("EmployerSuccessMessage").toString());	
		System.out.println("Employer is added successfully");
		return this;
	}	


 public StudentConfigurationPage ConfigurePromissoryNote(StringHash data) throws Exception{
	   
	   
	   Link FundSourcesSpan = new Link("FundSourcesSpan", byXPath("//span[. = 'Fund Sources']"));
	   Link CodeSpan = new Link("CodeSpan", byXPath("//a[@title='Code edit column settings']"));
	   Button FilterOptions = new Button("FilterOptions", byXPath("//span[text()='Filter']"));
	   TextField Value = new TextField("Value", byXPath("//input[@title='Value']"));
	   Button Filter = new Button("Filter", byXPath("//button[. = 'Filter']"));
	   Link PaymentTypeLink = new Link("PaymentTypeLink", byXPath("//a[. = '"+data.get("PaymentType")+"']"));
	   Link RulesAndAttributesCollapse = new Link("RulesAndAttributesCollapse", byXPath("//a[contains(text(),'Rules and Attributes')]"));
	   Link PromissoryNote = new Link("PromissoryNote", byXPath("//input[@id='isPromissoryNoteAllowed']"));
	   Button Save = new Button("Save", byXPath("//button[@aria-label='Save']"));
	   Link FundSourceSuccessMessage = new Link("FundSourceSuccessMessage", byXPath("//span[. = 'The Fund Source records were successfully saved.']"));
	   Dropbox CampusDropdown = new Dropbox("Campus Dropdown", byXPath("//button[@aria-label='Settings']/span"));
	   Link CampusName = new Link("Campus", byXPath("//span[text()='Reset to Default']"));
 
		waitForPageToLoad();
		SearchConfiguration.click();
		SearchConfiguration.clearAndType("Fund Sources");
		wait(2);
		FundSourcesSpan.click();
		wait(20);
		CampusDropdown.click();
		wait(2);
		CampusName.click();
		wait(4);
		CodeSpan.click();
		wait(2);
		FilterOptions.click();
		wait(2);
		Value.click();
		Value.clearAndType(data.get("FundSource").toString());
		wait(2);
		Filter.click();
		wait(5);
		PaymentTypeLink.click();
		wait(20);
		scrollPage(0,1000);
		wait(2);
		RulesAndAttributesCollapse.click();
		scrollPage(0,500);
		wait(5);
		if(PromissoryNote.isSelected())			
		{
			System.out.println("Promissory Note is already selected");
		}else {
			PromissoryNote.clickUsingJavaScriptExecutor();
			//System.out.println("Task template is not matching");
		}
		wait(3);
		scrollPage(0,-900);
		Save.click();
		wait(5);
		CustomAsserts.containsString(FundSourceSuccessMessage.getText(), data.get("FundSourceSuccessMessage").toString());	
		return this;
	}	

   
 public StudentConfigurationPage ConfdocsschedCorrierService(StringHash data) throws Exception{
	    
	    
	 	Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
	 	Link SelectModule = new Link("select module", byXPath("(//span[text()='"+data.get("Module Name")+"'])[1]"));
	 	Link SelectDocument = new Link("select module", byXPath("//span[@title='"+data.get("Document Name")+"']"));
	 	Link SelectDocumentStatus = new Link("select DocumentStatus", byXPath("//span[@title='"+data.get("Document Status")+"']"));
	 	Link SelectDocument1 = new Link("select module", byXPath("//span[@title='"+data.get("Document List")+"']"));
		//Login Page Web Elements
		//waitForPageToLoad();
		//MenuButton.click();
		//wait(5);
		//Students.click();
		waitForPageToLoad();
		wait(15);
		FilterDropDwon.click();
		wait(2);
		ClearFiltersButton.click();
		waitForPageToLoad();
		wait(10);
		StuNumDropDown.click();
		waitForPageToLoad();
		wait(2);
		StuNumFilter.click();
		waitForPageToLoad();
		wait(2);
		value.clearAndType(data.get("Student Number"));
		waitForPageToLoad();
		wait(2);
		FilterButton.click();
		waitForPageToLoad();
		wait(5);
		ClickStudentName.click();
		waitForPageToLoad();
		wait(5);
		ContactManager.clickUsingJavaScriptExecutor();
		wait(5);
		Documents1.clickUsingJavaScriptExecutor();
		wait(5);
		NewDocument.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(5);
		Entermodule.clearAndType(data.get("Module Name").toString());
		wait(5);
		SelectModule.clickUsingJavaScriptExecutor();
		wait(5);
		EnterDocument.clearAndType(data.get("Document Name").toString());
		wait(5);
		SelectDocument.clickUsingJavaScriptExecutor();
		wait(5);
		DocumentStatus.clearAndType(data.get("Document Status").toString());
		wait(5);
		SelectDocumentStatus.clickUsingJavaScriptExecutor();
		wait(5);
		SaveAndClose1.clickUsingJavaScriptExecutor();
		wait(5);
		NewDocumentList.clickUsingJavaScriptExecutor();
		wait(2);
		scrollPage(0, 500);
		wait(5);
		/*Entermodule.clearAndType(data.get("Module Name").toString());
		wait(5);
		SelectModule.clickUsingJavaScriptExecutor();
		wait(5);*/
		EnterDocument.clearAndType(data.get("Document List").toString());
		wait(5);
		SelectDocument1.clickUsingJavaScriptExecutor();
		wait(5);
		DocumentStatus.clearAndType(data.get("Document Status").toString());
		wait(5);
		SelectDocumentStatus.clickUsingJavaScriptExecutor();
		wait(5);
		SaveAndClose3.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(5);
		return this;
}	
 
 
 public StudentConfigurationPage TskConfEmp(StringHash data) throws Exception{
	   
		//Login Page Web Elements
		waitForPageToLoad();
		wait(15);
		SearchContactManager.clearAndType(data.get("Search Name").toString());
		wait(3);
		TaskTemplets.clickUsingJavaScriptExecutor();
		wait(10);
		NewButton1.clickUsingJavaScriptExecutor();
		wait(10);
		Description.clearAndType(data.get("Description").toString());
		wait(5);
		Code1.clearAndType(data.get("Code").toString());
		wait(3);
		Catogery.clearAndType(data.get("Catogery").toString());
		wait(3);
		SelCatogery.clickUsingJavaScriptExecutor();
		wait(3);
		scrollPage(0, 200);
		wait(2);
		EventType1.clearAndType(data.get("Select EventType").toString());
		wait(3);
		SelEventType1.clickUsingJavaScriptExecutor();
		wait(3);
		EmailSubject.clearAndType(data.get("Email Subject").toString());
        wait(3);
		scrollPage(0, -200);
		wait(2);
		SaveAndClose2.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(7);
		return this;
	}
 
 
 public StudentConfigurationPage ConTskConfEmp(StringHash data) throws Exception{
	 
	//Login Page Web Elements
			waitForPageToLoad();
			wait(15);
			SearchContactManager.clearAndType(data.get("Search Name").toString());
			wait(3);
			Employeer.clickUsingJavaScriptExecutor();
			wait(10);
			Filtericon.clickUsingJavaScriptExecutor();
			wait(2);
			ClearFilters.clickUsingJavaScriptExecutor();
			wait(15);
			TeDropDown.click();
			wait(2);
			TerNumFilter.click();
			wait(2);
			value.clearAndType(data.get("Employer Name"));
			wait(3);
			CFilterButton.clickUsingJavaScriptExecutor();
			wait(5);
			ClkEmpName.clickUsingJavaScriptExecutor();
			wait(7);
			Task.clickUsingJavaScriptExecutor();
			wait(5);
			NewButton1.clickUsingJavaScriptExecutor();
			wait(5);
			TaskTemplet.clearAndType(data.get("Search TaskTemplet").toString());
			wait(5);
			SelTask.clickUsingJavaScriptExecutor();
			wait(5);
			Student.click();
			wait(5);
			EnterStudent.clearAndType(data.get("Student Name").toString());
			wait(5);
			SelectStudent.click();
			wait(5);	
			Select.click();
			wait(2);
			SaveAndClose2.clickUsingJavaScriptExecutor();
			waitForPageToLoad();
			wait(7);
		    return this;
	}	
 
 public StudentConfigurationPage DegreeProgressAudit(StringHash data) throws Exception{

		//X-path Parameterization
	 Link ClikCourseCode = new Link("Course Code", byXPath("(//td[text()='"+data.get("Course Code")+"'])[1]"));
		//			Link CourseRequierement = new Link("Course Requierement ", byXPath("//li[1]/span/span[2]"));
		//Link CourseRequierement = new Link("Course Requierement ", byXPath("//span[contains(text(),'General Education')]"));
		Link CourseRequierement = new Link("Course Requierement ", byXPath("//a[contains(text(),'Course Requirements')]"));
		//			Link AcademicRecords = new Link("Academic records", byXPath("//cns-panel-bar/ul[1]/li[3]/span"));
		Link AcademicRecords = new Link("Academic Records", byXPath("//a[@aria-label='Academic Records']"));
		Link StudentCourse = new Link("Student Course", byXPath("//span[. = 'Student Courses']"));
		Link DegreeProgressAuditValue = new Link("Degree Progress Audit", byXPath("//span[text()='Degree Progress Audit']"));
		Link ClsFilterDropDwon = new Link("settings", byXPath("//button[@id='n.courseDetail.gridId_cnsToolbar_kendoToolBar_settingsButton']"));
		//Link ClsClearFiltersButton = new Link("Clear Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
		//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//a[. = 'Reset to Default']"));
		Link ClsClearFiltersButton = new Link("reset to default", byXPath("(//li[@id='n.courseDetail.gridId_cnsToolbar_kendoToolBar_clearFiltersButton']/span)[3]"));
		AngDropDown DegDropDown = new AngDropDown("Course name filter", byXPath("(//a[@title='Course Name edit column settings'])[1]"));
		Link Clikwaive = new Link("waive ", byXPath("//button[@id='requiredCourseWaive0']"));
		Link Clikwaive1 = new Link("waive1 ", byXPath("//button[text()=' Waive ']"));
		Button TerNumFilter = new Button("Filter", byXPath("(//span[.='Filter'])[1]"));
		TextField value = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
		Button FilterButton = new Button("Filter", byXPath("//button/span[text()=\"Filter\"]"));
		Link Arrow = new Link("Arrow", byXPath("(//a[@aria-label='Expand'])[1]"));
		Link HighLight = new Link("Highlight", byXPath("(//tbody[1]/tr[1]/td[4])[3]"));
		//Link ProgramRequirements = new Link("Program Requirements", byXPath("//span[contains(text(),'Program Requirements')]"));
		Link ProgramRequirements = new Link("Program Requirements", byXPath("(//li[@id='RequiredCoursePanelItem0']/a/span)[2]"));
		Link GeneralStudies = new Link("General Studies", byXPath("//span[contains(text(),'General Studies')]"));


		//Method Implementation
		//waitForPageToLoad();
		AcademicRecords.waitTillElementClickable();
		AcademicRecords.click();
		wait(3);
		DegreeProgressAuditValue.click();
		wait(30);
		scrollPage(0, 500);
		wait(3);
//		CourseRequierement.click();
//		wait(5);
		ProgramRequirements.click();
		wait(5);
//		GeneralStudies.click();
//		wait(2);
		//ClsFilterDropDwon.click();
		wait(5);
		//ClsClearFiltersButton.click();
		wait(3);
		DegDropDown.clickUsingJavaScriptExecutor();
		wait(2);
		TerNumFilter.click();
		wait(2);
		value.clearAndType(data.get("Course Code"));
		wait(3);
		FilterButton.click();
		wait(5);
		ClikCourseCode.click();
		wait(5);
		if (Clikwaive.isDisplayed()) {
			Clikwaive.click();

		} else {
			Arrow.click();
			wait(2);
			HighLight.click();
			wait(2);
			Clikwaive.click();
		}
		wait(3);
		Clikwaive1.click();
		wait(5);
		System.out.println("Degree progress audit is edited successfully");
			return this;
		}
 
 
 public StudentConfigurationPage ConfirmDocumentCarrierServices(StringHash data) throws Exception{
	    
		//X-path Parameterization	  
		 	TextField Module = new TextField("Module", byXPath("//input[@name='studentDocModule_input']"));
			Link SelectModule = new Link("select module", byXPath("(//ul[@id='studentDocModule_listbox']/li/span/div/span)[1]"));
			Link SelectDocument = new Link("Select Document", byXPath("//ul[@id='studentDocName_listbox']/li[1]/span/div/span[1]"));
			Link SelectDocumentStatus = new Link("select Document Status", byXPath("//ul[@id='studentDocStatus_listbox']/li[1]/span/div/span[1]"));
			//Link SelectDocument1 = new Link("select module", byXPath("//span[@title='"+data.get("Document List")+"']"));
			Link SelectModule1 = new Link("select module", byXPath("//ul[@id='studentDocModule_listbox']/li[1]/div/span[1]"));
			Link SelectDocumentStatus1 = new Link("select Document Status", byXPath("//ul[@id='studentDocStatus_listbox']/li[1]/div/span[1]"));
			//Link ConfirmDocsSchedCorrierServiceSaveMessage = new Link("Confirm Docs Schedule Carrier Service SaveMessage", byXPath("//span[. = 'The Document records were successfully saved.']"));			
			//Link SelectingModule= new Link(data.get("ModuleName"), byXPath("(//span[text()='"+data.get("ModuleName")+"'])[1]"));
			//Link SelectingModule= new Link(data.get("Module Name"), byXPath("(//span[text()='"+data.get("ModuleName")+"'])[1]"));
			TextField Document = new TextField("Document", byXPath("(//button[@aria-label='expand combobox'])[6]"));
			TextField DocumentStatus = new TextField("Document Status", byXPath("(//button[@aria-label='expand combobox'])[7]"));
			Link ContactManager = new Link("Contact Manager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
			Link Documents1 = new Link("Documents", byXPath("//span[text()='Documents']"));	
			Link NewDocument = new Link("New Documents", byXPath("(//button[@id='studentDocumentsAddButton'])[1]"));
			Button SaveAndClose1 = new Button("Save and Close", byXPath("//button[@id='studentDocumentSaveAnCloseButton']"));
			Link NewDocumentList = new Link("New Documents List", byXPath("(//button[@id='studentDocumentsAddButton'])[2]"));
			TextField Entermodule = new TextField("Madule", byXPath("//input[@name='studentDocModule_input']"));
			Button SaveAndClose3 = new Button("Save and Close", byXPath("//button[@id='studentDocumentListSaveAnCloseButton']"));
			Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Document records were successfully saved.']"));
			Link ValidationMessage1 = new Link("Validation Message", byXPath("//span[. = 'The Document records were successfully saved.']"));
			
		//Method Implementation
			//waitForPageToLoad();
			ContactManager.waitTillElementClickable();
			ContactManager.click();
			wait(5);
			Documents1.click();
			wait(5);
			NewDocument.click();
			wait(12);
			Module.clearAndType(data.get("ModuleName").toString());
			wait(3);
			SelectModule.clickUsingJavaScriptExecutor();
			String SelectedModule = SelectModule.getAttribute("title");
			System.out.println(SelectedModule);
			TestReportsLog.log(LogStatus.INFO, "Module is Selected as "+SelectedModule);
			wait(2);
			Document.click();
			wait(2);
			SelectDocument.click();
			String SelectedDocumnt = SelectDocument.getAttribute("title");
		    TestReportsLog.log(LogStatus.INFO, "Document Name is selected as "+SelectedDocumnt);
			wait(4);
			DocumentStatus.click();
			wait(2);
			SelectDocumentStatus.click();
			String SelectedDocumentStats = SelectDocumentStatus.getAttribute("title");
		    TestReportsLog.log(LogStatus.INFO, "Document Status Name is selected as "+SelectedDocumentStats);
			wait(4);
			SaveAndClose1.click();
			wait(5);
			//CustomAsserts.containsString(ValidationMessage1.getText(), data.get("SuccessMessage1").toString());
			wait(2);
			NewDocumentList.click();
			wait(2);
			scrollPage(0, 500);
			wait(2);
			Module.clearAndType(data.get("ModuleName").toString());
			wait(2);
			SelectModule.click();
			String SelectedModule1 = SelectModule.getAttribute("title");
		    TestReportsLog.log(LogStatus.INFO, "Module is selected as "+SelectedModule1);
			wait(2);;
			DocumentStatus.click();
			wait(2);
			SelectDocumentStatus.click();
			String SelectedDocumentStatas = SelectDocumentStatus.getAttribute("title");
		    TestReportsLog.log(LogStatus.INFO, "Document Status Name is selected as "+SelectedDocumentStatas);
			wait(2);
			SaveAndClose3.click();
			wait(5);
			CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
			wait(2);
			return this;
			}
 
 
 public StudentConfigurationPage ConfirmTaskConfigurationForEmployee(StringHash data) throws Exception{

		//X-path Parameterization
		Link SelCatogery = new Link("Select SelCatogery", byXPath("//ul[@id='taskCategoryId_listbox']/li[1]/div/span[1]"));
		Link SelEventType1 = new Link("Select SelEventType1", byXPath("//ul[@id='taskTypeId_listbox']/li[1]/div/span[1]"));
		Link TaskConfigEmployeeSaveMessage = new Link("TaskConfigEmployeeSaveMessage", byXPath("//span[. = 'The Task Template records were successfully saved.']"));			
		Link EventType1 = new Link("Search EventType1", byXPath("//span[contains(@aria-controls,'taskTypeId')]/span"));
		//Method Implementation
        waitForPageToLoad();
		wait(20);
		SearchContactManager.clearAndType(data.get("Search Name").toString());
		wait(3);
		TaskTemplets.click();
		wait(10);
		NewButton1.click();
		wait(10);
		Description.clearAndType(data.get("Description").toString());
		wait(5);
		Code1.clearAndType(TCode);
		wait(3);
		Catogery.click();
		wait(5);
		SelCatogery.clickUsingJavaScriptExecutor();
		wait(3);
		String SelCatogey = SelCatogery.getAttribute("title");
	    TestReportsLog.log(LogStatus.INFO, "SelCatogeryName is selected as "+SelCatogey);
		wait(2);
		scrollPage(0, 500);
		wait(2);
		EventType1.click();
		wait(3);
		SelEventType1.click();
		wait(3);
		String SelEveentType1 = SelEventType1.getAttribute("title");
	    TestReportsLog.log(LogStatus.INFO, "SelEventType1Name is selected as "+SelEveentType1);
		wait(2);
		EmailSubject.clearAndType(EmailSubject1);
		wait(3);
		scrollPage(0, -200);
		wait(2);
		SaveAndClose2.click();
		wait(5);
		CustomAsserts.containsString(TaskConfigEmployeeSaveMessage.getText(), data.get("SuccessMessage").toString());
		wait(2);
		return this;
			}
      
 public StudentConfigurationPage ConfirmTaskConfigurationForEmployeeDropdown(StringHash data) throws Exception{

		//X-path Parameterization
			Link SelTask = new Link("Select Task", byXPath("//ul[@id='taskTemplateId_listbox']/li[1]/span/div/span[1]"));
			Checkbox SelectStudent = new Checkbox("Select Student", byXPath("//input[@aria-label='"+data.get("StudentName")+"']"));	
			Link ConfirmTskConfEmployeeDropdownSaveMessage = new Link("Confirm Task Employee Dropdown SaveMessage", byXPath("//span[. = 'The Task records were successfully saved.']"));			
			Link ClkEmpName = new Link("Employee Name", byXPath("//a[text()='"+data.get("Employer Name")+"']"));	
			TextField SearchConfiguration = new TextField("Search Task Templet", byXPath("//input[@placeholder='Search Configuration']"));
			Link ClearFilters= new Link("Clear Filters", byXPath("//span[text()='Reset to Default']"));
			Link Employers = new Link("Employers", byXPath("(//span[text()='Employers'])[1]"));
			Button Filtericon = new Button("Filter icon", byXPath("(//div[contains(@id,'cnsToolbar_kendoToolBar_settingsButton_wrapper')]/button)[2]"));
			AngDropDown TeDropDown = new AngDropDown("Click Term Number Dropdown", byXPath("//a[@title='Name edit column settings']"));  
			Button TerNumFilter = new Button("Click Term Num Filter", byXPath("(//span[text()='Filter'])[1]"));
		    TextField Cvalue = new TextField("Enter Value", byXPath("(//input[@title='Value'])[3]"));
		    Button CFilterButton = new Button("Click Filter Button", byXPath("(//span[text()='Filter'])[2]"));
		    TextField value = new TextField("Enter Value", byXPath("//input[@title='Value']"));
		    Link Student = new Link("Click on Student", byXPath("//div[@id='search_display_studentId']"));
			TextField EnterStudent = new TextField("Enter Term", byXPath("//input[@id='search']"));
			Link Task = new Link("Click Task", byXPath("//div[. = 'Tasks']"));
			Button NewButton1 = new Button("New Residency Types ", byXPath("//*[@id='newButton']"));
			Button Select = new Button("Select Button", byXPath("//button[text()='Select']"));
			Button SaveAndClose2 = new Button("Save and Close", byXPath("//button[@aria-label='Save & Close']"));
			TextField StudentSearch = new TextField("Student Search", byXPath("//input[@id='search']"));
			
			
		//Method Implementation
			waitForPageToLoad();
			SearchConfiguration.clearAndType("Employers");
			wait(3);
			Employers.click();
			wait(10);
			Filtericon.click();
			wait(2);
			ClearFilters.click();
		    wait(15);
			TeDropDown.click();
			wait(2);
			TerNumFilter.click();
			wait(2);
			value.clearAndType(data.get("Employer Name"));
			wait(3);
			CFilterButton.click();
			wait(5);
			ClkEmpName.click();
			wait(15);
			Task.click();
			wait(5);
			NewButton1.click();
			wait(12);
			TaskTemplet.clearAndType("HJSFE");
			wait(5);
			SelTask.click();
			wait(5);
			Student.click();
			wait(2);
			StudentSearch.clearAndType(data.get("StudentName"));
			wait(5);
			SelectStudent.click();
			wait(2);	
			Select.clickUsingJavaScriptExecutor();
			wait(2);
			SaveAndClose2.click();
			wait(5);
			CustomAsserts.containsString(ConfirmTskConfEmployeeDropdownSaveMessage.getText(), data.get("SuccessMessage").toString());
			wait(2);
			return this;
			}
 
 public StudentConfigurationPage AddCollegePage(StringHash data) throws Exception{
	 
	 	Link SuccessMessage = new Link("Validation Message", byXPath("//span[. = 'The College records were successfully saved.']"));
		String ClgName = AppendValue.apendString();
		String ClgCode = AppendValue.apendString();
	 
		SearchConfiguration.sendKeys("Colleges");
		ClickColleges.click();
		wait(10);
		newButton.click();
		wait(10);
		CollegeName.clearAndType(ClgName);
		wait(2);
		CollegeCode.clearAndType(ClgCode);
		wait(2);
		SaveAndClose.click();
		wait(5);
		CustomAsserts.containsString(SuccessMessage.getText(), data.get("SuccessMessage").toString());
		wait(2);
		return this;
		
          }
public StudentConfigurationPage AddCollegeCoursePage(StringHash data) throws Exception{
	 
	 Link SuccessMessage = new Link("Validation Message", byXPath("//span[. = 'The College Course records were successfully saved.']"));
	 Link ClickCollege = new Link(data.get("CollegeName"), byXPath("//a[.='"+data.get("CollegeName")+"']"));
	 String clgCourseName = AppendValue.apendString(); 
	 String clgCourseCode = AppendValue.apendString(); 
	 Link NewCollegeCourse = new Link("Click New", byXPath("//a[@id='newButton_CollegeCourse']"));
	 TextField GradeRequired = new TextField("Grade", byXPath("//input[@id='minGradeRequired']"));
	 
	 	waitForPageToComplete();
	 	wait(10);
		SearchConfiguration.sendKeys("Colleges");
		wait(2);
		ClickColleges.click();
		wait(10);
		FilterDropDown.click();
		wait(2);
		ClearFilter.click();
		wait(5);
		CollegeNameDropDown.click();
		wait(2);
		Filter.click();
		wait(2);
		Collegevalue.clearAndType(data.get("CollegeName"));
		wait(4);
		Filter1.click();
		wait(5);
		ClickCollege.click();
		wait(10);
		//CollegeZipCode.clearAndType(data.get("CollegeZipCode"));
		scrollPage(0, 1000);
		scrollPage(0, 300);
		wait(4);
		NewCollegeCourse.click();
		wait(5);
		CourseName.sendKeys(clgCourseName);
		System.out.println("Course Name is"+clgCourseName);
		wait(2);
		CourseCode.sendKeys(clgCourseCode);
		wait(2);
		System.out.println("Course Name is"+clgCourseCode);
		wait(2);
		CourseStartDate.clearAndType(TDate);
		wait(2);
		GradeRequired.clearAndType("C");
		wait(2);
		CourseSaveClose.click();
		wait(2);
		scrollPage(0, -1000);
		wait(5);
		CustomAsserts.containsString(SuccessMessage.getText(), data.get("SuccessMessage").toString());
		wait(2);
		SaveAndClose.click();
		wait(2);
		return this;
		
	}


public StudentConfigurationPage StudentTaskTemplateConfiguration(StringHash data) throws Exception{

	//X-path Parameterization
		Link SelCatogery = new Link("Select Catogery", byXPath("//ul[@id='taskCategoryId_listbox']/li[1]/span/div/span[1]"));
		Link SelEventType1 = new Link("Select EventType1", byXPath("(//ul[@id='taskTypeId_listbox']/li/span/div/span)[1]"));
		Link TaskConfigEmployeeSaveMessage = new Link("Task Config Employee SaveMessage", byXPath("//span[. = 'The Task Template records were successfully saved.']"));			
		TextField EventType1 = new TextField("Search EventType1", byXPath("//input[@name='taskTypeId_input']"));
		TextField SearchConfiguration = new TextField("Search Task Templet", byXPath("//input[@placeholder='Search Configuration']"));
		Link TaskTemplets = new Link("TaskTemplets", byXPath("//span[text()='Task Templates']"));
		Button NewButton1 = new Button("New Residency Types ", byXPath("//button[@id='newButton']"));
		TextField Description = new TextField("Search Description", byXPath("//input[@name='name']"));
		TextField Code1 = new TextField("Search Code", byXPath("//input[@name='code']"));
		TextField Catogery = new TextField("Search Catogery", byXPath("//input[@name='taskCategoryId_input']"));
		TextField EmailSubject = new TextField("Select EmailSubject", byXPath("//input[@name='emailSubject']"));
		Button SaveAndClose2 = new Button("Save and Close", byXPath("//button[@aria-label='Save & Close']"));
		
	//Method Implementation
        waitForPageToLoad();
        SearchConfiguration.clearAndType("Task Templates");
		wait(3);
		TaskTemplets.click();
		wait(10);
		NewButton1.click();
		wait(10);
		Description.clearAndType(Description1);
		TaskName=Description1;
		wait(5);
		Code1.clearAndType(TaskCode);
		wait(2);
		/*Catogery.click();
		wait(5);
		SelCatogery.clickUsingJavaScriptExecutor();
		wait(3);
		String SelCatogey = SelCatogery.getAttribute("title");
	    TestReportsLog.log(LogStatus.INFO, "SelCatogeryName is selected as "+SelCatogey);
		wait(2);*/
		scrollPage(0, 500);
		wait(2);
		EventType1.clearAndType("E-Mail To Employer");
		wait(3);
		SelEventType1.click();
		wait(3);
		String SelEveentType1 = SelEventType1.getAttribute("title");
	    TestReportsLog.log(LogStatus.INFO, "EventType Name is selected as "+SelEveentType1);
		wait(2);
		EmailSubject.clearAndType(EmailSubject1);
		wait(3);
		scrollPage(0, -200);
		wait(2);
		SaveAndClose2.click();
		wait(5);
		CustomAsserts.containsString(TaskConfigEmployeeSaveMessage.getText(), data.get("SuccessMessage").toString());
		wait(2);
		return this;
			}



public StudentConfigurationPage ConfirmTaskConfigurationStudentDropdown(StringHash data) throws Exception{
	
	 //X-path Parameterization
		Link ContactManager = new Link("Contact Manager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
		Link TasksSpan = new Link("Tasks", byXPath("//span[text()='Tasks']"));
		Button New = new Button("New", byXPath("//button[. = 'New']"));
		TextField TaskTemplateName = new TextField("Enter Task Template", byXPath("//input[@name='taskTemplateId_input']"));
		Link SelectTaskTemplate = new Link("Task Template", byXPath("//ul[@id='taskTemplateId_listbox']/li[1]/span/div/span[1]"));
		TextField Subject = new TextField("Subject", byCSSSelector("[name='subject']"));
		Button StatusSpan = new Button("Status Span", byXPath("//div[8]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		Button SaveAndClose = new Button("Save And Close", byXPath("//div[2]/cmc-toolbar/section/cmc-toolbar-button-save-close//button"));
		Link Employer = new Link("Select Employer", byXPath("//*[@id='search_display_employerId']"));
		Checkbox EmployerButton = new Checkbox("Select Employer Button", byXPath("(//input[@type='checkbox'])[2]"));
		Button Select = new Button("Select Button", byXPath("//button[text()='Select']"));
		//Link ConfirmTskConfStudentDropdownSaveMessage = new Link("Confirm Task Employee Dropdown SaveMessage", byXPath("//span[. = 'The Task records were successfully saved.']"));			
		Dropbox SubjectDropDown = new Dropbox("Subject Drop Down", byXPath("//a[@title='Subject edit column settings']"));
		//static Link SubjectDropDown = new Link("Drop Down", byXPath("(//a[@title=\"Column Settings\"])[1]"));
		Button SubjectFilter = new Button("Filter", byXPath("(//span[text()='Filter'])[1]"));
		TextField SubjectValue = new TextField("Value", byXPath("//input[@title='Value']"));
		Button SubjectFilterButton = new Button("Filter Button", byXPath("(//span[text()='Filter'])[2]"));
		TextField Status = new TextField("Status", byXPath("//tr/td[5]/span[1]"));
		Link TaskSpan = new Link("Task Span", byXPath("//tr/td[1]/a"));
		Dropbox Taskdropdown = new Dropbox("Dropdown", byXPath("//button[@aria-label='Settings']/span"));
		Link TaskClearFilter = new Link("Clear All",byXPath("//span[text()='Clear All']"));
		
	//Method Implementation
		waitForPageToLoad();
		ContactManager.click();
		wait(2);
		TasksSpan.click();
		wait(15);
		Taskdropdown.clickUsingJavaScriptExecutor();
		wait(4);
		TaskClearFilter.clickUsingJavaScriptExecutor();
		wait(5);
		SubjectDropDown.click();
		wait(2);
		SubjectFilter.click();
		wait(2);
		SubjectValue.clearAndType("AC - General Comment");
		wait(2);
		SubjectFilterButton.click();
		wait(8);
		String text = TaskSpan.getText();
		if(text.equals("AC - General Comment"))
		{
			System.out.println("Configured task available for student");	
			TestReportsLog.log(LogStatus.INFO, "Task "+Description1 +" is available for student");
		}
		else {
			System.out.println("Configured task available for student");
			TestReportsLog.log(LogStatus.INFO, "Task "+Description1 +" is not available for student");
		}
		TaskSpan.click();
		System.out.println("Configured task available for student");
//		New.click();
//		wait(25);
//		TaskTemplateName.clearAndType(Description1);
//		wait(2);
//		SelectTaskTemplate.click();
//		wait(5);
//		/*Subject.click();
//		scrollPage(0, 300);
//		StatusSpan.click();
//		wait(2);
//		Status.click();*/
//		Employer.click();
//		wait(3);
//		EmployerButton.click();
//		wait(2);
//		Select.clickUsingJavaScriptExecutor();
//		wait(2);
//		SaveAndClose.clickUsingJavaScriptExecutor();
//		wait(7);
		//CustomAsserts.containsString(ConfirmTskConfStudentDropdownSaveMessage.getText(), data.get("SuccessMessage").toString());
		//wait(5);
		return this;
	}

}
