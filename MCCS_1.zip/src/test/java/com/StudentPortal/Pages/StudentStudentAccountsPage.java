package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;
import static com.framework.elements.Locator.byName;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.DatesUtil;
import com.framework.util.Encrypt;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentStudentAccountsPage extends BasePage{
	
	//New Ledger Payment Elements
	
	static Button FilterDropDwon = new Button("Filter Drop Down", byXPath("(//a[@class=\"k-button k-split-button-arrow\"])[1]"));
	static Button ClearFiltersButton = new Button("Filter Button", byId("listClearFiltersButton"));
	static AngDropDown StuNumDropDown = new AngDropDown(" Student Number Dropdown", byXPath("//th[2]/a/span"));
	static Button StuNumFilter = new Button("Stud Num Filter", byXPath("//span[.=\"Filter\"]"));
	static TextField value = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
	static Button FilterButton = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));
	static Link StudentAccounts = new Link("Student Accounts", byXPath("//cns-panel-bar/ul/li[6]/a/span"));
	static Link LedgerCard = new Link("Ledger Card", byXPath("//span[text()='Ledger Card']"));
	static Link NewPaymentButton = new Link("New", byXPath("//button[@id='newPaymentButton']"));
	//static TextField Password = new TextField("Enter Password", byId("password"));
	static Button OkCashier = new Button("OK", byId("cashierIDCheckAuthenticate"));
	//static Button SelectCashPaymentType = new Button(" Cash Payment Type", byXPath("//li[.=\"Cash Payment\"]"));
	//static Button ScheduledFA = new Button(" Scheduled FA Payment Type", byXPath("//li[.=\"Scheduled FA Disbursements/Student Cash Payments\"]"));
	//static Button UnscheduledPayment = new Button(" Unscheduled Payment Payment Type", byXPath("//li[.=\"Unscheduled Payment\"]"));
	static Link ClickTermList = new Link("New", byId("search_display_termId"));
	static TextField EnterTerm = new TextField("Term", byId("search"));
    //Checkbox checkboxTerm = new Checkbox(" term", byXPath("//input[@aria-label='"+data.get("Term Code")+"']"));
	//static TextField SelectPaymentMethod = new TextField(" Payment Method", byXPath("//li[@class=\"k-item k-state-focused k-state-hover\"]"));
	static Button SelectButton = new Button("Select", byXPath("//button[.=\"Select\"]"));
	static TextField PaymentName = new TextField("Payment Name", byId("transactionName"));
	//static Button PaymentMethod = new Button("Payment Method", byXPath("//span[@aria-label=\"Payment Method: Dropdown\"]"));
	static Button PaymentMethod = new Button("Payment Method", byXPath("//span[contains(@aria-label,'Payment Method')]"));
	static TextField EnterPaymentMethod = new TextField("Payment Method", byXPath("//input[@aria-owns=\"paymentType_listbox\"]"));
	//static Button ClickPaymentMethod =  new Button(" Payment Method", byXPath("//li[.='"+data.get("Payment Method")+"']"));
	static Button BankAccount = new Button("Bank Account", byXPath("//span[@aria-owns=\"bankAccountId_listbox\"]"));
	static TextField SelectBankAccount = new TextField("Bank Account", byXPath("//input[@aria-owns=\"bankAccountId_listbox\"]"));
	//static Button SelectBankAccount = new Button(" Bank Account", byXPath("//span[.='"+data.get("Bank Name")+"']"));
	static Link ClickTermSpan = new Link("Term Span",byXPath("//div[@id=\"search_display_termId\"]"));
	static TextField EnterTermCode = new TextField("Term Code", byId("search"));
	static Link SelectTerm = new Link("Term Code", byXPath("//input[@aria-label=\"NANDA\"]"));	
	static Button Selecttab = new Button("Select", byXPath("//button[.=\"Select\"]"));
	//static Button CashPaymentCode = new Button("Cash Payment Code", byXPath("//span[@aria-label=\"Cash Payment Code: Dropdown\"]"));
	static Button CashPaymentCode = new Button("Cash Payment Code", byXPath("//span[contains(@aria-label,'Cash Payment Code')]"));
	static TextField EnterCashPaymentCode = new TextField(" Cash Payment Code", byXPath("//input[@aria-owns=\"transactionNameDropDown_listbox\"]"));
	//static Button CashDrawerSession = new Button("Cash Drawer Session", byXPath("//span[@aria-label=\"Cash Drawer Session: Dropdown\"]"));
	static Button CashDrawerSession = new Button("Cash Drawer Session", byXPath("//span[contains(@aria-label,'Cash Drawer Session')]"));
	//static TextField SelectCashDrawerSession = new TextField(" Cash Drawer Session", byXPath("//span[.="KHARRISON"]"));
	static TextField PaymentAmount = new TextField("Payment Amount", byXPath("//input[1][@aria-label=\"Amount\"]"));
	static TextField TransactionDate = new TextField("Transaction Amount", byId("transactionDate"));
	static Button PVDropDown = new Button("Program Drop down", byXPath("(//span[@class=\"caret\"])[1]"));
	//  New Ledger Charge Web elements	
	static Link charge = new Link("Charge Button", byXPath("(//span[text()='Charge'])[1]"));
	//static Dropbox ChargeAYSpan = new Dropbox("Academic Year Span", byXPath("//span[@aria-label=\"Academic Year: Dropdown\"]/span/span[2]/span"));
	static Dropbox ChargeAYSpan = new Dropbox("Academic Year Span", byXPath("//span[contains(@aria-label,'Academic Year')]/span/span[2]/span"));
	static Link BillCodeSpan = new Link("Bill Code Span", byXPath("//span[@aria-owns=\"billingTransactionCode_listbox\"]"));
	static TextField EnterBillCode = new TextField("Bill Code", byXPath("//input[@aria-owns=\"billingTransactionCode_listbox\"]"));
	static TextField EnterAmount = new TextField("Charge Amount", byXPath("//input[1][@aria-label=\"Amount\"]"));
	static TextField TransDate = new TextField("Trnasaction date", byId("transactionDate"));
	static Button SaveClose = new Button("Save and Close", byXPath("(//button[@aria-label=\"Save & Close\"])[2]"));	
	// New Ledger Refund Web elements	
	static Button ButtonRefundTab = new Button("Refund tab",byXPath("//button[.=\"Refunds\"]"));
	static Button RefundDropdown = new Button("Refund drop down", byXPath("//div[2]/a[@class=\"k-button k-split-button-arrow\"]"));
	static Button RefundFilter = new Button("Refund Filter", byXPath("//a[.=\"Clear Filters\"]"));
	static AngDropDown FSdropdown = new AngDropDown(" Fund Source drop down", byXPath("//a[@title=\"Fund Source edit column settings\"]"));
	static Button FSFilter = new Button("Filter", byXPath("//span[text()=\"Filter\"]"));
	static TextField FSValue = new TextField("value", byXPath("//input[@title=\"Value\"]"));
	static Button FSFilterButton = new Button("Filter Button", byXPath("//button[.=\"Filter\"]"));
	//static Button HighlightFundSource = new Button("HighLight Fund Source", byXPath("//td[.=\"Cash Payment from Student\"]"));
	static Button FSNext = new Button("Next",byXPath("//button[text()=\"Next\"]"));
	//static Dropbox RefundOption = new Dropbox("Refund Option", byXPath("//span[@aria-label=\"Refund Option: Dropdown\"]/span/span[2]/span"));
	static Dropbox RefundOption = new Dropbox("Refund Option", byXPath("(//span[@aria-label='select']/span)[5]"));
	static Button SelectRefundOption = new Button("Refund Option", byXPath("//li/span[.=\"Post Directly to Ledger Card (No Check Required)\"]"));
	//static Button AYSpan = new Button("Academic Year", byXPath("//span[@aria-label=\"Academic Year: Dropdown\"]"));
	static Button AYSpan = new Button("Academic Year", byXPath("//span[contains(@aria-label,'Academic Year')]"));
	static Button SelectAYSpan = new Button("AY Start Date", byXPath("//span[.=\"07/01/2022\"]"));
	static TextField EnterrefundTerm = new TextField("Term", byXPath("//input[@aria-label=\"termId\" and @aria-owns=\"termId_listbox\"]"));
	static TextField RefundDateSent = new TextField("Due Date", byName("dateSend"));
	static TextField RefundName = new TextField("Refund Name", byXPath("//input[@aria-label=\"Refund Name\"]"));
	//static Button ReturnMethod = new Button("Return Method", byXPath("//span[@aria-label=\"Return Method: Dropdown\"]"));
	static Button ReturnMethod = new Button("Return Method", byXPath("//span[contains(@aria-label,'Return Method')]"));
	static TextField EnterReturnMethod = new TextField("Return Method", byXPath("//input[@aria-owns=\"returnMethod_listbox\"]"));
	static TextField RefundAmount = new TextField("Refund", byXPath("//input[1][@aria-label=\"Amount\"]"));
	static Button RefundSaveClose = new Button("Save and Close", byXPath("(//button[@aria-label=\"Post/Schedule\"])[2]"));
	//static Button RefundBankAccount = new Button("Bank Account", byXPath("//span[@aria-label=\"Bank Account: Dropdown\"]"));
	static Button RefundBankAccount = new Button("Bank Account", byXPath("//span[contains(@aria-label,'Bank Account')]"));
	static TextField EnterRefundBankAccount = new TextField("Refund Bank Account", byXPath("//input[@aria-owns=\"bankAccountId_listbox\"]"));
	static TextField RefundTransactionDate = new TextField("Refund Transaction Date", byName("transactionDate"));
	
	//Stipend Schedule Web Elements
	static Link StipendSchedule = new Link("Stipend Schedule", byXPath("//span[.=\"Stipend Schedule\"]"));
	//static Button FAStudentAY = new Button("FA Student AY", byXPath("//span[@aria-label=\"FA Student AY: Dropdown\"]"));
	static Button FAStudentAY = new Button("FA Student AY", byXPath("//span[contains(@aria-label,'FA Student AY')]"));
	static TextField TotalAmount = new TextField("Total Amount", byXPath("//input[1][@aria-label=\"Total Amount\"]"));
	//static Button Status = new Button("Status", byXPath("//span[@aria-label=\"Status: Dropdown\"]"));
	static Button Status = new Button("Status", byXPath("//span[contains(@aria-label,'Status')]"));
	//static Button SelectApproved = new Button("Select Status", byXPath("//li[.=\"Approved\"]"));
	static TextField NoOfStipends = new TextField("Number of Stipends", byXPath("//input[1][@aria-label=\"Number of Stipends\"]"));
	static TextField FirstScheduledDate = new TextField("First Scheduled Date", byId("firstPaymentDate"));
	static Button Calculate = new Button("Calculate Button", byXPath("//button[@id='calculateScheduledStipendButton']"));
//	static Link SelectLinkFundSource = new Link("Select Fund Source", byXPath("//a[.='<Select>']"));
	static Button FundSourceSpan = new Button("Fund Source Span", byXPath("(//button[@aria-label=\"expand combobox\"])[2]"));
	static TextField EnterFundSource = new TextField("Fund Source", byXPath("//input[@aria-owns=\"fundSourceId_listbox\"]"));
	//static TextField EnterFundSource = new TextField(" Fund Source", byXPath("//input[@aria-owns=\"fundSourceId_listbox\"]"));
	//static Button SelectFundSource = new Button(" Fund source", byXPath("//span[.=\"Direct PLUS Loan\"]"));
	static TextField DateScheduled = new TextField("Date Scheduled", byName("scheduledDate"));
	static Button Ok = new Button("Ok", byId("scheduledStipendSaveButton"));
	static Button Save = new Button("Save", byXPath("(//button[@aria-label=\"Save\"])[2]"));
	static TextField StipendAmount = new TextField("Stipend Amount", byXPath("//input[1][@aria-label=\"Net Amount\"]"));
	static String TDate = DatesUtil.getCurrentDatebyFormat("M/dd/yyyy");
	//TC848_Post an FA Disbursement for a Student Web Elements
	static Button ScheduledDisburdementSpan = new Button("Scheduled Disbursement", byId("search_display_scheduledPaymentId"));
	static TextField EnterFundSourceName = new TextField("Fund Source", byId("search"));

	public StudentStudentAccountsPage newLedgerCharge(StringHash data) throws Exception {
		
		//Link AcademicYear = new Link(data.get("AYStartDate"), byXPath("//span[@title='"+data.get("AYStartDate")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Charge records were successfully saved.']"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Checkbox CheckTerm = new Checkbox("Term", byXPath("//tr[1]/td/input[1]"));
		//Dropbox BillCodeSpan = new Dropbox("Bill Code Dropdown", byXPath("//span[@aria-label=\"Bill Code: Dropdown\"]/span/span[2]/span"));
		Dropbox BillCodeSpan = new Dropbox("Bill Code Dropdown", byXPath("(//span[@aria-label=\"select\"])[6]"));
		Link BillCode = new Link("Bill Code", byXPath("//ul[@id=\"billingTransactionCode_listbox\"]/li[1]/span/div/span[2]"));
		
		//waitForPageToLoad();
		StudentAccounts.waitTillElementClickable();
		StudentAccounts.click();
		wait(3);
		LedgerCard.click();
		wait(25);
		charge.clickUsingJavaScriptExecutor();
		wait(25);
//		ChargeAYSpan.click();
//		wait(2);
//		AcademicYear.click();
//		wait(2);
		ClickTermSpan.clickUsingJavaScriptExecutor();
		wait(10);
		CheckTerm.check();
		wait(2);
		String TermValue = CheckTerm.getAttribute("aria-label");
		TestReportsLog.log(LogStatus.INFO, "Term Value is selected as "+TermValue);
		wait(2);
		Selecttab.click();
		wait(2);
		BillCodeSpan.click();
		wait(2);
		BillCode.click();
		String BillCodeValue = BillCode.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Term Value is selected as "+BillCodeValue);
		wait(2);
		EnterAmount.sendKeys("10");
		wait(2);
		//TransDate.clearAndType(data.get("TransactionDate"));
		//wait(2);
		scrollPage(0, -300);
		wait(2);
		SaveClose.click();
		wait(10);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(10);
		return this;
	}
	public StudentStudentAccountsPage NewLedgerRefund(StringHash data) throws Exception {
		
		Button HighlightFundSource = new Button(data.get("FundSourceName"), byXPath("(//td[.='"+data.get("FundSourceName")+"'])[1]"));
		//Button SelectAYSpan = new Button(data.get("AYStartDate"), byXPath("//span[.='"+data.get("AYStartDate")+"']"));
		//Button SelectTermCode = new Button(data.get("TermCode"), byXPath("//span[.='"+data.get("TermCode")+"']"));
		//Button SelectReturnMethod = new Button(data.get("ReturnMethod"), byXPath("//li[.='"+data.get("ReturnMethod")+"']"));
		//Button SelectRefundBA = new Button(data.get("BankAccount"), byXPath("//li/div/span[.='"+data.get("BankAccount")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Refund records were successfully saved.']"));
		Dropbox Termdropdown = new Dropbox("Term Dropdown", byXPath("(//button[@aria-label=\"expand combobox\"])[2]"));
		Link SelectTerm = new Link("Term", byXPath("//ul[@id=\"termId_listbox\"]/li[1]/span/div/span[1]"));
		//Dropbox RetunMethodDopdown = new Dropbox("Return Method Dropdown", byXPath("//span[@aria-label=\"Return Method: Dropdown\"]/span/span[2]/span"));
		Dropbox RetunMethodDopdown = new Dropbox("Return Method Dropdown", byXPath("//span[@aria-label='Return Method']/span[2]"));
		Link SelectReturnMethod = new Link("Return Method", byXPath("//ul[@id='returnMethod_listbox']/li[1]/span[1]"));
		//Dropbox BankAccountDropdown = new Dropbox("Bank Account Dropdown", byXPath("//span[@aria-label=\"Bank Account: Dropdown\"]/span/span[2]/span"));
		Dropbox BankAccountDropdown = new Dropbox("Bank Account Dropdown", byXPath("(//span[@aria-label='select'])[10]"));
		Link BankAccount = new Link("Bank Account", byXPath("//ul[@id=\"bankAccountId_listbox\"]/li[1]/span/div/span[1]"));
		Dropbox AYDropdown = new Dropbox("Academic Year Dropdown", byXPath("(//span[@aria-controls='academicYearSequence_listbox']/span/span)[2]"));
		Link SelectAY = new Link("Academic Year Start Date", byXPath("//ul[@id=\"academicYearSequence_listbox\"]/li[1]/span/div/span[2]"));
		
		
		//waitForPageToLoad();
		StudentAccounts.waitTillElementClickable();
		StudentAccounts.click();
		wait(3);
		LedgerCard.click();
		wait(30);
		ButtonRefundTab.clickUsingJavaScriptExecutor();
	    wait(15);
	    /*	RefundDropdown.waitTillElementClickable();
		RefundDropdown.click();
		wait(4);
		RefundFilter.click();
		wait(2);
	    */
	    scrollPage(0, 200);
	    wait(2);
		FSdropdown.clickUsingJavaScriptExecutor();
		wait(3);
		FSFilter.click();
		wait(3);
		FSValue.clearAndType(data.get("FundSourceName"));
		wait(3);
		FSFilterButton.click();
		wait(5);
		HighlightFundSource.clickUsingJavaScriptExecutor();
		wait(10);
		scrollPage(0, 250);
		wait(2);
		FSNext.click();
		wait(5);
		scrollPage(0, 400);
		wait(2);
		RefundOption.click();
		wait(2);
		SelectRefundOption.click();
		wait(2);
		//AYDropdown.click();
		wait(2);
		//SelectAY.clickUsingJavaScriptExecutor();
		wait(2);
		Termdropdown.click();
		wait(2);
		SelectTerm.click();
		String TermValue = SelectTerm.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Term is selected as " +TermValue);
    	wait(2);
		RefundDateSent.sendKeys(TDate);
		wait(2);
		scrollPage(0, 300);
		wait(2);
		RetunMethodDopdown.click();
		wait(2);
		SelectReturnMethod.click();
		String ReturnMethodValue = SelectReturnMethod.getText();
		System.out.println("Return Method "+ReturnMethodValue);
		TestReportsLog.log(LogStatus.INFO, "Return Method is selected as " +ReturnMethodValue);
    	wait(2);
    	BankAccountDropdown.click();
		wait(2);
		BankAccount.click();
//		String BankAccountValue = BankAccount.getAttribute("title");
//		TestReportsLog.log(LogStatus.INFO, "Bank Account is selected as " +BankAccountValue);
		wait(2);
		RefundAmount.sendKeys("1");
		wait(2);
		RefundSaveClose.clickUsingJavaScriptExecutor();
		wait(7);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(2);
		return this;
	}
	
	public StudentStudentAccountsPage ScheduleStipendPage(StringHash data) throws Exception {
		
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Stipend records were successfully saved.']"));
		//Dropbox StatusDropdown = new Dropbox("Status Drpdown", byXPath("//span[@aria-label=\"Status: Dropdown\"]/span/span[2]/span"));
		Dropbox StatusDropdown = new Dropbox("Status Drpdown", byXPath("(//span[@aria-label=\"select\"])[3]"));
		Link SelectStatus = new Link("Select Status", byXPath("//li[.=\"Approved\"]"));
		//Dropbox FundSourceDropdown = new Dropbox("Fund Source Dropdown", byXPath("//span[@aria-label=\"Fund Source: Dropdown\"]/span/span[2]/span"));
		Dropbox FundSourceDropdown = new Dropbox("Fund Source Dropdown", byXPath("//span[contains(@aria-label,'Fund Source')]/span/span[2]/span"));
		Link SelectFundSource = new Link("Fund Source", byXPath("//ul[@id=\"fundSourceId_listbox\"]/li[1]/span/div/span[1]"));
		Link SelectReturnMethod = new Link("SelectReturnMethod", byXPath("//ul[@id='returnMethod_listbox']/li[1]"));
		Link EnterReturnMethod = new Link("Return Method", byXPath("//span[@aria-controls='returnMethod_listbox']"));
		Link SelectLinkFundSource = new Link("Select Fund Source", byXPath("(//a[text()='CARES ACT'])[1]"));
		
		//waitForPageToLoad();
		StudentAccounts.waitTillElementClickable();
		StudentAccounts.click();
		wait(2);
		StipendSchedule.click();
		wait(25);
//		FAStudentAY.click();
//		wait(2);
//		SelectAwardYear.click();
//		wait(5);
		TotalAmount.sendKeys("100");
		wait(2);
		StatusDropdown.click();
		wait(2);
		SelectStatus.click();
		wait(2);
		String StipendStatus = SelectStatus.getText();
		TestReportsLog.log(LogStatus.INFO, "Stipend Status is selected as " +StipendStatus);
    	wait(2);
		NoOfStipends.sendKeys("1");
		wait(2);
//		FirstScheduledDate.clearAndType(data.get("FirstScheduledDate"));
//		wait(2);
		scrollPage(0, 500);
		wait(5);
		Calculate.waitTillElementClickable();
		Calculate.clickUsingJavaScriptExecutor();
		wait(7);
		SelectLinkFundSource.click();
		wait(20);
		FundSourceSpan.click();
		wait(4);
		SelectFundSource.click();
		String FundSourceValue = SelectFundSource.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Term Value is selected as " +FundSourceValue);
		wait(4);
		//DateScheduled.clearAndType(data.get("DateScheduled"));
		wait(2);
//		ReturnMethod.click();
//		wait(2);
//		EnterReturnMethod.click();
//		wait(2);
//		SelectReturnMethod.click();
//		wait(2);
//		StipendAmount.sendKeys("100");
		wait(2);
		Ok.click();
		wait(2);
		scrollPage(0, -500);
		wait(2);
		Save.click();
		wait(6);
		//CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(3);
		return this;
	}
	
public StudentStudentAccountsPage LedgerPaymentPage(StringHash data) throws Exception {
		
		Checkbox ReceiptPrint = new Checkbox("Print Checkbox", byXPath("//input[@id='isPrinted']"));
		Link SelectCashPaymentType = new Link("Payment Type", byXPath("//li[.=\"Cash Payment\"]"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Transaction records were successfully saved.']"));
		TextField CashierNo = new TextField("Cashier Number", byXPath("//input[@id='checkNumber']"));
		TextField EnterPassword = new TextField("Enter Password", byId("password"));
		String Password = Encrypt.decodeString(data.get("Password").toString());
		Dropbox PaymentTypeDropdown = new Dropbox("Payment Dropdown", byXPath("(//span[@aria-label=\"select\"])[3]"));
		Checkbox CheckTerm = new Checkbox("Term", byXPath("//tr[1]/td/input"));
		Dropbox CashPaymentCodeDropdown = new Dropbox("Cash Payment Code Dropdown", byXPath("(//span[@aria-label='select'])[6]"));
		Link SelectCashPaymentCode = new Link("Cash Payment Code", byXPath("//ul[@id=\"transactionNameDropDown_listbox\"]/li[1]/span[1]/div/span[1]"));
		//Dropbox PaymentMethodDropdown = new Dropbox("Payment Method Dropdown", byXPath("//span[@aria-label=\"Payment Method: Dropdown\"]/span/span[2]/span"));
		Dropbox PaymentMethodDropdown = new Dropbox("Payment Method Dropdown", byXPath("//span[contains(@aria-label,'Payment Method')]/span/span[2]/span"));
		Link PaymentMethod = new Link("Payment Method", byXPath("(//ul[@id=\"paymentType_listbox\"]/li[1])[1]"));
		TextField CheckNo = new TextField("Check Number",byXPath("//input[@aria-label=\"Check No\"]"));
		Link SelectCashDrawerSession = new Link("Cash Drawer Session", byXPath("//ul[@id=\"cashDrawerSessionId_listbox\"]/li[1]/div/span[2]"));
		Dropbox BankAccountDropdown = new Dropbox("Bank Account Dropdown", byXPath("(//span[@aria-label=\"select\"])[8]"));
		Link BankAccount = new Link("Bank Account", byXPath("//ul[@id='bankAccountId_listbox']/li[1]/span/div/span[1]"));
		
		//wait(20);
		StudentAccounts.waitTillElementClickable();
		StudentAccounts.click();
		wait(2);
		LedgerCard.click();
		wait(25);
		NewPaymentButton.clickUsingJavaScriptExecutor();
		wait(20);
//		EnterPassword.clearAndType(Password);
//		wait(2);
//		OkCashier.click();
		PaymentTypeDropdown.click();
		wait(2);
		SelectCashPaymentType.click();
		wait(2);
		//scrollPage(0, 500);
		ClickTermList.click();
		wait(2);
		CheckTerm.check();
		String TermValue = CheckTerm.getAttribute("aria-label");
		TestReportsLog.log(LogStatus.INFO, "Term Value is selected as " +TermValue);
		wait(2);
		Selecttab.click();
		wait(2);
		CashPaymentCodeDropdown.click();
		wait(2);
		SelectCashPaymentCode.click();
		String CashPaymentCodeValue = SelectCashPaymentCode.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Cash Payment Code Value is selected as " +CashPaymentCodeValue);
		wait(2);
//		PaymentMethodDropdown.click();
//		wait(2);
//		PaymentMethod.click();
//		String PaymentMethodValue = PaymentMethod.getText();
//		TestReportsLog.log(LogStatus.INFO, "Payment Method Value is selected as " +PaymentMethodValue);
//		wait(2);
		CheckNo.sendKeys("1234");
		wait(2);
		BankAccountDropdown.click();
		wait(2);
		BankAccount.click();
		String BankAccountValue = BankAccount.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Cash Drawer Value is selected as " +BankAccountValue);
		wait(2);
		PaymentAmount.sendKeys("100");
		wait(2);
//		TransactionDate.sendKeys(TDate);
//		TestReportsLog.log(LogStatus.INFO, "Transaction Date " +TDate);
//		wait(2);
//		if (ReceiptPrint.isSelected()) {
//			ReceiptPrint.uncheck();
//		}else {
//			ReceiptPrint.check();
//		}
//		wait(2);
		scrollPage(0, -500);
		SaveClose.click();
		wait(10);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
		
	}
	
public StudentStudentAccountsPage LedgerFADisbursementPage(StringHash data) throws Exception {
		
		Checkbox PrintReceipt = new Checkbox("Print Checkbox", byXPath("//input[@aria-label=\"Print Receipt\"]"));
		Dropbox SelectCashPaymentType = new Dropbox("Select Cash Payment Type", byXPath("//li[.=\"Scheduled FA Disbursements/Student Cash Payments\"]"));
		//Dropbox ClickPaymentMethod =  new Dropbox(data.get("PaymentMethod"), byXPath("//li[.='"+data.get("PaymentMethod")+"']"));
		Link SelectCashDrawerSession = new Link("Cash Drawer Session", byXPath("//ul[@id=\"cashDrawerSessionId_listbox\"]/li[1]/div/span[2]"));
		//Dropbox AcademicYear = new Dropbox(data.get("AYStartDate"), byXPath("//span[@title='"+data.get("AYStartDate")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Transaction records were successfully saved.']"));
		TextField EnterPassword = new TextField("Enter Password", byId("password"));
		String Password = Encrypt.decodeString(data.get("Password").toString());
		//Dropbox PaymentTypeDropdown = new Dropbox("Payment Dropdown", byXPath("//span[@aria-label=\"Payment Type: Dropdown\"]/span/span[2]/span"));
		Dropbox PaymentTypeDropdown = new Dropbox("Payment Dropdown", byXPath("(//span[@aria-label=\"select\"])[3]"));
		Link SelectPaymentType = new Link("Payment Type", byXPath("//li[.=\"Scheduled FA Disbursements/Student Cash Payments\"]/span"));
		Checkbox CheckFundSource = new Checkbox("Fundsource", byXPath("//tr[1]/td/input"));
		Checkbox SelectTerm = new Checkbox("Fundsource", byXPath("//tr[1]/td/input"));
		//Dropbox PaymentMethodDropdown = new Dropbox("Payment Method Dropdown", byXPath("//span[@aria-label=\"Payment Method: Dropdown\"]/span/span[2]/span"));
		Dropbox PaymentMethodDropdown = new Dropbox("Payment Method Dropdown", byXPath("//span[contains(@aria-label,'Payment Method')]"));
		Link PaymentMethod = new Link("Payment Method", byXPath("//ul[@id='paymentType_listbox']/li[1]/span"));
		TextField CheckNo = new TextField("Check Number",byXPath("//input[@aria-label=\"Check No\"]"));
		int CheckNumber = AppendValue.apendNumber();
		Dropbox AYear = new Dropbox("Academic year Dropdown", byXPath("//span[@aria-owns='academicYearSequence_listbox']"));
		Link SelectAYear = new Link("Ayear", byXPath("//span[text()='05/23/2022']"));
		Dropbox BankAccountDropdown = new Dropbox("Bank Account Dropdown", byXPath("(//span[@aria-label=\"select\"])[8]"));
		Link BankAccount = new Link("Bank Account", byXPath("//ul[@id=\"bankAccountId_listbox\"]/li[1]/span/div/span[1]"));
		TextField PaymentName = new TextField("PaymentName", byXPath("//input[@name='transactionName']"));
		TextField Amount = new TextField("Amount", byXPath("(//input[@aria-label='Amount'])[1]"));
		
		
		//wait(20);
		StudentAccounts.waitTillElementClickable();
		StudentAccounts.click();
		wait(2);
		LedgerCard.click();
		wait(25);
		NewPaymentButton.clickUsingJavaScriptExecutor();
		wait(20);
//		EnterPassword.clearAndType(Password.toString());
//		wait(2);
//		OkCashier.click();
		PaymentTypeDropdown.click();
		wait(2);
		SelectPaymentType.click();
		wait(2);
//		AYear.click();
//		wait(2);
//		SelectAYear.click();
//		wait(2);
		ScheduledDisburdementSpan.click();
		wait(10);
		CheckFundSource.check();
		String Fundsourcevalue = CheckFundSource.getText();
		TestReportsLog.log(LogStatus.INFO, "Fund Source Value is selected as " +Fundsourcevalue);
		wait(3);
		Selecttab.clickUsingJavaScriptExecutor();
		wait(5);
		scrollPage(0, 300);
		wait(2);
		ClickTermList.click();
		wait(2);
		SelectTerm.check();
		String TermValue = SelectTerm.getText();
		TestReportsLog.log(LogStatus.INFO, "Term Value is selected as " +TermValue);
		wait(2);
		Selecttab.clickUsingJavaScriptExecutor();
		wait(2);
		PaymentName.clearAndType("Student Payment");
		wait(2);
		PaymentMethodDropdown.click();
		wait(2);
		PaymentMethod.click();
		String PaymentMethodValue = PaymentMethod.getText();
		TestReportsLog.log(LogStatus.INFO, "Payment Method Value is selected as " +PaymentMethodValue);
		wait(2);
		BankAccountDropdown.click();
		wait(2);
		BankAccount.click();
		String BankAccountValue = BankAccount.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Cash Drawer Value is selected as " +BankAccountValue);
		wait(2);
		//CheckNo.sendKeys("1234");
		scrollPage(0, 100);
		Amount.sendKeys("5");
		wait(2);
		scrollPage(0, -300);
		wait(2);
//		TransactionDate.clearAndType(TDate);
//		wait(2);
//		if (PrintReceipt.isSelected()) {
//			PrintReceipt.check();
//		}
//		else
//			wait(2);
//		scrollPage(0, -500);
//		wait(2);
		SaveClose.click();
		wait(10);
		//CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;	
	}
}	
	

	
	

