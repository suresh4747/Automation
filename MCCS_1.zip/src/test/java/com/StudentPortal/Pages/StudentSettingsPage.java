package com.StudentPortal.Pages;

import org.apache.tools.ant.taskdefs.MacroDef.Text;
import org.openqa.selenium.By.ByXPath;
import static com.framework.elements.Locator.byXPath;

import java.util.concurrent.TimeUnit;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentSettingsPage extends BasePage {
	
	static String StatusNameValue = AppendValue.apendString();
	static String StatusCodeValue = AppendValue.apendString();
	static TextField SearchField = new TextField("Search Settings", byXPath("//input[@placeholder='Search Settings']"));
	static Link StatusChanges = new Link("Status changes", byXPath("//span[text()='Status Changes']"));
	static Button NewButton = new Button("New Status", byXPath("//button[@id='newButton']"));
	static TextField Name = new TextField("Status Name", byXPath("//input[@id='name']"));
	static TextField Code = new TextField("Status Code", byXPath("//input[@id='code']"));
	static TextField SystemStatusInput = new TextField("System Status",byXPath("//input[@name='SystemStatus_input']"));
	static Button SelectingSystemStatus = new Button("Selecting system status", byXPath("//li[. = 'New Lead']"));
	static TextField NSLDSStatusInput = new TextField("NSLDS Status",byXPath("//input[@name='NSLDSStatus_input']"));
	static TextField CampusGroupInput = new TextField("Campus Group",byXPath("//input[@name='campusGroupId_input']"));
	static Link SelectingCampus = new Link("Selecting Campus",byXPath("//li[. = 'DTS']"));
	static Button SaveAndClose = new Button("Save & CLose",byXPath("//button[@aria-label='Save & Close']"));
	static Button Filtericon = new Button("Filter icon", byXPath("(//div[1]/button[2])[2]"));
	static Link ClearFilters= new Link("Clear Filters", byXPath("//span[. = 'Reset to Default']"));
	static AngDropDown Statusnamedrpdwn= new AngDropDown("Column Settings Filters", byXPath("//th[2]/a/span"));
	static Button ApplFilterDropDown = new Button("Click Filter", byXPath("//span[text()=\"Filter\"]"));
	static Button Filteroption= new Button("Filteroption", byXPath("//span[text()='Filter']"));
	//static Link FilteroptionExpand= new Link("Filteroption expand", byXPath("//form/div/span[1]/span/span/span"));
	//static Link SelectingfilterOption= new Link("Selecting Filteroption", byXPath("//div/div/div//li[. = 'Contains']"));
	static TextField FilterValue = new TextField("Filter Value",byXPath("//input[@title='Value']"));
	static Button Filterbutton = new Button("Filter icon", byXPath("//button[. = 'Filter']"));
	static Link SchoolstatusName= new Link("Schoolstatus Name", byXPath("//td/a"));
	static Link FetchingName= new Link("Schoolstatus Name", byXPath("//td/a"));
	static Link GeneralSA = new Link("General Student Accounts", byXPath("(//span[text()='General'])[1]"));
	static Link SettingsList= new Link("Settings List", byXPath("//a[@title='Setting edit column settings']"));
	static Link SelectingApplyPayment= new Link("Selecting apply payment flag link", byXPath("//a[text()='Apply Payment Flag']"));
	//static Link ApplyPaymentFlag= new Link("Apply payment flag dropdown", byXPath("//span[@aria-label='Apply Payment Flag: Dropdown']"));
	static Link ApplyPaymentFlag= new Link("Apply payment flag dropdown", byXPath("//span[contains(@aria-label,'Apply Payment Flag')]"));
	static Button Save = new Button("Save",byXPath("(//button[text()='Save'])[1]"));
	static Link FetchingValue= new Link("Fetching Value", byXPath("(//tr[1]/td[2])[1]"));
	static Button SettingsFilter = new Button("Click Filter", byXPath("(//span[text()='Filter'])[1]"));
    static TextField SettingsValue = new TextField("Enter value", byXPath("//input[@title='Value']"));
    static Button SettingsFilterButton = new Button("Click Settings Filter", byXPath("//button[.=\"Filter\"]"));
    static Link DocumentPolicies = new Link("Document Policies", byXPath("//span[text()='Document Policies']"));
    static TextField Description = new TextField("Description", byXPath("//input[@id='name']"));
    //static Link Module= new Link("Module", byXPath("//span[@aria-label='Module: Dropdown']"));
    static Link Module= new Link("Module", byXPath("//span[contains(@aria-label,'Module')]"));
    static AngDropDown NameDrp= new AngDropDown("Name dropdown", byXPath("(//th/a/span)[1]"));
	static Link SettingsDropDown = new Link("Click Drop Down", byXPath("(//a[@title=\"Column Settings\"])[1]"));
	
	//Xpath for School defined fields
	static Link SchoolDFields = new Link("School Defined Fields", byXPath("//span[text()='School Defined Fields']"));
	static TextField NameSchl = new TextField("School field Name", byXPath("//input[@name='fieldDescription']"));
	static TextField CodeSchl = new TextField("School field Code", byXPath("//input[@aria-label='Code']"));
	static AngDropDown DataType= new AngDropDown("Data Type", byXPath("//span[@aria-owns='dataType_listbox']/span"));
	static Link SelectingDataType = new Link("Selecting data type", byXPath("//li[text()='Character']"));
	static AngDropDown TypeValidation= new AngDropDown("Type validation", byXPath("//span[@aria-owns='validationType_listbox']/span"));
	static Link SelectingValidType = new Link("Selecting validation type", byXPath("//li[text()='None']"));
	static TextField Length = new TextField("Length", byXPath("//input[@aria-label='Length'][1]"));
	static Checkbox SelectingView = new Checkbox("Selecting View Checkbox", byXPath("//input[@aria-label='Select All View']"));
	static Checkbox SelectingEdit = new Checkbox("Selecting Edit Checkbox", byXPath("//input[@aria-label='Select All Edit']"));
	
//Method implementation
	//Create new school status
	public StudentSettingsPage CreateSchoolStatus(StringHash data) throws Exception {
		Button SelectingSystemStatus1 = new Button("Selecting system status", byXPath("//li[. = '"+data.get("SystemStatus")+"']"));
		Link SelectingCampus1 = new Link("Selecting Campus",byXPath("//li[. = '"+data.get("CampusGroup")+"']"));
		
		waitForPageToLoad();
		SearchField.clearAndType(data.get("Component").toString());
		StatusChanges.waitTillElementClickable();
		StatusChanges.clickUsingJavaScriptExecutor();
		wait(10);
		NewButton.clickUsingJavaScriptExecutor();
		wait(2);
		Name.waitTillElementClickable();
		//StatusName.clearAndType(data.get("Statusname").toString());
		Name.clearAndType(StatusNameValue);
		wait(2);
		Code.clickUsingJavaScriptExecutor();
		//StatusCode.clearAndType(data.get("Statuscode").toString());
		Code.clearAndType(StatusCodeValue);
		SystemStatusInput.clearAndType(data.get("SystemStatus").toString());
		wait(2);
		SelectingSystemStatus1.clickUsingJavaScriptExecutor();
		CampusGroupInput.waitTillElementClickable();
		wait(2);
		CampusGroupInput.clearAndType(data.get("CampusGroup").toString());
		wait(1);
		SelectingCampus1.click();
		wait(3);
		scrollPage(0, -200);
		SaveAndClose.waitTillElementClickable();
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(2);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(5);
		Statusnamedrpdwn.click();
		wait(2);
		Filteroption.click();
		wait(2);
		FilterValue.clearAndType(StatusNameValue);
		wait(2);
		Filterbutton.click();
		wait(2);
		String SchoolStatusName = FetchingName.getText();
		System.out.println(SchoolStatusName);
		if(SchoolStatusName.equalsIgnoreCase(StatusNameValue))
		{
			System.out.println("School Status is matching");
		}else {
			System.out.println("School Status is not matching");
		}
		wait(1);
		return this;
	//End of Menu Button	
	}


	
	public StudentSettingsPage ConfigureApplyPayment(StringHash data) throws Exception {
		Link AppPaymentMsg= new Link("Apply Payment Msg", byXPath("//span[text()='The General settings were successfully saved.']"));
		Link SelectingFlag= new Link("Selecting apply payment flag", byXPath("//ul[@id='settingValueDrp_listbox']/li[2]/span"));
		
		waitForPageToLoad();
		//waitForPageToComplete();
		SearchField.clearAndType(data.get("Component").toString());
		wait(3);
		GeneralSA.clickUsingJavaScriptExecutor();
		wait(5);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(5);
        //SettingsList.clickUsingJavaScriptExecutor();
        //wait(2);
        //SettingsFilter.click();
        //wait(2);
        //SettingsValue.clearAndType("Apply Payment Flag");
        //wait(2);
        //SettingsFilterButton.click();
        wait(3);
		SelectingApplyPayment.clickUsingJavaScriptExecutor();
		wait(4);
		ApplyPaymentFlag.click();
		wait(1);
		SelectingFlag.clickUsingJavaScriptExecutor();
		String SelectedFlag = SelectingFlag.getText();
		System.out.println(SelectedFlag);
		TestReportsLog.log(LogStatus.INFO, "Selected Flag is "+SelectedFlag);
		//wait(2);
		Save.clickUsingJavaScriptExecutor();
		wait(2);
		CustomAsserts.containsString(AppPaymentMsg.getText(), data.get("AppPaymentMsg").toString());
		String SetValue =FetchingValue.getText();
		System.out.println(SetValue);
		if(SetValue.equalsIgnoreCase(SelectedFlag))
		{
			System.out.println("Changes are updated correctly");
		}else {
			System.out.println("Changes are not updated correctly");
		}
		return this;
		
	}

	public StudentSettingsPage ConfigureDocumentPolicy(StringHash data) throws Exception {
		Link SelectingModule= new Link(data.get("ModuleName"), byXPath("//span[text()='"+data.get("ModuleName")+"']"));	
		Link DocPolicyMsg= new Link("Document Policy Msg", byXPath("//span[text()='The Document Policy records were successfully saved.']"));
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
	
		//waitForPageToLoad();
		//waitForPageToComplete();
		SearchField.waitTillElementClickable();
		SearchField.click();
		wait(3);
		SearchField.clearAndType(data.get("Component").toString());
		wait(2);
		DocumentPolicies.clickUsingJavaScriptExecutor();
		wait(8);
		//waitForPageToLoad();
		Filtericon.clickUsingJavaScriptExecutor(); 
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(5);
        NewButton.click();
        wait(10);
        scrollPage(0, -500);
        wait(3);
        Name.clearAndType(StatusNameValue);
        wait(2);
        Code.clearAndType(StatusCodeValue);
        wait(2);
        Module.click();
        wait(2);
        SelectingModule.click();
        TestReportsLog.log(LogStatus.INFO, "Selected Module is "+data.get("ModuleName"));
        wait(2);
        scrollPage(0, -500);
        SaveAndClose.click();
        wait(7);
        CustomAsserts.containsString(DocPolicyMsg.getText(), data.get("DocPolicyMsg").toString());
//        Filtericon.clickUsingJavaScriptExecutor();
//		wait(1);
//		ClearFilters.clickUsingJavaScriptExecutor();
//		wait(5);
//		NameDrp.click();
//		wait(2);
//		Filteroption.click();
//		wait(2);
//		FilterValue.clearAndType(StatusNameValue);
//		wait(2);
//		Filterbutton.click();
//		wait(2);
//		String DocPolicyName = FetchingName.getText();
//		System.out.println(DocPolicyName);
//		if(DocPolicyName.equalsIgnoreCase(StatusNameValue))
//		{
//			System.out.println("Document Policy is matching");
//		}else {
//			System.out.println("Document Policy is not matching");
//		}
		wait(1);
		return this;
        
}
	
	public StudentSettingsPage ConfigureSchoolDefinedFields(StringHash data) throws Exception {
	
		Link SchlFieldMsg= new Link("School Defined Field Msg", byXPath("//span[text()='The School Defined Field records were successfully saved.']"));
		String FieldName = AppendValue.apendString();
		String FieldCode = AppendValue.apendString();
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
		 AngDropDown DataType= new AngDropDown("Data Type", byXPath("(//span[@aria-controls='dataType_listbox']/span/span)[2]"));
		 Link SelectingDataType = new Link("Selecting data type", byXPath("(//ul[@id='dataType_listbox']/li/span)[1]/font/font"));
		 AngDropDown TypeValidation= new AngDropDown("Type validation", byXPath("(//span[@aria-label='Type Validation']/span)[2]/span"));
		 Link SelectingValidType = new Link("Selecting validation type", byXPath("//span[text()='None']"));

		
		//waitForPageToComplete();
		SearchField.waitTillElementFound();
		SearchField.clearAndType(data.get("Component").toString());
		SchoolDFields.waitTillElementClickable();
		SchoolDFields.clickUsingJavaScriptExecutor();
		wait(4);
		//waitForPageToLoad();
		//Filtericon.waitTillElementClickable();
		//Filtericon.clickUsingJavaScriptExecutor();
	    //ClearFilters.waitTillElementClickable();
		//ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		NewButton.waitTillElementClickable();
		NewButton.click();
		wait(10);
		scrollPage(0, -500); 
		NameSchl.waitTillElementClickable();
		NameSchl.click();
		NameSchl.waitTillElementFound();
		NameSchl.clearAndType(FieldName);
		wait(1);
		CodeSchl.waitTillElementClickable();
		CodeSchl.click();
		wait(1);
		CodeSchl.waitTillElementFound();
		CodeSchl.clearAndType(FieldCode);
		wait(1);
		scrollPage(0, 500);
//		DataType.waitTillElementClickable();
//		DataType.clickUsingJavaScriptExecutor();
//	     SelectingDataType.waitTillElementClickable();
//		SelectingDataType.click();
//		wait(1);
//		TypeValidation.waitTillElementClickable();
//		TypeValidation.clickUsingJavaScriptExecutor();
//		SelectingValidType.waitTillElementClickable();
//		SelectingValidType.click();
		wait(6);
		//Length.waitTillElementFound();
		Length.sendkeys(data.get("Length"));
		wait(2);
		//SelectingView.clickUsingJavaScriptExecutor();
		//wait(2);
		SelectingEdit.waitTillElementClickable();
		SelectingEdit.clickUsingJavaScriptExecutor();
		scrollPage(0, -800);
		wait(2);
		SaveAndClose.waitTillElementClickable();
	    SaveAndClose.clickUsingJavaScriptExecutor();
		wait(5);
		CustomAsserts.containsString(SchlFieldMsg.getText(), data.get("SchlFieldMsg").toString());
		return this;
	}
}
	