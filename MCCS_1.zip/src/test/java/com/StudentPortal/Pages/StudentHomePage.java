package com.StudentPortal.Pages;

import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.interactions.ClickAction;
import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;
import static com.framework.elements.Locator.byLinkText;
import static com.framework.elements.Locator.byCSSSelector;
import java.util.ArrayList;
import java.util.List;
import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Label;
import com.framework.elements.Link;
import com.framework.elements.Table;
import com.framework.elements.TextField;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By.ByCssSelector;
import org.openqa.selenium.WebElement;
import com.framework.driver.DriverConfig;
import org.openqa.selenium.internal.FindsByCssSelector;

public class StudentHomePage extends BasePage{
	
	//Login Page Web Elements
	static Link MenuButton = new Link("Click Menu Button", byXPath("//button[@aria-label='Menu']/span"));
	static Link TasksButton = new Link("TasksButton", byXPath("(//a[@title='Tasks'])[1]"));
	//static Link TasksButton = new Link("TasksButton", byXPath("(//a[@title='Tasks'])[1]"));
	static Link Configuration = new Link("Click Configuration", byXPath("//a[@title=\"Configuration\"]"));
	//static Link Students = new Link("Click Students", byXPath("//a[@title=\"Students\"]"));
	static Link Processes =  new Link("Click Processes",byXPath("//a[@title=\"Processes\"]"));
	static Link  Menu = new Link("Main Menu", byXPath("//button[@aria-label='Menu']/span"));
	static Link subMenuConfiguration = new Link("Sub Menu Configuration", byXPath("//a[. = 'Configuration']"));
	static Link subMenuClassScheduling = new Link("Sub Menu Class Scheduling", byXPath("//a[. = 'Class Scheduling']"));
	static Link subMenuStudents = new Link("Sub Menu Students", byXPath("//a[. = 'Students']"));
	static Link Span8 = new Link("Click on student status span", byXPath("//div[2]/cmc-drop-down-list-classic/div/div/span/span"));
	static Link Span9 = new Link("Click on student status span", byXPath("//div[1]/cmc-drop-down-list-classic/div/div/span/span"));
	static Button ApplyFilters = new Button("Apply filters button", byXPath("//button[. = 'Apply Filter']"));
	static TextField SearchName = new TextField("Search Name", byXPath("//input[@placeholder = 'Search Name']"));
	static Link StudentSpan = new Link("Click on student span", byXPath("//td/span"));
	static Link Students = new Link("Student tile", byXPath("//a[. = 'Students']"));
	static Link Settings = new Link("Settings tile", byXPath("//a[text()='Settings']"));
	static Button FilterDropDwon = new Button("Click Filter Drop Down", byXPath("(//a[@class=\"k-button k-split-button-arrow\"])[1]"));
	static Button ClearFiltersButton = new Button("Click Filter Button", byId("listClearFiltersButton"));
	static AngDropDown StuNumDropDown = new AngDropDown("Click Student Number Dropdown", byXPath("//th[2]/a/span"));
	static Button StuNumFilter = new Button("Click Stud Num Filter", byXPath("//span[.=\"Filter\"]"));
	static TextField value = new TextField("Enter Value", byXPath("//input[@title=\"Value\"]"));
	static Button FilterButton = new Button("Click Filter Button", byXPath("//button[text()=\"Filter\"]"));
	static AngDropDown Role = new AngDropDown("Role Dropdown", byXPath("(//span[@aria-label=\"select\"])[1]"));
	static TextField GlobalSearch = new TextField("Global Search", byXPath("//input[@id='globalSearchSearchField']"));
	static Link Search = new Link("Search", byXPath("//i[@title='Search Button']"));
	static Link Task = new Link("Tasks", byXPath("//div[text()='Tasks']"));
	static Button NewButton = new Button("New button", byXPath("//a[@id='newButton']"));
	static TextField TaskTemplate = new TextField("Task Template", byXPath("(//input[@aria-label='Task Template'])[1]"));
	//static Link Student = new Link("Student", byXPath("//div[@aria-label='Student']"));
	static Link Student = new Link("Student", byXPath("//div[contains(@aria-label,'Student')]"));
	static Button SelectButton = new Button("Select button", byXPath("//button[text()='Select']"));
	static Button SaveAndClose = new Button("Save and Close", byXPath("//button[@aria-label = 'Save & Close']"));
	static Link Groups = new Link("Click Groups", byXPath("//a[.=\"Groups\"]"));
	static Link Filter= new Link("Filter", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
	static Link ClearFilter= new Link("Clear Filters", byXPath("//li[@id='listClearFiltersButton']"));
	static Button Filteroption= new Button("Filteroption", byXPath("//span[text()='Filter']"));
	static TextField FilterValue = new TextField("Filter Value",byXPath("//input[@title='Value']"));
	static Button Filterbutton = new Button("Filter icon", byXPath("//button[. = 'Filter']"));
	

public StudentHomePage SelectConfigurationMenu(StringHash data) throws Exception {
	
	//Login Page Web Elements
	//waitForPageToLoad();
	//setImplicitWaitTimeout(implicitWaitTimeout);	
	//setImplicitWaitTimeout();
	//JavascriptExecutor js = (JavascriptExecutor)driver;
	//Thread.sleep(25000);
	//setImplicitWaitTimeout(implicitWaitTimeout);
	//setImplicitWaitTimeout();
	//JavascriptExecutor js = (JavascriptExecutor)driver;
	//Thread.sleep(25000);
	//setImplicitWaitTimeout(implicitWaitTimeout);
	//setImplicitWaitTimeout();
	//JavascriptExecutor js = (JavascriptExecutor)driver;
	//Thread.sleep(25000);
	//Menu.waitTillElementClickable();
	Menu.clickUsingJavaScriptExecutor();
	wait(2);
	//js.executeScript("arguments[0].click();",Menu);
	subMenuConfiguration.waitTillElementClickable();
	//js.executeScript("arguments[0].click();",subMenuConfiguration);
	//wait(5);
	subMenuConfiguration.click();
	return this;
}

public StudentHomePage SelectClassSchedulingMenu(StringHash data) throws Exception {
	
	//Login Page Web Elements
	//waitForPageToLoad();	
	//JavascriptExecutor js = (JavascriptExecutor)driver;
	//Thread.sleep(25000);
	Menu.waitTillElementClickable();
	Menu.click();
	wait(2);
	//wait(2);
	//js.executeScript("arguments[0].click();",Menu);
	subMenuClassScheduling.waitTillElementClickable();
	//js.executeScript("arguments[0].click();",subMenuConfiguration);
	subMenuClassScheduling.click();	
	return this;
}



public StudentHomePage SelectStudentsMenu(StringHash data) throws Exception {
	
	//Login Page Web Elements
	//waitForPageToLoad();	
	//JavascriptExecutor js = (JavascriptExecutor)driver;
	//Thread.sleep(20000);
	//Menu.waitTillElementFound();
	//wait(5);
	Menu.waitTillElementClickable();
	Menu.click();
	//js.executeScript("arguments[0].click();",Menu);
	subMenuStudents.waitTillElementClickable();
	//js.executeScript("arguments[0].click();",subMenuConfiguration);
	subMenuStudents.click();
	//waitForPageToLoad();
	return this;
}


public StudentHomePage SelectStudent(StringHash data) throws Exception {
		
	Dropbox StudentStatus = new Dropbox("Student Status", byXPath("//li[. = '"+data.get("StudentStatus")+"']"));
	Dropbox Campus = new Dropbox("Campus", byXPath("//li[. = '"+data.get("Campus")+"']"));
		
	//Login Page Web Elements
	waitForPageToLoad();
	wait(5);
	wait(5);
	Span8.waitTillElementClickable();
	Span8.click();
	wait(2);
	//StudentStatus.click();
	Span9.waitTillElementClickable();
	Span9.click();
	wait(2);
	Campus.click();
	ApplyFilters.waitTillElementClickable();
	ApplyFilters.click();
	wait(6);
	waitForPageToComplete();
	wait(10);
	FilterDropDwon.click();
	wait(2);
	ClearFiltersButton.click();
	wait(2);
	StuNumDropDown.click();
	wait(2);
	StuNumFilter.click();
	wait(2);
	value.clearAndType(data.get("Student Number"));
	wait(2);
	FilterButton.click();
	wait(2);
/*	SearchName.clearAndType(data.get("StudentName").toString());
	wait(2);
*/
	StudentSpan.click();	
	return this;

}


public StudentHomePage SelectNewStudent(StringHash data) throws Exception {
	
	
	Link  NewStudent = new Link("New Student link", byCSSSelector("#listAddButton"));	
	//Login Page Web Elements
	waitForPageToLoad();
	//wait(35);
	NewStudent.click();
	return this;
}


public StudentHomePage configurationPage(){
 
	waitForPageToLoad();						 
	MenuButton.click();
	waitForPageToComplete();																												  
	Configuration.click();						  
	waitForPageToLoad();							
	return this;	
	}
	
public StudentHomePage StudentPage() {
				  
	//waitForPageToLoad();								  
	MenuButton.click();
	wait(3);
	//waitForPageToComplete();
	//Students.waitTillElementClickable();
	Students.click();
	//wait(10);
	//waitForPageToLoad();
	return this;
	}

public StudentHomePage SearchStudent(StringHash data)throws Exception {
//StudentHomePage SearchStudent(StringHash data)throws Exception {
	Link Filter= new Link("Filter", byXPath("(//div[@id='listSettingsButton_wrapper']/button)[2]"));
	//Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));
	//AngDropDown SSNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='Ssn']/a/span"));	
	AngDropDown SNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='StudentNumber']/a/span"));
	Link StudentNumRadioButton= new Link("StudentNumRadioButton", byXPath("//div[@id='radioGroup container-horizontal']/div/div[2]"));
	TextField StudentNumValue = new TextField("StudentNumValue", byXPath("//input[@name='panelStudentNumber']"));
	Button ApplyFilter = new Button("ApplyFilter", byXPath("//button[text()='Apply Filter']"));
	Button ClearFilter1 = new Button("ClearFilter", byXPath("//button[text()='Clear Filter']"));
	
	//Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
	//setImplicitWaitTimeout(getImplicitWaitTimeout());
	//waitForPageToLoad();
	//wait(5);
	//Filter.waitTillElementIsStale();
	//waitForPageToLoadNew();
	//Filter.waitTillElementClickableNew();
	//Filter.waitTillElementClickable();
	
	
	wait(30);
	Filter.clickUsingJavaScriptExecutor();
	wait(2);
	ClearFilter.clickUsingJavaScriptExecutor();
	wait(6);
	//Filter.waitTillElementIsStale();
	ClearFilter1.clickUsingJavaScriptExecutor();
	wait(2);
	StudentNumRadioButton.click();
	wait(2);
	StudentNumValue.click();
	wait(1);
	StudentNumValue.clearAndType(data.get("StudentNumber"));
	wait(1);
	ApplyFilter.clickUsingJavaScriptExecutor();
	wait(10);
//	Filter.clickUsingJavaScriptExecutor();
//	wait(3);
//	ClearFilter.click();
//	wait(5);
//	SNdrpdwn.click();
//	wait(2);
//	Filteroption.click();
//	wait(2);
//	FilterValue.clearAndType(data.get("StudentNumber"));
//	wait(2);
//	Filterbutton.click();
//	wait(5);
	StudentSpan.click();
	wait(12);
	return this;     
}

public StudentHomePage SearchStudent1(StringHash data)throws Exception {
	//StudentHomePage SearchStudent(StringHash data)throws Exception {
		 
	Link Filter= new Link("Filter", byXPath("(//div[@id='listSettingsButton_wrapper']/button)[2]"));
	//Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));
	//AngDropDown SSNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='Ssn']/a/span"));	
	AngDropDown SNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='StudentNumber']/a/span"));	
	
	
	Link StudentNumRadioButton= new Link("StudentNumRadioButton", byXPath("//div[@id='radioGroup container-horizontal']/div/div[2]"));
	TextField StudentNumValue = new TextField("StudentNumValue", byXPath("//input[@name='panelStudentNumber']"));
	Button ApplyFilter = new Button("ApplyFilter", byXPath("//button[text()='Apply Filter']"));
	Button ClearFilter1 = new Button("ClearFilter", byXPath("//button[text()='Clear Filter']"));
	//Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
	//setImplicitWaitTimeout(getImplicitWaitTimeout());
	//waitForPageToLoad();
	//wait(5);
	//Filter.waitTillElementIsStale();
	//waitForPageToLoadNew();
	//Filter.waitTillElementClickableNew();
	//Filter.waitTillElementClickable();
	//Filter.waitTillElementIsStale();
	wait(30);
	Filter.clickUsingJavaScriptExecutor();
	wait(2);
	ClearFilter.clickUsingJavaScriptExecutor();
	wait(6);
	ClearFilter1.clickUsingJavaScriptExecutor();
	wait(2);
	StudentNumRadioButton.click();
	wait(2);
	StudentNumValue.click();
	wait(1);
	StudentNumValue.clearAndType(data.get("StudentNumber"));
	wait(1);
	ApplyFilter.clickUsingJavaScriptExecutor();
	wait(10);	
//	Filter.clickUsingJavaScriptExecutor();
//	wait(3);
//	ClearFilter.clickUsingJavaScriptExecutor();
//	wait(10);
//	SNdrpdwn.click();
//	wait(3);
//	Filteroption.clickUsingJavaScriptExecutor();
//	wait(2);
    //FilterValue.clearAndType(data.get("StudentNumber"));
//	wait(2);
//	Filterbutton.click();
//	wait(5);
	StudentSpan.click();
	wait(12);
	return this;     
	}
	

public StudentHomePage ProcessesPage() {

	//wait(5);
	//waitForPageToLoad();
	MenuButton.waitTillElementClickable();
	MenuButton.click();
	waitForPageToComplete();						 
	Processes.click();
	//waitForPageToLoad();
	//wait(5);				 
	return this;
	}


public StudentHomePage MenuButton() throws Exception {


		//waitForPageToLoad();	   
		Menu.waitTillElementClickable();
		Menu.click();
		wait(2);
		return this;
	//End of Menu Button	
	}

public StudentHomePage StudentButton() throws Exception{
		Students.click();
		//waitForPageToLoad();
		//wait(5);
		return this;
		//return this;
    }
		
public StudentHomePage SettingsButton() throws Exception{
		Settings.click();
		wait(2);
		return this;
	}

public StudentHomePage ConfigurationButton() throws Exception{
		//wait(5);
		Configuration.click();
		return this;
		//return this;
	}

public StudentHomePage ProcessesButton() throws Exception{
	//wait(5);
	Processes.click();
	return this;
}
public StudentHomePage SelectAStudent(StringHash data) throws Exception {
	
	
	//Dropbox StudentStatus = new Dropbox("Student Status", byXPath("//div[. = '"+data.get("StudentStatus")+"']"));
	Dropbox StudentStatus = new Dropbox("Student Status", byXPath("//div/ul[@id='studentStatusIdDropDown_listbox']/li[text()='"+data.get("StudentStatus")+"']"));
	Dropbox Campus = new Dropbox("Campus", byXPath("//li[. = '"+data.get("Campus")+"']"));	
	//Login Page Web Elements
	waitForPageToLoad();
	wait(5);	
	Filter.clickUsingJavaScriptExecutor();
	wait(2);
    ClearFilter.clickUsingJavaScriptExecutor();
    wait(6);
	Span8.waitTillElementClickable();
	Span8.click();
	wait(2);
	StudentStatus.click();
	Span9.waitTillElementClickable();
	Span9.click();
	wait(2);
	Campus.clickUsingJavaScriptExecutor();
	ApplyFilters.waitTillElementClickable();
	ApplyFilters.clickUsingJavaScriptExecutor();
	wait(6);
	SearchName.clearAndType(data.get("StudentName").toString());
	wait(7);
	StudentSpan.clickUsingJavaScriptExecutor();	
	return this;
}


public StudentHomePage SelectTasksMenu(StringHash data) throws Exception {
	
	//Login Page Web Elements
	//wait(10);
	//waitForPageToLoad();	
	//JavascriptExecutor js = (JavascriptExecutor)driver;
	//Thread.sleep(20000);
	//Menu.waitTillElementFound();
	Menu.waitTillElementClickable();
	Menu.click();
	wait(2);
	//js.executeScript("arguments[0].click();",Menu);
	TasksButton.waitTillElementClickable();
	//js.executeScript("arguments[0].click();",subMenuConfiguration);
	TasksButton.click();
	return this;
}

public StudentHomePage CreateLetter(StringHash data) throws Exception {

	Link TaskMsg = new Link("TaskMsg", byXPath("//span[text()='The Task records were successfully saved.']"));
	Link RoleSelect = new Link("Role", byXPath("//li[text()='"+data.get("Role")+"']"));
	Link SelectingEmployer = new Link("Selecting searched employer", byXPath("//a[text()='"+data.get("EmpName")+"']"));
	Link SelectingTaskTemp = new Link("Selecting task template", byXPath("//a[text()='//span[text()='"+data.get("TaskTemplate")+"']']"));
	Checkbox SelectingStudent = new Checkbox("Selecting Student", byXPath("//div[@id='searchModel_searchgrid}']/div[2]/table/tbody/tr[1]/td[1]/input"));
	//waitForPageToLoad();
	wait(5);
	Role.click();
	wait(2);
	RoleSelect.click();
	wait(2);
	GlobalSearch.sendKeys(data.get("EmpName"));
	wait(2);
	Search.click();
	wait(5);
	SelectingEmployer.click();
	wait(15);
	Task.click();
	wait(5);
	NewButton.click();
	wait(8);
	TaskTemplate.clearAndType(data.get("TaskTemplate"));
	wait(1);
	//SelectingTaskTemp.click();
	wait(8);
	Student.clickUsingJavaScriptExecutor();
	wait(4);
	//SearchName.clearAndType(data.get("FullName"));
	//wait(3);
	SelectingStudent.click();
	String SelectedStudent = SelectingStudent.getAttribute("aria-label");
	System.out.println(SelectedStudent);
	TestReportsLog.log(LogStatus.INFO, "Selected Student is "+SelectedStudent);
	wait(2);
	SelectButton.click();
	wait(3);
	SaveAndClose.click();
	wait(2);
	CustomAsserts.containsString(TaskMsg.getText(), data.get("TaskMsg").toString());
	return this;
//End of Menu Button	

}

public StudentHomePage SelectStudentusingSN(StringHash data) throws Exception {

	Link Filter= new Link("Filter", byXPath("(//div[@id='listSettingsButton_wrapper']/button)[2]"));
	//Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));
	//AngDropDown SSNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='Ssn']/a/span"));	
	AngDropDown SNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='StudentNumber']/a/span"));	
	Link StudentNumRadioButton= new Link("StudentNumRadioButton", byXPath("//div[@id='radioGroup container-horizontal']/div/div[2]"));
	TextField StudentNumValue = new TextField("StudentNumValue", byXPath("//input[@name='panelStudentNumber']"));
	Button ApplyFilter = new Button("ApplyFilter", byXPath("//button[text()='Apply Filter']"));
	Button ClearFilter1 = new Button("ClearFilter", byXPath("//button[text()='Clear Filter']"));
	//Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
	//setImplicitWaitTimeout(getImplicitWaitTimeout());
	//waitForPageToLoad();
	//wait(5);
	//Filter.waitTillElementIsStale();
	//waitForPageToLoadNew();
	//Filter.waitTillElementClickableNew();
	//Filter.waitTillElementClickable();
	wait(30);
	//Filter.waitTillElementIsStale();
	Filter.clickUsingJavaScriptExecutor();
	wait(3);
	ClearFilter.clickUsingJavaScriptExecutor();
	wait(6);
	ClearFilter1.clickUsingJavaScriptExecutor();
	wait(4);
	StudentNumRadioButton.click();
	wait(2);
	StudentNumValue.click();
	wait(1);
	StudentNumValue.clearAndType(data.get("StudentNumber"));
	wait(1);
	ApplyFilter.clickUsingJavaScriptExecutor();
	wait(10);
//	SNdrpdwn.click();
//	wait(2);
//	Filteroption.click();
//	wait(2);
//	FilterValue.clearAndType(data.get("StudentNumber"));
//	wait(2);
//	Filterbutton.click();
//	wait(5);
	StudentSpan.click();
	//wait(25);
	return this;        
}


public StudentHomePage GroupPage() {
	
	//waitForPageToLoad();
	Menu.click();
	wait(3);
	Groups.click();
	//waitForPageToLoad();
	wait(20);
	return this;
}
}

