package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byXPath;

import org.openqa.selenium.interactions.SendKeysAction;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

import static com.framework.elements.Locator.byCSSSelector;
import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byName;
public class StudentContactManagerPage extends BasePage{
	
	static Link ContactManager = new Link("Contact Manager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
	static Link Tasks = new Link("Tasks", byXPath("//span[text()='Tasks']"));
	static Link Documents = new Link("Documents", byXPath("//span[text()='Documents']"));
	static AngDropDown Taskdropdown = new AngDropDown("Awards Drop Down", byXPath("(//button[@aria-label=\"arrow-button\"])[1]"));
	static Button TaskClearFilter = new Button("Clear Filter", byXPath("//span[text()='Reset to Default']"));
	static Dropbox SubjectDropDown = new Dropbox("Subject Drop Down", byXPath("//a[@title=\"Subject edit column settings\"]"));
	//static Link SubjectDropDown = new Link("Drop Down", byXPath("(//a[@title=\"Column Settings\"])[1]"));
	static Button SubjectFilter = new Button("Filter", byXPath("(//span[text()=\"Filter\"])[1]"));
	static TextField SubjectValue = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
	static Button SubjectFilterButton = new Button("Filter Button", byXPath("//button[.=\"Filter\"]"));
	//static Button HighlightTask = new Button("Highlight the task", byXPath("//td[.=\"07/15/2022 !\"]"));
	static Button CloseTask = new Button("Close Task", byXPath("(//*[text()='Close Task'])[1]"));
	static TextField Comments = new TextField("Comments", byName("callScriptComments"));
	static Button TaskSaveClose = new Button("Save and Close", byId("studentTaskCallScriptAndFollowUpDialogButton"));
	static Button ConfirmCloseTask = new Button("Close Task", byId("studentTaskCloseDialogButton"));	
	//FA Document Web Elements
	static TextField DocEnterModule = new TextField("Module", byName("studentDocumentModule_input"));
	static TextField DocAwardYear = new TextField("New Document", byName("studentDocumentAwardYear_input"));
	static Link NewDocument = new Link("New Document", byXPath("(//button[.=\"New Document\"])[1]"));
	static TextField DocumentModule = new TextField("Document Module", byName("studentDocModule_input"));
	//static Button SelectMainModule = new Button("Main Module", byXPath("//span[.=\"Financial Aid\"]"));
	static TextField DocumentName = new TextField("Document Name", byName("studentDocName_input"));
	static TextField DocumentAwardYear = new TextField("Award Year", byName("studentDocAwardYear_input"));
	static TextField DocStatus = new TextField("Document List Status", byName("studentDocStatus_input"));
	static TextField DocDateRequested = new TextField("Date requested", byId("studentDocDateRequested"));
	static Button DocSaveClose = new Button("Save and Close", byXPath("//button[@id='studentDocumentSaveAnCloseButton']"));	
	//FA Document List Web Elements
	static TextField DLEnterModule = new TextField("Module", byName("studentDocumentModule_input"));
	static TextField DLAwardYear = new TextField("New Document", byName("studentDocumentAwardYear_input"));
	static Link NewDocumentList = new Link("New Document List", byXPath("(//button[.=\"New Document List\"])[1]"));
	static TextField DLDocumentModule = new TextField("Document Module", byName("studentDocModule_input"));
	static TextField DocumentListName = new TextField("Document List Name", byXPath("(//input[@aria-label=\"studentDocName\"])[1]"));
	static TextField DLStatus = new TextField("Document List Status", byName("studentDocStatus_input"));
	static TextField DLDateRequested = new TextField("Date requested", byId("studentDocDateRequested"));
	static Button DLSaveClose = new Button("Save and Close", byId("studentDocumentListSaveAnCloseButton"));
	
	
	public StudentContactManagerPage CloseTask(StringHash data) throws Exception{
		
		Button HighlightTask = new Button("Highlight Task", byXPath("(//tr/td[2])[1]"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Task records were successfully closed.']"));
		Button CloseTaskButton = new Button("CloseTask", byXPath("//button[@id='studentTaskCloseDialogButton']"));
		Dropbox StatusDropdown = new Dropbox("Status", byXPath("(//a[@aria-label='Column Settings'])[5]"));
		Link StatusFilter = new Link("Filter", byXPath("//span[text()='Filter']"));//span[text()=\"Filter\"]
		TextField StatusValue = new TextField("Value", byXPath("//input[@aria-label='Status']"));//input[@title=\"Value\"]
		Button Refresh = new Button("Refresh Button", byXPath("//a[@aria-label='Refresh']//span[1]"));
		
		
		//waitForPageToLoad();
		ContactManager.waitTillElementClickable();
		ContactManager.click();
		wait(2);
		Tasks.click();
		wait(25);
		Taskdropdown.click();
		wait(4);
		TaskClearFilter.click();
		wait(5);
		SubjectDropDown.click();
		wait(4);
		SubjectFilter.click();
		wait(3);
		SubjectValue.clearAndType(data.get("TaskSubject"));
		wait(2);
		SubjectFilterButton.click();
		wait(5);
	    /*SubjectDropDown.click();
		wait(2);
		AssignedToFilter.click();
		wait(2);
		AssignedToValue.clearAndType(data.get("TaskSubject"));
		wait(2);
		AssignedToFilterButton.click();
	    */
//		StatusDropdown.click();
//		wait(3);
//	//	StatusFilter.mouseHover();
//		StatusFilter.clickUsingJavaScriptExecutor();
//		wait(2);
//		StatusValue.clearAndType("Pending");
//		wait(3);
//		Refresh.clickUsingJavaScriptExecutor();
//		wait(3);
		HighlightTask.clickUsingJavaScriptExecutor();
		wait(5);
		CloseTask.clickUsingJavaScriptExecutor();
		wait(5);
		//Comments.sendKeys("Closing the task");
		wait(6);
		//TaskSaveClose.click();
		CloseTaskButton.click();
		//waitForPageToLoad();
		//ConfirmCloseTask.click();
		wait(8);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
	}
	
	public StudentContactManagerPage AddFADocumentPage(StringHash data) throws Exception{

		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Document records were successfully saved.']"));
		Dropbox DocumentDropdown = new Dropbox("Document Dropdown", byXPath("(//button[@aria-label='expand combobox']/span)[6]"));
		Link SelectDocument = new Link("Document", byXPath("//ul[@id=\"studentDocName_listbox\"]/li[1]/span/div/span[1]"));
		Link SelectStatus = new Link("Status", byXPath("//ul[@id=\"studentDocStatus_listbox\"]/li[1]/span/div/span[1]"));
		Link SelectModule = new Link("Module", byXPath("(//span[.=\"Financial Aid\"])[2]"));
		
		//waitForPageToLoad();
		ContactManager.waitTillElementClickable();
		ContactManager.click();
		wait(2);
		Documents.click();
		wait(10);
		/*	DocEnterModule.clearAndType(data.get("Module"));
		wait(2);
		SelectMainModule.click();
		wait();
		DocAwardYear.clearAndType(data.get("AwardYear"));
		wait(2);
		SelectMainAwardYear.click();
		wait(2);
		*/
		NewDocument.click();
		wait(10);
		DocumentModule.clearAndType("Financial Aid");
		wait(4);
		SelectModule.click();
		wait(2);
		//SelectDocModule.click();
		//wait(4);
		DocumentDropdown.click();
		wait(2);
		SelectDocument.click();
		String DocumentName = SelectDocument.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Document Name is selected as " +DocumentName);
		wait(2);
		DocStatus.clearAndType("Requested - Not Required");
		wait(2);
		SelectStatus.click();
		wait(2);
		DocSaveClose.click();
		wait(7);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;	
	}
	
	public StudentContactManagerPage AddFADocumentListPage(StringHash data) throws Exception{

		Link SelectDocumentListName = new Link(data.get("DocumentListName"), byXPath("//span[.='"+data.get("DocumentListName")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Document records were successfully saved.']"));
		Link SelectStatus = new Link("Status", byXPath("//ul[@id=\"studentDocStatus_listbox\"]/li[1]/span/div/span[1]"));
		Link SelectModule = new Link("Module", byXPath("//ul[@id=\"studentDocModule_listbox\"]/li/span[1]/div/span[1]"));
		
		//waitForPageToLoad();
		ContactManager.waitTillElementClickable();
		ContactManager.click();
		wait(2);
		Documents.click();
		wait(10);
		/*    DLEnterModule.clearAndType(data.get("Module"));
	        wait(2);
	        DLAwardYear.clearAndType(data.get("AwardYear"));
	        wait(2);
		 */
		NewDocumentList.click();
		wait(15);
		scrollPage(0, 500);
		wait(5);
		DLDocumentModule.sendKeys("Financial Aid");
		wait(5);
		SelectModule.click();
		wait(2);
//		DocumentListName.clearAndType(data.get("DocumentListName"));
//		wait(4);
//		SelectDocumentListName.click();
		wait(2);
		DLStatus.clearAndType("Requested - Not Required");
		wait(4);
		SelectStatus.click();
		wait(2);
		DLSaveClose.click();
		wait(8);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;  
	    }    
}
