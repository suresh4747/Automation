package com.StudentPortal.Pages;


import static com.framework.elements.Locator.byId;


import static com.framework.elements.Locator.byXPath;

import java.util.concurrent.TimeUnit;


import static com.framework.elements.Locator.byXPath;


import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.DatesUtil;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentSubsidiaryPage extends BasePage{
	
	static String Note = AppendValue.apendString();
	//static Link Subsidiary = new Link("Subsidiary", byXPath("//div/span[. = 'Subsidiary']"));
	static Link Subsidiary = new Link("Subsidiary", byXPath("//span[. = 'Subsidiary']"));
	static TextField Amount = new TextField("Amount subsidiary", byXPath("(//input[@aria-label='Amount'])[1]"));
	static TextField SubsidiaryNote = new TextField("Transaction note", byXPath("(//div/textarea[@aria-label='Note'])[1]"));
	static Link FectingAmount = new Link("Fetching amount", byXPath("//tr[1]/td[9]"));
	static TextField SubsidiaryVoidNote = new TextField("Subsidiary Void note", byXPath("//textarea[@id='studentTransactionVoidPaymentNote']"));
	static Link ExporttoExcelorPDF = new Link("Export to excel or pdf", byXPath("//*[@title='Export to Excel or PDF']"));
	static Link PDFExport = new Link("Export to pdf", byXPath("//li[@id='cnsSubsidiaryTransactionGrid_cnsToolbar_kendoToolBar_exportPdfAllButton']"));
	static Link addcharge = new Link("Click on Add charge", byXPath("//a[@id='newChargeButton']"));
	//static Link AcademicYear = new Link("Enter Academic Year", byXPath("//span[@aria-label='Academic Year: Dropdown']"));
	static Link AcademicYear = new Link("Enter Academic Year", byXPath("//span[contains(@aria-label,'Academic Year')]"));
	//static TextField Billcode = new TextField("Enter Billcode", byXPath("//span[@aria-label='Bill Code: Dropdown']"));
	static TextField Billcode = new TextField("Enter Billcode", byXPath("//span[contains(@aria-label,'Bill Code')]"));
	static Link SelAcademicyear = new Link("Click on AcademicYear", byXPath("//span[@title=\"1\"]"));
	static Link SelBillcode = new Link("Click on BC", byXPath("//span[text()='ACCBFEE']"));
	//static Link SelBillcode = new Link("Click on BC", byXPath("//div/div/div[4]/ul//span[1]"));
	static Button AddSubsidiary = new Button("Add subsidiary", byXPath("(//div/div[1]/button)[2]"));
	static AngDropDown SubsidiaryList = new AngDropDown("Subsidiary List", byXPath("(//div/cmc-drop-down-list-classic/div/div/span/span)[2]"));
	static TextField SubsidiarySearch = new TextField("Subsidiary Search", byXPath("/html/body/div[47]/div/span/input"));  
	static Link SelectingSubsidiary = new Link("Selecting Subsidiary", byXPath("//span[. = ' LAPTOPDE ']")); 
	static TextField MaintainedBalance = new TextField("Maintained Balance", byXPath("(//input[@aria-label='Maintained Balance'])[1]"));
	static Button Save = new Button("Save button", byXPath("//button[@id='maintainedBalanceSaveButton']"));
	static Link GettingSubsidiaryName = new Link("Getting subsidiary Name", byXPath("(//span[@aria-label='Subsidiary']/span/span)[2]"));
	static Link FetchingSubsidiaryName = new Link("Fetching subsidiary name", byXPath("//div/cmc-drop-down-list-classic/div/div/span/span"));
	static Link Filtericon = new Link("Filter icon", byXPath("//cmc-common-toolbar/div/div[1]/button[1]"));
	static Link ClearFilters= new Link("Clear Filters", byXPath("//span[text()='Reset to Default']"));
	static AngDropDown Transactionlist = new AngDropDown("Transaction list", byXPath("//th[7]//span"));
	static Link FilterOptions = new Link("Filter options", byXPath("//span[text()='Filter']"));
	static Link Operator = new Link("Operator dropdown", byXPath("//form/div[1]/span[1]/span"));
	static Link SelectingOperator = new Link("Selecting operator", byXPath("//div/div/div//li[. = 'Contains']"));
	static TextField Value = new TextField("Enter filter value", byXPath("(//input[@title='Value'])[2]"));
	//static TextField Value = new TextField("Enter filter value", byXPath("//form/div/input[1]"));
	static Button Filterbutton = new Button("Filter icon", byXPath("(//button[text()='Filter'])[2]"));
	static Link Tablevalue= new Link("Table value", byXPath("(//tr[1]/td[1])[1]"));
	static Link TermList= new Link("Term list", byXPath("//div[@id='search_display_termId']"));
	static TextField SearchCode = new TextField("Search code", byXPath("//input[@placeholder='Search Code']"));
	static Link SelectingTransaction = new Link("Selecting Transaction", byXPath("//span[. = 'Student Payment on SL ']"));
	static Checkbox Term = new Checkbox("Selecting Term", byXPath("//input[@aria-label='2022FAR']"));
	static Button SelectButton = new Button("Select button", byXPath("//button[text()='Select']"));
	static Button SaveAndClose = new Button("Save and Close", byXPath("(//button[@aria-label= 'Save & Close'])[2]"));
	static Link TermValue= new Link("Term value", byXPath("//tr[1]/td[12]"));
	static Link FilterDropDwon = new Link("Click Filter Drop Down", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
    static Link ClearFiltersButton = new Link("Click Filter Button", byXPath("//a[text()='Clear Filters']"));
    static AngDropDown StuNumDropDown = new AngDropDown("Click Student Number Dropdown", byXPath("//th[2]/a/span"));
    static Button StuNumFilter = new Button("Click Stud Num Filter", byXPath("//span[.=\"Filter\"]"));
    static TextField value = new TextField("Enter Value", byXPath("//input[@title=\"Value\"]"));
    static Button FilterButton = new Button("Click Filter Button", byXPath("//button[text()=\"Filter\"]"));
    //static Link StudentAccounts = new Link("Click on StudentAccounts", byXPath("//span[@class='k-link k-header k-state-selected']"));
    static Link StudentAccounts = new Link("Click on StudentAccounts", byXPath("//li[6]/span[1]"));
    static Link MenuButton = new Link("Click MenuButton", byXPath("//div[@id='navbar']/ul/li[2]/a/span"));
	static Link Students = new Link("Students tile", byXPath("//a[text()=\"Students\"]"));
	//static Link SelSubsidery = new Link("Select Subsidery", byXPath("//span[@aria-label='Subsidiary: Dropdown']"));
	static Link SelSubsidery = new Link("Select Subsidiary", byXPath("//span[contains(@aria-label,'Subsidiary')]"));
	static Link ClkSubsidery = new Link("Click Subsidiary", byXPath("//span[@title=' NewTestSub2 ']"));
	static TextField EntMaintainedBalance = new TextField("Enter Maintained Balance", byXPath("//span[@class='k-numeric-wrap k-state-default k-expand-padding']"));
	static TextField SubSave = new TextField("click Save", byXPath("//button[@id='maintainedBalanceSaveButton']"));
	static TextField SearchBillcode = new TextField("Enter Billcode", byXPath("//span[@class='k-list-filter']"));
	static Button ClsFilterDropDwon = new Button("Click Filter Drop Down", byXPath("(//a[@class='k-button k-split-button-arrow'])[1]"));
	static Link ClsClearFiltersButton = new Link("Click Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
	static AngDropDown TeDropDown = new AngDropDown("Click Term Number Dropdown", byXPath("(//span[@class='k-icon k-i-more-vertical'])[2]"));
	static AngDropDown TrFilter = new AngDropDown("Click Term Number Dropdown", byXPath("//span[text()='Filter']"));
	static AngDropDown TrDropDown = new AngDropDown("Click Term Number Dropdown", byXPath("(//span[@class='k-icon k-i-more-vertical'])[8]"));
    static Button TerNumFilter = new Button("Click Term Num Filter", byXPath("//span[.='Filter']"));
    static TextField Cvalue = new TextField("Enter Value", byXPath("(//input[@title='Value'])[3]"));
    static Button CFilterButton = new Button("Click Filter Button", byXPath("//button[text()='Filter']"));
    static Checkbox SelCharge = new Checkbox("Click Term Button", byXPath("//tr/td[6]"));
    static Link More= new Link("More", byXPath("//*[text()='More']"));
    static Button Delete = new Button("Delete icon", byXPath("//a[text()='Delete']"));
    static TextField DeleteNote = new TextField("Delete note", byXPath("(//div/textarea[@aria-label='Note'])[1]"));
    static Button Deletebutton = new Button("Delete button", byXPath("//button[@id='okDelete']"));
    static TextField VoidNote = new TextField("VoidNote", byXPath("(//div/textarea[@id=\"studentTransactionVoidPaymentNote\"])[1]"));
    static Button VoidButton = new Button("Void button", byXPath("//button[@id='okVoidPayment']"));
    static Button Void = new Button("Void icon", byXPath("//a[text()='Void']"));
    static TextField PaymentName = new TextField("PaymentName", byXPath("//input[@name='paymentName']"));
    static Link PaymentMethod = new Link("PaymentMethod", byXPath("//span/span/span[. = 'Check']"));
    static Link SelPaymentMethod = new Link("SelPaymentMethod", byXPath("//li[. = 'Cash']"));
    static Link CashDrawer = new Link("CashDrawer", byXPath("//cmc-drop-down-list-classic[3]/div/div/span/span/span/span"));
    static Link SelCashDrawer = new Link("SelCashDrawer", byXPath("//span[. = 'NANDA']"));
    static TextField Amount1 = new TextField("Amount", byXPath("(//input[@aria-label='Amount'])[1]"));
    static Checkbox printreciept = new Checkbox("Click printreciept", byXPath("//cmc-checkbox[3]//label"));
    static Link Payment = new Link("Payment", byXPath("//a[6][. = 'Payment']"));
    static TextField Password = new TextField("Password", byXPath("//input[@id='password']"));
    static Button Ok = new Button("ok", byXPath("//button[text()='OK']"));
    static Button Refund = new Button("Refund", byXPath("//button[. = 'Refunds']"));
    static Link RefundSource = new Link("RefundSource", byXPath("//td[. = 'NewTestSub1']"));
    static Button Nextt = new Button("Nextt", byXPath("//button[. = 'Next']"));
    static Link TermField = new Link("TermField", byXPath("//div/cmc-drop-down-list/div/div/span/span/span/span"));
    static Link SelTermField = new Link("SelTermField", byXPath("//span[. = '010322']"));
    static TextField DueDate = new TextField("DueDate", byXPath("(//input[@placeholder=\"MM/DD/YYYY\"])[2]"));
    static Button PostSchedule = new Button("PostSchedule", byXPath("(//button[@aria-label=\"Post/Schedule\"])[2]"));
    
    //Random Value
    static String PayName = AppendValue.apendString();
    static String Date = DatesUtil.getCurrentDatebyFormat("M/dd/yyyy");
    static String PaymentTransactionName;
    
  //X-path for SubReturn CHeck
    static Link PaymentSub = new Link("Add payment", byXPath("//*[@id='newPaymentButton']"));
    //static AngDropDown AcademicYr = new AngDropDown("Academic year dropdown", byXPath("//span[@aria-label='Academic Year: Dropdown']/span/span/span"));
    static AngDropDown AcademicYr = new AngDropDown("Academic year dropdown", byXPath("//span[contains(@aria-label,'Academic Year')]/span/span/span"));
    static Link SelectingAYr = new Link("Selecting Academic year", byXPath("//ul[@id='academicYearSequence_listbox']/li/div/span[1]"));
    static TextField PaymentNameSub = new TextField("Payment Name", byXPath("//input[@id='paymentName']"));
    //static AngDropDown PaymentMethodSub = new AngDropDown("Payment Method", byXPath("//span[@aria-label='Payment Method: Dropdown']/span/span/span"));
    static AngDropDown PaymentMethodSub = new AngDropDown("Payment Method", byXPath("//span[contains(@aria-label,'Payment Method')]/span/span/span"));
    static Link SelectingPayMethod = new Link("Selecting Payment Method", byXPath("//li[text()='Check']"));
    static TextField CheckNumber = new TextField("Check number", byXPath("//input[@name='checkNumber']"));
    static Button Cancel = new Button("Cancel button", byXPath("//button[@id='cancelPrintReceipt']"));
    static AngDropDown Transaction = new AngDropDown("Transaction", byXPath("//*[@title='Transaction edit column settings']/span"));
    static Link HighlightingTransaction = new Link("Highlighting transaction", byXPath("(//tr/td[5])[1]"));
    static Link MoreSub = new Link("More button", byXPath("//a[@id='ledgerCardMoreButton']"));
    static Link ReturnedCheck = new Link("Retruned Check", byXPath("//*[@id='returnedCheckTransactionButton']"));
    static Button ReturnedCheckOk = new Button("Retruned Check Ok", byXPath("//button[@id='okReturnedCheck']"));
    static TextField ReturnNote = new TextField("Retruned Check Note", byXPath("//textarea[@name='studentTransactionReturnedCheckNote']"));
    
    public StudentSubsidiaryPage AdjustSubTransaction(StringHash data) throws Exception {
		Link AdjustSubMsg= new Link("Adjust Subsidiary Msg", byXPath("//span[text()='The Transaction records were successfully saved.']"));
		Checkbox Term = new Checkbox("Selecting Term", byXPath("(//tbody/tr[1]/td[1]/input)[1]"));
		Link SelectingBillCode= new Link("Selectecting billcode", byXPath("//div[@id='billingTransactionCode-list']/div[4]/ul/li[1]/div/span[1]"));
		Link SelectingSubsidiary = new Link("Selecting Subsidiary", byXPath("//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/div/span[1]"));
		Link SelectingTransaction = new Link("Selecting Transaction", byXPath("(//tr/td/a/span)[1]"));
		//bharath
		Link CashPaymentCode= new Link("CashPaymentCode", byXPath("//span[@aria-label='Cash Payment Code']"));
		Link CashPaymentCodeValue= new Link("CashPaymentCodeValue", byXPath("//ul[@id='transactionNameDropDown_listbox']/li[1]"));
		Button cancelbutton= new Button("cancelbutton", byXPath("//button[@id='cancelPrintReceipt']"));

		Link ClkSubsidery=new Link("Selecting Transaction", byXPath("//ul[@id='subsidiaryAccountTypeId_listbox']/li/span/div/span"));
		Link Payment = new Link("Payment", byXPath("//button[@id='newPaymentButton']"));
		
		Link BankAccount = new Link("BankAccount", byXPath("//span[@aria-label='Bank Account']"));
		Link BankAccountValue = new Link("BankAccountValue", byXPath("(//ul[@id='bankAccountId_listbox']/li/span/div/span)[1]"));


		//Login Page Web Elements
		waitForPageToLoad();
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		/*Subsidiary.clickUsingJavaScriptExecutor(); 
		wait(25);
		GettingSubsidiaryName.click();
		wait(2);
		SelectingSubsidiary.click();
		wait(3);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		StudentLedgerAccountPage.AddCharge.click();
	    wait(6);
		//wait(2);
		TermList.clickUsingJavaScriptExecutor();
		wait(4);
		Term.clickUsingJavaScriptExecutor();
        wait(2);
        String SelectedTerm = Term.getAttribute("aria-label");
  	    System.out.println("Term is selected");
        TestReportsLog.log(LogStatus.INFO, "Selected Term is "+SelectedTerm);
        SelectButton.clickUsingJavaScriptExecutor();
	    wait(2);
	    StudentLedgerAccountPage.BillCode.click();
	    wait(2);
	    SelectingBillCode.click();
	    String SelectedBillCode = SelectingBillCode.getAttribute("title");
		System.out.println(SelectedBillCode);
	    TestReportsLog.log(LogStatus.INFO, "Selected BillCode is "+SelectedBillCode);
	    wait(2);
	    Amount.sendKeys("100");
	    wait(5);
	    scrollPage(0, -300);
	    wait(1);
	    SaveAndClose.click();
		//Term.click();
		wait(4); */
		Subsidiary.clickUsingJavaScriptExecutor();
		wait(15);
		SelSubsidery.clickUsingJavaScriptExecutor();
		wait(3);
		ClkSubsidery.clickUsingJavaScriptExecutor();
		wait(3);
		String ClkSubsidry = ClkSubsidery.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Subsidiary name is selected as "+ClkSubsidry);
		wait(2);
		Payment.click();
		wait(10);
		//Password.clearAndType(data.get("Password1").toString());
		//wait(3);
		//Ok.click();
		//wait(2);
		TermList.click();
		wait(2);
		Term.click();
		wait(2);
		SelectButton.clickUsingJavaScriptExecutor();
		wait(5);
		CashPaymentCode.clickUsingJavaScriptExecutor();
		wait(2);
		CashPaymentCodeValue.clickUsingJavaScriptExecutor();
		wait(2);
		PaymentName.clearAndType("Student Payment");
		//		PaymentName.clearAndType(PayName);
		//		PaymentTransactionName=PayName;
		wait(3);
		PaymentMethod.click();
		wait(3);
		SelPaymentMethod.click();
		wait(2);
		String SelPaymentMetod = SelPaymentMethod.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Payment Method name is selected as "+SelPaymentMetod);
		wait(2);
		BankAccount.click();
		wait(2);
		BankAccountValue.click();
		wait(2);
		//CheckNumber.clearAndType("234");
		//CashDrawer.click();
		//wait(3);
		//SelCashDrawer.click();
		//wait(2);
		//String SelCashDrawr = SelCashDrawer.getAttribute("title");
		//TestReportsLog.log(LogStatus.INFO, "SelCashDrawername is selected as "+SelCashDrawr);
		//wait(2);
		Amount1.sendKeys("200");
		wait(7);
		scrollPage(0, 400);
		wait(3);
		//printreciept.click();
		//wait(3);
		scrollPage(0, -400);
		wait(3);
		SaveAndClose.click();
		wait(6);
		cancelbutton.clickUsingJavaScriptExecutor();
		wait(7);
		SelectingTransaction.clickUsingJavaScriptExecutor();
		String SelectedTransaction = SelectingTransaction.getText();
		System.out.println(SelectedTransaction);
		TestReportsLog.log(LogStatus.INFO, "Selected Transaction is "+SelectedTransaction);
		wait(8);
		//		TermList.clickUsingJavaScriptExecutor();
		//	    wait(3);
		//		if(Term.isSelected())
		//        {
		//            System.out.println("Term is already selected");
		//            StudentLedgerAccountPage.CancelButton.clickUsingJavaScriptExecutor();
		//        }else {
		//            Term.click();
		//            String SelectedTerm1 = Term.getAttribute("aria-label");
		//            System.out.println(SelectedTerm1);
		//            TestReportsLog.log(LogStatus.INFO, "Selected Term is "+SelectedTerm1);
		//            wait(2);
		//            SelectButton.clickUsingJavaScriptExecutor();
		//        }
		SubsidiaryNote.click();
		SubsidiaryNote.sendkeys(Note);
		wait(2);
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(6);
		CustomAsserts.containsString(AdjustSubMsg.getText(), data.get("AdjustSubMsg").toString());
		//		String TermName = TermValue.getText();
		//		if(TermName.equalsIgnoreCase(data.get("TermCode")))
		//		{
		//			System.out.println("Subsidiary Changes are reflecting");
		//		}else {
		//			System.out.println("Subsidiary Changes are not reflecting");
		//		}
		return this;
	}
		
	public StudentSubsidiaryPage PrintSubsidiaryLedger(StringHash data) throws Exception {
			
		Link SelectingSubsidiary = new Link("Selecting Subsidiary", byXPath("//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/span/div/span[1]"));
			driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
			//Login Page Web Elements
			waitForPageToLoad();
			setImplicitWaitTimeout(implicitWaitTimeout);
			StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
			wait(2);
			Subsidiary.clickUsingJavaScriptExecutor();
			wait(25);
			GettingSubsidiaryName.click();
			wait(2);
			SelectingSubsidiary.click();
			wait(3);
			ExporttoExcelorPDF.clickUsingJavaScriptExecutor();
			wait(2);
			PDFExport.clickUsingJavaScriptExecutor();
			System.out.println("Subsidiary ledger is printed successfully");
			return this;
	}
       	
	public StudentSubsidiaryPage AddSubsidiary(StringHash data) throws Exception {
    	Link AddSubMsg= new Link("Add Subsidiary Msg", byXPath("//span[text()='The Student Subsidiary records were successfully saved.']"));
    	Link SelectingSubsidiary = new Link("Selecting Subsidiary", byXPath("//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/div/span[1]")); 
    	Link SelectingNewSubsidiary = new Link("Selecting Subsidiary", byXPath("//ul[@id='subsidiaryDialogAccountTypeId_listbox']/li[1]/span/div/span[1]")); 
    	Link SubsidiaryList = new Link("Selecting Subsidiary drop down", byXPath("(//span[@aria-label='select']/span)[3]"));
    	
    	//Link SelectingNewSubsidiaryCode = new Link(data.get("NewSubCode"), byXPath("//span[. = '"+data.get("NewSubCode")+"']")); 
		//Login Page Web Elements
		waitForPageToLoad();
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(2);
		Subsidiary.clickUsingJavaScriptExecutor();
		wait(25);
		AddSubsidiary.clickUsingJavaScriptExecutor();
		wait(3);
		SubsidiaryList.clickUsingJavaScriptExecutor();
		wait(2);
		SelectingNewSubsidiary.clickUsingJavaScriptExecutor();
		String SelectedSubsidiary = SelectingNewSubsidiary.getAttribute("title");
		System.out.println(SelectedSubsidiary);
		TestReportsLog.log(LogStatus.INFO, "Selected Subsidiary is "+SelectedSubsidiary);
		wait(2);
		MaintainedBalance.sendKeys("10");
		wait(2);
		Save.clickUsingJavaScriptExecutor();
		wait(8);
		CustomAsserts.containsString(AddSubMsg.getText(), data.get("AddSubMsg").toString());
//		GettingSubsidiaryName.click();
//		wait(2);
//		SelectingSubsidiary.click();
//		wait(1);
//		String NewSubName = FetchingSubsidiaryName.getText();
//		System.out.println(NewSubName);
//		if(NewSubName.contains(SelectedSubsidiary))
//		{
//			System.out.println("New subsidiary is added successfully");
//		}else {
//			System.out.println("New subsidiary is not added");
//		}
		return this;
}
	
	public StudentSubsidiaryPage AdjustSubTransactionReturnedCheck(StringHash data) throws Exception {
		Checkbox Term = new Checkbox("Selecting Term", byXPath("(//tbody/tr[1]/td[1]/input)[1]"));
		Link ReturnedCHeckMsg= new Link("Returned Check Msg", byXPath("//span[text()='The check was successfully marked as returned.']"));
		Link PaymentMsg= new Link("Payment Msg", byXPath("//span[text()='The Transaction records were successfully saved.']"));
		Link SelectingSubsidiary = new Link("Selecting Subsidiary", byXPath("(//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/span/div/span)[1]"));
		Dropbox PaymentCode = new Dropbox("Payment Code", byXPath("//span[@aria-label='Cash Payment Code']"));
		Link SelectPaymentCode = new Link("Payment Code", byXPath("(//ul[@id='transactionNameDropDown_listbox']/li[1]/span/div/span)[1]"));
		
		Link BankAccount = new Link("BankAccount", byXPath("//span[@aria-label='Bank Account']"));
		Link BankAccountValue = new Link("BankAccountValue", byXPath("(//ul[@id='bankAccountId_listbox']/li/span/div/span)[1]"));
		
		//driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS) ;
		//Login Page Web Elements
		waitForPageToLoad();
		//ImplicitlyWait();
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		Subsidiary.clickUsingJavaScriptExecutor();
		wait(50);
		GettingSubsidiaryName.waitTillElementClickable();
		GettingSubsidiaryName.click();
		wait(2);
		SelectingSubsidiary.click();
		wait(3);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		PaymentSub.click();
		wait(10);
		//AcademicYr.clickUsingJavaScriptExecutor();
		wait(2);
		//SelectingAYr.clickUsingJavaScriptExecutor();
		wait(2);
		TermList.click();
		wait(5);
		Term.click();
		wait(2);
		SelectButton.clickUsingJavaScriptExecutor();
		wait(2);
		PaymentCode.clickUsingJavaScriptExecutor();
		wait(2);
		SelectPaymentCode.click();
		wait(2);
		//PaymentNameSub.sendkeys(data.get("PaymentName"));
//		wait(2);
//		PaymentMethodSub.click();
//		wait(2);
//		SelectingPayMethod.click();
		wait(2);
		CheckNumber.sendkeys("234");
		wait(1);
		Amount.sendkeys("10");
		wait(2);
		BankAccount.click();
		wait(2);
		BankAccountValue.click();
		wait(2);
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(8);
		CustomAsserts.containsString(data.get("PaymentMsg"), PaymentMsg.getText());
		wait(2);
		Cancel.clickUsingJavaScriptExecutor();
		wait(5);
		scrollPage(0, -800);
		wait(2);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(2);
		ClearFilters.clickUsingJavaScriptExecutor();
//		wait(8);
//		Transaction.clickUsingJavaScriptExecutor();
//		wait(2);
//		StudentLedgerAccountPage.Filter1.click();
//		wait(2);
//		StudentLedgerAccountPage.Value1.clearAndType(data.get("PaymentName"));
//		wait(2);
//		StudentLedgerAccountPage.Filterbutton.click();
		wait(10);
		HighlightingTransaction.click();
		wait(5);
		More.click();
		wait(2);
		ReturnedCheck.click();
		wait(3);
		ReturnNote.clearAndType(Note);
		wait(2);
		ReturnedCheckOk.click();
		wait(8);
		CustomAsserts.containsString(data.get("RetunerCheckMsg"), ReturnedCHeckMsg.getText());
		wait(2);
		return this;
	}
      
     public StudentSubsidiaryPage PostCharge(StringHash data) throws Exception {


    	 Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
 		
 		//Login Page Web Elements
 		waitForPageToLoad();
 		MenuButton.click();
 		wait(5);
 		Students.click();
 		//waitForPageToLoad();
 		wait(20);
 		FilterDropDwon.click();
 		wait(1);
 		ClearFiltersButton.click();
 		waitForPageToLoad();
 		wait(15);
 		StuNumDropDown.click();
 		waitForPageToLoad();
 		wait(1);
 		StuNumFilter.click();
 		waitForPageToLoad();
 		wait(1);
 		value.clearAndType(data.get("Student Number"));
 		waitForPageToLoad();
 		wait(1);
 		FilterButton.click();
 		wait(10);
 		ClickStudentName.click();
 		wait(15);
 		//StudentAccounts.click();
 		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
 		wait(2);
 		Subsidiary.clickUsingJavaScriptExecutor();
 		wait(15);
 		SelSubsidery.clickUsingJavaScriptExecutor();
 		wait(3);
 		ClkSubsidery.clickUsingJavaScriptExecutor();
 		wait(3);
 		addcharge.clickUsingJavaScriptExecutor();
 		wait(10);
 		/*AddSubsidery.click();
 		wait(2);
 		Subsidery.click();
 		wait(2);
 		SerachSubsidery.clearAndType(data.get("Subsidery Name").toString());
 		wait(2);
 		SelSubsidery.click();
 		wait(2);
 		EntMaintainedBalance.sendKeys("Balance Value");
 		wait(2);
 		SubSave.click();
 		wait(2);*/
 		AcademicYear.click();
 		wait(2);
 		SelAcademicyear.clickUsingJavaScriptExecutor();
 		wait(2);
 		TermList.clickUsingJavaScriptExecutor();
 		wait(2);
 		SearchCode.clearAndType(data.get("Enter Term").toString());
 		wait(3);
 		Term.clickUsingJavaScriptExecutor();
 		wait(2);
 		SelectButton.click();
 		wait(2);
 		Billcode.click();
 		wait(10);
 		//SearchBillcode.sendKeys(data.get("Bill Code Name"));
 		//wait(5);
 		SelBillcode.clickUsingJavaScriptExecutor();
 		wait(5);
 		Amount.sendKeys(data.get("Amount Value"));
 		wait(7);
 		SaveAndClose.clickUsingJavaScriptExecutor();
 		waitForPageToLoad();
 		wait(10);
 		return this;
	}
        
   public StudentSubsidiaryPage PostChargeDel(StringHash data) throws Exception {
	   Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		
		//Login Page Web Elements
		waitForPageToLoad();
		//wait(20);
		//MenuButton.click();
		//wait(5);
		//Students.click();
		//waitForPageToLoad();
		wait(15);
		FilterDropDwon.click();
		wait(1);
		ClearFiltersButton.click();
		waitForPageToLoad();
		wait(15);
		StuNumDropDown.click();
		waitForPageToLoad();
		wait(1);
		StuNumFilter.click();
		waitForPageToLoad();
		wait(1);
		value.clearAndType(data.get("Student Number"));
		waitForPageToLoad();
		wait(1);
		FilterButton.click();
		wait(20);
		ClickStudentName.click();
		wait(15);
		//StudentAccounts.click();
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		wait(2);
		Subsidiary.clickUsingJavaScriptExecutor();
		wait(15);
		SelSubsidery.clickUsingJavaScriptExecutor();
		wait(3);
		ClkSubsidery.clickUsingJavaScriptExecutor();
		wait(5);
		ClsFilterDropDwon.click();
		wait(2);
		ClsClearFiltersButton.click();
		wait(15);
		TeDropDown.click();
		wait(2);
		TerNumFilter.click();
		wait(2);
		value.clearAndType(data.get("Code"));
		wait(3);
		CFilterButton.clickUsingJavaScriptExecutor();
		wait(5);
		SelCharge.click();
		wait(3);
		More.click();
		wait(2);
		Delete.click();
		wait(2);
		DeleteNote.clearAndType(data.get("Delete Note").toString());
		wait(3);
		Deletebutton.click();
		wait(5);
		return this;
	}
   
   public StudentSubsidiaryPage SubsidiaryPostCharge(StringHash data) throws Exception {
		Link AdjustSubMsg= new Link("Post charge Subsidiary Msg", byXPath("//span[text()='The Transaction records were successfully saved.']"));
		Link SelectSubsidiary = new Link("Selecting Subsidiary", byXPath("//span[. = ' LAPTOPDE ']"));
		Checkbox Term = new Checkbox("Selecting Term", byXPath("(//tbody/tr[1]/td[1]/input)[1]"));
		Link SelectingBillCode= new Link("Selectecting billcode", byXPath("(//ul[@id='billingTransactionCode_listbox']/li[1]/span/div/span)[1]"));
		Link SelectingSubsidiary = new Link("Selecting Subsidiary", byXPath("//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/span/div/span[1]"));
		//Login Page Web Elements
		waitForPageToLoad();
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		StudentStudentPage.StudentAccounts.clickUsingJavaScriptExecutor();
		Subsidiary.clickUsingJavaScriptExecutor();
		wait(25);
		GettingSubsidiaryName.click();
		wait(2);
		SelectingSubsidiary.click();
		wait(3);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(1);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(2);
		StudentLedgerAccountPage.AddCharge.click();
      wait(6);
      TermList.clickUsingJavaScriptExecutor();
      wait(3);
      //SearchCode.clearAndType(data.get("TermCode"));
      //wait(3);
      if(Term.isSelected())
      {
          String SelectedTerm = Term.getAttribute("aria-label");
   	   System.out.println("Term is already selected");
          TestReportsLog.log(LogStatus.INFO, "Selected Term is "+SelectedTerm);
          StudentLedgerAccountPage.CancelButton.clickUsingJavaScriptExecutor();
      }else {
          Term.clickUsingJavaScriptExecutor();
          wait(2);
          String SelectedTerm = Term.getAttribute("aria-label");
   	   System.out.println("Term is selected");
          TestReportsLog.log(LogStatus.INFO, "Selected Term is "+SelectedTerm);
          SelectButton.clickUsingJavaScriptExecutor();
          //System.out.println("Task template is not matching");
      }
      wait(2);
      StudentLedgerAccountPage.BillCode.click();
      wait(2);
      //StudentLedgerAccountPage.SearchBillCode.waitTillElementClickable();
      //StudentLedgerAccountPage.SearchBillCode.sendKeys(data.get("BillCode"));
      SelectingBillCode.click();
      String SelectedBillCode = SelectingBillCode.getAttribute("title");
	   System.out.println(SelectedBillCode);
      TestReportsLog.log(LogStatus.INFO, "Selected BillCode is "+SelectedBillCode);
      wait(2);
      //StudentLedgerAccountPage.SelectingBillCode.click();
      //wait(3);
      Amount.sendKeys("100");
      wait(5);
      scrollPage(0, -300);
      wait(1);
      SaveAndClose.click();
      wait(5);
      CustomAsserts.containsString(StudentLedgerAccountPage.PostingChargeMsg.getText(), data.get("PostingChargeMsg").toString());
		return this;
	}
   
   public StudentSubsidiaryPage SubsidiaryLedgerPostCharge(StringHash data) throws Exception {

		//X-path Parameterization	
			Checkbox Term = new Checkbox("Selecting Term", byXPath("//tr[1]/td/input"));
			Link SubsideryPostChargeSaveMessage = new Link("Subsidiary PostCharge SaveMessage", byXPath("//span[. = 'The Charge records were successfully saved.']"));			
			Link ClkSubsidery = new Link("Subsidiary select", byXPath("(//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/span/div/span)[1]"));
			Link SelBillcode = new Link("BillCode", byXPath("(//ul[@id='billingTransactionCode_listbox']/li/span/div/span[2])[1]"));
			Link StudentAccounts = new Link("StudentAccounts", byXPath("//cns-panel-bar/ul/li[6]/a/span"));
			Link Subsidiary = new Link("Subsidiary tile", byXPath("//span[. = 'Subsidiary']"));
			//Link SelSubsidery = new Link("Subsidery", byXPath("//span[@aria-label='Subsidiary: Dropdown']"));
			Link SelSubsidery = new Link("Subsidiary add", byXPath("(//span[@aria-label='select'])[2]"));
			Link addcharge = new Link("Add charge", byXPath("//button[@id='newChargeButton']"));
			//Link AcademicYear = new Link("Academic Year", byXPath("//span[@aria-label='Academic Year: Dropdown']"));
			Link AcademicYear = new Link("Academic Year", byXPath("//span[contains(@aria-label,'Academic Year')]"));
			//TextField Billcode = new TextField("Billcode", byXPath("//span[@aria-label='Bill Code: Dropdown']"));
			TextField Billcode = new TextField("Billcode", byXPath("//span[contains(@aria-label,'Bill Code')]"));
			Link SelAcademicyear = new Link("AcademicYear select", byXPath("//span[@title=\"1\"]"));
			Link TermList= new Link("Term list", byXPath("//div[@id='search_display_termId']"));
			Button SelectButton = new Button("Select button", byXPath("//button[text()='Select']"));
			TextField Amount = new TextField("Amount subsidiary", byXPath("(//input[@aria-label='Amount'])[1]"));
			Button SaveAndClose = new Button("Save and Close", byXPath("(//button[@aria-label= 'Save & Close'])[2]"));
					
		//Method Implementation
			//waitForPageToLoad();
			StudentAccounts.waitTillElementClickable();
			StudentAccounts.click();
			wait(3);
			Subsidiary.clickUsingJavaScriptExecutor();
			wait(10);
			SelSubsidery.clickUsingJavaScriptExecutor();
			wait(3);
			ClkSubsidery.click();
			wait(3);
			String ClkSubsidry = ClkSubsidery.getAttribute("title");
			TestReportsLog.log(LogStatus.INFO, "Subsidery name is selected as "+ClkSubsidry);
			addcharge.click();
			wait(2);
			//AcademicYear.click();
			wait(2);  	
			//SelAcademicyear.click();
			wait(2);
			//String SelAcdemicyear = SelAcademicyear.getAttribute("title");
			//TestReportsLog.log(LogStatus.INFO, "Academicyear Name is selected as "+SelAcdemicyear);
			wait(2);
			TermList.click();
			wait(2);
			Term.click();
			wait(2);
			SelectButton.click();
			wait(5);
			Billcode.click();
			wait(3);
			SelBillcode.clickUsingJavaScriptExecutor();
			wait(2);
			String SelBilcode = SelBillcode.getAttribute("title");
			TestReportsLog.log(LogStatus.INFO, "Billcode Name is selected as "+SelBilcode);
			wait(3);
			Amount.sendKeys("120");
			wait(3);
			SaveAndClose.clickUsingJavaScriptExecutor();
			wait(6);
			CustomAsserts.containsString(SubsideryPostChargeSaveMessage.getText(), data.get("SuccessMessage").toString());
			wait(2);
			return this;
		}
   
   public StudentSubsidiaryPage SubLedgerPostChargeDelete(StringHash data) throws Exception {

		//X-path Parameterization
			Link SubLedgerPostChargeDeleteSaveMessage = new Link("Subsidiary Ledger Post Charge Delete SaveMessage", byXPath("//span[. = 'The Student Subsidiary records were successfully deleted.']"));			
			Link ClkSubsidery = new Link(" Subsidiary", byXPath("(//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/span/div/span)[1]"));	 	 	   
			//Link SelCharge = new Link("Click Term Button", byXPath("(//span[text()='"+data.get("SelCharge")+"'])[1]"));
			Link SelCharge = new Link("Term Button", byXPath("(//tr/td[1])[1]"));
			TextField DeleteCharge = new TextField("Delete Charge", byXPath("//textarea[@name='studentTransactionNote']"));
			TextField DeleteNote = new TextField("Delete note", byXPath("(//div/textarea[@aria-label='Note'])[1]"));
			Link StudentAccounts = new Link("Student Accounts", byXPath("//cns-panel-bar/ul/li[6]/a/span"));
			Link Subsidiary = new Link("Subsidiary", byXPath("//span[. = 'Subsidiary']"));
			//Link SelSubsidery = new Link("Select Subsidiary", byXPath("//span[@aria-label='Subsidiary: Dropdown']"));
			Link SelSubsidery = new Link("Select Subsidiary", byXPath("(//span[@aria-label='select'])[2]"));
			Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("(//div[@id='cnsSubsidiaryTransactionGrid_cnsToolbar_kendoToolBar_settingsButton_wrapper']/button)[2]"));
        	//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
        	Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//li[@id='cnsSubsidiaryTransactionGrid_cnsToolbar_kendoToolBar_clearFiltersButton']"));
			Link More= new Link("More", byXPath("//span[text()='More']"));
		    Button Delete = new Button("Delete icon", byXPath("//li[@id='deleteTransactionButton']"));
		    Button Deletebutton = new Button("Delete button", byXPath("//button[@id='okDelete']"));
		    
		    AngDropDown Transaction = new AngDropDown("Transaction", byXPath("//*[@title='Transaction edit column settings']/span"));
		    
		//Method Implementation
			//waitForPageToLoad();
		    StudentAccounts.waitTillElementClickable();
			StudentAccounts.click();
			wait(3);
			Subsidiary.clickUsingJavaScriptExecutor();
			wait(15);
			SelSubsidery.clickUsingJavaScriptExecutor();
			wait(3);
			ClkSubsidery.click();
			wait(3);
			String ClkSubsidry = ClkSubsidery.getAttribute("title");
			TestReportsLog.log(LogStatus.INFO, "Subsidiary name is selected as "+ClkSubsidry);
			wait(5);
			ClsFilterDropDwon.click();
			wait(2);
			ClsClearFiltersButton.click();
			wait(4);
			Transaction.clickUsingJavaScriptExecutor();
			wait(2);
			StudentLedgerAccountPage.Filter1.click();
			wait(4);
			StudentLedgerAccountPage.Value1.clearAndType(data.get("PaymentName"));
			wait(2);
			StudentLedgerAccountPage.Filterbutton.click();
			wait(5);
			SelCharge.click();
			wait(3);
			More.click();
			wait(2);
			Delete.click();
			wait(2);
			//DeleteNote.clearAndType(data.get("Delete Note").toString());
			DeleteCharge.clickUsingJavaScriptExecutor();
			wait(2);
			DeleteNote.clearAndType("Delete");
			wait(3);
			Deletebutton.click();
			wait(5);
			CustomAsserts.containsString(SubLedgerPostChargeDeleteSaveMessage.getText(), data.get("SuccessMessage").toString());
			wait(2);
			return this;
		}
    
   public StudentSubsidiaryPage SubTransactionVoid(StringHash data) throws Exception {

		//X-path Parameterization
			Link SubTransVoidSaveMessage = new Link("Subsidiary Transaction Void SaveMessage", byXPath("//span[. = 'The Student Subsidiary records were successfully voided.']"));			
			Link ClkSubsidery = new Link("Subsidiary", byXPath("(//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/span/div/span)[1]"));
			//Link SelCharge = new Link("Term Button", byXPath("//span[. = '120.00 ']"));
			Link SelectTransaction = new Link("Choose Transaction", byXPath("//td[. = 'CASH/']"));
			TextField DeleteCharge = new TextField("Delete Charge", byXPath("//textarea[@name='studentTransactionNote']"));
			TextField DeleteNote = new TextField("Delete note", byXPath("(//div/textarea[@aria-label='Note'])[1]"));
			Link StudentAccounts = new Link("Student Accounts", byXPath("//cns-panel-bar/ul/li[6]/a/span"));
			Link Subsidiary = new Link("Subsidiary", byXPath("//span[. = 'Subsidiary']"));
			//Link SelSubsidery = new Link("Select Subsidiary", byXPath("//span[@aria-label='Subsidiary: Dropdown']"));
			Link SelSubsidery = new Link("Select Subsidiary", byXPath("(//span[@aria-label='select'])[2]"));
			//Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("//cmc-common-toolbar/div/div[1]/button[1]"));
			//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("(//div//span[. = 'Reset to Default'])[1]"));
			Link More= new Link("More", byXPath("//span[text()='More']"));
			AngDropDown TransactionDropDown = new AngDropDown("Transaction Number Dropdown", byXPath("(//span[@class='k-icon k-i-more-vertical'])[8]"));
			AngDropDown TransactionFilter = new AngDropDown("Transaction Number Filter", byXPath("//span[text()='Filter']"));
			AngDropDown TrDropDown = new AngDropDown("Transaction Number Dropdown", byXPath("(//span[@class='k-icon k-i-more-vertical'])[8]"));
		    Button TerNumFilter = new Button("Term Num Filter", byXPath("//span[.='Filter']"));
		    TextField Cvalue = new TextField("Enter Value", byXPath("(//input[@title='Value'])[3]"));
		    Button CFilterButton = new Button("Filter Button", byXPath("//button[text()='Filter']"));
		    TextField value = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
		    Button FilterButton = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));
		    Button Void = new Button("Void", byXPath("//span[text()='Void']"));
		    TextField VoidNote = new TextField("Void Note", byXPath("(//div/textarea[@id='studentTransactionVoidPaymentNote'])[1]"));
		    Button VoidButton = new Button("Void button", byXPath("//button[@id='okVoidPayment']"));
		    Link SelCharge = new Link("Term Button", byXPath("(//tr[1]/td[1])[1]"));
		    
		    Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("(//div[@id='cnsSubsidiaryTransactionGrid_cnsToolbar_kendoToolBar_settingsButton_wrapper']/button)[2]"));
        	//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
        	Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//li[@id='cnsSubsidiaryTransactionGrid_cnsToolbar_kendoToolBar_clearFiltersButton']"));
		    
		//Method Implementation
			//waitForPageToLoad();
		    StudentAccounts.waitTillElementClickable();
			StudentAccounts.click();
			wait(2);
			Subsidiary.click();
			wait(40);
			SelSubsidery.click();
			wait(2);
			ClkSubsidery.click();
			wait(5);
			ClsFilterDropDwon.click();
			wait(2);
			ClsClearFiltersButton.click();
			wait(5);	
			Transaction.clickUsingJavaScriptExecutor();
			wait(10);
			StudentLedgerAccountPage.Filter1.click();
			wait(2);
			StudentLedgerAccountPage.Value1.clearAndType(data.get("PaymentName"));
			wait(2);
			StudentLedgerAccountPage.Filterbutton.click();
			wait(5);
			SelCharge.click();
			
//			TransactionDropDown.click();
//			wait(2);
//			TransactionFilter.click();
//			wait(2);
//			value.clearAndType(PaymentTransactionName);
//			wait(2);
//			FilterButton.click();
//			wait(3);
//			SelectTransaction.click();
			wait(3);
			More.click();
			wait(3);
			Void.click();
			wait(3);
			VoidNote.clearAndType("Void");
			wait(3);
			VoidButton.click();
			wait(5);
			CustomAsserts.containsString(SubTransVoidSaveMessage.getText(), data.get("SuccessMessage").toString());
			wait(2);
			return this;
		}
   
   public StudentSubsidiaryPage SubLedgerPostPayment(StringHash data) throws Exception {

		//X-path Parameterization
			Link StudentAccounts = new Link("Student Accounts", byXPath("//cns-panel-bar/ul/li[6]/a/span"));		     	
			Link SubsideryPostPaymentSaveMessage = new Link("Subsidiary Post Payment SaveMessage", byXPath("//span[. = 'The Transaction records were successfully saved.']"));			
			Link SelPaymentMethod = new Link("Payment Method", byXPath("//ul[@id='paymentType_listbox']/li[1]/span"));
			Link SelCashDrawer = new Link("CashDrawer", byXPath("//ul[@id='cashDrawerSessionId_listbox']/li[1]"));
			Link ClkSubsidery = new Link("Subsidiary", byXPath("(//ul[@id='subsidiaryAccountTypeId_listbox']/li[1]/span/div/span)[1]"));
			Link Subsidiary = new Link("Subsidiary", byXPath("//span[. = 'Subsidiary']"));
			//Link SelSubsidery = new Link("Subsidery", byXPath("//span[@aria-label='Subsidiary: Dropdown']"));
			Link SelSubsidery = new Link("Subsidiary", byXPath("(//span[@aria-label='select'])[2]"));
			Link Payment = new Link("Payment", byXPath("//button[6][. = 'Payment']"));
			Link TermList= new Link("Term list", byXPath("//div[@id='search_display_termId']"));
			Button SelectButton = new Button("Select button", byXPath("//button[text()='Select']"));
			Link PaymentMethod = new Link("Payment Method", byXPath("//span/span/span[. = 'Check']"));
			TextField Amount1 = new TextField("Amount", byXPath("(//input[@aria-label='Amount'])[1]"));
			Button SaveAndClose = new Button("Save and Close", byXPath("(//button[@aria-label= 'Save & Close'])[2]"));
			Checkbox Term = new Checkbox("Selecting Term", byXPath("(//tr//td//input)[1]"));
			
			Link CashPaymentCode= new Link("CashPaymentCode", byXPath("//span[@aria-label='Cash Payment Code']"));
			Link CashPaymentCodeValue= new Link("CashPaymentCodeValue", byXPath("(//ul[@id='transactionNameDropDown_listbox']/li[1]/span/div/span)[2]"));
			
			Link BankAccount = new Link("BankAccount", byXPath("//span[@aria-label='Bank Account']"));
			Link BankAccountValue = new Link("BankAccountValue", byXPath("(//ul[@id='bankAccountId_listbox']/li/span/div/span)[1]"));
			
			
		//Method Implementation
			//waitForPageToLoad();
			StudentAccounts.waitTillElementClickable();
			StudentAccounts.clickUsingJavaScriptExecutor();
			wait(2);
			Subsidiary.clickUsingJavaScriptExecutor();
			wait(15);
			SelSubsidery.clickUsingJavaScriptExecutor();
			wait(3);
			ClkSubsidery.clickUsingJavaScriptExecutor();
			wait(3);
			String ClkSubsidry = ClkSubsidery.getAttribute("title");
			TestReportsLog.log(LogStatus.INFO, "Subsidiary name is selected as "+ClkSubsidry);
			wait(2);
			Payment.click();
			wait(10);
			//Password.clearAndType(data.get("Password1").toString());
			//wait(3);
			//Ok.click();
			//wait(2);
			TermList.click();
			wait(2);
			Term.click();
			wait(2);
			SelectButton.clickUsingJavaScriptExecutor();
			wait(5);
			//CashPaymentCode.clickUsingJavaScriptExecutor();
			wait(2);
			//CashPaymentCodeValue.clickUsingJavaScriptExecutor();
			wait(3);
			PaymentName.clearAndType("Student Payment");
//			PaymentName.clearAndType(PayName);
//			PaymentTransactionName=PayName;
			wait(3);
			PaymentMethod.click();
			wait(3);
			SelPaymentMethod.click();
			wait(2);
			String SelPaymentMetod = SelPaymentMethod.getAttribute("title");
			TestReportsLog.log(LogStatus.INFO, "Payment Method name is selected as "+SelPaymentMetod);
			wait(2);
			BankAccount.click();
			wait(2);
			BankAccountValue.click();
			//CashDrawer.click();
			wait(3);
			//SelCashDrawer.click();
			//wait(2);
			//String SelCashDrawr = SelCashDrawer.getAttribute("title");
			//TestReportsLog.log(LogStatus.INFO, "SelCashDrawername is selected as "+SelCashDrawr);
			//wait(2);
			Amount1.sendKeys("200");
			wait(7);
			scrollPage(0, 400);
			wait(3);
			//printreciept.click();
			//wait(3);
			scrollPage(0, -400);
			wait(3);
			SaveAndClose.click();
			wait(6);
			CustomAsserts.containsString(SubsideryPostPaymentSaveMessage.getText(), data.get("SuccessMessage").toString());
			wait(2);
			return this;
		}
    
   public StudentSubsidiaryPage SubPostRefundForStudent(StringHash data) throws Exception {

		//X-path Parameterization
			Link SubPostRefundSaveMessage = new Link("Subsidiary Post Refund SaveMessage", byXPath("//span[. = 'The Refund records were successfully saved.']"));			
			Link RefundSource = new Link("RefundSource", byXPath("//td[. = '"+data.get("RefundSource")+"']"));
			Link SelTermField = new Link("TermField", byXPath("//ul[@id='termId_listbox']/li[1]/span/div/span[1]"));
			Link StudentAccounts = new Link("StudentAccounts", byXPath("//cns-panel-bar/ul/li[6]/a/span"));
			Link Subsidiary = new Link("Subsidiary", byXPath("//span[. = 'Subsidiary']"));
			Button Refund = new Button("Refund", byXPath("//button[. = 'Refunds']"));
			AngDropDown TeDropDown = new AngDropDown("Term Number Dropdown", byXPath("//a[@title='Source edit column settings']/span"));
			AngDropDown TrFilter = new AngDropDown("Filter Dropdown", byXPath("(//span[text()='Filter'])[1]"));
			AngDropDown TrDropDown = new AngDropDown("Term Number Dropdown", byXPath("(//span[@class='k-icon k-i-more-vertical'])[8]"));
		    Button TerNumFilter = new Button("Term Number Filter", byXPath("//span[.='Filter']"));
		    TextField Cvalue = new TextField("Value", byXPath("(//input[@title='Value'])[3]"));
		    Button CFilterButton = new Button("Filter Button", byXPath("//button[text()='Filter']"));
		    TextField value = new TextField("Value", byXPath("//input[@title='Value']"));
		    Button FilterButton = new Button("Filter Button", byXPath("//button/span[text()='Filter']"));
		    Button Next5 = new Button("Next", byXPath("//button[. = 'Next']"));
		    Link TermField = new Link("TermField", byXPath("//div/cmc-drop-down-list/div/div/span/button"));
		    TextField DueDate = new TextField("DueDate", byXPath("(//input[@placeholder='MM/DD/YYYY'])[2]"));
		    Button PostSchedule = new Button("PostSchedule", byXPath("(//button[@aria-label='Post/Schedule'])[2]"));
		    TextField Amount1 = new TextField("Amount", byXPath("(//input[@aria-label='Amount'])[1]"));
		    
		//Method Implementation
			//waitForPageToLoad();
		    StudentAccounts.waitTillElementClickable();
			StudentAccounts.click();
			wait(2);
			Subsidiary.click();
			wait(35);
			Refund.clickUsingJavaScriptExecutor();
			wait(5);
			TeDropDown.click();
			wait(2);
			TrFilter.click();
			wait(2);
			value.clearAndType(data.get("RefundSource"));
			wait(4);
			FilterButton.click();
			wait(5);
			RefundSource.click();
			wait(7);
			Next5.click();
			wait(7);
			scrollPage(0, 600);
			wait(7);
			TermField.clickUsingJavaScriptExecutor();
			wait(3);
			SelTermField.click();
			wait(3);
			DueDate.clearAndType(Date);
			wait(3);
			Amount1.sendKeys("1");
			wait(5);
			PostSchedule.click();
			wait(7);
			CustomAsserts.containsString(SubPostRefundSaveMessage.getText(), data.get("SuccessMessage").toString());
			wait(2);
			return this;
		}

}





