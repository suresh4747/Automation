package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byXPath;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import static com.framework.elements.Locator.byCSSSelector;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByCssSelector;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentStudentPage extends BasePage {

	static String LastNameValue = AppendValue.apendString();
	static String FirstNameValue = AppendValue.apendString();
	static Link New_Prospect = new Link("New Prospect", byCSSSelector("#listAddProspectButton"));
	static TextField LastName = new TextField("Last Name Field", byCSSSelector("#LastName"));
	static TextField FirstName = new TextField("First Name Field", byXPath("//div[2]/div/div//input"));
	static TextField Zip_Code = new TextField("Zip code", byCSSSelector("[name='Zip_input']"));
	//static Link SelectingZipCode = new Link("Selecting ZipCode", byXPath("//span[. = '00501']"));
	//static TextField PhoneNumber = new TextField("Phone number", byXPath("//input[@id='Phone']"));
	static TextField PhoneNumber = new TextField("Phone number", byXPath("//input[@placeholder = '(###) ###-####']"));
	static TextField Email = new TextField("Email", byXPath("//input[@name='email']"));
	static Link SaveandClose = new Link("Save & Close", byXPath("//div/a[. = 'Save & Close']"));
	static Button Dontsave = new Button("Don't Save", byXPath("//button[. = concat('Don', \"'\", 't Save')]"));
	static TextField SearchName = new TextField("Search Name", byXPath("//input[@placeholder='Search Name']"));
	//static Link SelectingStudent = new Link("Selecting Student", byXPath("//span[text()='Testing, Regression']"));
	static Link SelectingStudent = new Link("Selecting Student", byXPath("//div[2]//td[1]"));
	static Link ContactManager = new Link("Contact Manager", byXPath("//cns-panel-bar/ul/li[1]/a/span"));
	static Link Admissions = new Link("Admissions", byXPath("//cns-panel-bar/ul[1]/li[2]/a/span"));
	static Link AcademicRecords = new Link("Academic records", byXPath("//cns-panel-bar/ul[1]/li[3]/a/span"));
	static Link CareerServices = new Link("Careerservices", byXPath("//cns-panel-bar/ul[1]/li[4]/a/span"));
	static Link FinancialAid = new Link("Financial Aid", byXPath("//cns-panel-bar/ul[1]/li[5]/a/span"));
	static Link StudentAccounts = new Link("Student Accounts", byXPath("//cns-panel-bar/ul[1]/li[6]/a/span"));
	static Link StudentServices = new Link("Student Services", byXPath("//cns-panel-bar/ul/li[7]/a/span"));
	static Link Tasks = new Link("Tasks", byXPath("//span[text()='Tasks']"));
	static Button NewButton = new Button("New TaskTemplate", byXPath("//button[@id='newButton']"));
	static TextField TaskTemplate = new TextField("Task Template", byXPath("//input[@name='taskTemplateId_input']"));
	//static Link SelectingTaskTemplate= new Link("Selecting TaskTemplate", byXPath("//span[. = 'Duplicate Lead']"));
	static Link SaveAndCloseTask= new Link("Save and close Task", byXPath("(//button[@aria-label= 'Save & Close'])[2]"));
	static Link Documents = new Link("Documents", byXPath("//span[text()='Documents']"));
	static Link NewDocument = new Link("New Document", byXPath("(//button[@id='studentDocumentsAddButton'])[1]"));
	static Link NewDocumentList = new Link("New DocumentList", byXPath("//a[text()='New Document List']"));
	static TextField Module = new TextField("Module", byXPath("(//input[@aria-label='studentDocModule'])[1]"));
	static Link SelectingModule= new Link("Selecting Module", byXPath("(//span[text()=\"Career Services\"])[1]"));
	static TextField DocumentList = new TextField("Document List", byXPath("//input[@name='studentDocName_input']"));
	static Link SelectingDocumentList= new Link("Selecting Document List", byXPath("//span[text()='Fakey Doc List']"));
	static TextField Document = new TextField("Document", byXPath("(//button[@aria-label='expand combobox'])[6]"));
	//static Link SelectingDocument= new Link("Selecting Document", byXPath("//span[text()='NewDocument']"));
	static TextField DocumentStatus = new TextField("Document Status", byXPath("(//button[@aria-label='expand combobox'])[7]"));
	static Link SelectingDocumentStatus= new Link("Selecting Document Status", byXPath("//span[text()='NOTSENT']"));
	static Link SaveAndCloseDocument= new Link("Save and close document", byXPath("//button[@id='studentDocumentSaveAnCloseButton']"));
	static Link Filter= new Link("Filter", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
	static Link ClearFilter= new Link("Clear Filters", byXPath("//li[@id='listClearFiltersButton']"));
	static Button Filtericon = new Button("Filter icon", byXPath("//div[2]/a[2]"));
	static Link ClearFilters= new Link("Clear Filters", byXPath("(//a[text()='Clear Filters'])[2]"));
	static AngDropDown TaskTemplatedrpdwn= new AngDropDown("Task template dropdown", byXPath("//th[1]/a[1]/span"));
	static Button Filteroption= new Button("Filteroption", byXPath("//span[text()='Filter']"));
	static TextField FilterValue = new TextField("Filter Value",byXPath("//input[@title='Value']"));
	static Button Filterbutton = new Button("Filter icon", byXPath("//button[. = 'Filter']"));
	static Link Tablevalue= new Link("Table value", byXPath("//td/a"));
	static AngDropDown Documentlistdrpdwn= new AngDropDown("Documentlist dropdown", byXPath("//th[2]/a[1]/span"));
	static Link saveAndCloseDocumentLisLink= new Link("Save and close document list", byXPath("//button[@id='studentDocumentListSaveAnCloseButton']"));
	static Link StudentSpan = new Link("Click on student span", byXPath("//td/span"));

	public StudentStudentPage SelectStudent(StringHash data) throws Exception {
		// Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));
		//
		//       // Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		//        Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("FullName")+"']"));
		//        Link Filter= new Link("Filter", byXPath("//div[@id='listSettingsButton_wrapper']"));
		//        Link ClearFilter= new Link("Clear Filters", byXPath("//a[@id='listClearPreferencesButton']"));
		//        
		//        //setImplicitWaitTimeout(getImplicitWaitTimeout());
		//       // driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		//        //wait(40);
		//        Filter.waitTillElementIsStale();
		//        Filter.click();
		//        wait(3);
		//        ClearFilter.click();
		//        wait(5);
		//        SearchName.waitTillElementClickable();
		//        SearchName.clearAndType(data.get("FullName").toString());
		//        wait(4);
		//        //SearchName.clearAndType(FirstNameValue);
		//        SelectingStudent1.clickUsingJavaScriptExecutor();
		//        //wait(25);
		Link Filter= new Link("Filter", byXPath("(//div[@id='listSettingsButton_wrapper']/button)[2]"));
		//Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));
		//AngDropDown SSNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='Ssn']/a/span"));	
		AngDropDown SNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='StudentNumber']/a/span"));	
		Link StudentNumRadioButton= new Link("StudentNumRadioButton", byXPath("//div[@id='radioGroup container-horizontal']/div/div[2]"));
		TextField StudentNumValue = new TextField("StudentNumValue", byXPath("//input[@name='panelStudentNumber']"));
		Button ApplyFilter = new Button("ApplyFilter", byXPath("//button[text()='Apply Filter']"));
		Button ClearFilter1 = new Button("ClearFilter", byXPath("//button[text()='Clear Filter']"));
		//Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		//setImplicitWaitTimeout(getImplicitWaitTimeout());
		//waitForPageToLoad();
		//wait(5);
		//Filter.waitTillElementIsStale();
		//waitForPageToLoadNew();
		//Filter.waitTillElementClickableNew();
		//Filter.waitTillElementClickable();
		//Filter.waitTillElementIsStale();
		wait(30);
		Filter.click();
		wait(3);
		ClearFilter.click();
		wait(5);
		ClearFilter1.clickUsingJavaScriptExecutor();
		wait(4);
		StudentNumRadioButton.click();
		wait(2);
		StudentNumValue.click();
		wait(1);
		StudentNumValue.clearAndType(data.get("StudentNumber"));
		wait(1);
		ApplyFilter.clickUsingJavaScriptExecutor();
		wait(10);
		//    	SNdrpdwn.click();
		//    	wait(2);
		//    	Filteroption.click();
		//    	wait(2);
		//    	FilterValue.clearAndType(data.get("StudentNumber"));
		//    	wait(2);
		//    	Filterbutton.click();
		//    	wait(5);
		StudentSpan.click();
		//wait(25);

		return this;        
	}

	public StudentStudentPage SelectStudentusingSN(StringHash data) throws Exception {

		Link Filter= new Link("Filter", byXPath("//div[@id='listSettingsButton_wrapper']"));
		Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));
		//AngDropDown SSNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='Ssn']/a/span"));	
		AngDropDown SNdrpdwn= new AngDropDown("SSN dropdown", byXPath("//th[@data-field='StudentNumber']/a/span"));

		Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		//setImplicitWaitTimeout(getImplicitWaitTimeout());
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		wait(40);
		Filter.clickUsingJavaScriptExecutor();
		ClearFilter.clickUsingJavaScriptExecutor();
		wait(5);
		SNdrpdwn.click();
		wait(2);
		Filteroption.click();
		wait(2);
		FilterValue.clearAndType(data.get("StudentNumber"));
		wait(2);
		Filterbutton.click();
		wait(8);
		SelectingStudent1.clickUsingJavaScriptExecutor();
		//wait(25);

		return this;        
	}

	public StudentStudentPage CreateProspect(StringHash data) throws Exception {
		Dropbox Location = new Dropbox("Location", byXPath("//li[1]//span[. = '"+data.get("Postalcode")+"']"));
		///Dropbox Location = new Dropbox("Location", byXPath("//input[@aria-label='"+data.get("Campus")+"']"));
		Link SelectingZipCode1 = new Link(data.get("Postalcode"), byXPath("//span[. = '"+data.get("Postalcode")+"']"));
		Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));

		waitForPageToLoad();
		//Thread.sleep(30000);
		New_Prospect.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		wait(8);
		//String alphabet = "abc";
		//String s = RandomStringUtils.random(8, alphabet);
		LastName.waitTillElementFound();
		//LastName.clearAndType(s);
		LastName.clearAndType(LastNameValue);
		FirstName.clearAndType(FirstNameValue);
		//PhoneNumber.waitTillElementFound();
		//PhoneNumber.clearAndType(data.get("PhoneNumber").toString());
		Email.clearAndType(FirstNameValue+"@gmail.com");
		WebElement wb = driver.findElement(By.name("Phone"));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].value='(522)222-2222';", wb);
		Zip_Code.clearAndType(data.get("Postalcode").toString());
		wait(5);
		SelectingZipCode1.click();
		wait(5);

		//jse.executeScript("document.getElementById('ssn').value='555-55-5555';");
		//Location.waitTillElementFound();
		//Location.click();
		SaveandClose.click();
		Dontsave.waitTillElementFound();
		Dontsave.click();
		wait(20);
		Filter.clickUsingJavaScriptExecutor();
		wait(3);
		ClearFilter.clickUsingJavaScriptExecutor();
		SearchName.clearAndType(FirstNameValue);
		wait(3);
		String FullName=LastNameValue+", "+FirstNameValue;
		System.out.println(FullName);
		//Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='LastNameValue, FirstNameValue']"));
		String StudentName = SelectingStudent2.getText();
		System.out.println(StudentName);
		if(StudentName.equalsIgnoreCase(FullName))
		{
			System.out.println("Student data is matching");
		}else {
			System.out.println("Student data is not matching");
		}
		wait(1);

		return this;
	}

	public StudentStudentPage AddTaskToStudent(StringHash data) throws Exception {
		Link SelectingTaskTemplate1= new Link("Selecting TaskTemplate", byXPath("//span[. = '"+data.get("TaskTemplate")+"']"));
		Link SelectingStudent1 = new Link("Selecting Student", byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));

		waitForPageToLoad();
		wait(20);
		Filter.clickUsingJavaScriptExecutor();
		ClearFilter.clickUsingJavaScriptExecutor();
		wait(3);
		SearchName.waitTillElementClickable();
		//SearchName.clearAndType(data.get("FirstName").toString());
		SearchName.clearAndType("F");
		SelectingStudent2.clickUsingJavaScriptExecutor();
		wait(15);
		ContactManager.clickUsingJavaScriptExecutor();
		Tasks.clickUsingJavaScriptExecutor();
		NewButton.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		TaskTemplate.clearAndType(data.get("TaskTemplate").toString());
		wait(3);
		SelectingTaskTemplate1.click();
		SelectingTaskTemplate1.clickUsingJavaScriptExecutor();
		wait(5);
		SaveAndCloseTask.clickUsingJavaScriptExecutor();
		wait(5);
		waitForPageToLoad();
		scrollPage(0, -300);
		wait(2);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(2);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(5);
		TaskTemplatedrpdwn.click();
		wait(2);
		Filteroption.click();
		wait(2);
		FilterValue.clearAndType(data.get("TaskTemplate"));
		wait(2);
		Filterbutton.click();
		wait(2);
		String TaskTemplate = Tablevalue.getText();
		System.out.println(TaskTemplate);
		if(TaskTemplate.equalsIgnoreCase(data.get("TaskTemplate")))
		{
			System.out.println("Task template id is matching");
		}else {
			System.out.println("Task template id not matching");
		}
		wait(1);

		return null;
	}

	public StudentStudentPage AddDocumentToStudent(StringHash data) throws Exception {
		Link SelectingDocument1= new Link("Selecting document", byXPath("//ul[@id='studentDocName_listbox']/li[1]/span/div/span[1]"));
		Link SelectingDocumentStatus1= new Link("Selecting Document Status", byXPath("//ul[@id='studentDocStatus_listbox']/li[1]/span/div/span[1]"));
		//Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));
		Link SelectingModule= new Link(data.get("ModuleName"), byXPath("(//span[text()='"+data.get("ModuleName")+"'])[1]"));
		Link AddDocStudMsg= new Link("Add Document to Student", byXPath("//span[text()='The Document records were successfully saved.']"));
		TextField Module = new TextField("Module", byXPath("//input[@name='studentDocModule_input']"));
		Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("FullName")+"']"));

		//waitForPageToLoad();
		//wait(30);
		//		Filter.waitTillElementIsStale();
		//		Filter.clickUsingJavaScriptExecutor();
		//		wait(3);
		//		ClearFilter.clickUsingJavaScriptExecutor();
		//		wait(3);
		//		SearchName.waitTillElementClickable();
		//		SearchName.clearAndType(data.get("FullName").toString());
		//		//SearchName.clearAndType(FirstNameValue);
		//		//SelectingStudent2.clickUsingJavaScriptExecutor();
		//		wait(6);
		//		SelectingStudent1.clickUsingJavaScriptExecutor();
		//		waitForPageToLoad();
		wait(8);
		ContactManager.waitTillElementClickable();
		ContactManager.clickUsingJavaScriptExecutor();
		wait(2);
		Documents.clickUsingJavaScriptExecutor();
		wait(5);
		NewDocument.clickUsingJavaScriptExecutor();
		wait(10);
		//Module.clickUsingJavaScriptExecutor();
		Module.clearAndType(data.get("ModuleName"));
		wait(1);
		SelectingModule.clickUsingJavaScriptExecutor();
		String SelectedModule = SelectingModule.getAttribute("title");
		System.out.println(SelectedModule);
		TestReportsLog.log(LogStatus.INFO, "Selected Module is "+SelectedModule);
		//wait(2);
		Document.click();
		wait(2);
		SelectingDocument1.click();
		String SelectedDocument = SelectingDocument1.getAttribute("title");
		System.out.println(SelectedDocument);
		TestReportsLog.log(LogStatus.INFO, "Selected Document is "+SelectedDocument);
		//wait(6);
		DocumentStatus.click();
		wait(3);
		SelectingDocumentStatus1.click();
		String SelectedDocumentStatus = SelectingDocumentStatus1.getAttribute("title");
		System.out.println(SelectedModule);
		TestReportsLog.log(LogStatus.INFO, "Selected Document status is "+SelectedDocumentStatus);
		//wait(1);
		SaveAndCloseDocument.click();
		wait(7);
		CustomAsserts.containsString(AddDocStudMsg.getText(), data.get("AddDocStudMsg").toString());
		/*waitForPageToLoad();
		scrollPage(0, -300);
		wait(2);
		Filtericon.clickUsingJavaScriptExecutor();
		wait(2);
		ClearFilters.clickUsingJavaScriptExecutor();
		wait(5);
		Documentlistdrpdwn.click();
		wait(2);
		Filteroption.click();
		wait(2);
		FilterValue.clearAndType(data.get("DocumentName"));
		wait(2);
		Filterbutton.click();
		wait(2);
		String DocumentName = Tablevalue.getText();
		System.out.println(DocumentName);
		System.out.println(data.get("DocumentName"));
		if(DocumentName.equalsIgnoreCase(data.get("DocumentName")))
		{
			System.out.println("Document name is matching");
		}else {
			System.out.println("Document name is not matching");
		}*/
		wait(1);

		return null;
	}

	public StudentStudentPage AddDocumentListToStudent(StringHash data) throws Exception {

		Link SelectingDocumentStatus1= new Link("Selecting Document Status", byXPath("//ul[@id='studentDocStatus_listbox']/li[1]/span/div/span[1]"));
		Link SelectingStudent1 = new Link(data.get("FullName"), byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		//Link SelectingStudent2 = new Link("Selecting Student", byXPath("//span[text()='"+LastNameValue+", "+FirstNameValue+"']"));
		Link SelectingModule= new Link(data.get("ModuleName"), byXPath("(//span[text()='"+data.get("ModuleName")+"'])[2]"));
		Link AddDocStudMsg= new Link("Add Document to Student", byXPath("//span[text()='The Document records were successfully saved.']"));
		//Link DocumentStatus = new Link("Document Status", byXPath("//span[@aria-controls='studentDocStatus_listbox']/span"));
		//Link DocumentStatus = new Link("Document Status", byXPath("(//button/span)[39]"));
		Link Doclist = new Link("Document list", byXPath("(//button/span)[38]"));
		Link selectDoclist = new Link("selecting Document list", byXPath("//span[text()='FA - General Document List']"));
		TextField Module = new TextField("Module", byXPath("//input[@name='studentDocModule_input']"));
		Link NewDocumentList = new Link("New DocumentList", byXPath("(//span[text()='New Document List'])[1]"));
		
		Link DocumentStatus = new Link("Document Status", byXPath("(//button[@aria-label='expand combobox'])[7]"));
		
		//waitForPageToLoad();
		wait(8); 
		ContactManager.waitTillElementClickable();
		ContactManager.clickUsingJavaScriptExecutor();
		wait(2);
		Documents.clickUsingJavaScriptExecutor();
		wait(10);
		NewDocumentList.click();
		wait(6);
		scrollPage(0, 500);
		wait(2);
		Module.clearAndType(data.get("ModuleName"));
		wait(2);
		SelectingModule.clickUsingJavaScriptExecutor();
		String SelectedModule = SelectingModule.getAttribute("title");
		System.out.println(SelectedModule);
		TestReportsLog.log(LogStatus.INFO, "Selected Module is "+SelectedModule);
		wait(3);
		DocumentStatus.click();
		wait(2);
		SelectingDocumentStatus1.click();
		wait(2);
		saveAndCloseDocumentLisLink.click();
		wait(6);
		CustomAsserts.containsString(AddDocStudMsg.getText(), data.get("AddDocStudMsg").toString());
		/*scrollPage(0, -300);
	wait(1);
	Filtericon.clickUsingJavaScriptExecutor();
	wait(2);
	ClearFilters.clickUsingJavaScriptExecutor();
	wait(5);
	Documentlistdrpdwn.click();
	wait(2);
	Filteroption.click();
	wait(2);
	FilterValue.clearAndType(data.get("DocumentType"));
	wait(2);
	Filterbutton.click();
	wait(2);
	String DocumentName = Tablevalue.getText();
	System.out.println(DocumentName);
	System.out.println(data.get("DocumentType"));
	if(DocumentName.equalsIgnoreCase(data.get("DocumentType")))
	{
		System.out.println("Document List name is matching");
	}else {
		System.out.println("Document List name is not matching");
	}*/
		wait(1);

		return null;
	}

}
