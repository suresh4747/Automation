package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byXPath;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.DatesUtil;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

import static com.framework.elements.Locator.byCSSSelector;
import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byName;


public class StudentFinancialAidPage extends BasePage{

	//WebElements of financial Aid 
	static Link FinancialAid = new Link("Financial Aid", byXPath("//cns-panel-bar/ul/li[5]/a/span"));
	static Link Awarding = new Link("Awarding", byXPath("//span[text()='Awarding']"));
	static AngDropDown Awarddropdown = new AngDropDown("Awards Drop Down", byXPath("//button[@id='cnsGridAwards_cnsToolbar_kendoToolBar_settingsButton']"));
	//static Button AwardClearFilter = new Button("Clear Filter", byXPath("//div//a[. = 'Clear Filters']"));
	static Button AwardClearFilter = new Button("Clear Filter", byXPath("//li[@id='cnsGridAwards_cnsToolbar_kendoToolBar_clearFiltersButton']"));
	static AngDropDown FSdropdown = new AngDropDown("Fund Source drop down", byXPath("(//a[@title=\"Fund Source edit column settings\"])[1]"));
	static Button FSFilter = new Button("Filter", byXPath("(//span[text()='Filter'])[1]"));
	static AngDropDown ClickEqualsTo = new AngDropDown("Equals To", byXPath("//div/span[1]/span/span[. = 'Is equal to']"));
	static Button ClickContains = new Button("Contains", byXPath("//div/div/div//li[. = 'Contains']"));
	static TextField FSValue = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
	static Button FSFilterButton = new Button("Filter Button", byXPath("//button[.=\"Filter\"]"));
	//static Button HighlightFundSource = new Button("HighLight Fund Source", byXPath("//td[.=\"Cash Payment from Student\"]"));	
	static Button Awards = new Button("Awards", byXPath("//button[.=\"Awards\"]"));
	//FAReassignment Web Elements
	//Checkbox CheckFundSource = new Checkbox("Fund Source", byXpath("//input[@aria-label="PELL"]"));
	static Link Reassign = new Link("Reassign", byId("awardReassignButton"));
	//static Button HighlightAcademicYear = new Button("Highlight Academic Year", byXPath("//td[. = '01/08/2018']"));
	static Button OkReassign = new Button("Reassign", byId("okTransferSectionr"));
	static Button ConfirmReassign = new Button("Confirm Reassign", byId("//button[@aria-label=\"Reassign\"]"));
	//static Button AYSpan = new Button("Academic Year Span", byXPath("//span[@aria-label=\"Academic Year: Dropdown\"]"));	
	static Button AYSpan = new Button("Academic Year Span", byXPath("//span[contains(@aria-label,'Academic Year')]"));
	//Award Summary Print Web Elements
	static Button PrintButton = new Button("Print Button", byId("printButton"));
	//Verify Disbursement Data Web Elements
	Button PaymentReceived = new Button("Payment Received tab", byXPath("//button[.=\"Payments Received\"]"));
	//Creation of Academic Year
	static Button AcademicYear = new Button("Academic Year", byXPath("//button[.=\"Academic Years\"]"));
	static Link NewAY = new Link("New AY", byId("newButton"));
	static Button Manual = new Button("Manual", byId("autoAwardingYearDialogNotOkButton"));
	static TextField AYStartdate = new TextField("AY startdate", byId("startDate"));
	static TextField AYEnddate = new TextField("AY Enddate", byId("endDate"));
	//static Button AwardYearSpan = new Button("Award Year Span", byXPath("//span[@aria-label=\"Award Year1: Dropdown\"]"));
	static Button AwardYearSpan = new Button("Award Year Span", byXPath("//span[contains(@aria-label,'Award Year1')]"));
	static TextField EnterAwardYear = new TextField("Award Year", byXPath("//input[@aria-owns=\"firstAwardYear_listbox\"]"));
	//static Button SelectAwardYear = new Button("Award Year", byXPath("(//li[text()=\"2022-23\"])[1]"));
	//static Button GradeLevelSpan = new Button("Grade Level Span", byXPath("//span[@aria-label=\"Grade Level: Dropdown\"]"));
	static Button GradeLevelSpan = new Button("Grade Level Span", byXPath("//span[contains(@aria-label,'Grade Level')]"));
	static TextField EnterGradeLevel = new TextField("Grade Level", byXPath("//input[@aria-owns=\"gradeLevelId_listbox\"]"));
	//static Button SelectGradeLevel = new Button("Grade Level", byXPath("//span[.=\"1st Year Freshman\"]"));
	//static TextField WeeksinAY = new TextField("Weeks in AY", byId("//input[@aria-label=\"Weeks in AY\"]"));
	static TextField MonthsinAY = new TextField("Months in AY", byId("monthsIncademicYear"));
	//static Button HousingSpan = new Button("Housing Span", byXPath("//span[@aria-label=\"Housing: Dropdown\"]"));
	static Button HousingSpan = new Button("Housing Span", byXPath("//span[contains(@aria-label,'Housing')]"));
	static TextField EnterHousing = new TextField("Housing", byXPath("//input[@aria-owns=\"housingStatusCode_listbox\"]"));
	//static Button SelectHousing = new Button("Housing", byXPath("//div/span[.=\"Off Campus\"]"));
	//static Button FAAdvisorSpan = new Button("FAAdvisor", byXPath("//span[@aria-label=\"Financial Aid Advisor: Dropdown\"]"));
	static Button FAAdvisorSpan = new Button("FAAdvisor", byXPath("//span[contains(@aria-label,'Financial Aid Advisor')]"));
	static TextField EnterAdvisor = new TextField("Advisor", byXPath("//input[@aria-owns=\"financialAidAdvisor_listbox\"]"));
	//static Button SelectAdvisor = new Button(" Advisor", byXPath("(//div/span[.=\"R P, Nandakumara\"])[1]"));
	//static Button PackagingStatus = new Button(" Packing Status", byXPath("aria-label=\"Award Year 1 Packaging Status: Dropdown\""));
	static TextField EnterPackagingStatus = new TextField("Packaging Status", byXPath("//input[@aria-owns=\"awardYear1PackageStatus_listbox\"]"));
	//static Button SelectPackagingStatus = new Button("Packaging Status", byXPath("(//span[.=\"04 - Ready to Package\"])[1]"));
	static Button BudgetSpan = new Button("Budget Span", byXPath("//span[@aria-owns=\"budgetId_listbox\"]"));
	static TextField EnterBudget = new TextField("Budget", byXPath("//input[@aria-owns=\"budgetId_listbox\"]"));
	//static Button SelectBudget = new Button("Budget", byXPath("//div/span[.=\"2022_Tuition\"]"));
	static Button Calculate = new Button("Calculate", byXPath("//button[.=\"Calculate\"]"));
	static Button AYSave = new Button("Save", byXPath("(//button[@aria-label=\"Save\"])[2]"));


	public StudentFinancialAidPage FinancialAidReassignment(StringHash data) throws Exception{


		Checkbox CheckFundSource = new Checkbox("Select Fund Source", byXPath("//tr/td[1]/input"));
		// Button HighlightAcademicYear = new Button("Highlight Academic Year", byXPath("//td[. = '"+data.get("StartDate")+"']"));
		Button HighlightStartDate = new Button("Highlight Academic Year", byXPath("//div[@id=\"cnsReassignGrid_cmcGrid\"]/div[2]/table/tbody/tr[1]/td[1]"));
		//Dropbox SelectAcademicYear = new Dropbox(data.get("AYStartDate"), byXPath("//span[.='"+data.get("AYStartDate")+"']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Reassign records were successfully saved.']"));

		//Button reassignConfirmDialogOkButton = new Button("reassignConfirmDialogOkButton", byXPath("//button[@id='reassignConfirmDialogOkButton']"));
		wait(7);
		//waitForPageToLoad();
		FinancialAid.waitTillElementClickable();
		FinancialAid.clickUsingJavaScriptExecutor();
		wait(2);
		Awarding.click();
		waitForPageToLoad();
		Awards.click();
		wait(15);
		//		AYSpan.click();
		//		wait(2);
		//		SelectAcademicYear.click();
		//		wait(5);
		//		Awarddropdown.click();
		//		wait(2);
		//		AwardClearFilter.click();
		//		wait(4);
		//		FSdropdown.click();
		//		wait(2);
		//		FSFilter.click();
		//		wait(2);
		//		ClickEqualsTo.click();
		//		wait(2);
		//		ClickContains.click();
		//		wait(2);
		//		FSValue.clearAndType(data.get("FundSource"));
		//		wait(2);
		//		FSFilterButton.click();
		//		wait(4);
		CheckFundSource.check();
		wait(5);
		Reassign.click();
		wait(20);
		HighlightStartDate.click();
		wait(5);
		OkReassign.click();
		wait(7);
		ConfirmReassign.click();
		wait(5);
		
		WebElement reassignConfirmDialogOkButton=driver.findElement(By.xpath("//button[@id='reassignConfirmDialogOkButton']"));
		if (reassignConfirmDialogOkButton.isDisplayed()) {
			reassignConfirmDialogOkButton.click();
			wait(3);
			CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
			return this;
		}
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(3);
		return this;
	}

	public StudentFinancialAidPage PrintAwardSummaryPage(StringHash data) throws Exception{

		Checkbox CheckFundSource = new Checkbox("Fund Source", byXPath("//tr[1]/td[1]/input"));
		//Button HighlightAcademicYear = new Button(data.get("AYStartDate"), byXPath("//span[@title='"+data.get("AYStartDate")+"']"));
		Dropbox FilterDropdown = new Dropbox("Filter Dropdown", byXPath("(//button[@aria-label=\"arrow-button\"])[1]"));
		Link ClearFilter = new Link("Clear Filter", byXPath("(//span[text()='Clear All'])[3]"));
		wait(4);
		//waitForPageToLoad();
		FinancialAid.waitTillElementClickable();
		FinancialAid.clickUsingJavaScriptExecutor();
		wait(2);
		Awarding.click();
		wait(25);
		Awards.click();
		wait(15);
		//		AYSpan.clickUsingJavaScriptExecutor();
		//		wait(4);
		//		HighlightAcademicYear.clickUsingJavaScriptExecutor();
		//		wait(5);
		FilterDropdown.click();
		wait(2);
		ClearFilter.click();
		wait(5);
		//		Awarddropdown.click();
		//		wait(2);
		//		AwardClearFilter.click();
		//		wait(4);
		//		FSdropdown.click();
		//		wait(2);
		//		FSFilter.click();
		//		wait(2);
		//		ClickEqualsTo.click();
		//		wait(2);
		//		ClickContains.click();
		//		wait(2);
		//		FSValue.clearAndType(data.get("FundSource"));
		//		wait(2);
		//		FSFilterButton.click();
		//		wait(4);
		CheckFundSource.check();
		String FundSourceValue = CheckFundSource.getAttribute("aria-label");
		TestReportsLog.log(LogStatus.INFO, "Fund Source is selected as " +FundSourceValue);
		wait(10);
		PrintButton.clickUsingJavaScriptExecutor();
		wait(10);
		return this;
	}
	public StudentFinancialAidPage VerifyDisbursementDataPage(StringHash data) throws Exception{

		Checkbox ClickFundSource = new Checkbox(data.get("FundSource"), byXPath("(//a[contains(text(),'"+data.get("FundSource")+"')])[1]"));
		TextField CheckTransactionDate = new TextField("Check Transaction Date", byXPath("(//table/tbody/tr[1]/td[1])[2]")); 
		String TDate = DatesUtil.getCurrentDatebyFormat("M/dd/yyyy");

		//waitForPageToLoad();
		FinancialAid.waitTillElementClickable();
		FinancialAid.click();
		wait(2);
		Awarding.click();
		wait(25);
		//Awards.click();
		//wait(15);
		//		AYSpan.clickUsingJavaScriptExecutor();
		//		wait(4);
		//		HighlightAcademicYear.clickUsingJavaScriptExecutor();
		//		wait(5);
		//Awarddropdown.click();
		wait(2);
		//AwardClearFilter.click();
		wait(6);
		scrollPage(0, 150);
		wait(2);
//		FSdropdown.click();
//		wait(3);
//		FSFilter.click();
//		wait(2);
//		//ClickEqualsTo.click();
//		wait(2);
//		//ClickContains.click();
//		wait(2);
//		FSValue.clearAndType(data.get("FundSource"));
//		wait(2);
//		FSFilterButton.click();
		wait(4);
		ClickFundSource.check();
		wait(20);
		scrollPage(0, 1000);
		wait(4);
		PaymentReceived.clickUsingJavaScriptExecutor();
		wait(10);
		scrollPage(0, 300);
		System.out.println("Received successfully");
		String TransactionDate = CheckTransactionDate.getText();
		if (TransactionDate.equals(TDate)) {
			System.out.print("Disbursement Data Verification is successful");  
			TestReportsLog.log(LogStatus.INFO, "Disbursement Data Verification is successful " +data.get("FundSource"));
		}  
		else
			System.out.print("Disbursement data is  found");  
		TestReportsLog.log(LogStatus.INFO, "Disbursement Data is  found ");
		wait(5);
		return this;	
	}

	/**
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public StudentFinancialAidPage AcademicYearPage(StringHash data) throws Exception{

		Link SelectAwardYear = new Link("Award Year", byXPath("//ul[@id=\"firstAwardYear_listbox\"]/li[.='"+data.get("AwardYear")+"']"));
		Dropbox SelectPackagingStatus = new Dropbox("Packaging Status", byXPath("//ul[@id=\"awardYear1PackageStatus_listbox\"]/li[1]/div/span[2][.=\"04 - Ready to Package\"]"));
		Link SelectBudget = new Link("Budget", byXPath("//ul[@id=\"budgetId_listbox\"]/li[1]/div/span[1]"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Academic Year records were successfully saved.']"));
		//Dropbox HousingDropdown = new Dropbox("Housing Dropdown", byXPath("//span[@aria-label=\"Housing: Dropdown\"]/span/span[2]/span"));
		Dropbox HousingDropdown = new Dropbox("Housing Dropdown", byXPath("//span[contains(@aria-label,'Housing')]/span/span[2]/span"));
		Link SelectHousing = new Link("Housing", byXPath("//ul[@id=\"housingStatusCode_listbox\"]/li[1]/div/span[1]"));
		//Dropbox GradeLevelDropdown = new Dropbox("Grade Level Dropdown", byXPath("//span[@aria-label=\"Grade Level: Dropdown\"]/span/span[2]/span"));
		Dropbox GradeLevelDropdown = new Dropbox("Grade Level Dropdown", byXPath("//span[contains(@aria-label,'Grade Level')]/span/span[2]/span"));
		Link SelectGradeLevel = new Link("Grade Level", byXPath("//ul[@id=\"gradeLevelId_listbox\"]/li[1]/div/span[1]"));
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
		Date date = new Date();
		String StartDate = formatter.format(date);
		String[] dateArray = StartDate.split("/");
		int year = Integer.parseInt(dateArray[2]);
		int EndDateValue = year+1;
		String EndDate = StartDate.replace(dateArray[2], String.valueOf(EndDateValue));
		System.out.println(EndDateValue);
		//Dropbox PackagingStatusDropdown = new Dropbox("Packaging Status", byXPath("//span[@aria-label=\"Award Year 1 Packaging Status: Dropdown\"]/span/span[2]/span"));
		Dropbox PackagingStatusDropdown = new Dropbox("Packaging Status", byXPath("//span[contains(@aria-label,'Award Year 1 Packaging Status')]/span/span[2]/span"));
		TextField WeeksinAY = new TextField("Weeks in AY", byXPath("//input[@aria-label=\"Weeks in AY\"]"));//button
		Button ConfirmOK = new Button("Confirm", byXPath("//button[@id=\"weeksEnrolledInAcademicYearDialogOkButton\"]"));

		waitForPageToLoad();
		FinancialAid.click();
		wait(2);
		Awarding.click();
		wait(25);
		AcademicYear.click();
		wait(25);
		NewAY.click();
		wait(5);
		Manual.click();
		wait(10);
		AYStartdate.clearAndType(StartDate);
		wait(2);
		AYEnddate.clearAndType(EndDate);
		wait(2);
		AwardYearSpan.click();
		wait(2);
		EnterAwardYear.clearAndType(data.get("AwardYear"));
		wait(2);
		SelectAwardYear.click();
		wait(4);
		GradeLevelDropdown.click();
		wait(2);
		SelectGradeLevel.click();
		String GradeLevelValue = SelectGradeLevel.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Grade Level is selected as " +GradeLevelValue);
		wait(2);
		//		WeeksinAY.clearAndType("36");
		//		wait(2);
		//		MonthsinAY.clearAndType(data.get("MonthsinAY"));
		//		wait(2);
		HousingDropdown.click();
		wait(2);
		SelectHousing.click();
		String HousingValue = SelectHousing.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Housing Value is selected as " +HousingValue);
		wait(2);
		//		FAAdvisorSpan.click();
		//		wait(2);
		//		EnterAdvisor.clearAndType(data.get("FAAdvisor"));
		//		wait(2);
		scrollPage(0, 600);
		wait(2);
		PackagingStatusDropdown.click();
		wait(2);
		EnterPackagingStatus.clearAndType("04 - Ready to Package");
		wait(2);
		SelectPackagingStatus.click();
		wait(2);
		BudgetSpan.click();
		wait(2);
		SelectBudget.click();
		String BudgetValue = SelectBudget.getAttribute("title");
		TestReportsLog.log(LogStatus.INFO, "Budget Value is selected as " +BudgetValue);
		wait(2);
		Calculate.click();
		wait(5);
		scrollPage(0, -1000);
		wait(5);
		AYSave.click();
		wait(2);
		ConfirmOK.click();
		wait(2);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(10);
		return this;
	}

	public StudentFinancialAidPage CreatingFundSource(StringHash data) throws Exception{

		Link Awarding = new Link("Awarding", byXPath("//span[text()='Awarding']"));
		Button Awards = new Button("Awards", byXPath("//button[text()='Awards']"));
		//Link PackagingMethod = new Link("Packaging Method", byXPath("//span[@aria-label='Packaging Method: Dropdown']"));
		Link PackagingMethod = new Link("Packaging Method", byXPath("//span[contains(@aria-label,'Packaging Method')]"));
		TextField SearchPackingMethod = new TextField("Search Packing Method", byXPath("//input[@aria-controls='packageMethod_listbox']"));
		Link SelectingPackingMethod = new Link(data.get("PackagingMethod"), byXPath("//span[text()='"+data.get("PackagingMethod")+"']"));
		//Link TypeOfAid = new Link("Type of Aid", byXPath("//span[@aria-label='Type of Aid: Dropdown']"));
		Link TypeOfAid = new Link("Type of Aid", byXPath("//span[contains(@aria-label,'Type of Aid')]"));
		TextField SearchTypeOfAid = new TextField("Search Type of Aid", byXPath("//input[@aria-controls='typeOfAidId_listbox']"));
		Link SelectingTypeOfAid = new Link(data.get("TypeofAid"), byXPath("//li[text()='"+data.get("TypeofAid")+"']"));
		//Link Source = new Link("Source", byXPath("//span[@aria-label='Source: Dropdown']"));
		Link Source = new Link("Source", byXPath("//span[contains(@aria-label,'Source')]"));
		TextField SearchSource = new TextField("Search Source", byXPath("//input[@aria-controls='sourceId_listbox']"));
		Link SelectingSource = new Link("Source", byXPath("//span[text()='"+data.get("Source")+"    ']"));
		TextField GrossAmount = new TextField("Gross Amount", byXPath("(//input[@aria-label='Gross Amount'])[1]"));
		Button Proceed = new Button("Proceed", byXPath("//button[text()='Proceed']"));
		//Link Status = new Link("Status", byXPath("//span[@aria-label='Status: Dropdown']"));
		Link Status = new Link("Status", byXPath("//span[contains(@aria-label,'Status')]"));
		TextField SearchStatus = new TextField("Search Source", byXPath("//input[@aria-owns='statusNewAid_listbox']"));
		Link SelectingStatus = new Link("Status", byXPath("//ul[@id=\"statusNewAid_listbox\"]/li[1]/span[1]"));
		Button SaveAndClose = new Button("Save And CLose", byXPath("//*[@id= 'cashOthersSaveCloseButton']"));
		//	Button UpdateSave = new Button("Update and Save", byXPath("//button[@id='commonValidationDialogCashOtherOkButton']"));
		//	Button DontSave = new Button("Dont update and Save", byXPath("//button[@id='commonValidationDialogCashOtherNotOkButton']"));
		Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Cash/Other fund source records were successfully saved.']"));
		TextField Number = new TextField("Number", byXPath("(//input[@aria-label='Number'])[1]"));
		Button Calculate = new Button("Calculate", byXPath("//*[@id='calculateButton']"));
		//	TextField SearchStatus1 = new TextField("Search Status", byXPath("//input[@aria-owns='Status_listbox']"));
		//	Link SelectingStatus1 = new Link(data.get("Status"), byXPath("//span[text()='"+data.get("Status")+"']"));

		wait(2);
		StudentStudentPage.FinancialAid.click();
		wait(2);
		Awarding.click();
		//waitForPageToLoad();
		wait(10);
		Awards.click();
		wait(15);
		PackagingMethod.click();
		wait(2);
		SearchPackingMethod.sendKeys(data.get("PackagingMethod"));
		wait(2);
		SelectingPackingMethod.click();
		wait(2);
		StudentStudentPage.NewButton.click();
		wait(20);
		TypeOfAid.click();
		wait(2);
		SearchTypeOfAid.sendKeys(data.get("TypeofAid"));
		wait(2);
		SelectingTypeOfAid.click();
		wait(2);
		Source.click();
		wait(2);
		SearchSource.sendKeys(data.get("Source"));
		wait(2);
		SelectingSource.click();
		wait(2);
		Status.click();
		wait(2);
		//	SearchStatus.sendKeys(data.get("Status"));
		//	wait(2);
		SelectingStatus.click();
		wait(2);
		GrossAmount.sendKeys("100");
		wait(2);
		Proceed.click();
		wait(20);
		//	Status.click();
		//	wait(2);
		//	SearchStatus1.sendKeys(data.get("Status"));
		//	wait(2);
		//	SelectingStatus1.click();
		//	wait(2);
		Number.clearAndType("1");
		wait(2);
		Calculate.click();
		wait(2);
		scrollPage(0, -300);
		wait(2);
		SaveAndClose.click();
		wait(2);
		//DontSave.click();
		wait(5);
		CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;
	}
}
