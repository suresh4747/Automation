package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byCSSSelector;
import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;

import org.openqa.selenium.By;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class StudentCoursePage extends BasePage{ 
	//Login Page Web Elements
	//static Link AcademicRecords = new Link("Academic Records", byXPath("//cns-panel-bar/ul/li[3]/a/span"));
	static Link MenuButton = new Link("Click MenuButton", byXPath("//div[@id='navbar']/ul/li[2]/a/span"));
	static Link Students = new Link("Students tile", byXPath("//a[text()=\"Students\"]"));
	static Link FilterDropDwon = new Link("Click Filter Drop Down", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
    static Link ClearFiltersButton = new Link("Click Filter Button", byXPath("//a[text()='Clear Filters']"));
    static AngDropDown StuNumDropDown = new AngDropDown("Click Student Number Dropdown", byXPath("//th[2]/a/span"));
    static Button StuNumFilter = new Button("Click Stud Num Filter", byXPath("//span[.='Filter']"));
    static TextField value = new TextField("Enter Value", byXPath("//input[@title=\"Value\"]"));
    static Button FilterButton = new Button("Click Filter Button", byXPath("//button[text()=\"Filter\"]"));
    static Link TESTAPI = new Link("API TEST", byXPath("//span[text()=\"TEST, API\"]"));
	static Link Admissions = new Link("Click on Admissions", byXPath("(//span[@class=\"k-link k-header\"])[2]"));
	static Link TestScores = new Link("Click on TestScores", byXPath("(//span[@class=\"tile-label text-left ng-binding\"])[16]"));
	static Button New = new Button("Click New", byId("studentEntranceTestScoresAddButton"));
	static TextField Test = new TextField("Enter Test", byXPath("//input[@name=\"test_input\"]"));
	static TextField SelTest = new TextField("Enter Test", byXPath("(//span[@class=\"student-label-container\"])[1]"));
	static Button SaveAndClose = new Button("Save and Close", byId("studentEntranceTestScoreSaveAndCloseButton"));	
	static Link AcademicRecords = new Link("Academic records", byXPath("//cns-panel-bar/ul[1]/li[3]/a/span"));
	static Link StudentCourse = new Link("Click on Student Course", byXPath("//span[. = 'Student Courses']"));
	static Link add = new Link("Click add", byXPath("//a[@id=\"addCourseButton\"]"));
	static Link ClickCourse = new Link("Click on Course", byXPath("//div[@aria-label='Course']"));
    static TextField Course = new TextField("Enter Course", byXPath("//input[@placeholder = 'Search Code or Name']"));
	static Link SelCourse = new Link("select Course", byXPath("(//td[1]/input)[1]"));
	static Button Select = new Button("Select Button", byXPath("//button[text()='Select']"));
	static Link ClickTerm = new Link("Term", byXPath("//div[@aria-label='Term ']"));
    static TextField Term = new TextField("Enter Term", byXPath("//input[@placeholder = 'Search Name']"));
	static Link SelTerm = new Link("select Term", byXPath("//input[@aria-label='2020 Fall']"));
	static Button SaveandRegister = new Button("Click on SaveandReg", byXPath("//button[@aria-label=\"Save & Register\"]"));
	static Button addcoursewithoutCatogery = new Button("Click on addcoursewithoutCatogery", byXPath("//button[@id=\"courseTakenNotAppliedDialogOkButton\"]"));
	static TextField ConfirmTerm = new TextField("Click on ConfirmTerm", byXPath("//input[@name=\"termId_input\"]"));
	static Link SelConfirmTerm = new Link("Click on SelConfirmTerm", byXPath("//span[@title='201011-3P']"));
	static Button Next = new Button("Click on Next", byXPath("//div/button[. = 'Next']"));
	static Link Selcls = new Link("Click on Selcls", byXPath("//div/div[1]/div/cns-grid//td[4]"));
	static Button Register = new Button("Click on Reg", byXPath("(//a[@id=\"registerSaveButton\"])[2]"));
	static Link SelRegister = new Link("Click on SelReg", byXPath("//button[@id=\"schedueCourseDialogOkButton\"]"));
	static Button ClsFilterDropDwon = new Button("Click Filter Drop Down", byXPath("(//a[@class='k-button k-split-button-arrow'])[1]"));
	static Link ClsClearFiltersButton = new Link("Click Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
	static Link ClsClearFiltersButton1 = new Link("Click Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
	static Link TermDropDown = new Link("Click Term Number Dropdown", byXPath("(//th[3]//span)[1]"));
    static Button TerNumFilter = new Button("Click Term Num Filter", byXPath("//span[.='Filter']"));
    static TextField value1 = new TextField("Enter Value", byXPath("//input[@title='Value']"));
    static Button FilterButton1 = new Button("Click Filter Button", byXPath("//button[text()='Filter']"));
    static Checkbox SelectallCheckbox = new Checkbox("Click SelectallCheckbox", byXPath("//th/input"));
    static Link Unregister = new Link("Click on Unregister", byXPath("//a[7][. = 'Unregister']"));
    static Link Clickreasonspan = new Link("Click on Clickreasonspan", byXPath("//ng-transclude/div[2]/cmc-drop-down-list-classic/div/div/span/span/span/span"));
    static TextField ReasonName = new TextField("Enter Reason Value", byXPath("//div[@id='reason-list']/span/input"));
    static Link SelReasonName = new Link("Click on SelReasonName", byXPath("(//li[. = 'Non Attendance'])[1]"));
    static Link Unregister1 = new Link("Click on Unregister1", byXPath("(//button[@id='okUnRegister'])[3]"));
    static Link ClickCourse2 = new Link("Click on Course", byXPath("//span[text()='BI231']"));
    static Button Attendance = new Button("Click on Attendance", byXPath("//button[. = 'Attendance']"));
    static Link CourseCodeDropDown = new Link("Click Term Number CourseCodeDropDown", byXPath("//th[1]//span"));
    static Link SelectAttendance = new Link("Click SelectAttendance", byXPath("(//tr[1]/td[3])[2]"));
    static Button PostRecord = new Button("Click PostRecord", byXPath("//a[6][. = 'Post Makeup Time']"));
	//static TextField Course = new TextField("Click on course input box", byCSSSelector("[name='courseId_input']"));
    static TextField Date = new TextField("Enter Date", byXPath("(//input[@placeholder='MM/DD/YYYY'])[3]"));
    static TextField Hours = new TextField("Enter Hours", byXPath("(//input[@aria-label='Hours'])[6]"));
	static Button Save = new Button("Click on Save", byXPath("(//button[text()='Save'])[7]"));
    static Link SelectHourse = new Link("Click SelectHourse", byXPath("(//div[@id='postMakeupHrDialog']/ng-transclude/div/div[3]/div/div/ng-transclude/div/div[2]/cmc-numeric-input-text/div/div/span/span/span[2]/span/span)[1]"));

    public StudentCoursePage RecordMakeupHourForStudent(StringHash data) throws Exception{

    	//X-path Parameterization
    	int Hour = AppendValue.apendNumber();
    	Link RecordmakeupStdSaveMessage = new Link("Record makeup Hours SaveMessage", byXPath("//span[. = 'The Attendance records were successfully saved.']"));
    	Link ClickCourse2 = new Link(data.get("Course"), byXPath("//span[text()='"+data.get("Course")+"']"));
    	Link SelectAttendance = new Link("Select Attendance", byXPath("//span[. = 'Attendance Recorded']"));
    	Button Post = new Button("Post", byXPath("//button[. = 'Post']"));
    	TextField Date = new TextField("Date", byXPath("//input[@id='makeupHrDate']"));
    	//Link Hours = new Link("Hours", byXPath("(//div[@id='postMakeupHrDialog']/ng-transclude/div/div[3]/div/div/ng-transclude/div/div[2]/cmc-numeric-input-text/div/div/span/span/span[2]/span/span)[1]"));
    	Link Hours = new Link("Hours", byXPath("(//div[@id='postMakeupHrDialog']/ng-transclude/div/div[3]/div/div/ng-transclude/div/div[2]/cmc-numeric-input-text/div/div/span/span/span[2]/span/span)[1]"));
    	Button PostRecord = new Button("PostRecord", byXPath("//a[@id='postMakeUpHoursButton']"));
    	Button Attendance = new Button("Attendance", byXPath("//button[. = 'Attendance']"));
    	Link AcademicRecords = new Link("Academic records", byXPath("//cns-panel-bar/ul/li[3]/a/span"));
    	Link StudentCourse = new Link("Student Course", byXPath("//span[. = 'Student Courses']"));
    	//Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("//button[@id='cnsGrid_cnsToolbar_kendoToolBar_settingsButton']"));
    	//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
    	//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("(//li[@id='cnsGrid_cnsToolbar_kendoToolBar_clearFiltersButton']/span/span[2])[2]"));
    	Link TermDropDown = new Link("Term Number Dropdown", byXPath("(//th[3]//span)[1]"));
    	Button TerNumFilter = new Button("Term Number Filter", byXPath("//span[.='Filter']"));
    	TextField value = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
    	Button FilterButton = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));
    	Checkbox SelectCheckbox = new Checkbox("Select Checkbox", byXPath("(//tr//td//input)[1]"));
    	Button Save = new Button("Save", byXPath("(//button[text()='Save'])[7]"));
    	
    	Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("//*[@id='cnsGrid_cnsToolbar_kendoToolBar_settingsButton']"));
    	//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
    	Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//*[@id='cnsGrid_cnsToolbar_kendoToolBar_clearFiltersButton']"));

    //Method Implementation
    	//waitForPageToLoad();
    	//wait(10);
    	AcademicRecords.waitTillElementClickable();
    	AcademicRecords.click();
    	wait(3);
    	StudentCourse.clickUsingJavaScriptExecutor();
    	wait(10);
    	ClsFilterDropDwon.clickUsingJavaScriptExecutor();
    	wait(2);
    	ClsClearFiltersButton.clickUsingJavaScriptExecutor();
    	wait(10);
    	TermDropDown.click();
    	wait(2);
    	TerNumFilter.click();
    	wait(2);
    	value.clearAndType(data.get("Course"));
    	wait(2);
    	FilterButton.click();
    	wait(5);
    	SelectCheckbox.click();
    	wait(5);
    	ClickCourse2.click();
    	wait(15);
    	scrollPage(0, -200);
    	wait(2);
    	Attendance.clickUsingJavaScriptExecutor();
    	wait(3);
    	scrollPage(0, 500);
    	wait(2);
    	SelectAttendance.click();
    	wait(2);
    	PostRecord.click();
    	wait(2);
    	Date.clearAndType(data.get("Date").toString());
    	wait(3);
    	//Hours.click();
    	//Hours.sendKeys(data.get("Hours"));
    	//wait(3);
    	Save.click();
    	wait(7);
    	CustomAsserts.containsString(RecordmakeupStdSaveMessage.getText(), data.get("SuccessMessage").toString());
    	wait(2);
    	return this;
    }

    public StudentCoursePage AddStudentCourse(StringHash data) throws Exception{

    	//X-path Parameterization
    	Link ConfirmTerm = new Link("Confirm Term", byXPath("//div/cmc-drop-down-list/div/div/span/span/span/span"));
    	//Link SelCourse = new Link(data.get("Course"), byXPath("(//tr//td//input)[1]"));
    	//Checkbox SelTerm = new Checkbox(data.get("Term"), byXPath("//input[@aria-label='"+data.get("Term")+"']"));
    	Checkbox SelTerm = new Checkbox("SelTerm", byXPath("//input[@aria-label='"+data.get("Term Name")+"']"));
    	Link SelConfirmTerm = new Link("Confirm Term", byXPath("//ul[@id='termId_listbox']/li[1]/div/span[1]"));
    	Link StdCourSaveMessage = new Link("Student Course Save Message", byXPath("//span[. = 'The Student Course records were successfully saved.']"));
    	Link Register1 = new Link("Register", byXPath("//button[@id='schedueCourseDialogOkButton']"));
    	Button AddCourse = new Button("Add Course", byXPath("//button[@id='schedueCourseDialogOkButton']"));
    	Button Override = new Button("Override", byXPath("//button[@id='studentOnHoldWindowOkButton']"));
    	Link PopUpValidation = new Link("Validation Message", byXPath("//div[@data-role='alert']/div/span[2]"));
    	Button RegisterButton = new Button("Register", byXPath("//button[@id='schedueCourseDialogOkButton']"));
    	Link FilterDropDwon = new Link("Filter Drop Down", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
    	Link ClearFiltersButton = new Link("Filter Button", byXPath("//a[text()='Clear Filters']"));
    	AngDropDown StuNumDropDown = new AngDropDown("Student Number Dropdown", byXPath("//th[2]/a/span"));
    	Button StuNumFilter = new Button("Student Number Filter", byXPath("//span[.='Filter']"));
    	TextField value = new TextField("Value", byXPath("//input[@title='Value']"));
    	Button FilterButton = new Button("Filter Button", byXPath("//button[text()='Filter']"));
    	
    	Link StudentCourse = new Link("Student Course", byXPath("//span[. ='Student Courses']"));
    	Link add = new Link("add", byXPath("//*[@id='addCourseButton']"));
    	Link ClickCourse = new Link("Course", byXPath("//div[@id='search_display_courseId']"));
    	TextField Course = new TextField("Course", byXPath("//input[@id='search']"));
    	Link SelCourse = new Link("Course", byXPath("(//td[1]/input)[1]"));
    	Button Select = new Button("Select Button", byXPath("//button[text()='Select']"));
    	//Link ClickTerm = new Link("Term", byXPath("//div[@aria-label=\"Term\"]"));
    	TextField Term = new TextField("Term", byXPath("//input[@id='search']"));
    	//Link SelTerm = new Link("select Term", byXPath("//input[@aria-label='2020 Fall']"));
    	Button SaveandRegister = new Button("Save and Register", byXPath("//button[@aria-label='Save & Register']"));
    	Button Save1 = new Button("Save", byXPath("(//button[@aria-label='Save'])[2]"));
    	Button addcoursewithoutCatogery = new Button("addcoursewithoutCatogery", byXPath("//*[contains(text(),'Add Course without Category')]"));
    	//TextField ConfirmTerm = new TextField("ConfirmTerm", byXPath("//input[@name=\"termId_input\"]"));
    	//Link SelConfirmTerm = new Link("Select ConfirmTerm", byXPath("//span[@title='201011-3P']"));
    	Button Next = new Button("Next", byXPath("//div/button[. = 'Next']"));
    	Link Selcls = new Link("Select Class Section", byXPath("//div/div[1]/div/cns-grid//td[4]"));
    	Button Register = new Button("Register", byXPath("(//a[@id='registerSaveButton'])[2]"));
    	Link SelRegister = new Link("Select Register", byXPath("//button[@id='schedueCourseDialogOkButton']"));
    	Link ClickTerm = new Link("Term", byXPath("//div[@id='search_display_termId']"));

    	//Method Implementation
//    	waitForPageToLoad();
    	AcademicRecords.waitTillElementClickable();
    	AcademicRecords.click();
    	wait(2);
    	StudentCourse.click();
    	wait(10);
    	add.click();
    	wait(3);
    	ClickCourse.clickUsingJavaScriptExecutor();
    	wait(2);
    	Course.clearAndType(data.get("Course Code").toString());
    	wait(2);
    	SelCourse.click();
    	wait(2);
    	Select.clickUsingJavaScriptExecutor();
    	wait(3);
    	ClickTerm.click();
    	wait(4);
    	Term.clearAndType(data.get("Term Name").toString());
    	wait(4);
    	SelTerm.click();
    	wait(2);
    	Select.clickUsingJavaScriptExecutor();
    	wait(3);
    	Save1.clickUsingJavaScriptExecutor();
    	wait(3);
    	addcoursewithoutCatogery.clickUsingJavaScriptExecutor();
    	wait(2);
//    	if(AddCourse.isDisplayed()) {
//    		AddCourse.click();
//    		wait(2);
//    	}
    	wait(3);
    	CustomAsserts.containsString(StdCourSaveMessage.getText(), data.get("SuccessMessage").toString());
    	System.out.println("Course is added successfully");
//    	wait(10);
    	return this;
    }       



    public StudentCoursePage CourseRegistrationForStudent(StringHash data) throws Exception{

        //X-path Parameterization
        	Button CourseFilter = new Button("Term Number Filter", byXPath("//span[.='Filter']"));
        	Link PopUpValidation = new Link("Validation Message", byXPath("//div[@data-role='alert']/div/span[2]"));
        	Link StudentCourse = new Link("Student Course", byXPath("//span[. = 'Student Courses']"));
        	Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("(//*[@id='cnsGrid_cnsToolbar_kendoToolBar_settingsButton_wrapper']/button/span)[2]"));
        	//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
        	Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//ul[@id='cnsGrid_cnsToolbar_kendoToolBar_settingsButton_buttonmenu']/li/span/span[text()='Reset to Default']"));
        	Link TermDropDown = new Link("Term Number Dropdown", byXPath("(//th[3]//span/a)[1]"));
        	Button TerNumFilter = new Button("Term Number Filter", byXPath("(//span[.='Filter'])[1]"));
        	TextField value = new TextField("Value", byXPath("//input[@title='Value']"));
        	Button FilterButton = new Button("Filter Button", byXPath("//button/span[text()='Filter']"));
        	Checkbox SelectallCheckbox = new Checkbox("Select all Checkbox", byXPath("//td/input"));
        	Button Register1 = new Button("Register Button",byXPath("//*[@id='courseUnRegisterButton']"));
        	Button Next = new Button("Next", byXPath("(//button[text()='Next'])[1]"));
        	Link Selcls = new Link("Select class", byXPath("(//table[1]/tbody[1]/tr[1]/td[2])[2]"));
        	Button Register = new Button("Register", byXPath("(//*[@id=\"registerSaveButton\"])[2]"));
        	Button RegisterConfirm = new Button("RegisterConfirm", byXPath("(//button[@aria-label='Register'])[2]"));
        	Link SelRegister = new Link("Select Register", byXPath("//button[@id=\"schedueCourseDialogOkButton\"]"));
        	//Link AcademicRecords = new Link("Academic records", byXPath("//cns-panel-bar/ul/li[3]/a/span"));
        	//span[. = 'The Student Course records were successfully saved.']
        	Link SelConfirmTerm = new Link("Click on SelConfirmTerm", byXPath("(//ul[@id='termId_listbox']/li/div/span)[1]"));
        	Link ConfirmTerm = new Link("Click on ConfirmTerm", byXPath("//div/cmc-drop-down-list/div/div/span/span/span/span"));
        	
        	Button Override = new Button("Override", byXPath("(//button[text()='Override'])[6]"));
        	
        //Method Implementation	
        	//waitForPageToLoad();
        	//wait(10);
        	AcademicRecords.waitTillElementClickable();
        	AcademicRecords.click();
        	wait(2);
        	StudentCourse.click();
        	wait(25);
        	ClsFilterDropDwon.click();
        	wait(2);
        	ClsClearFiltersButton.clickUsingJavaScriptExecutor();
        	wait(5);
        	TermDropDown.clickUsingJavaScriptExecutor();
        	wait(2);
        	TerNumFilter.click();
        	wait(2);
        	value.clearAndType(data.get("Course"));
        	wait(2);
        	FilterButton.click();
        	wait(5);
        	SelectallCheckbox.click();
        	wait(5);
        	Register1.clickUsingJavaScriptExecutor();
        	wait(30);
        	scrollPage(0, 250);
        	wait(5);
        	//ConfirmTerm.click();
        	wait(2);
        	//SelConfirmTerm.click();
       		wait(2);
       		//String SelConfrmTerm = SelConfirmTerm.getAttribute("title");
       		//TestReportsLog.log(LogStatus.INFO, "Confirm Term Name is selected as "+SelConfrmTerm);
       		wait(2);
        	Next.clickUsingJavaScriptExecutor();
        	wait(5);
        	Selcls.clickUsingJavaScriptExecutor();
        	wait(3);
        	scrollPage(0, 1000);
        	Register.clickUsingJavaScriptExecutor();
        	wait(6);
        	//RegisterConfirm.click();
//        	try {
//        		if(RegisterConfirm.isDisplayed()) {
//        			RegisterConfirm.click();
//            	}
//        	} 
//       	catch (Exception e) {
//       		TestReportsLog.log(LogStatus.PASS, "Over ride button is not displayed");
//         	} 
        	
        	//SelRegister.clickUsingJavaScriptExecutor();
//        	String SM=PopUpValidation.getText();
//        		wait(10);
//        		CustomAsserts.containsString(SM, data.get("SuccessMessage").toString());
        	wait(15);
        	return this;

        }

    public StudentCoursePage CourseUnRegistrationForStudent(StringHash data) throws Exception{

        //X-path Parameterization
        	Link CourseUnRegSaveMessage = new Link("Course UnRegister Save Message", byXPath("//span[. = 'The Student Course records were successfully unregistered.']"));
        	Link Clickreasonspan = new Link("reason span", byXPath("//span[contains(@aria-controls,'reason')]/span[2]/span"));
        	Link SelReasonName = new Link("Select Reason Name", byXPath("//ul[@id='reason_listbox']/li[1]/span"));
        	//Link AcademicRecords = new Link("Academic Records", byXPath("//a[@aria-label='Academic Records']"));
        	Link StudentCourse = new Link("Student Course", byXPath("//span[. ='Student Courses']"));
        	Button ClsFilterDropDwon = new Button("Filter Drop Down", byXPath("//*[@id='cnsGrid_cnsToolbar_kendoToolBar_settingsButton']"));
        	//Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//div//a[. = 'Clear Filters']"));
        	Link ClsClearFiltersButton = new Link("Filter Button", byXPath("//*[@id='cnsGrid_cnsToolbar_kendoToolBar_clearFiltersButton']"));
        	Link TermDropDown = new Link("Term Number Dropdown", byXPath("//th[@data-field='CourseCode']//a"));
        	Link CourseStatusDropDown = new Link("Course Status DropDown", byXPath("(//th[8]//span)[1]"));
        	Button TerNumFilter = new Button("Term Number Filter", byXPath("(//span[.='Filter'])[1]"));
        	TextField value = new TextField("Value", byXPath("//input[@title='Value']"));
        	Button FilterButton = new Button("Filter Button", byXPath("(//span[text()='Filter'])[2]"));
        	Checkbox SelectCheckbox = new Checkbox("Checkbox", byXPath("//input[@id='checkAll']"));
        	Link Unregister = new Link("Unregister", byXPath("//*[@id='courseUnRegisterButton']"));
        	Link Unregister1 = new Link("Unregister", byXPath("//button[text()='Unregister']"));

        //Method Implementation
//        	waitForPageToLoad();
        	AcademicRecords.waitTillElementClickable();
        	AcademicRecords.click();
        	wait(2);
        	StudentCourse.click();
        	wait(8);
        	ClsFilterDropDwon.clickUsingJavaScriptExecutor();
        	wait(3);
        	ClsClearFiltersButton.clickUsingJavaScriptExecutor();
        	wait(7);
        	TermDropDown.clickUsingJavaScriptExecutor();
        	wait(2);
        	TerNumFilter.click();
        	wait(2);
        	value.clearAndType(data.get("Course Code"));
        	wait(2);
        	FilterButton.click();
        	wait(10);
        	SelectCheckbox.click();
        	wait(5);
        	Unregister.clickUsingJavaScriptExecutor();
        	wait(5);
        	Clickreasonspan.click();
        	wait(2);
        	SelReasonName.click();
        	wait(2);
        	//String SelResonName = SelReasonName.getAttribute("title");
        	//TestReportsLog.log(LogStatus.INFO, "Reason Name is selected as "+SelResonName);
        	Unregister1.click();
        	wait(5);
        	CustomAsserts.containsString(CourseUnRegSaveMessage.getText(), data.get("SuccessMessage").toString());
        	System.out.println("Course is unregistered successfully");
        	return this;
        }
}