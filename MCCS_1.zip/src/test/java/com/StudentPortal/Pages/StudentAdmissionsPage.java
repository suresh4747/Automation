package com.StudentPortal.Pages;

import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;

//import static com.framework.elements.Locator.byXPath


import static com.framework.elements.Locator.byName;
import com.codepine.api.testrail.model.Field.Config.DropdownOptions;

public class StudentAdmissionsPage extends BasePage {
	
	//Student Application Web Elements
	static Button FilterDropDwon = new Button("Filter Drop Down", byXPath("(//a[@class=\"k-button k-split-button-arrow\"])[1]"));
	static Button ClearFiltersButton = new Button("Filter Button", byId("listClearFiltersButton"));
	static AngDropDown StuNumDropDown = new AngDropDown("Student Number Dropdown", byXPath("//th[2]/a/span"));
	static Button StuNumFilter = new Button("Stud Num Filter", byXPath("//span[.=\"Filter\"]"));
	static TextField value = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
	static Button FilterButton = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));
	//static Link ClickStudent = new Link(" Student Name",byXPath("//span[.=\"Harris, Colette\"]"));
    static Button Admissons = new Button("Admissions", byXPath("//cns-panel-bar/ul/li[2]/a/span"));
    static Link StudentApplications =  new Link(" Student Application", byXPath("//span[. = \"Student Applications\"]"));
    static Link NewButton = new Link("New", byId("newButton"));
    static TextField ApplicantType = new TextField("Applicant Type", byXPath("//input[@name=\"applicantTypeId_input\"]"));
    static TextField ProgramCode = new TextField("Program Code", byName("programIdCode_input"));
   // static TextField SchoolStatus = new TextField("School Status", byXPath("//span/span/input[@aria-label=\"schoolStatusId\"]"));
    static TextField SchoolStatus = new TextField("School Status", byXPath("//input[@name='schoolStatusId_input']"));
    static Button SelectSchoolStatus = new Button("School Status",byXPath("//span[text()=\"Applicant\"]"));
    static TextField AdminRep = new TextField("Admin Rep", byName("assignedAdmissionsRepId_input"));
    static Button SelectAdminRep = new Button("Admin Rep",byXPath("//li[text()=\"Andrew Yates\"]"));
    static Button SaveAndClose = new Button("Save & Close", byXPath("(//button[@aria-label=\"Save & Close\"])[2]"));
    static Button EnrolNum = new Button("Enrollment Num", byId("enrollmentNumber"));
    static Link ClickFilter = new Link("Filter", byXPath("//a[text()=\"Clear Filters\"]"));
    static Link CourseCodeDropdown = new Link("Course Code dropdown", byXPath("(//a[@aria-label=\"Column Settings\"])[1]"));
    static Button CClFilterDropDown = new Button("Filter", byXPath("//span[text()=\"Filter\"]"));
    static TextField Value = new TextField("Filter", byXPath("//input[@title=\"Value\"]"));
    static Button Filter = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));
	static TextField Notes = new TextField("Notes", byXPath("//textarea[@aria-label=\"Notes\"]"));
    //static Button StatusReason = new Button("Status Reason", byXPath("//span[@aria-label=\"Status Reason: Dropdown\"]"));
	static Button StatusReason = new Button("Status Reason", byXPath("//span[contains(@aria-label,'Status Reason')]"));
  
    public StudentAdmissionsPage CreateStudentApplication(StringHash data) throws Exception {
    	
    	Link ClickStudent = new Link(data.get("StudentName"),byXPath("//span[.='"+data.get("StudentName")+"']"));
    	Link ValidationMessage = new Link("Validation Message", byXPath("//span[. = 'The Student Application records were successfully saved.']"));
    	Dropbox SelectAdmRep = new Dropbox(data.get("AdmRep"), byXPath("//li[.='"+data.get("AdmRep")+"']"));
    	Dropbox ApplicationTypeSpan = new Dropbox("Application Type Span", byXPath("//span[@aria-controls=\"applicantTypeId_listbox\"]/span"));
    	Link SelectApplicationType = new Link("Application Type", byXPath("//ul[@id=\"applicantTypeId_listbox\"]/li[1]/div/span[1]"));
    	Dropbox StudentStatusSpan = new Dropbox("Status Span", byXPath("//span[@aria-controls=\"schoolStatusId_listbox\"]/span"));
    	Link SelectStudentStatus = new Link("Student Status", byXPath("//*[@id=\"schoolStatusId_listbox\"]/li[1]/div/span[1]"));
    	Dropbox AdminRepSpan = new Dropbox("Admin Rep Span", byXPath("//span[@aria-controls=\"assignedAdmissionsRepId_listbox\"]/span"));
    	Link SelectAdminRep = new Link("Student Status", byXPath("//*[@id=\"schoolStatusId_listbox\"]/li[1]/div/span[1]"));
    	Link SchoolStatusValue = new Link("SchoolStatusValue", byXPath("//span[text()='Application Submitted']"));
    	
    	Link FilterDropDwon= new Link("Filter", byXPath("//div[@id='listSettingsButton_wrapper']"));
    	Admissons.waitTillElementClickable();
    	Admissons.click();
    	wait(2);
    	StudentApplications.click();
    	waitForPageToLoad();
    	wait(2);
    	NewButton.click();
    	wait(5);
    	waitForPageToLoad();
    	scrollPage(0, 500);
    	wait(2);
    	//ApplicationTypeSpan.click();
    	//wait(2);
    	//SelectApplicationType.click();
    	//String ApplicationTypeValue = SelectApplicationType.getAttribute("title");
		//TestReportsLog.log(LogStatus.INFO, "Application Type Value is selected as "+ApplicationTypeValue);
    	wait(3);
    	scrollPage(0, 700);
    	wait(2);
    	//StatusReason.click();
    	wait(2);
    	SchoolStatus.sendKeys("Application Submitted");
    	wait(5);
    	SchoolStatusValue.click();
    	wait(3);
    	AdminRep.clearAndType(data.get("AdmRep"));
    	wait(2);
    	SelectAdmRep.click();
    	wait(5);
    	/*    	SelectAdminRep.click();
     	Thread.sleep(1000);
    	 */      
    	//EnrolNum.click();
    	scrollPage(0, -1000);
    	wait(5);
    	SaveAndClose.click();
    	wait(10);
    	CustomAsserts.containsString(ValidationMessage.getText(), data.get("SuccessMessage").toString());
		wait(5);
		return this;	   	
    }
}
