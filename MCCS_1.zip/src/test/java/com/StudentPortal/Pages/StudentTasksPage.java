package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byCSSSelector;
import static com.framework.elements.Locator.byXPath;

import com.framework.base.BasePage;
import com.framework.elements.Button;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;


public class StudentTasksPage extends BasePage {
	
	public StudentTasksPage ConfirmPendingTasksForStaff(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));		
		Link TasksSpan = new Link("TasksSpan", byXPath("//li[1]/div/div[1]/div"));
		Button ApplyFilter = new Button("ApplyFilter", byXPath("//button[text()='Apply Filter']"));
		Button TaskTemplateSpan = new Button("TaskTemplateSpan", byXPath("//cns-student-task-form/div/div[2]/cmc-drop-down-list/div/div/span//span[2]"));		
		Link StatusTableCell = new Link(data.get("Status"), byXPath("(//td[text()='"+data.get("Status")+"'])[1]"));
		Link TaskSubjectTableCell = new Link("TaskSubjectTableCell", byXPath("(//td[@title='"+data.get("TaskTemplate")+"'])[1]"));

		waitForPageToLoad();
		wait(12);
		//ApplyFilter.waitTillElementClickable();
		ApplyFilter.clickUsingJavaScriptExecutor();
		wait(8);
		CustomAsserts.containsString(StatusTableCell.getText(), data.get("Status").toString());
		CustomAsserts.containsString(TaskSubjectTableCell.getText(), data.get("TaskTemplate").toString());
		return this;

	}


	public StudentTasksPage EditTaskByStaff(StringHash data) throws Exception{

		//Link InstructorTableCell = new Link("Click on Instructor table cell", byXPath("//td[. = '"+data.get("SectionCode")+"']"));

		Link TasksSpan = new Link("TasksSpan", byXPath("//li[1]/div/div[1]/div"));
		Button ApplyFilter = new Button("ApplyFilter", byXPath("//button[text()='Apply Filter']"));
		Button TaskTemplateSpan = new Button("TaskTemplateSpan", byXPath("//cns-student-task-form/div/div[2]/cmc-drop-down-list/div/div/span//span[2]"));	
		//Link StatusTableCell = new Link("StatusTableCell", byXPath("(//td[text()='"+data.get("Status")+"'])[1]"));	
		Link TaskSubjectCell = new Link("TaskSubjectCell", byXPath("(//a[. = '"+data.get("TaskTemplate")+"'])[1]"));
		Button StatusSpan = new Button("StatusSpan", byXPath("//div[9]/cmc-drop-down-list-classic/div/div/span//span[2]"));
		//Dropbox Status = new Dropbox(data.get("Status"), byXPath("//span[. = '"+data.get("Status")+"']"));
		Link Status = new Link("StatusDropdownValue", byXPath("//div/ul[@id='taskStatusId_listbox']/li[2]"));
		TextField Note = new TextField("Note", byCSSSelector("[name='noteTextArea']"));
		Button SaveAndClose = new Button("SaveAndClose", byCSSSelector("#formSaveCloseButton"));

		String NoteValue = AppendValue.apendString();

		waitForPageToLoad();
		wait(8);
		//ApplyFilter.waitTillElementClickable();
		ApplyFilter.clickUsingJavaScriptExecutor();
		wait(8);
		TaskSubjectCell.clickUsingJavaScriptExecutor();
		waitForPageToLoad();
		scrollPage(0, 500);
		StatusSpan.click();
		wait(2);
		Status.click();
		wait(2);
		String StatusValue = Status.getTextValue();
		TestReportsLog.log(LogStatus.INFO, "Task Status Value is selected as "+StatusValue);
		Note.clearAndType(NoteValue.toString());
		scrollPage(0, -500);
		SaveAndClose.click();
		waitForPageToLoad();
		//Link StatusTableCell = new Link("StatusTableCell", byXPath("(//td[text()='"+StatusValue+"'])[1]"));
		CustomAsserts.containsString(TaskSubjectCell.getText(), data.get("TaskTemplate").toString());
		//CustomAsserts.containsString(StatusTableCell.getText(), StatusValue.toString());

		return this;

	}
}
