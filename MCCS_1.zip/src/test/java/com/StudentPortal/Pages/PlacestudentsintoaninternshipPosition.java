package com.StudentPortal.Pages;

import static com.framework.elements.Locator.byId;
import static com.framework.elements.Locator.byXPath;

import java.awt.ScrollPane;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;

import com.fasterxml.jackson.annotation.JsonFormat.Value;
import com.framework.base.BasePage;
import com.framework.elements.AngDropDown;
import com.framework.elements.Button;
import com.framework.elements.Checkbox;
import com.framework.elements.CustomAsserts;
import com.framework.elements.Dropbox;
import com.framework.elements.Link;
import com.framework.elements.TextField;
import com.framework.util.AppendValue;
import com.framework.util.DatesUtil;
import com.framework.util.StringHash;
import com.framework.util.TestReportsLog;
import com.relevantcodes.extentreports.LogStatus;

public class PlacestudentsintoaninternshipPosition extends BasePage{ 
	
	static Link FilterDropDwon = new Link("Click Filter Drop Down", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
    static Link ClearFiltersButton = new Link("Click Filter Button", byXPath("//a[text()='Clear Filters']"));
    static AngDropDown StuNumDropDown = new AngDropDown("Click Student Number Dropdown", byXPath("//th[2]/a/span"));
    static Button StuNumFilter = new Button("Click Stud Num Filter", byXPath("//span[.='Filter']"));
    static TextField value = new TextField("Enter Value", byXPath("//input[@title=\"Value\"]"));
    static Button FilterButton = new Button("Click Filter Button", byXPath("//button[text()=\"Filter\"]"));
    static Link OLIVIAWARNER = new Link("Click on OLIVIA WARNER", byXPath("//span[text()='WARNER, OLIVIA']"));
	static Link CareerServices = new Link("Click on Career Services", byXPath("//cns-panel-bar/ul[1]/li[4]/span"));
	static Link PlacementsInternships = new Link("Click on Placements&Internships", byXPath("//*[@id='studentTilesPanelBar']/li[4]/div/div[2]/div/span"));
	static Button New = new Button("New", byXPath("//a[@id='studentPlacementNewButton']"));
	static Link Employer = new Link("Select Employer", byXPath("//*[@id='search_display_employerSearch']"));
	static TextField SearchEmployer = new TextField("Search Employer Name", byXPath("//*[@id='search']"));
	static Checkbox EmployerButton = new Checkbox("Select Employer Button", byXPath("(//input[@type='checkbox'])[2]"));
	static Button Select = new Button("Select Button", byXPath("//button[text()='Select']"));
	//static TextField JobType = new TextField("Enter Job Type", byXPath("//input[@name='jobType_input']"));	
	static Link SelJobType = new Link("Select Job Type", byXPath("//span[. ='Internship/Externship']"));
	static Link PlacementStatus = new Link("Click PlacementStatus", byXPath("//section/div/div[2]/div/div[2]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
	static Link SelPlacementStatus = new Link("Select Job Status", byXPath("//*[@id='0884bfb5-865a-4e2f-ab5a-efd249df6840']/div/span[1]"));
	static Link jobTitle_input = new Link("jobTitle_input'", byXPath("//div/div/div[2]/div/div[2]/cmc-drop-down-list/div/div/span/span/span/span"));
	static Link SeljobTitle_input = new Link("Select jobTitle_input'", byXPath("//span[. ='Administrative']"));
	static Link InFieldofStudy = new Link("Click Field od Study'", byXPath("//div[5]/cmc-drop-down-list[3]/div/div/span/span/span/span"));
	static Link SelInFieldofStudy = new Link("Select Field od Study'", byXPath("//span[. ='Related']"));
	static Link HowPlaced = new Link("Click HowPlaced Value'", byXPath("//cmc-drop-down-list[4]/div/div/span/span/span/span"));
	static Link SelHowPlaced = new Link("Sel HowPlaced Value'", byXPath("//span[. ='College']"));
	static TextField SalAmount = new TextField("Enter Salary Amount'", byXPath("(//input[@aria-label='Salary Amount'])[1]"));
	//static Link SelSalaryAmount = new Link("Select Salary Amount'", byXPath("//*[@id='salary']/.."));
	static Link SalaryStatus = new Link("Click Salary Status'", byXPath("//div[6]/cmc-drop-down-list[1]/div/div/span/span/span/span"));
	static Link SelSalaryStatus = new Link("Select Salary Status'", byXPath("//span[. ='Actual']"));
	static Link SalaryType = new Link("Click Salary Type'", byXPath("//div[6]/cmc-drop-down-list[2]/div/div/span/span/span/span"));
	static Link SelSalaryType = new Link("Select Salary Type'", byXPath("//span[. ='Flat Rate']"));
	static TextField DatePlaced = new TextField("Enter Date Placed'", byXPath("//*[@id='datePlaced']"));
	static TextField StartDate = new TextField("Enter Start Date'", byXPath("//*[@id='startDate']"));
	static Button SaveAndClose = new Button("Save and Close", byXPath("(//button[@aria-label='Save & Close'])[2]"));	
	
//Random Value
	static String RstName = AppendValue.apendString();
	static String RstCode = AppendValue.apendString();
	
	static String Date = DatesUtil.getCurrentDatebyFormat("M/dd/yyyy");
	static String VerificationAgentValue = AppendValue.apendString();
	
	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
	Date date = new Date();
	String currentDate = formatter.format(date);
	
	
public PlacestudentsintoaninternshipPosition PlaceInternshipPosition(StringHash data) throws Exception{
		
	//X-path Parameterization
		Link FilterDropDwon = new Link("Filter Drop Down", byXPath("//div[3]/div[3]/div/div[1]/div/div[1]/a[2]"));
        Link ClearFiltersButton = new Link("Filter Button", byXPath("//a[text()='Clear Filters']"));
        AngDropDown StuNumDropDown = new AngDropDown("Student Number Dropdown", byXPath("//th[2]/a/span"));
        Button StuNumFilter = new Button("Student Number Filter", byXPath("//span[.='Filter']"));
        TextField value = new TextField("Value", byXPath("//input[@title=\"Value\"]"));
        Button FilterButton = new Button("Filter Button", byXPath("//button[text()=\"Filter\"]"));
		//Link ClickStudentName = new Link("Selecting Student", byXPath("//span[text()='"+data.get("LastName")+", "+data.get("FirstName")+"']"));
		Checkbox EmployerButton = new Checkbox("Employer Button", byXPath("//tr[1]/td/input"));
		//Link CareerServices = new Link("Career Services", byXPath("//cns-panel-bar/ul[1]/li[4]/span"));
		Link CareerServices = new Link("Click on Career Services", byXPath("//cns-panel-bar/ul/li[4]/a/span"));
		Link PlacementsInternships = new Link("Placements&Internships", byXPath("//span[text()='Placements & Internships']"));
		Link InFieldofStudy = new Link("Field od Study'", byXPath("//div[5]/cmc-drop-down-list[3]/div/div/span/span/span/span"));
		Link HowPlaced = new Link("HowPlaced Value'", byXPath("//cmc-drop-down-list[4]/div/div/span/span/span/span"));
		Link SalaryStatus = new Link("Salary Status'", byXPath("(//button[@aria-label='expand combobox'])[15]"));
		Link SalaryType = new Link("Salary Type'", byXPath("(//button[@aria-label='expand combobox'])[16]"));
		//Link SelJobType = new Link(data.get("JobType Name"), byXPath("//span[. ='"+data.get("JobType Name")+"']"));
		Link SeljobTitle_input = new Link("jobTitle_input", byXPath("//ul[@id='jobTitle_listbox']/li[1]/div/span[1]"));
		Link SelInFieldofStudy = new Link("InFieldofStudy", byXPath("//ul[@id='inFieldOfStudy_listbox']/li[1]/div/span[1]"));
		Link SelHowPlaced = new Link("HowPlaced", byXPath("//ul[@id='howPlaced_listbox']/li[1]/div/span[1]"));
		Link SelSalaryStatus = new Link("SalaryStatus", byXPath("(//ul[@id='salaryOption_listbox']/li[1]/span/div/span)[1]"));
		Link SelSalaryType = new Link("SalaryType", byXPath("(//ul[@id='salaryType_listbox']/li[1]/span/div/span)[1]"));
		Link SelPlacementStatus = new Link("Job Status", byXPath("//ul[@id='placementStatus_listbox']/li[1]/div/span[1]"));
		Link StudentIntershipSaveMessage = new Link("SaveMessage", byXPath("//span[. = 'The Placement records were successfully saved.']"));		
		TextField VerificationAgent = new TextField("Verification Agent", byXPath("//input[@id='plVerificationAgent']"));
		TextField VerificationAgentTitle = new TextField("Verification Agent Title", byXPath("//input[@id='plVerificationAgentTitle']"));
		TextField VerificationDate = new TextField("Verification Date", byXPath("//input[@id='plVerificationDate']"));
		TextField VerificationPhoneNum = new TextField("Verification PhoneNumber", byXPath("//input[@id='plVerificationPhone']"));
		Button VerificationRep = new Button("Verification Representative", byXPath("//span[@aria-controls='plVerificationRep_listbox']"));
		Link VerificationRepValue = new Link("Verification Representative Value", byXPath("//div/ul[@id='plVerificationRep_listbox']/li[1]"));
		int VerificationPhoneNumValue = AppendValue.apendNumber();
		Button Reload = new Button("Reload", byXPath("//a[@id='cnsGridPlacement_cnsToolbar_kendoToolBar_reloadButton']"));
		Button SaveAndClose = new Button("Save and Close", byXPath("(//button[@aria-label='Save & Close'])[2]"));
		Link JobStatus = new Link("JobStatus'", byXPath("(//div[5]/cmc-drop-down-list/div/div/span/span/span[2]/span)[1]"));
		Link SelJobStatus = new Link("SelJobStatusy", byXPath("(//ul[@id='jobStatus_listbox']/li/div/span)[1]"));
		Link SelectExtJobType = new Link("Ext Job Type", byXPath("//span[text()='"+data.get("JobType Name")+"']"));
		Dropbox JobTypeDropdown = new Dropbox("Job Type Dropdown", byXPath("(//button[@aria-label='expand combobox'])[2]"));
		Button New = new Button("New", byXPath("//button[@id='studentPlacementNewButton']"));
		Link Employer = new Link("Select Employer", byXPath("//*[@id='search_display_employerSearch']"));
		Button Select = new Button("Select Button", byXPath("//button[text()='Select']"));
		Link jobTitle_input = new Link("jobTitle_input'", byXPath("//div/div/div[2]/div/div[2]/cmc-drop-down-list/div/div/span/span/span/span"));
		TextField SalAmount = new TextField("Enter Salary Amount'", byXPath("(//input[@aria-label='Salary Amount'])[1]"));
		
	//Method Implementation
		wait(10);
		CareerServices.waitTillElementClickable();
	    CareerServices.click();
		wait(3);
		PlacementsInternships.click();
		wait(10);
		New.click();
		waitForPageToLoad();
		scrollPage(0, 500);
        Employer.click();
		wait(6);
		EmployerButton.click();
		wait(5);
		Select.click();
		wait(8);
		//JobType.clearAndType(data.get("JobType Name").toString());
		//wait(4);
		//SelJobType.clickUsingJavaScriptExecutor();
		//wait(4);
		JobTypeDropdown.click();
		wait(4);
		SelectExtJobType.click();
		wait(4);
		//jobTitle_input.click();
		wait(4);
		//SeljobTitle_input.click();
		wait(4);
		//String SelectjobTitle = SeljobTitle_input.getAttribute("title");
	    //TestReportsLog.log(LogStatus.INFO, "jobTitle_input Name is selected as "+SelectjobTitle);
		wait(4);
		scrollPage(0, 420);
		wait(4);
		SalAmount.sendKeys("100");
		wait(4);
		/*JobStatus.click();
		wait(4);
		SelJobStatus.click();
		wait(4);*/
		//InFieldofStudy.click();
		wait(4);
		//SelInFieldofStudy.click();
		wait(4);
		//String SelInFieldStudy = SelInFieldofStudy.getAttribute("title");
	    //TestReportsLog.log(LogStatus.INFO, "InField of StudyName is selected as "+SelInFieldStudy);
		wait(4);
		//HowPlaced.click();
		wait(4);
		//SelHowPlaced.click();
		//String SelPlaced = SelHowPlaced.getAttribute("title");
	    //TestReportsLog.log(LogStatus.INFO, "HowPlaced Name is selected as "+SelPlaced);
		wait(4);
		SalaryStatus.click();
		wait(4);
		SelSalaryStatus.click();
		String SelSalarySts = SelSalaryStatus.getAttribute("title");
	    TestReportsLog.log(LogStatus.INFO, "Salary Status Name is selected as "+SelSalarySts);
		wait(4);
		SalaryType.click();
		wait(4);
		SelSalaryType.click();
		String SelSalType = SelSalaryType.getAttribute("title");
	    TestReportsLog.log(LogStatus.INFO, "Salary Type Name is selected as "+SelSalType);
		wait(2);
		DatePlaced.clearAndType(Date);
		wait(2);
		StartDate.clearAndType(Date);		
//		VerificationAgent.click();
//		wait(2);
//		VerificationAgent.clearAndType(VerificationAgentValue.toString());
//		wait(2);
//		VerificationAgentTitle.click();
//		wait(2);
//		VerificationAgentTitle.clearAndType("Mr");
//		wait(2);
//		VerificationDate.clearAndType(currentDate);
//		wait(2);
//		VerificationPhoneNum.sendKeys(String.valueOf(VerificationPhoneNumValue));
//		wait(2);
//		VerificationRep.click();
//		wait(2);
//		VerificationRepValue.click();		
		wait(5);
		scrollPage(0, -700);
		wait(2);
		SaveAndClose.clickUsingJavaScriptExecutor();
		wait(10);
		CustomAsserts.containsString(StudentIntershipSaveMessage.getText(), data.get("SuccessMessage").toString());
		wait(2);
		return this;
    }
}

	
