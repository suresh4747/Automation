package com.StudentPortal.StudentTests;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.StudentPortal.Businessflow.StudentFlows;
import com.StudentPortal.Businessflow.StudentLoginFlow;
import com.StudentPortal.Businessflow.StudentLoginTest1Flow;
import com.StudentPortal.Businessflow.StudentTestFlow;
import com.framework.base.constants.FrameworkConstants;
import com.framework.core.AutomationTestPlan;
import com.framework.util.DataUtil;
import com.framework.util.StringHash;
import com.framework.util.TestCaseFields;
import com.framework.util.Xls_Reader;

public class DCRC_Demo extends AutomationTestPlan {
	
	public DCRC_Demo() {
		xls = new Xls_Reader(FrameworkConstants.PS_DATA_XLS_PATH);
	}
	
// Test 1
	@Test(enabled = true, dataProvider = "getData", priority = 2, alwaysRun = true, description = "Test Script to add FA document", testName = "TC216_FA Documents to Individual Students")
	@TestCaseFields(testCaseName = "TC216_FA Documents to Individual Students")
	public void TC216_FADocumentsToIndividualStudents(StringHash data) throws Exception {

		StudentTestFlow.FADocument(data);
	}

//Test 2
	@Test(enabled = true, dataProvider = "getData", priority = 1,alwaysRun = true, description ="Test Script to add FA document List", testName = "TC216_FA Document List to Individual Students")
	@TestCaseFields(testCaseName = "TC216_FA Document List to Individual Students")
	public void TC216_FADocumentListToIndividualStudents(StringHash data) throws Exception {

		StudentTestFlow.FADocumentList(data);
	}	

//Test 3
	@Test(enabled = true, dataProvider = "getData", priority = 3, alwaysRun = true, description = "Test Script to add tasks to a student", testName = "Add tasks to a student")
	@TestCaseFields(testCaseName = "Add tasks to a student")
	public void TC879_Addtaskstoastudent(StringHash data) throws Exception {

		StudentFlows.AddTasksToAStudent(data);
	}

//Test 4
	@Test(enabled = true, dataProvider = "getData", priority = 7, alwaysRun = true, description = "Test Script to TC66_AddDegreestoaStudent", testName = "TC66_AddDegreestoaStudent")
	@TestCaseFields(testCaseName = "TC66_AddDegreestoaStudent")
	public void TC903_AddDegreestoaStudent(StringHash data) throws Exception {

		StudentLoginFlow.AddDegreeToStudent(data);

	}

//Test 5
	@Test(enabled = true, dataProvider = "getData", priority = 4, alwaysRun = true, description = "Test Script to place students into job", testName = "TC163_Use the Placement wizard to place students into a job")
	@TestCaseFields(testCaseName = "TC163_Use the Placement wizard to place students into a job")
	public void TC163_PlaceStudentsIntoJob(StringHash data) throws Exception {

		StudentTestFlow.PlacementsIntoJob(data);
	}

//Test 6 ---Configure Document Schedules
	@Test(enabled = true, dataProvider = "getData", priority = 5,alwaysRun = true, description ="Configure Document Schedules", testName = "Configure Document Schedules")
	@TestCaseFields(testCaseName = "Configure Document Schedules")
	public void TC1739_2ConfigureDocumentSchedules(StringHash data) throws Exception {
		StudentLoginTest1Flow.DocumentScheduleCreation(data);

	}
	
//Test 7 ---School Fields - Confirm new information can be added to field for Student Accounts
	@Test(enabled = true, dataProvider = "getData", priority = 6,alwaysRun = true, description ="School Fields - Confirm new information can be added to field for Student Accounts", testName = "School Fields - Confirm new information can be added to field for Student Accounts")
	@TestCaseFields(testCaseName = "School Fields - Confirm new information can be added to field for Student Accounts")
	public void TC1747_SchooldefinedFieldStdAcct(StringHash data) throws Exception {
		StudentLoginTest1Flow.SchoolDefinedFiledStudentAccounts(data);
	}

	
//Test 8
	@Test(enabled = true, dataProvider = "getData", priority = 8,alwaysRun = true, description ="Test Script to add SMS Service Provider", testName = "Add SMS Service providers under configuration")
	@TestCaseFields(testCaseName = "Add SMS Service providers under configuration")
	public void TC875_AddSMSServiceprovidersunderconfiguration(StringHash data) throws Exception {

		StudentFlows.AddSMSServiceProvider(data);
	}
	
	
//Test 9
	@Test(enabled = true, dataProvider = "getData", priority = 9,alwaysRun = true, description ="Test Script to Add new employers", testName = "Validate the ability to add new employers")
	@TestCaseFields(testCaseName = "Validate the ability to add new employers")
	public void TC894_Validatetheabilitytoaddnewemployers(StringHash data) throws Exception {

		StudentFlows.AddNewEmployers(data);
	}
				
//Test 10
	@Test(enabled = true, dataProvider = "getData", priority = 10,alwaysRun = true, description ="Test Script to place students in Externship position", testName = "Place students into an externship Position")
	@TestCaseFields(testCaseName = "Place students into an externship Position")
	public void TC893_PlacestudentsintoanexternshipPosition(StringHash data) throws Exception {

		StudentFlows.PlaceStudentsIntoExternshipPosition(data);
	}
	
	
//Test 11 - Add an enrollment for a student

	@Test(enabled = true, dataProvider = "getData", priority = 61,alwaysRun = true, description ="Test Script to Add an enrollment for a student", testName = "TC61_Addanenrollmentforastudent")
	@TestCaseFields(testCaseName = "TC61_Addanenrollmentforastudent")
	public void TC898_Addanenrollmenttoastudent(StringHash data) throws Exception {

		StudentLoginFlow.StudentEnrollment(data);
																					
	}
	
    @DataProvider
	public Object[][] getData(Method method) {

	return DataUtil.getData(xls, method.getAnnotation(TestCaseFields.class).testCaseName());
	
	}
}
