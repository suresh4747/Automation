package com.StudentPortal.StudentTests;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.StudentPortal.Businessflow.StudentFlows;
import com.StudentPortal.Businessflow.StudentLoginFlow;
import com.StudentPortal.Businessflow.StudentLoginTest1Flow;
import com.StudentPortal.Businessflow.StudentTestFlow;
import com.StudentPortal.Pages.APIAutomationPage;
import com.framework.base.constants.FrameworkConstants;
import com.framework.core.AutomationTestPlan;
import com.framework.core.AutomationTestPlanThree;
import com.framework.util.DataUtil;
import com.framework.util.StringHash;
import com.framework.util.TestCaseFields;
import com.framework.util.Xls_Reader;

public class DCRC_Demo_API extends AutomationTestPlanThree {
	
	public DCRC_Demo_API() {
		xls = new Xls_Reader(FrameworkConstants.PS_DATA_XLS_PATH_API);
	}  

	//Test 1
			@Test(enabled = true, dataProvider = "getData", priority = 1,alwaysRun = true, description ="Test Script to add tasks to student", testName = "Add tasks to a student")
			@TestCaseFields(testCaseName = "Add tasks to a student")
			public void TC879_Addtaskstoastudent(StringHash data) throws Exception {
				APIAutomationPage APage = new APIAutomationPage();
				APage.AddTasksToAStudent_API(data);
			  }
			
	//Test 2
			@Test(enabled = true, dataProvider = "getData", priority = 13,alwaysRun = true, description ="Test Script to Add new employers", testName = "Validate the ability to add new employers")
			@TestCaseFields(testCaseName = "Validate the ability to add new employers")
			public void TC894_Validatetheabilitytoaddnewemployers(StringHash data) throws Exception {

				APIAutomationPage APage = new APIAutomationPage();
			    APage.AddNewEmployers_API(data);
			  }
					
	//Test 3
			@Test(enabled = true, dataProvider = "getData", priority = 14,alwaysRun = true, description ="Test Script to place students in Externship position", testName = "Place students into an externship Position")
			@TestCaseFields(testCaseName = "Place students into an externship Position")
			public void TC893_PlacestudentsintoanexternshipPosition(StringHash data) throws Exception {

				APIAutomationPage APage = new APIAutomationPage();
			    APage.PlaceStudentsIntoExternship_API(data);
			  }
			
	//Test 4 - Add Degrees to a Student

			@Test(enabled = true, dataProvider = "getData", priority = 10,alwaysRun = true, description ="Test Script to Add Degrees to a Student", testName = "AddDegreestoaStudent")
			@TestCaseFields(testCaseName = "AddDegreestoaStudent")
			public void AddDegreestoaStudent(StringHash data) throws Exception {

				APIAutomationPage DPpage = new APIAutomationPage();
				DPpage.AddDegreestoaStudent(data);
																	
			  }
	   
	//Test 5 - Add Honors to a Student

			@Test(enabled = true, dataProvider = "getData", priority = 11,alwaysRun = true, description ="Test Script to Add Honors to a Student", testName = "AddHonorstoaStudent")
			@TestCaseFields(testCaseName = "AddHonorstoaStudent")
			public void AddHonorstoaStudent(StringHash data) throws Exception {

				APIAutomationPage DPpage = new APIAutomationPage();
				DPpage.AddHonorstoaStudent(data);
																	
			  }  
	     
	//Test 6
			@Test(enabled = true, dataProvider = "getData", priority = 1,alwaysRun = true, description ="Student Application Creation", testName = "TC831_Student Application Creation")
			@TestCaseFields(testCaseName = "TC831_Student Application Creation")
			public void TC831_StudentApplicationCreation(StringHash data) throws Exception {
				APIAutomationPage Spage = new APIAutomationPage();
				Spage.StudentApplicationCreation(data);
			  }   
			
	//Test 7
			@Test(enabled = true, dataProvider = "getData", priority = 1,alwaysRun = true, description ="Enter Transfer Credits", testName = "TC835_Enter Transfer Credits")
			@TestCaseFields(testCaseName = "TC835_Enter Transfer Credits")
			public void TC835_TransferCredits(StringHash data) throws Exception {
				APIAutomationPage Spage = new APIAutomationPage();
				Spage.TransferCredits(data);
			  }
			
	//Test 8
			@Test(enabled = true, dataProvider = "getData", priority = 1,alwaysRun = true, description ="LedgerCardPostaCharge", testName = "LedgerCardPostaCharge")
			@TestCaseFields(testCaseName = "LedgerCardPostaCharge")
			public void TC938_1_LedgerCardPostaCharge(StringHash data) throws Exception {
				APIAutomationPage Spage = new APIAutomationPage();
				Spage.LedgerPostCharge(data);
			 }
	   
	//Test 9	
			@Test(enabled = true, dataProvider = "getData", priority = 1,alwaysRun = true, description ="AddLettertoEmp", testName = "AddLettertoEmp")
			@TestCaseFields(testCaseName = "AddLettertoEmp")
			public void TC943_1_AddLettertoEmp(StringHash data) throws Exception {
				APIAutomationPage Spage = new APIAutomationPage();
				Spage.AddLettertoEmp(data);
			 }
			
	//Test 10 - Subsidiary Ledger - Post a Charge.

			@Test(enabled = true, dataProvider = "getData", priority = 54,alwaysRun = true, description ="Test Script to SubsidiaryLedgerPostaCharge", testName = "SubsidiaryLedgerPostaCharge")
			@TestCaseFields(testCaseName = "SubsidiaryLedgerPostaCharge")
			public void SubsidiaryLedgerPostaCharge(StringHash data) throws Exception {

				APIAutomationPage BRpage = new APIAutomationPage();
				BRpage.SubsidiaryLedgerPostaCharge(data);

			}

								
    @DataProvider
	public Object[][] getData(Method method) {

	return DataUtil.getData(xls, method.getAnnotation(TestCaseFields.class).testCaseName());
	
	}
}
