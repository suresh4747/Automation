package com.StudentPortal.StudentTests;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.StudentPortal.Businessflow.StudentFlows;
import com.StudentPortal.Businessflow.StudentLoginFlow;
import com.StudentPortal.Businessflow.StudentLoginTest1Flow;
import com.StudentPortal.Businessflow.StudentTestFlow;
import com.StudentPortal.Pages.APIAutomationPage;
import com.framework.base.constants.FrameworkConstants;
import com.framework.core.AutomationTestPlan;
import com.framework.util.DataUtil;
import com.framework.util.StringHash;
import com.framework.util.TestCaseFields;
import com.framework.util.Xls_Reader;

public class DCRC_Demo_UI extends AutomationTestPlan {
	
	public DCRC_Demo_UI() {
		xls = new Xls_Reader(FrameworkConstants.PS_DATA_XLS_PATH);
	}  

	//Test 1 - Add an enrollment for a student

		@Test(enabled = true, dataProvider = "getData", priority = 61,alwaysRun = true, description ="Test Script to Add an enrollment for a student", testName = "TC61_Addanenrollmentforastudent")
		@TestCaseFields(testCaseName = "TC61_Addanenrollmentforastudent")
		public void TC898_Addanenrollmenttoastudent(StringHash data) throws Exception {

				StudentLoginFlow.StudentEnrollment(data);
																				
		}
								
    @DataProvider
	public Object[][] getData(Method method) {

	return DataUtil.getData(xls, method.getAnnotation(TestCaseFields.class).testCaseName());
	
	}
}
