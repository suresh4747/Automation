package com.StudentPortal.StudentTests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.lang.reflect.Method;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.StudentPortal.Businessflow.StudentFlows;
import com.StudentPortal.Businessflow.StudentTestFlow;
import com.StudentPortal.Pages.StudentProgramGroupCreation;
import com.StudentPortal.Pages.StudentProgramPage;
import com.framework.base.constants.FrameworkConstants;
import com.framework.core.AutomationTestPlan;
import com.framework.util.DataUtil;
import com.framework.util.StringHash;
import com.framework.util.TestCaseFields;
import com.framework.util.Xls_Reader;

public class StudentTestExecution_1 extends AutomationTestPlan {
	
	public StudentTestExecution_1() {
		xls = new Xls_Reader(FrameworkConstants.PS_DATA_XLS_PATH);
	}
	
	//Test 1
		@Test(enabled = true, dataProvider = "getData", priority = 6,alwaysRun = true, description ="Test Script to Verify Student Application Creation", testName = "TC831_Student Application Creation")
		@TestCaseFields(testCaseName = "TC831_Student Application Creation")
		public void TC831_StudentApplicationCreation(StringHash data) throws Exception {

			StudentTestFlow.StudentApplicationFlow(data);
		} 
		
//Test 2
		@Test(enabled = true, dataProvider = "getData", priority = 4,alwaysRun = true, description ="Test Script to Enroll a student", testName = "TC248_Place Graduate Student into Internship")
		@TestCaseFields(testCaseName = "TC248_Place Graduate Student into Internship")
		public void TC248_PlaceGraduateStudentIntoInternship(StringHash data) throws Exception {

			StudentTestFlow.GraduateInternship(data);
		}

//Test 3
		@Test(enabled = true, dataProvider = "getData", priority = 5,alwaysRun = true, description ="Test Script to Enroll a student", testName = "TC267_Place Graduate Student into Externship")
		@TestCaseFields(testCaseName = "TC267_Place Graduate Student into Externship")
		public void TC267_PlaceGraduateStudentIntoExternship(StringHash data) throws Exception {

			StudentTestFlow.GraduateExternship(data);
		}
		
//Test 4
		@Test(enabled = true, dataProvider = "getData", priority = 3,alwaysRun = true, description ="Test Script to place students into job", testName = "TC163_Use the Placement wizard to place students into a job")
		@TestCaseFields(testCaseName = "TC163_Use the Placement wizard to place students into a job")
		public void TC163_PlaceStudentsIntoJob(StringHash data) throws Exception {

			StudentTestFlow.PlacementsIntoJob(data);
		}
		
//Test 5
		@Test(enabled = true, dataProvider = "getData", priority = 13,alwaysRun = true, description ="Test Script to post a charge", testName = "TC845_Post a Charge to Student Ledger card")
		@TestCaseFields(testCaseName = "TC845_Post a Charge to Student Ledger card")
		public void TC845_Post_Charge(StringHash data) throws Exception {

			StudentTestFlow.PostChargeforStudent(data);
		}
		
//Test 6
		@Test(enabled = true, dataProvider = "getData", priority = 24,alwaysRun = true, description ="Test Script to post a payment ", testName = "TC847_Post a Payment for a Student")
		@TestCaseFields(testCaseName = "TC847_Post a Payment for a Student")
		public void TC847_Post_LedgerPayment(StringHash data) throws Exception {

			StudentTestFlow.LedgerPayment(data);
		}
		
//Test 7
		@Test(enabled = true, dataProvider = "getData", priority = 38,alwaysRun = true, description ="Test Script to add Housing deposits", testName = "TC1780_Adding_Housing_Deposits")
		@TestCaseFields(testCaseName = "TC1780_Adding_Housing_Deposits")
		public void TC1780_Housing_Deposits(StringHash data) throws Exception {

			StudentTestFlow.HousingDepositsFlow(data);
		}
		
//Test 8
		@Test(enabled = true, dataProvider = "getData", priority = 14,alwaysRun = true, description ="Test Script to post a refund directly to Ledger Card", testName = "TC844_Post Refund(directly to Ledger Card)")
		@TestCaseFields(testCaseName = "TC844_Post Refund(directly to Ledger Card)")
		public void TC844_Post_Refund(StringHash data) throws Exception {

			StudentTestFlow.PostRefundforStudent(data);
		}


//Test 9
		@Test(enabled = true, dataProvider = "getData", priority = 15,alwaysRun = true, description ="Test Script to post enter transfer credits", testName = "TC835_Enter Transfer Credits")
		@TestCaseFields(testCaseName = "TC835_Enter Transfer Credits")
		public void TC835_Enter_Transfer_Credits(StringHash data) throws Exception {

		   				StudentTestFlow.TransferCredits(data);
		}
		
//Test 10
		@Test(enabled = true, dataProvider = "getData", priority = 17,alwaysRun = true, description ="Test Script to add FA document", testName = "TC216_FA Documents to Individual Students")
		@TestCaseFields(testCaseName = "TC216_FA Documents to Individual Students")
		public void TC216_FADocuments_To_Individual_Students(StringHash data) throws Exception {

			StudentTestFlow.FADocument(data);
		}

//Test 11
		@Test(enabled = true, dataProvider = "getData", priority = 18,alwaysRun = true, description ="Test Script to add FA document List", testName = "TC216_FA Document List to Individual Students")
		@TestCaseFields(testCaseName = "TC216_FA Document List to Individual Students")
		public void TC216_FADocumentList_To_Individual_Students(StringHash data) throws Exception {

			StudentTestFlow.FADocumentList(data);
		}
		
//Test 12
		@Test(enabled = true, dataProvider = "getData", priority = 37,alwaysRun = true, description ="Test Script to change student status", testName = "TC240_Perform Status Changes")
		@TestCaseFields(testCaseName = "TC840_Perform Status Changes")
		public void TC840_Student_Status_Change(StringHash data) throws Exception {

			StudentTestFlow.PerformStatusChanges(data);
		}
		
//Test 13
		@Test(enabled = true, dataProvider = "getData", priority = 36,alwaysRun = true, description ="Test Script to perform Program Change", testName = "TC223_Perform a Program Change for a Student")
		@TestCaseFields(testCaseName = "TC223_Perform a Program Change for a Student")
		public void TC223_Perform_ProgramChange(StringHash data) throws Exception {

			StudentTestFlow.PerformProgramChange(data);
		}
		
		@DataProvider
			public Object[][] getData(Method method) {

				return DataUtil.getData(xls, method.getAnnotation(TestCaseFields.class).testCaseName());
			}
}
	