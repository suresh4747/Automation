package com.StudentPortal.StudentTests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.lang.reflect.Method;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.StudentPortal.Businessflow.StudentFlows;
import com.StudentPortal.Businessflow.StudentTestFlow;
import com.StudentPortal.Pages.StudentProgramGroupCreation;
import com.StudentPortal.Pages.StudentProgramPage;
import com.framework.base.constants.FrameworkConstants;
import com.framework.core.AutomationTestPlan;
import com.framework.util.DataUtil;
import com.framework.util.StringHash;
import com.framework.util.TestCaseFields;
import com.framework.util.Xls_Reader;

public class StudentTestExecution_3 extends AutomationTestPlan {
	
	public StudentTestExecution_3() {
		xls = new Xls_Reader(FrameworkConstants.PS_DATA_XLS_PATH);
	}
//Test 27
		@Test(enabled = true, dataProvider = "getData", priority = 16,alwaysRun = true, description ="Creation of fund source", testName = "Create Fund Source")
		@TestCaseFields(testCaseName = "Create Fund Source")
		public void Create_Fund_Source(StringHash data) throws Exception {
			
			StudentTestFlow.FundSourceCreation(data);	
		}
		
//Test 28
		@Test(enabled = true, dataProvider = "getData", priority = 11,alwaysRun = true, description ="Test Script to print Awards Summary", testName = "TC209_Summary document can be printed for individual students")
		@TestCaseFields(testCaseName = "TC209_Summary document can be printed for individual students")
		public void TC209_Print_AwardSummary(StringHash data) throws Exception {

			StudentTestFlow.PrintAwardSummary(data);
		}
		
//Test 29
		@Test(enabled = true, dataProvider = "getData", priority = 25,alwaysRun = true, description ="Test Script to post an FA Disburdement", testName = "TC848_Post an FA Disbursement for a Student")
		@TestCaseFields(testCaseName = "TC848_Post an FA Disbursement for a Student")
		public void TC848_Post_FADisbursement(StringHash data) throws Exception {

			StudentTestFlow.LedgerFADisbursement(data);
		}
	
//Test 30
		@Test(enabled = true, dataProvider = "getData", priority = 26,alwaysRun = true, description ="Test Script to verify the disbursement data", testName = "TC848_1_Verify Disbursement Data")
		@TestCaseFields(testCaseName = "TC848_1_Verify Disbursement Data")
		public void TC848_1_Verify_DisbursementData(StringHash data) throws Exception {

			StudentTestFlow.VerifyDisbursementData(data);
		}
//Test 31
		@Test(enabled = true, dataProvider = "getData", priority = 20,alwaysRun = true, description ="Test Script to schedule a stipend ", testName = "TC846_Schedule a Stipend for a student")
		@TestCaseFields(testCaseName = "TC846_Schedule a Stipend for a student")
		public void TC846_Schedule_Stipend(StringHash data) throws Exception {

			StudentTestFlow.StipedSchedule(data);
		}
//Test 32
		@Test(enabled = true, dataProvider = "getData", priority = 35,alwaysRun = true, description ="Test Script to reassign FA to other Academic year", testName = "TC194_Reassignment of FA to Other Academic year")
		@TestCaseFields(testCaseName = "TC194_Reassignment of FA to Other Academic year")
		public void TC194_Reassignment_FA_To_OtherAY(StringHash data) throws Exception {

			StudentTestFlow.FAReassignment(data);
		} 
		
//Test 33
		@Test(enabled = true, dataProvider = "getData", priority = 39,alwaysRun = true, description ="Test Script to create a student group ", testName = "TC1924_1_Process_Test_Student_Groups")
		@TestCaseFields(testCaseName = "TC1924_1_Process_Test_Student_Groups")
		public void TC1924_1_ProcessTest_StudentGroups(StringHash data) throws Exception {

			StudentTestFlow.StudentGroupCreation(data);
		}
		
//Test 34
		@Test(enabled = true, dataProvider = "getData", priority = 40,alwaysRun = true, description ="Test Script to update school fields ", testName = "TC1924_2_Update_School_Fields")
		@TestCaseFields(testCaseName = "TC1924_2_Update_School_Fields")
		public void TC1924_2_Update_School_Fields(StringHash data) throws Exception {

			StudentTestFlow.UpdateSchoolFieldsFlow(data);
		}

//Test 35
		@Test(enabled = true, dataProvider = "getData", priority = 21,alwaysRun = true, description ="Test Script to create a student group ", testName = "TC234_1_Verify Registration Locks_Create a Student Group")
		@TestCaseFields(testCaseName = "TC234_1_Verify Registration Locks_Create a Student Group")
		public void TC234_1_Create_Student_Group(StringHash data) throws Exception {

			StudentTestFlow.StudentGroupCreation(data);
		}

//Test 36
		@Test(enabled = true, dataProvider = "getData", priority = 22,alwaysRun = true, description ="Test Script to add Student to a Group ", testName = "TC234_2_Add Student to a Group")
		@TestCaseFields(testCaseName = "TC234_2_Add Student to a Group")
		public void TC234_2_Add_Student_To_Group(StringHash data) throws Exception {

			StudentTestFlow.AddStudentToStudentGroup(data);
		}

//Test 37
		@Test(enabled = true, dataProvider = "getData", priority = 23,alwaysRun = true, description ="Test Script to create Registration locks ", testName = "TC234_3_Create Registration locks for a Student Group")
		@TestCaseFields(testCaseName = "TC234_3_Create Registration locks for a Student Group")
		public void TC234_3_Create_Registration_Locks(StringHash data) throws Exception {

			StudentTestFlow.RegistrationLocksCreation(data);
		}

//Test 38
		@Test(enabled = true, dataProvider = "getData", priority = 29,alwaysRun = true, description ="Test Script to verify minimum limit", testName = "TC234_5_Verify Minimum Limit Registration Lock")
		@TestCaseFields(testCaseName = "TC234_5_Verify Minimum Limit Registration Lock")
		public void TC234_5_Verify_MinimumLimit_RegistrationLock(StringHash data) throws Exception {

			StudentTestFlow.VerifyMinimumRegistrationLimit(data);
		}

//Test 39
		@Test(enabled = true, dataProvider = "getData", priority = 30,alwaysRun = true, description ="Test Script to verify maximum limit", testName = "TC234_4_Verify Maximum Limit Registration Lock")
		@TestCaseFields(testCaseName = "TC234_4_Verify Maximum Limit Registration Lock")
		public void TC234_4_Verify_MaximumLimit_RegistrationLock(StringHash data) throws Exception {

			StudentTestFlow.VerifyMaximumRegistrationLimit(data);
		}

//Test 40
		@Test(enabled = true, dataProvider = "getData", priority = 31,alwaysRun = true, description ="Test Script to verify schedule limit", testName = "TC234_6_Verify Schedule Registration Lock")
		@TestCaseFields(testCaseName = "TC234_6_Verify Schedule Registration Lock")
		public void TC234_6_Verify_Schedule_RegistrationLock(StringHash data) throws Exception {

			StudentTestFlow.VerifyScheduleRegistrationLock(data);
		}
		
//Test 41
			@Test(enabled = true, dataProvider = "getData", priority = 23,alwaysRun = true, description ="Test Script to delete Student Group", testName = "Delete Student Group")
			@TestCaseFields(testCaseName = "Delete Student Group")
			public void Delete_Student_Group(StringHash data) throws Exception {

				StudentTestFlow.deleteStudentGroup(data);
			}
		
		@DataProvider
			public Object[][] getData(Method method) {

				return DataUtil.getData(xls, method.getAnnotation(TestCaseFields.class).testCaseName());
			}
}