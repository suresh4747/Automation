package com.StudentPortal.StudentTests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.lang.reflect.Method;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.StudentPortal.Businessflow.StudentFlows;
import com.StudentPortal.Businessflow.StudentTestFlow;
import com.StudentPortal.Pages.StudentProgramGroupCreation;
import com.StudentPortal.Pages.StudentProgramPage;
import com.framework.base.constants.FrameworkConstants;
import com.framework.core.AutomationTestPlan;
import com.framework.util.DataUtil;
import com.framework.util.StringHash;
import com.framework.util.TestCaseFields;
import com.framework.util.Xls_Reader;

public class StudentTestExecution_2 extends AutomationTestPlan {
	
	public StudentTestExecution_2() {
		xls = new Xls_Reader(FrameworkConstants.PS_DATA_XLS_PATH);
	}

	//Test 14
		@Test(enabled = true, dataProvider = "getData", priority = 27,alwaysRun = true, description ="Test Script to post attendance in a batch", testName = "TC839_Record batch attendance for a course")
		@TestCaseFields(testCaseName = "TC839_Record batch attendance for a course")
		public void TC839_Record_BatchAttendance(StringHash data) throws Exception {

			StudentTestFlow.RecordBatchAttendance(data);
		}

//Test 15
		@Test(enabled = true, dataProvider = "getData", priority = 28,alwaysRun = true, description ="Test Script to post final grades in a batch", testName = "TC837_Record batch Final Grades for a course")
		@TestCaseFields(testCaseName = "TC837_Record batch Final Grades for a course")
		public void TC837_Record_BatchFinalGrades(StringHash data) throws Exception {

			StudentTestFlow.RecordBatchFinalGrades(data);
		}
		
//Test 16
		@Test(enabled = true, dataProvider = "getData", priority = 16,alwaysRun = true, description ="Test Script to verify SAP calculation", testName = "TC841_Verify SAP")
		@TestCaseFields(testCaseName = "TC841_Verify SAP")
		public void TC841_SAP_Calculation(StringHash data) throws Exception {

			StudentTestFlow.VerifySAP(data);
		}
		
//Test 17
		@Test(enabled = true, dataProvider = "getData", priority = 19,alwaysRun = true, description ="Test Script to verufy Disbursement Approval Criteria ", testName = "TC843_Verify Disbursement Approval Criteria is configured accurately")
		@TestCaseFields(testCaseName = "TC843_Verify Disbursement Approval Criteria is configured accurately")
		public void TC843_Verify_Disbursement_Approval_Criteria(StringHash data) throws Exception {

			StudentTestFlow.ApproveDisbursementToPay(data);
		}	
		
//Test 18-- *Prerequisite script*
		@Test(enabled = true, dataProvider = "getData", priority = 34,alwaysRun = true, description ="Test Script to add Course To Student Schedule", testName = "Add Course To Student Schedule")
		@TestCaseFields(testCaseName = "Add Course To Student Schedule")
		public void Add_Course_To_Student_Schedule(StringHash data) throws Exception {

			StudentTestFlow.AddCourseToStudent(data);
		}
		

//Test 19
	   @Test(enabled = true, dataProvider = "getData", priority = 7,alwaysRun = true, description ="Test Script to register a course", testName = "TC833_Register a course to the enrolled student")
	   @TestCaseFields(testCaseName = "TC833_Register a course to the enrolled student")
	   public void TC833_RegisterCourse(StringHash data) throws Exception {

	   StudentTestFlow.RegisterCourseToStudent(data);
	   }

//Test 20
	   @Test(enabled = true, dataProvider = "getData", priority = 10,alwaysRun = true, description ="Test Script to drop a course", testName = "TC834_Drop a course from the student schedule")
	   @TestCaseFields(testCaseName = "TC834_Drop a course from the student schedule")
	   public void TC834_DropCourse(StringHash data) throws Exception {

	   StudentTestFlow.DropCourseFromStudentSchedule(data);
	   }
	   
//Test 21
		@Test(enabled = true, dataProvider = "getData", priority = 40,alwaysRun = true, description ="Test Script to reinstate course", testName = "Reinstate Course")
		@TestCaseFields(testCaseName = "Reinstate Course")
		public void Reinstate_Course(StringHash data) throws Exception {

			StudentTestFlow.ReinstateFlow(data);
		}

//Test 22
	   @Test(enabled = true, dataProvider = "getData", priority = 8,alwaysRun = true, description ="Test Script to post Individual Attendence for Students", testName = "TC838_Record individual attendance for students")
	   @TestCaseFields(testCaseName = "TC838_Record individual attendance for students")
	   public void TC838_Record_Individual_Attendance(StringHash data) throws Exception {

	   				StudentTestFlow.RecordIndividualAttendence(data);
	   			}

//Test 23
	   @Test(enabled = true, dataProvider = "getData", priority = 9,alwaysRun = true, description ="Test Script to post Individual Final Grades for Students", testName = "TC836_Record individual final grades for a student")
	   @TestCaseFields(testCaseName = "TC836_Record individual final grades for a student")
	   public void TC836_Record_Individual_FinalGrades(StringHash data) throws Exception {

	   				StudentTestFlow.RecordIndividualFinalGrades(data);
	   			}

//Test 24 -- CleanUp script
		@Test(enabled = true, dataProvider = "getData", priority = 33,alwaysRun = true, description ="Test Script to Delete Course from Student Courses", testName = "Delete Course from Student Courses")
		@TestCaseFields(testCaseName = "Delete Course from Student Courses")
		public void Delete_Course_From_StudentCourses(StringHash data) throws Exception {

			StudentTestFlow.DeleteCourse(data);
		}
		
//Test 25
	@Test(enabled = true, dataProvider = "getData", priority = 1,alwaysRun = true, description ="Test Script to add tasks to student", testName = "Contact Manager Task Creation")
	@TestCaseFields(testCaseName = "Contact Manager Task Creation")
	public void TC879_Addtaskstoastudent(StringHash data) throws Exception {

		StudentTestFlow.AddTasksToAStudent(data);
	}

//Test 26
		@Test(enabled = true, dataProvider = "getData", priority = 12,alwaysRun = true, description ="Test Script to close the task", testName = "TC203_Contact Manager Task Close")
		@TestCaseFields(testCaseName = "TC203_Contact Manager Task Close")
		public void TC203_Student_Task_Close(StringHash data) throws Exception {

			StudentTestFlow.CloseTaskContactManager(data);
		} 
		
		@DataProvider
			public Object[][] getData(Method method) {

				return DataUtil.getData(xls, method.getAnnotation(TestCaseFields.class).testCaseName());
			}
}