
package com.framework.browserfactory;

/**
 * FireFoxProfileMarker.
 */
public class FireFoxProfileMarker { }
