
package com.framework.browserfactory;

/**
 * Class to locate for web driver external resources like IEDriver.exe, ChromeDriver.exe.
 */
public class WebDriverExternalResources { }
