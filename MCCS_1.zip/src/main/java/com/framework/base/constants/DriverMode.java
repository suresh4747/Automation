package com.framework.base.constants;

public class DriverMode {
	public static String LOCAL = "local";
	public static String GRID = "grid";
	
	
}
