package com.framework.base.constants;

public class TestType {

    public static String WEB="web";
    public static String APP="app";
}
