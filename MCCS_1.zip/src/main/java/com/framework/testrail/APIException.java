
package com.framework.testrail;
 
public class APIException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8741296989226790553L;

	public APIException(String message)
	{
		super(message);
	}
}
