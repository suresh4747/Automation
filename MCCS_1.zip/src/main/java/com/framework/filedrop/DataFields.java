package com.framework.filedrop;

public class DataFields {

	private String message;

	public DataFields(String msg) {
		this.message = msg;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String msg) {
		this.message = msg;
	}
}
