

package com.framework.core;

import org.testng.xml.XmlSuite;

public class DefaultXmlSuite extends XmlSuite {

    private static final long serialVersionUID = -5443556778899088771L;

}
